<?php
/**
 * Page template.
 *
 * @package KMAE
 */

get_header();

$is_hub_menu        = false;
$is_listing_create  = false;
if ( have_posts() ) {
	while ( have_posts() ) {
		the_post();
		$content = (string) get_post_field( 'post_content', get_the_ID() );
		$slug    = (string) get_post_field( 'post_name', get_the_ID() );
		$is_hub_menu = has_shortcode( $content, 'kmae_hub_sell' )
			|| has_shortcode( $content, 'kmae_hub_buy' )
			|| has_shortcode( $content, 'kmae_hub_stats' )
			|| false !== strpos( $content, '[kmae_hub_sell' )
			|| false !== strpos( $content, '[kmae_hub_buy' )
			|| false !== strpos( $content, '[kmae_hub_stats' )
			|| in_array( $slug, array( 'eladni', 'venni', 'statisztikak' ), true );
		$is_listing_create = has_shortcode( $content, 'kmae_create_listing' )
			|| false !== strpos( $content, '[kmae_create_listing' )
			|| 'hirdetes-feladasa' === $slug;
		break;
	}
	rewind_posts();
}

$page_mod = '';
if ( $is_hub_menu ) {
	$page_mod = ' kmae-page--hub-menu';
} elseif ( $is_listing_create ) {
	$page_mod = ' kmae-page--listing-create';
}
?>

<section class="kmae-page<?php echo esc_attr( $page_mod ); ?>">
	<?php if ( $is_hub_menu ) : ?>
		<?php while ( have_posts() ) : the_post(); ?>
			<div class="kmae-hub-menu-shell" style="width:min(100%,1180px);max-width:1180px;margin:0 auto;box-sizing:border-box;">
				<?php the_content(); ?>
			</div>
		<?php endwhile; ?>
	<?php elseif ( $is_listing_create ) : ?>
		<?php while ( have_posts() ) : the_post(); ?>
			<?php the_content(); ?>
		<?php endwhile; ?>
	<?php else : ?>
		<div class="kmae-container">
			<?php while ( have_posts() ) : the_post(); ?>
				<article <?php post_class( 'kmae-page__article' ); ?>>
					<h1 class="kmae-page__title"><?php the_title(); ?></h1>
					<div class="kmae-page__content">
						<?php the_content(); ?>
					</div>
				</article>
			<?php endwhile; ?>
		</div>
	<?php endif; ?>
</section>

<?php
get_footer();
