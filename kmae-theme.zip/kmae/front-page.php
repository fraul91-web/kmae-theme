<?php
/**
 * Front page — marketing landing (guest) or app home (logged-in).
 *
 * PC + phone landscape: 16:9 landscape hero.
 * Phone portrait: álló hero + adapted layout.
 *
 * @package KMAE
 */

get_header();

if ( is_user_logged_in() ) {
	get_template_part( 'template-parts/app', 'home' );
	get_footer();
	return;
}

$hero_landscape = kmae_media_url( 'hero_landscape' );
$hero_portrait  = kmae_media_url( 'hero_portrait' );
$cta_src        = kmae_media_url( 'cta_landscape' );
$cta_portrait   = kmae_media_url( 'cta_portrait' );
$reg_url        = kmae_page_url( 'regisztracio' );
$browse_url     = kmae_page_url( 'hirdetesek' );
$how_url        = kmae_page_url( 'hogyan-mukodik' );
?>

<div class="kmae-landing">

	<section class="kmae-landing-hero" aria-labelledby="kmae-landing-hero-title">
		<div class="kmae-landing-hero__frame">
			<div class="kmae-landing-hero__media" aria-hidden="true">
				<picture>
					<source media="(max-width: 1024px) and (orientation: portrait)" srcset="<?php echo esc_url( $hero_portrait ); ?>" type="image/webp" />
					<img
						class="kmae-landing-hero__img"
						src="<?php echo esc_url( $hero_landscape ); ?>"
						alt=""
						width="1717"
						height="916"
						decoding="async"
						fetchpriority="high"
					/>
				</picture>
				<div class="kmae-landing-hero__veil"></div>
			</div>

			<div class="kmae-landing-hero__copy">
				<p class="kmae-landing-hero__eyebrow"><?php esc_html_e( 'Új generációs autóadásvétel', 'kmae' ); ?></p>
				<h1 id="kmae-landing-hero-title" class="kmae-landing-hero__title">
					<span class="kmae-landing-hero__title-line"><?php esc_html_e( 'Autóvásárlás', 'kmae' ); ?></span>
					<span class="kmae-landing-hero__title-accent"><?php esc_html_e( 'új szinten.', 'kmae' ); ?></span>
				</h1>
				<p class="kmae-landing-hero__lead">
					<?php esc_html_e( 'Az Albira összeköti az eladókat és a vevőket', 'kmae' ); ?><br>
					<?php esc_html_e( 'egy teljesen új élményért – gyorsabban,', 'kmae' ); ?><br>
					<?php esc_html_e( 'biztonságosabban, egyszerűbben.', 'kmae' ); ?>
				</p>
				<div class="kmae-landing-hero__actions">
					<a class="kmae-landing-btn kmae-landing-btn--browse" href="<?php echo esc_url( $browse_url ); ?>">
						<?php esc_html_e( 'Autók böngészése', 'kmae' ); ?>
					</a>
					<a class="kmae-landing-btn kmae-landing-btn--ghost" href="<?php echo esc_url( $how_url ); ?>">
						<span class="kmae-landing-btn__play" aria-hidden="true"></span>
						<?php esc_html_e( 'Nézd meg, hogyan működik', 'kmae' ); ?>
					</a>
				</div>
			</div>

			<ul class="kmae-landing-benefits" id="elonyok" aria-label="<?php echo esc_attr__( 'Előnyök', 'kmae' ); ?>">
				<li class="kmae-landing-benefits__item">
					<span class="kmae-landing-benefits__icon" aria-hidden="true">
						<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 3 5 6v5c0 5 3.2 8.4 7 9.5 3.8-1.1 7-4.5 7-9.5V6l-7-3z"/><path d="m9 12 2 2 4-4"/></svg>
					</span>
					<div class="kmae-landing-benefits__text">
						<strong><?php esc_html_e( 'Megbízható és biztonságos', 'kmae' ); ?></strong>
						<p><?php esc_html_e( 'Ellenőrzött eladók és valós hirdetések.', 'kmae' ); ?></p>
					</div>
				</li>
				<li class="kmae-landing-benefits__item">
					<span class="kmae-landing-benefits__icon" aria-hidden="true">
						<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M13 2 4 14h7l-1 8 10-14h-7l0-6z"/></svg>
					</span>
					<div class="kmae-landing-benefits__text">
						<strong><?php esc_html_e( 'Gyors és hatékony', 'kmae' ); ?></strong>
						<p><?php esc_html_e( 'Spórolj időt okos szűrőkkel és automatikus megoldásokkal.', 'kmae' ); ?></p>
					</div>
				</li>
				<li class="kmae-landing-benefits__item">
					<span class="kmae-landing-benefits__icon" aria-hidden="true">
						<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 2 4.5 6v5.5c0 4.8 3.1 8.1 7.5 9.5 4.4-1.4 7.5-4.7 7.5-9.5V6L12 2z"/><path d="M12 8v5"/><circle cx="12" cy="16" r="0.9" fill="currentColor" stroke="none"/></svg>
					</span>
					<div class="kmae-landing-benefits__text">
						<strong><?php esc_html_e( 'Költséghatékony', 'kmae' ); ?></strong>
						<p><?php esc_html_e( 'Nincsenek rejtett díjak, csak egy tisztességes rendszer.', 'kmae' ); ?></p>
					</div>
				</li>
				<li class="kmae-landing-benefits__item">
					<span class="kmae-landing-benefits__icon" aria-hidden="true">
						<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M19 14c1.5-1.5 2-3.2 2-5a5 5 0 0 0-9-3 5 5 0 0 0-9 3c0 1.8.5 3.5 2 5l7 7 7-7z"/></svg>
					</span>
					<div class="kmae-landing-benefits__text">
						<strong><?php esc_html_e( 'Neked tervezve', 'kmae' ); ?></strong>
						<p><?php esc_html_e( 'Modern felület, ami minden eszközön tökéletes élményt nyújt.', 'kmae' ); ?></p>
					</div>
				</li>
			</ul>
		</div>
	</section>

	<section class="kmae-landing-devices" id="keszen" aria-labelledby="kmae-landing-devices-title">
		<div class="kmae-landing-wrap">
			<h2 id="kmae-landing-devices-title" class="kmae-landing-sr">
				<?php esc_html_e( 'Készen állsz a változásra?', 'kmae' ); ?>
			</h2>
			<figure class="kmae-landing-devices__art">
				<picture>
					<source
						media="(max-width: 1024px) and (orientation: portrait)"
						srcset="<?php echo esc_url( $cta_portrait ); ?>"
						type="image/webp"
					/>
					<img
						src="<?php echo esc_url( $cta_src ); ?>"
						alt="<?php echo esc_attr__( 'Készen állsz a változásra? Próbáld ki az Albira új szintű autóadásvételi élményét — megbízható, gyors, költséghatékony, neked tervezve.', 'kmae' ); ?>"
						width="1844"
						height="853"
						decoding="async"
						loading="lazy"
					/>
				</picture>
			</figure>
		</div>
	</section>

	<section class="kmae-landing-close" aria-label="<?php echo esc_attr__( 'Regisztráció', 'kmae' ); ?>">
		<div class="kmae-landing-wrap kmae-landing-close__inner">
			<a class="kmae-landing-btn kmae-landing-btn--primary" href="<?php echo esc_url( $reg_url ); ?>">
				<?php esc_html_e( 'Regisztrálj most', 'kmae' ); ?>
			</a>
		</div>
	</section>

</div>

<?php
get_footer();
