<?php
/**
 * Logged-in PC left sidebar — Főnavigáció (collapsible, full menu).
 *
 * @package KMAE
 */

if ( ! defined( 'ABSPATH' ) || ! is_user_logged_in() ) {
	return;
}

$path     = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '/';
$listings = 0;
$unseen   = 0;

if ( class_exists( 'KMAE_Seller' ) ) {
	$listings = (int) KMAE_Seller::count_active_cycle_listings( get_current_user_id() );
}
if ( class_exists( 'KMAE_Database' ) ) {
	$unseen = (int) KMAE_Database::count_unseen_offer_activity( get_current_user_id() );
}

$is = static function ( $slug ) use ( $path ) {
	return false !== strpos( $path, '/' . $slug );
};

$nav = array(
	array(
		'label'  => __( 'Keresés', 'kmae' ),
		'url'    => kmae_page_url( 'hirdetesek' ),
		'active' => $is( 'hirdetesek' ) && ! $is( 'sajat-hirdetesek' ),
		'icon'   => '🔍',
	),
	array(
		'label'       => __( 'Hirdetéseim', 'kmae' ),
		'url'         => kmae_page_url( 'sajat-hirdetesek' ),
		'active'      => $is( 'sajat-hirdetesek' ) || $is( 'hirdetes-feladasa' ),
		'icon'        => '📋',
		'badge'       => $listings > 0 ? (string) $listings : '',
		'badge_class' => 'green',
	),
	array(
		'label'  => __( 'Ajánlataim', 'kmae' ),
		'url'    => kmae_page_url( 'ajanlatok' ),
		'active' => $is( 'ajanlatok' ) || isset( $_GET['kmae_offer'] ),
		'icon'   => '🤝',
		'badge'  => $unseen > 0 ? (string) $unseen : '',
	),
	array(
		'label'  => __( 'Üzenetek', 'kmae' ),
		'url'    => kmae_page_url( 'uzenetek' ),
		'active' => $is( 'uzenetek' ),
		'icon'   => '💬',
		'badge'  => $unseen > 0 ? (string) $unseen : '',
	),
);

$account = array(
	array(
		'label'  => __( 'Profilom', 'kmae' ),
		'url'    => kmae_page_url( 'profil' ),
		'active' => $is( 'profil' ),
		'icon'   => '👤',
	),
	array(
		'label'  => __( 'Beállítások', 'kmae' ),
		'url'    => kmae_page_url( 'beallitasok' ),
		'active' => $is( 'beallitasok' ),
		'icon'   => '⚙️',
	),
);

$extra = array(
	array(
		'label'  => __( 'Szupertag', 'kmae' ),
		'url'    => kmae_page_url( 'profil' ),
		'active' => false,
		'icon'   => '⭐',
	),
	array(
		'label'  => __( 'Statisztikák', 'kmae' ),
		'url'    => kmae_page_url( 'sajat-hirdetesek' ),
		'active' => false,
		'icon'   => '📊',
	),
);

$render_item = static function ( $item ) {
	?>
	<a class="nav-item<?php echo ! empty( $item['active'] ) ? ' active' : ''; ?>" href="<?php echo esc_url( $item['url'] ); ?>">
		<div class="nav-icon" aria-hidden="true"><?php echo esc_html( $item['icon'] ); ?></div>
		<?php echo esc_html( $item['label'] ); ?>
		<?php if ( ! empty( $item['badge'] ) ) : ?>
			<span class="nav-badge<?php echo ! empty( $item['badge_class'] ) ? ' ' . esc_attr( $item['badge_class'] ) : ''; ?>"><?php echo esc_html( $item['badge'] ); ?></span>
		<?php endif; ?>
	</a>
	<?php
};
?>
<aside class="kmae-app-sidebar sidebar is-open" id="kmae-app-sidebar" aria-label="<?php echo esc_attr__( 'Főnavigáció', 'kmae' ); ?>">
	<button
		type="button"
		class="kmae-app-sidebar__toggle"
		id="kmae-sidebar-toggle"
		aria-expanded="true"
		aria-controls="kmae-sidebar-panel"
		aria-label="<?php echo esc_attr__( 'Főnavigáció', 'kmae' ); ?>"
		data-tip="<?php echo esc_attr__( 'Főnavigáció', 'kmae' ); ?>"
	>
		<span class="kmae-app-sidebar__toggle-icon" aria-hidden="true"></span>
	</button>

	<div class="kmae-app-sidebar__panel" id="kmae-sidebar-panel">
		<div class="sidebar-label"><?php esc_html_e( 'Navigáció', 'kmae' ); ?></div>
		<?php foreach ( $nav as $item ) { $render_item( $item ); } ?>

		<div class="sidebar-label"><?php esc_html_e( 'Fiók', 'kmae' ); ?></div>
		<?php foreach ( $account as $item ) { $render_item( $item ); } ?>

		<div class="sidebar-label"><?php esc_html_e( 'Egyéb', 'kmae' ); ?></div>
		<?php foreach ( $extra as $item ) { $render_item( $item ); } ?>
	</div>
</aside>
