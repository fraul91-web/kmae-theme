<?php
/**
 * Logged-in PC right sidebar — Információs menü (collapsible).
 *
 * @package KMAE
 */

if ( ! defined( 'ABSPATH' ) || ! is_user_logged_in() ) {
	return;
}

$path = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '/';

$is = static function ( $slug ) use ( $path ) {
	return false !== strpos( $path, '/' . $slug );
};

$info = array(
	array(
		'label'  => __( 'Rólunk', 'kmae' ),
		'url'    => kmae_page_url( 'rolunk' ),
		'active' => $is( 'rolunk' ),
		'icon'   => 'ℹ️',
	),
	array(
		'label'  => __( 'Hogyan működik?', 'kmae' ),
		'url'    => kmae_page_url( 'hogyan-mukodik' ),
		'active' => $is( 'hogyan-mukodik' ),
		'icon'   => '📖',
	),
	array(
		'label'  => __( 'Gyakori kérdések', 'kmae' ),
		'url'    => kmae_page_url( 'gyik' ),
		'active' => $is( 'gyik' ),
		'icon'   => '❓',
	),
	array(
		'label'  => __( 'Biztonság', 'kmae' ),
		'url'    => kmae_page_url( 'biztonsag' ),
		'active' => $is( 'biztonsag' ),
		'icon'   => '🛡️',
	),
	array(
		'label'  => __( 'Kapcsolat', 'kmae' ),
		'url'    => kmae_page_url( 'kapcsolat' ),
		'active' => $is( 'kapcsolat' ),
		'icon'   => '✉️',
	),
	array(
		'label'  => __( 'Felhasználási feltételek', 'kmae' ),
		'url'    => kmae_page_url( 'feltetelek' ),
		'active' => $is( 'feltetelek' ),
		'icon'   => '📄',
	),
	array(
		'label'  => __( 'Adatvédelem', 'kmae' ),
		'url'    => kmae_page_url( 'adatvedelem' ),
		'active' => $is( 'adatvedelem' ),
		'icon'   => '🔐',
	),
);
?>
<aside class="kmae-app-info sidebar" id="kmae-app-info" aria-label="<?php echo esc_attr__( 'Információs menü', 'kmae' ); ?>">
	<button
		type="button"
		class="kmae-app-info__toggle"
		id="kmae-info-toggle"
		aria-expanded="false"
		aria-controls="kmae-info-panel"
		aria-label="<?php echo esc_attr__( 'Információs menü', 'kmae' ); ?>"
		data-tip="<?php echo esc_attr__( 'Információs menü', 'kmae' ); ?>"
	>
		<span class="kmae-app-info__toggle-icon" aria-hidden="true"></span>
	</button>

	<div class="kmae-app-info__panel" id="kmae-info-panel" hidden>
		<div class="sidebar-label"><?php esc_html_e( 'Információ', 'kmae' ); ?></div>
		<?php foreach ( $info as $item ) : ?>
			<a class="nav-item<?php echo ! empty( $item['active'] ) ? ' active' : ''; ?>" href="<?php echo esc_url( $item['url'] ); ?>">
				<div class="nav-icon" aria-hidden="true"><?php echo esc_html( $item['icon'] ); ?></div>
				<?php echo esc_html( $item['label'] ); ?>
			</a>
		<?php endforeach; ?>
	</div>
</aside>
