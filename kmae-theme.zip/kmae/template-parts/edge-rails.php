<?php
/**
 * Logged-in edge drawers — left navigation (blue), right info (orange).
 * Desktop only; hidden under 1025px in favor of the hamburger sheet.
 *
 * @package KMAE
 */

if ( ! defined( 'ABSPATH' ) || ! is_user_logged_in() ) {
	return;
}

$groups = kmae_app_menu_groups();

$render = static function ( $item ) {
	?>
	<a
		class="kmae-edge__item<?php echo ! empty( $item['active'] ) ? ' is-active' : ''; ?>"
		href="<?php echo esc_url( $item['url'] ); ?>"
	>
		<span class="kmae-edge__icon" aria-hidden="true">
			<?php
			if ( class_exists( 'KMAE_Icons' ) ) {
				echo KMAE_Icons::render( $item['icon'], array( 'size' => 20 ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}
			?>
		</span>
		<span class="kmae-edge__label"><?php echo esc_html( $item['label'] ); ?></span>
		<?php if ( ! empty( $item['badge'] ) ) : ?>
			<span class="kmae-edge__badge<?php echo ! empty( $item['badge_class'] ) ? ' ' . esc_attr( $item['badge_class'] ) : ''; ?>"><?php echo esc_html( $item['badge'] ); ?></span>
		<?php endif; ?>
	</a>
	<?php
};
?>
<nav class="kmae-edge kmae-edge--left" id="kmae-edge-left" aria-label="<?php echo esc_attr__( 'Navigáció', 'kmae' ); ?>">
	<p class="kmae-edge__title"><?php esc_html_e( 'Navigáció', 'kmae' ); ?></p>
	<?php foreach ( $groups['nav'] as $item ) { $render( $item ); } ?>
</nav>

<nav class="kmae-edge kmae-edge--right" id="kmae-edge-right" aria-label="<?php echo esc_attr__( 'Információ', 'kmae' ); ?>">
	<p class="kmae-edge__title"><?php esc_html_e( 'Információ', 'kmae' ); ?></p>
	<?php foreach ( $groups['info'] as $item ) { $render( $item ); } ?>
</nav>
