<?php
/**
 * Phone portrait icon rail — Információs menü (right).
 *
 * @package KMAE
 */

if ( ! defined( 'ABSPATH' ) || ! is_user_logged_in() ) {
	return;
}

$path = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '/';

$is = static function ( $slug ) use ( $path ) {
	return false !== strpos( $path, '/' . $slug );
};

$right = array(
	array(
		'url'    => kmae_page_url( 'rolunk' ),
		'icon'   => 'ℹ️',
		'label'  => __( 'Rólunk', 'kmae' ),
		'active' => $is( 'rolunk' ),
	),
	array(
		'url'    => kmae_page_url( 'hogyan-mukodik' ),
		'icon'   => '📖',
		'label'  => __( 'Hogyan működik?', 'kmae' ),
		'active' => $is( 'hogyan-mukodik' ),
	),
	array(
		'url'    => kmae_page_url( 'gyik' ),
		'icon'   => '❓',
		'label'  => __( 'Gyakori kérdések', 'kmae' ),
		'active' => $is( 'gyik' ),
	),
	array(
		'url'    => kmae_page_url( 'biztonsag' ),
		'icon'   => '🛡️',
		'label'  => __( 'Biztonság', 'kmae' ),
		'active' => $is( 'biztonsag' ),
	),
	array(
		'url'    => kmae_page_url( 'kapcsolat' ),
		'icon'   => '✉️',
		'label'  => __( 'Kapcsolat', 'kmae' ),
		'active' => $is( 'kapcsolat' ),
	),
	array(
		'url'    => kmae_page_url( 'feltetelek' ),
		'icon'   => '📄',
		'label'  => __( 'Feltételek', 'kmae' ),
		'active' => $is( 'feltetelek' ),
	),
	array(
		'url'    => kmae_page_url( 'adatvedelem' ),
		'icon'   => '🔐',
		'label'  => __( 'Adatvédelem', 'kmae' ),
		'active' => $is( 'adatvedelem' ),
	),
);

$render = static function ( $item ) {
	?>
	<a
		class="kmae-phone-rail__item<?php echo ! empty( $item['active'] ) ? ' is-active' : ''; ?>"
		href="<?php echo esc_url( $item['url'] ); ?>"
		data-tip="<?php echo esc_attr( $item['label'] ); ?>"
		aria-label="<?php echo esc_attr( $item['label'] ); ?>"
	>
		<span class="kmae-phone-rail__icon" aria-hidden="true"><?php echo esc_html( $item['icon'] ); ?></span>
		<?php if ( ! empty( $item['badge'] ) ) : ?>
			<span class="kmae-phone-rail__badge <?php echo esc_attr( $item['badge_class'] ?? '' ); ?>"><?php echo esc_html( $item['badge'] ); ?></span>
		<?php endif; ?>
	</a>
	<?php
};
?>
<div class="kmae-phone-rails" id="kmae-phone-rails">
	<aside class="kmae-phone-rail kmae-phone-rail--right" id="kmae-phone-rail-right" aria-label="<?php echo esc_attr__( 'Információs menü', 'kmae' ); ?>">
		<button
			type="button"
			class="kmae-phone-rail__toggle kmae-phone-rail__toggle--right"
			id="kmae-phone-rail-right-toggle"
			aria-expanded="false"
			aria-controls="kmae-phone-rail-right-nav"
			data-tip="<?php echo esc_attr__( 'Információs menü', 'kmae' ); ?>"
			aria-label="<?php echo esc_attr__( 'Információs menü', 'kmae' ); ?>"
		>
			<span class="kmae-phone-rail__chevron" aria-hidden="true"></span>
		</button>
		<nav class="kmae-phone-rail__nav" id="kmae-phone-rail-right-nav" hidden>
			<?php foreach ( $right as $item ) { $render( $item ); } ?>
		</nav>
	</aside>
</div>
