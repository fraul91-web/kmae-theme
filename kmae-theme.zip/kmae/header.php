<?php
/**
 * Header — PC full nav + mobile top bar (drawer + bottom nav in footer).
 *
 * @package KMAE
 */

$kmae_logged_in = is_user_logged_in();
$kmae_user      = $kmae_logged_in ? wp_get_current_user() : null;
$kmae_name      = $kmae_user ? ( $kmae_user->display_name ?: $kmae_user->user_login ) : '';
$kmae_initials  = '';
if ( $kmae_name ) {
	$parts = preg_split( '/\s+/u', trim( $kmae_name ) );
	if ( is_array( $parts ) && count( $parts ) >= 2 ) {
		$kmae_initials = mb_strtoupper( mb_substr( $parts[0], 0, 1 ) . mb_substr( $parts[1], 0, 1 ) );
	} else {
		$kmae_initials = mb_strtoupper( mb_substr( $kmae_name, 0, 2 ) );
	}
}
$kmae_path      = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '/';
$kmae_unseen    = ( $kmae_logged_in && class_exists( 'KMAE_Database' ) )
	? (int) KMAE_Database::count_unseen_offer_activity( get_current_user_id() )
	: 0;
$kmae_nav_active = static function ( $slug ) use ( $kmae_path ) {
	return false !== strpos( $kmae_path, '/' . $slug );
};
$kmae_guest_nav_active = static function ( $item ) use ( $kmae_nav_active ) {
	switch ( $item ) {
		case 'home':
			return is_front_page();
		case 'browse':
			return ( is_page( 'hirdetesek' ) || $kmae_nav_active( 'hirdetesek' ) ) && ! $kmae_nav_active( 'sajat-hirdetesek' );
		case 'hogyan':
			return is_page( 'hogyan-mukodik' ) || $kmae_nav_active( 'hogyan-mukodik' );
		case 'kapcsolat':
			return is_page( 'kapcsolat' ) || $kmae_nav_active( 'kapcsolat' );
		default:
			return false;
	}
};
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?> data-home="<?php echo esc_attr( trailingslashit( wp_parse_url( home_url( '/' ), PHP_URL_PATH ) ?: '/' ) ); ?>">
<?php wp_body_open(); ?>

<a class="kmae-skip-link" href="#main"><?php esc_html_e( 'Ugrás a tartalomhoz', 'kmae' ); ?></a>

<header class="kmae-header<?php echo $kmae_logged_in ? ' kmae-pc-topbar' : ''; ?>" id="site-header">
	<div class="kmae-container kmae-header__inner">
		<?php /* ---- Mobile / tablet top ---- */ ?>
		<div class="kmae-header__mobile-top">
			<?php if ( $kmae_logged_in ) : ?>
				<a class="kmae-logo kmae-logo--header kmae-logo--mobile kmae-logo--phone" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="<?php echo esc_attr__( 'Albira', 'kmae' ); ?>">
					<?php kmae_logo_img(); ?>
				</a>

				<div class="kmae-phone-header__tools">
					<a
						class="kmae-header__icon-btn"
						href="<?php echo esc_url( kmae_page_url( 'ertesitesek' ) ); ?>"
						aria-label="<?php echo esc_attr__( 'Értesítések', 'kmae' ); ?>"
					>
						<span aria-hidden="true">🔔</span>
						<?php if ( $kmae_unseen > 0 ) : ?>
							<span class="kmae-phone-header__dot" aria-hidden="true"></span>
						<?php endif; ?>
					</a>
					<a
						class="kmae-header__icon-btn"
						href="<?php echo esc_url( kmae_page_url( 'uzenetek' ) ); ?>"
						aria-label="<?php echo esc_attr__( 'Üzenetek', 'kmae' ); ?>"
					>
						<span aria-hidden="true">💬</span>
					</a>
					<a
						class="kmae-phone-header__avatar"
						href="<?php echo esc_url( kmae_page_url( 'profil' ) ); ?>"
						aria-label="<?php echo esc_attr( $kmae_name ?: __( 'Profil', 'kmae' ) ); ?>"
					>
						<?php echo esc_html( $kmae_initials ?: '??' ); ?>
					</a>
					<button
						type="button"
						class="kmae-header__icon-btn kmae-header__drawer-open"
						id="kmae-drawer-open"
						aria-expanded="false"
						aria-controls="kmae-drawer"
						aria-label="<?php echo esc_attr__( 'Menü megnyitása', 'kmae' ); ?>"
					>
						<span class="kmae-header__menu-bars" aria-hidden="true">
							<span></span><span></span><span></span>
						</span>
					</button>
				</div>
			<?php else : ?>
				<button
					type="button"
					class="kmae-header__icon-btn kmae-header__drawer-open"
					id="kmae-drawer-open"
					aria-expanded="false"
					aria-controls="kmae-drawer"
					aria-label="<?php echo esc_attr__( 'Menü megnyitása', 'kmae' ); ?>"
				>
					<span class="kmae-header__menu-bars" aria-hidden="true">
						<span></span><span></span><span></span>
					</span>
				</button>

				<a class="kmae-logo kmae-logo--header kmae-logo--mobile" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="<?php echo esc_attr__( 'Albira', 'kmae' ); ?>">
					<?php kmae_logo_img(); ?>
				</a>

				<a class="kmae-header__icon-btn kmae-header__login-icon" href="<?php echo esc_url( kmae_page_url( 'belepes' ) ); ?>" aria-label="<?php echo esc_attr__( 'Belépés', 'kmae' ); ?>">
					<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true">
						<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
						<circle cx="12" cy="7" r="4"/>
					</svg>
				</a>
			<?php endif; ?>
		</div>

		<?php /* ---- Desktop logo ---- */ ?>
		<a class="kmae-logo kmae-logo--header kmae-logo--desktop" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="<?php echo esc_attr__( 'Albira', 'kmae' ); ?>">
			<?php kmae_logo_img(); ?>
		</a>

		<?php if ( $kmae_logged_in ) : ?>
			<a class="kmae-pc-logo" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="<?php echo esc_attr__( 'Albira', 'kmae' ); ?>">
				<?php kmae_logo_img( 'kmae-pc-logo__img' ); ?>
			</a>

			<nav class="kmae-header__nav kmae-header__nav--desktop kmae-pc-topnav topnav" aria-label="<?php echo esc_attr__( 'Fő navigáció', 'kmae' ); ?>">
				<a class="kmae-nav-home<?php echo is_front_page() ? ' active' : ''; ?>" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Főoldal', 'kmae' ); ?></a>
				<a class="kmae-nav-sell<?php echo $kmae_nav_active( 'eladni' ) || $kmae_nav_active( 'sajat-hirdetesek' ) || $kmae_nav_active( 'hirdetes-feladasa' ) ? ' active' : ''; ?>" href="<?php echo esc_url( kmae_page_url( 'eladni' ) ); ?>"><?php esc_html_e( 'Eladni', 'kmae' ); ?></a>
				<a class="kmae-nav-buy<?php echo $kmae_nav_active( 'venni' ) || ( $kmae_nav_active( 'hirdetesek' ) && ! $kmae_nav_active( 'sajat-hirdetesek' ) ) ? ' active' : ''; ?>" href="<?php echo esc_url( kmae_page_url( 'venni' ) ); ?>"><?php esc_html_e( 'Venni', 'kmae' ); ?></a>
				<a class="kmae-nav-stats<?php echo $kmae_nav_active( 'statisztikak' ) || $kmae_nav_active( 'ertesitesek' ) ? ' active' : ''; ?>" href="<?php echo esc_url( kmae_page_url( 'statisztikak' ) ); ?>"><?php esc_html_e( 'Statisztikák', 'kmae' ); ?></a>
				<a class="kmae-nav-how<?php echo $kmae_nav_active( 'hogyan-mukodik' ) ? ' active' : ''; ?>" href="<?php echo esc_url( kmae_page_url( 'hogyan-mukodik' ) ); ?>"><?php esc_html_e( 'Hogyan működik?', 'kmae' ); ?></a>
			</nav>

			<div class="kmae-header__tools kmae-header__tools--desktop kmae-pc-topbar-right topbar-right">
				<a class="kmae-header__icon-btn icon-btn kmae-header__icon-btn--search" href="<?php echo esc_url( kmae_page_url( 'hirdetesek' ) ); ?>" aria-label="<?php echo esc_attr__( 'Hirdetések keresése', 'kmae' ); ?>">
					<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" aria-hidden="true">
						<circle cx="10.8" cy="10.8" r="5.7"/><path d="m15.2 15.2 4.1 4.1"/>
					</svg>
				</a>

				<div class="kmae-header__dropdown" data-kmae-dropdown>
					<button type="button" class="kmae-header__icon-btn icon-btn kmae-header__icon-btn--notify" aria-expanded="false" aria-haspopup="true" aria-controls="kmae-panel-notifications" aria-label="<?php echo esc_attr__( 'Értesítések', 'kmae' ); ?>">
						<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true">
							<path d="M18 10a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9"/><path d="M10 22h4"/>
						</svg>
						<?php if ( $kmae_unseen > 0 ) : ?>
							<span class="badge kmae-pc-badge" aria-label="<?php echo esc_attr( sprintf( _n( '%d új értesítés', '%d új értesítés', $kmae_unseen, 'kmae' ), $kmae_unseen ) ); ?>"><?php echo esc_html( min( 99, $kmae_unseen ) ); ?></span>
						<?php endif; ?>
					</button>
					<div class="kmae-header__panel" id="kmae-panel-notifications" hidden>
						<p class="kmae-header__panel-title"><?php esc_html_e( 'Értesítések', 'kmae' ); ?></p>
						<p class="kmae-header__panel-empty"><?php esc_html_e( 'Még nincs új értesítésed.', 'kmae' ); ?></p>
						<a class="kmae-header__panel-link" href="<?php echo esc_url( kmae_page_url( 'ertesitesek' ) ); ?>"><?php esc_html_e( 'Összes értesítés', 'kmae' ); ?></a>
					</div>
				</div>

				<div class="kmae-header__dropdown" data-kmae-dropdown>
					<a class="kmae-header__icon-btn icon-btn kmae-header__icon-btn--messages" href="<?php echo esc_url( kmae_page_url( 'uzenetek' ) ); ?>" aria-label="<?php echo esc_attr__( 'Üzenetek', 'kmae' ); ?>">
						<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true">
							<path d="M20 15a4 4 0 0 1-4 4H8l-4 3v-3a4 4 0 0 1-2-3.5V8a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4z"/><path d="M7 11h10M7 15h6"/>
						</svg>
					</a>
				</div>

				<div class="kmae-header__dropdown kmae-header__dropdown--profile" data-kmae-dropdown>
					<button type="button" class="kmae-header__profile-btn" aria-expanded="false" aria-haspopup="true" aria-controls="kmae-panel-profile" aria-label="<?php echo esc_attr( $kmae_name ?: __( 'Profil', 'kmae' ) ); ?>">
						<span class="kmae-header__avatar avatar" aria-hidden="true"><?php echo esc_html( $kmae_initials ?: '??' ); ?></span>
						<span class="kmae-header__profile-label"><?php echo esc_html( $kmae_name ?: __( 'Profil', 'kmae' ) ); ?></span>
						<span class="kmae-header__caret" aria-hidden="true"></span>
					</button>
					<div class="kmae-header__panel kmae-header__panel--menu" id="kmae-panel-profile" hidden>
						<a href="<?php echo esc_url( kmae_page_url( 'profil' ) ); ?>"><?php esc_html_e( 'Profilom', 'kmae' ); ?></a>
						<a href="<?php echo esc_url( kmae_page_url( 'beallitasok' ) ); ?>"><?php esc_html_e( 'Beállítások', 'kmae' ); ?></a>
						<hr class="kmae-header__panel-sep" />
						<a class="kmae-header__logout" href="<?php echo esc_url( wp_logout_url( home_url( '/' ) ) ); ?>"><?php esc_html_e( 'Kijelentkezés', 'kmae' ); ?></a>
					</div>
				</div>
			</div>
		<?php else : ?>
			<nav class="kmae-header__nav kmae-header__nav--desktop kmae-header__nav--guest" data-kmae-guest-nav aria-label="<?php echo esc_attr__( 'Fő navigáció', 'kmae' ); ?>">
				<a data-nav="home" class="<?php echo $kmae_guest_nav_active( 'home' ) ? 'is-active' : ''; ?>" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Főoldal', 'kmae' ); ?></a>
				<a data-nav="browse" class="kmae-header__nav-browse<?php echo $kmae_guest_nav_active( 'browse' ) ? ' is-active' : ''; ?>" href="<?php echo esc_url( kmae_page_url( 'hirdetesek' ) ); ?>"><?php esc_html_e( 'Autók böngészése', 'kmae' ); ?></a>
				<a data-nav="hogyan" class="<?php echo $kmae_guest_nav_active( 'hogyan' ) ? 'is-active' : ''; ?>" href="<?php echo esc_url( kmae_page_url( 'hogyan-mukodik' ) ); ?>"><?php esc_html_e( 'Hogyan működik?', 'kmae' ); ?></a>
				<a data-nav="kapcsolat" class="<?php echo $kmae_guest_nav_active( 'kapcsolat' ) ? 'is-active' : ''; ?>" href="<?php echo esc_url( kmae_page_url( 'kapcsolat' ) ); ?>"><?php esc_html_e( 'Kapcsolat', 'kmae' ); ?></a>
			</nav>
			<div class="kmae-header__actions kmae-header__actions--desktop">
				<a class="kmae-btn kmae-btn--login kmae-btn--sm" href="<?php echo esc_url( kmae_page_url( 'belepes' ) ); ?>"><?php esc_html_e( 'Belépés', 'kmae' ); ?></a>
				<a class="kmae-btn kmae-btn--register kmae-btn--sm" href="<?php echo esc_url( kmae_page_url( 'regisztracio' ) ); ?>"><?php esc_html_e( 'Regisztráció', 'kmae' ); ?></a>
			</div>
		<?php endif; ?>
	</div>
</header>

<?php /* Drawer — all devices under 1025px */ ?>
<div class="kmae-drawer-backdrop" id="kmae-drawer-backdrop" hidden></div>
<aside class="kmae-drawer<?php echo $kmae_logged_in ? ' kmae-drawer--sheet' : ''; ?>" id="kmae-drawer" hidden aria-hidden="true" aria-labelledby="kmae-drawer-title">
	<div class="kmae-drawer__head">
		<p class="kmae-drawer__brand" id="kmae-drawer-title"><?php echo $kmae_logged_in ? esc_html__( 'Menü', 'kmae' ) : esc_html__( 'Albira', 'kmae' ); ?></p>
		<?php if ( ! $kmae_logged_in ) : ?>
		<button type="button" class="kmae-header__icon-btn" id="kmae-drawer-close" aria-label="<?php echo esc_attr__( 'Menü bezárása', 'kmae' ); ?>">
			<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
				<path d="M18 6 6 18"/><path d="m6 6 12 12"/>
			</svg>
		</button>
		<?php endif; ?>
	</div>
	<nav class="kmae-drawer__nav" aria-label="<?php echo esc_attr__( 'Mobil menü', 'kmae' ); ?>">
		<?php if ( $kmae_logged_in ) : ?>
			<?php get_template_part( 'template-parts/app-menu-panels' ); ?>
			<a class="kmae-drawer__logout" href="<?php echo esc_url( wp_logout_url( home_url( '/' ) ) ); ?>"><?php esc_html_e( 'Kijelentkezés', 'kmae' ); ?></a>
		<?php else : ?>
			<a href="<?php echo esc_url( kmae_page_url( 'hogyan-mukodik' ) ); ?>"><?php esc_html_e( 'Hogyan működik?', 'kmae' ); ?></a>
			<a href="<?php echo esc_url( kmae_page_url( 'gyik' ) ); ?>"><?php esc_html_e( 'Gyakori kérdések', 'kmae' ); ?></a>
			<a href="<?php echo esc_url( kmae_page_url( 'kapcsolat' ) ); ?>"><?php esc_html_e( 'Kapcsolat', 'kmae' ); ?></a>
		<?php endif; ?>
	</nav>
</aside>

<?php if ( $kmae_logged_in ) : ?>
	<?php get_template_part( 'template-parts/edge-rails' ); ?>
	<div class="kmae-app-layout is-panels-closed">
		<div class="kmae-app-content">
<?php endif; ?>

<main id="main" class="kmae-main">
