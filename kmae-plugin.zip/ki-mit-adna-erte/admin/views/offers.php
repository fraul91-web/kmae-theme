<?php
/**
 * Admin offers management view.
 *
 * @package KMAE
 * @var array  $offers
 * @var int    $total
 * @var int    $paged
 * @var int    $per_page
 * @var string $status_filter
 * @var array  $status_labels
 * @var string $notice
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$statuses = array(
	''          => __( 'Mind', 'ki-mit-adna-erte' ),
	'pending'   => $status_labels['pending'] ?? 'pending',
	'accepted'  => $status_labels['accepted'] ?? 'accepted',
	'rejected'  => $status_labels['rejected'] ?? 'rejected',
	'withdrawn' => $status_labels['withdrawn'] ?? 'withdrawn',
);
?>
<div class="wrap kmae-admin-wrap">
	<h1><?php esc_html_e( 'Ajánlatok kezelése', 'ki-mit-adna-erte' ); ?></h1>

	<?php if ( 'offer_deleted' === $notice ) : ?>
		<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Ajánlat törölve.', 'ki-mit-adna-erte' ); ?></p></div>
	<?php elseif ( 'delete_failed' === $notice ) : ?>
		<div class="notice notice-error is-dismissible"><p><?php esc_html_e( 'A művelet sikertelen.', 'ki-mit-adna-erte' ); ?></p></div>
	<?php endif; ?>

	<ul class="subsubsub">
		<?php
		$i = 0;
		foreach ( $statuses as $code => $label ) :
			++$i;
			$url = add_query_arg(
				array(
					'page'   => 'kmae-offers',
					'status' => $code,
				),
				admin_url( 'admin.php' )
			);
			$count = KMAE_Database::count_all_offers( $code );
			?>
			<li>
				<a href="<?php echo esc_url( $url ); ?>" <?php echo $status_filter === $code ? 'class="current"' : ''; ?>>
					<?php echo esc_html( $label ); ?> <span class="count">(<?php echo esc_html( $count ); ?>)</span>
				</a><?php echo count( $statuses ) > $i ? ' |' : ''; ?>
			</li>
		<?php endforeach; ?>
	</ul>

	<table class="widefat striped kmae-admin-table">
		<thead>
			<tr>
				<th><?php esc_html_e( 'ID', 'ki-mit-adna-erte' ); ?></th>
				<th><?php esc_html_e( 'Hirdetés', 'ki-mit-adna-erte' ); ?></th>
				<th><?php esc_html_e( 'Ajánlat', 'ki-mit-adna-erte' ); ?></th>
				<th><?php esc_html_e( 'Státusz', 'ki-mit-adna-erte' ); ?></th>
				<th><?php esc_html_e( 'Ajánlattevő', 'ki-mit-adna-erte' ); ?></th>
				<th><?php esc_html_e( 'Dátum', 'ki-mit-adna-erte' ); ?></th>
				<th><?php esc_html_e( 'Műveletek', 'ki-mit-adna-erte' ); ?></th>
			</tr>
		</thead>
		<tbody>
			<?php if ( empty( $offers ) ) : ?>
				<tr><td colspan="7"><?php esc_html_e( 'Nincs ajánlat.', 'ki-mit-adna-erte' ); ?></td></tr>
			<?php else : ?>
				<?php foreach ( $offers as $offer ) : ?>
					<?php
					$offerer = get_userdata( (int) $offer->offerer_id );
					$summary = KMAE_Offers::get_offer_summary( $offer );
					?>
					<tr>
						<td><?php echo esc_html( $offer->id ); ?></td>
						<td>
							<strong>
								<a href="<?php echo esc_url( get_edit_post_link( $offer->listing_id ) ); ?>">
									<?php echo esc_html( $offer->listing_title ); ?>
								</a>
							</strong>
							<div class="row-actions">
								<a href="<?php echo esc_url( get_permalink( $offer->listing_id ) ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Megtekintés', 'ki-mit-adna-erte' ); ?></a>
							</div>
						</td>
						<td><?php echo esc_html( $summary ); ?></td>
						<td><?php echo wp_kses_post( KMAE_Admin::status_badge( $offer->status ) ); ?></td>
						<td><?php echo esc_html( $offerer ? $offerer->display_name : '—' ); ?></td>
						<td><?php echo esc_html( mysql2date( 'Y.m.d H:i', $offer->created_at ) ); ?></td>
						<td class="kmae-admin-actions">
							<a href="<?php echo esc_url( KMAE_Pages::offer_thread_url( $offer->id ) ); ?>" class="button button-small" target="_blank" rel="noopener"><?php esc_html_e( 'Szál', 'ki-mit-adna-erte' ); ?></a>
							<a href="<?php echo esc_url( KMAE_Admin::admin_action_url( 'kmae_admin_delete_offer', array( 'offer_id' => $offer->id ) ) ); ?>" class="button button-small button-link-delete" onclick="return confirm('<?php echo esc_js( __( 'Biztosan törlöd az ajánlatot?', 'ki-mit-adna-erte' ) ); ?>');"><?php esc_html_e( 'Törlés', 'ki-mit-adna-erte' ); ?></a>
						</td>
					</tr>
				<?php endforeach; ?>
			<?php endif; ?>
		</tbody>
	</table>

	<?php
	$total_pages = ceil( $total / $per_page );
	if ( $total_pages > 1 ) :
		echo '<div class="tablenav"><div class="tablenav-pages">';
		echo paginate_links(
			array(
				'base'    => add_query_arg( 'paged', '%#%' ),
				'format'  => '',
				'current' => $paged,
				'total'   => $total_pages,
			)
		);
		echo '</div></div>';
	endif;
	?>
</div>
