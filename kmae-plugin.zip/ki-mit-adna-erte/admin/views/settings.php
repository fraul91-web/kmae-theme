<?php
/**
 * Plugin settings admin page.
 *
 * @package KMAE
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$saved = isset( $_GET['settings-updated'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
?>
<div class="wrap kmae-admin-wrap">
	<h1><?php esc_html_e( 'KMAE beállítások', 'ki-mit-adna-erte' ); ?></h1>

	<?php if ( $saved ) : ?>
		<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Beállítások mentve.', 'ki-mit-adna-erte' ); ?></p></div>
	<?php endif; ?>

	<form method="post" action="options.php">
		<?php settings_fields( 'kmae_settings' ); ?>

		<table class="form-table">
			<tr>
				<th scope="row"><label for="kmae_contact_unlock_price"><?php esc_html_e( 'Kapcsolatfeloldás ára (Ft)', 'ki-mit-adna-erte' ); ?></label></th>
				<td>
					<input type="number" id="kmae_contact_unlock_price" name="kmae_contact_unlock_price" value="<?php echo esc_attr( KMAE_Settings::contact_unlock_price() ); ?>" min="0" step="1" class="regular-text" />
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="kmae_premium_monthly_price"><?php esc_html_e( 'Szupertag havi díj (Ft)', 'ki-mit-adna-erte' ); ?></label></th>
				<td>
					<input type="number" id="kmae_premium_monthly_price" name="kmae_premium_monthly_price" value="<?php echo esc_attr( KMAE_Settings::premium_monthly_price() ); ?>" min="0" step="1" class="regular-text" />
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="kmae_featured_listing_price"><?php esc_html_e( 'Kiemelt hirdetés ára (Ft / 7 nap)', 'ki-mit-adna-erte' ); ?></label></th>
				<td>
					<input type="number" id="kmae_featured_listing_price" name="kmae_featured_listing_price" value="<?php echo esc_attr( KMAE_Settings::featured_listing_price() ); ?>" min="0" step="1" class="regular-text" />
				</td>
			</tr>
			<tr>
				<th scope="row"><?php esc_html_e( 'Automatikus hirdetés-ellenőrzés', 'ki-mit-adna-erte' ); ?></th>
				<td>
					<label>
						<input type="checkbox" name="kmae_auto_moderation" value="1" <?php checked( KMAE_Settings::auto_moderation_enabled() ); ?> />
						<?php esc_html_e( 'Bekapcsolva — közzététel előtt szabályalapú ellenőrzés (mezők, leírás hossz, képek, elérhetőség tiltás).', 'ki-mit-adna-erte' ); ?>
					</label>
					<p class="description"><?php esc_html_e( 'Autó launch módban: kötelező mezők, min. 3 kép, min. 80 karakter leírás.', 'ki-mit-adna-erte' ); ?></p>
				</td>
			</tr>
			<tr>
				<th scope="row"><?php esc_html_e( 'Demo fizetés mód', 'ki-mit-adna-erte' ); ?></th>
				<td>
					<label>
						<input type="checkbox" name="kmae_demo_payments" value="1" <?php checked( KMAE_Settings::demo_payments_enabled() ); ?> />
						<?php esc_html_e( 'Bekapcsolva — fizetés nélkül működik a kapcsolatfeloldás, prémium és kiemelés (teszteléshez).', 'ki-mit-adna-erte' ); ?>
					</label>
					<p class="description"><?php esc_html_e( 'Éles induláskor kapcsold ki, és kösd be a SimplePay / Barion integrációt.', 'ki-mit-adna-erte' ); ?></p>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="kmae_seller_video_url"><?php esc_html_e( 'Eladóknak — YouTube videó', 'ki-mit-adna-erte' ); ?></label></th>
				<td>
					<input type="url" id="kmae_seller_video_url" name="kmae_seller_video_url" value="<?php echo esc_attr( KMAE_Settings::seller_video_url() ); ?>" class="regular-text" placeholder="https://www.youtube.com/watch?v=..." />
					<p class="description"><?php esc_html_e( 'A „Hogyan működik?” oldal eladói videója. Üresen hagyva: „Videó hamarosan”.', 'ki-mit-adna-erte' ); ?></p>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="kmae_buyer_video_url"><?php esc_html_e( 'Vevőknek — YouTube videó', 'ki-mit-adna-erte' ); ?></label></th>
				<td>
					<input type="url" id="kmae_buyer_video_url" name="kmae_buyer_video_url" value="<?php echo esc_attr( KMAE_Settings::buyer_video_url() ); ?>" class="regular-text" placeholder="https://www.youtube.com/watch?v=..." />
					<p class="description"><?php esc_html_e( 'A „Hogyan működik?” oldal vevői videója. Üresen hagyva: „Videó hamarosan”.', 'ki-mit-adna-erte' ); ?></p>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="kmae_contact_form_email"><?php esc_html_e( 'Kapcsolat űrlap e-mail', 'ki-mit-adna-erte' ); ?></label></th>
				<td>
					<input type="email" id="kmae_contact_form_email" name="kmae_contact_form_email" value="<?php echo esc_attr( KMAE_Settings::contact_form_email() ); ?>" class="regular-text" placeholder="te@pelda.hu" />
					<p class="description"><?php esc_html_e( 'Ide érkeznek a /kapcsolat/ oldalról küldött üzenetek.', 'ki-mit-adna-erte' ); ?></p>
				</td>
			</tr>
		</table>

		<?php submit_button(); ?>
	</form>
</div>
