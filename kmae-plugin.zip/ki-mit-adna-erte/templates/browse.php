<?php
/**
 * Grid browse with filters.
 *
 * @package KMAE
 * @var array $listings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$categories   = get_terms( array( 'taxonomy' => 'kmae_category', 'hide_empty' => false ) );
$offer_labels = KMAE_Taxonomies::offer_type_labels();
$current_cat  = isset( $_GET['kategoria'] ) ? sanitize_text_field( wp_unslash( $_GET['kategoria'] ) ) : '';
$current_type = isset( $_GET['tipus'] ) ? sanitize_text_field( wp_unslash( $_GET['tipus'] ) ) : '';
$base_url     = get_permalink();
?>
<div class="kmae-browse">
	<div class="kmae-browse-header">
		<h2><?php esc_html_e( 'Böngészés', 'ki-mit-adna-erte' ); ?></h2>
		<p class="kmae-subtitle"><?php esc_html_e( 'Nézd meg, mit adnának érte — anélkül, hogy eladnál.', 'ki-mit-adna-erte' ); ?></p>
	</div>

	<?php if ( isset( $_GET['kmae_success'] ) && 'continue_yes' === sanitize_text_field( wp_unslash( $_GET['kmae_success'] ) ) ) : ?>
		<div class="kmae-notice kmae-notice-success"><?php esc_html_e( 'Rendben — folytathatod a többi autóval az alkudozást.', 'ki-mit-adna-erte' ); ?></div>
	<?php endif; ?>

	<div class="kmae-filters">
		<span class="kmae-filter-label"><?php esc_html_e( 'Típus:', 'ki-mit-adna-erte' ); ?></span>
		<?php foreach ( $offer_labels as $code => $label ) : ?>
			<a href="<?php echo esc_url( add_query_arg( 'tipus', $code, remove_query_arg( 'tipus', $base_url ) ) ); ?>" class="kmae-filter-chip <?php echo $current_type === $code ? 'active' : ''; ?>"><?php echo esc_html( $label ); ?></a>
		<?php endforeach; ?>
	</div>
	<div class="kmae-filters">
		<span class="kmae-filter-label"><?php esc_html_e( 'Kategória:', 'ki-mit-adna-erte' ); ?></span>
		<?php foreach ( $categories as $cat ) : ?>
			<a href="<?php echo esc_url( add_query_arg( 'kategoria', $cat->slug, $base_url ) ); ?>" class="kmae-filter-chip <?php echo $current_cat === $cat->slug ? 'active' : ''; ?>"><?php echo esc_html( $cat->name ); ?></a>
		<?php endforeach; ?>
	</div>

	<?php if ( empty( $listings ) ) : ?>
		<div class="kmae-empty"><p><?php esc_html_e( 'Nincs találat.', 'ki-mit-adna-erte' ); ?></p></div>
	<?php else : ?>
		<div class="kmae-browse-grid">
			<?php foreach ( $listings as $listing ) : ?>
				<?php
				$thumb    = KMAE_Query::get_listing_thumbnail_url( $listing->ID, 'full' );
				$types    = KMAE_Meta::get_offer_types( $listing->ID );
				$labels   = array_map( fn( $t ) => $offer_labels[ $t ] ?? $t, $types );
				$location = KMAE_Counties::format_listing_location( $listing->ID );
				$featured = KMAE_Premium::is_featured( $listing->ID );
				?>
				<a href="<?php echo esc_url( get_permalink( $listing->ID ) ); ?>" class="kmae-browse-card">
					<div class="kmae-browse-image kmae-image-frame">
						<?php if ( $thumb ) : ?>
							<img src="<?php echo esc_url( $thumb ); ?>" alt="" class="kmae-card-image" loading="lazy" decoding="async" />
						<?php else : ?>
							<div class="kmae-no-photo"><?php esc_html_e( 'Nincs kép', 'ki-mit-adna-erte' ); ?></div>
						<?php endif; ?>
						<?php if ( $featured ) : ?><span class="kmae-featured-badge"><?php esc_html_e( 'Kiemelt', 'ki-mit-adna-erte' ); ?></span><?php endif; ?>
					</div>
					<div class="kmae-browse-info">
						<h3><?php echo esc_html( $listing->post_title ); ?></h3>
						<?php if ( KMAE_Seller::is_fixed_price( $listing->ID ) ) : ?>
							<span class="kmae-card-price"><?php echo esc_html( KMAE_Offers::format_cash( KMAE_Seller::get_fixed_price( $listing->ID ) ) ); ?></span>
						<?php elseif ( KMAE_Seller::PRICE_OFFERS === KMAE_Seller::get_price_mode( $listing->ID ) ) : ?>
							<span class="kmae-card-price kmae-card-price--offers"><?php esc_html_e( 'Ajánlatokat vár', 'ki-mit-adna-erte' ); ?></span>
						<?php endif; ?>
						<?php if ( $location ) : ?><span class="kmae-location"><?php echo esc_html( $location ); ?></span><?php endif; ?>
						<?php
						$listing_id = $listing->ID;
						include KMAE_PLUGIN_DIR . 'templates/partials/listing-pledge-badges.php';
						?>
						<div class="kmae-type-tags">
							<?php foreach ( $labels as $label ) : ?>
								<span class="kmae-type-tag"><?php echo esc_html( $label ); ?></span>
							<?php endforeach; ?>
						</div>
					</div>
				</a>
			<?php endforeach; ?>
		</div>
	<?php endif; ?>
</div>
