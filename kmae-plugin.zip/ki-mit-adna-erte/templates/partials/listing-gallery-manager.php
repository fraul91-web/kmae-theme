<?php
/**
 * Edit form — gallery manager (reorder, delete, preview).
 *
 * @package KMAE
 * @var int   $listing_id
 * @var int[] $gallery_ids
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( empty( $gallery_ids ) ) {
	return;
}
?>
<div class="kmae-field kmae-gallery-manager-wrap">
	<label><?php esc_html_e( 'Képek kezelése', 'ki-mit-adna-erte' ); ?></label>
	<p class="kmae-hint">
		<?php esc_html_e( 'Az első kép a főkép (borítókép). Kattints a képre a nagyításhoz. A nyilakkal rendezhetsz, az × gombbal törölhetsz.', 'ki-mit-adna-erte' ); ?>
	</p>

	<ul class="kmae-gallery-manager" id="kmae-gallery-manager">
		<?php foreach ( $gallery_ids as $i => $gid ) : ?>
			<?php
			$thumb = KMAE_Images::get_url( $gid, 'medium' );
			$full  = KMAE_Images::get_url( $gid, 'full' );
			if ( ! $thumb ) {
				continue;
			}
			?>
			<li class="kmae-gallery-manager-item" data-id="<?php echo esc_attr( $gid ); ?>" draggable="true">
				<input type="hidden" name="kmae_gallery_order[]" value="<?php echo esc_attr( $gid ); ?>" />
				<button type="button" class="kmae-gallery-manager-view kmae-zoomable" data-full="<?php echo esc_url( $full ?: $thumb ); ?>">
					<img src="<?php echo esc_url( $thumb ); ?>" alt="" />
				</button>
				<?php if ( 0 === $i ) : ?>
					<span class="kmae-gallery-manager-badge"><?php esc_html_e( 'Főkép', 'ki-mit-adna-erte' ); ?></span>
				<?php endif; ?>
				<div class="kmae-gallery-manager-actions">
					<button type="button" class="kmae-gallery-manager-up" aria-label="<?php esc_attr_e( 'Előrébb', 'ki-mit-adna-erte' ); ?>">&#8593;</button>
					<button type="button" class="kmae-gallery-manager-down" aria-label="<?php esc_attr_e( 'Hátrébb', 'ki-mit-adna-erte' ); ?>">&#8595;</button>
					<button type="button" class="kmae-gallery-manager-remove" aria-label="<?php esc_attr_e( 'Kép törlése', 'ki-mit-adna-erte' ); ?>">&times;</button>
				</div>
			</li>
		<?php endforeach; ?>
	</ul>

	<div id="kmae-gallery-removed-inputs" hidden aria-hidden="true"></div>
</div>
