<?php
/**
 * Pending company seller fees (1%).
 *
 * @package KMAE
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! is_user_logged_in() || ! KMAE_Auth::is_company( get_current_user_id() ) ) {
	return;
}

$fees = KMAE_Company::get_fees_for_seller( get_current_user_id() );
if ( empty( $fees ) ) {
	return;
}

$pending = array_filter(
	$fees,
	static function ( $fee ) {
		return KMAE_Company::STATUS_PENDING === $fee->status;
	}
);
?>
<div class="kmae-company-fees">
	<h3><?php esc_html_e( 'Albira díjak (1%)', 'ki-mit-adna-erte' ); ?></h3>
	<p class="kmae-hint"><?php esc_html_e( 'Céges eladásnál sikeres üzlet után 1% díjat fizetsz. Hirdetési darabszám-limit nincs.', 'ki-mit-adna-erte' ); ?></p>

	<?php if ( empty( $pending ) ) : ?>
		<p class="kmae-notice kmae-notice-success"><?php esc_html_e( 'Nincs függő díjad.', 'ki-mit-adna-erte' ); ?></p>
	<?php else : ?>
		<ul class="kmae-company-fees__list">
			<?php foreach ( $pending as $fee ) : ?>
				<?php $listing = get_post( $fee->listing_id ); ?>
				<li class="kmae-company-fees__item">
					<div>
						<strong><?php echo esc_html( $listing ? $listing->post_title : __( 'Hirdetés', 'ki-mit-adna-erte' ) ); ?></strong>
						<span class="kmae-hint" style="display:block;">
							<?php
							printf(
								/* translators: 1: sale amount, 2: fee */
								esc_html__( 'Eladás: %1$s, díj: %2$s', 'ki-mit-adna-erte' ),
								esc_html( KMAE_Offers::format_cash( (float) $fee->sale_amount ) ),
								esc_html( KMAE_Company::format_fee( (float) $fee->fee_amount ) )
							);
							?>
						</span>
					</div>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="kmae-inline-form">
						<?php wp_nonce_field( 'kmae_pay_company_fee', 'kmae_pay_fee_nonce' ); ?>
						<input type="hidden" name="action" value="kmae_pay_company_fee" />
						<input type="hidden" name="kmae_fee_id" value="<?php echo esc_attr( $fee->id ); ?>" />
						<button type="submit" class="kmae-btn kmae-btn-sm kmae-btn-primary">
							<?php
							printf(
								/* translators: %s: fee amount */
								esc_html__( 'Rendezem (%s)', 'ki-mit-adna-erte' ),
								esc_html( KMAE_Company::format_fee( (float) $fee->fee_amount ) )
							);
							?>
						</button>
					</form>
				</li>
			<?php endforeach; ?>
		</ul>
	<?php endif; ?>
</div>
