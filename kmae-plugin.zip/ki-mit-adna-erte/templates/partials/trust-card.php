<?php
/**
 * Trust score block for profile / listing.
 *
 * @package KMAE
 * @var int $trust_user_id
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$trust = KMAE_Trust::get_summary( $trust_user_id );
?>
<div class="kmae-trust-card">
	<?php if ( KMAE_Auth::is_company( $trust_user_id ) ) : ?>
		<p class="kmae-trust-card__seller">
			<span class="kmae-badge kmae-badge-accepted"><?php esc_html_e( 'Autókereskedés', 'ki-mit-adna-erte' ); ?></span>
			<strong><?php echo esc_html( KMAE_Company::get_company_name( $trust_user_id ) ); ?></strong>
		</p>
	<?php endif; ?>
	<div class="kmae-trust-card__score">
		<span class="kmae-trust-card__label"><?php esc_html_e( 'Bizalmi szám', 'ki-mit-adna-erte' ); ?></span>
		<strong class="kmae-trust-card__value">
			<?php echo $trust['score'] > 0 ? esc_html( (string) $trust['score'] ) : '—'; ?>
		</strong>
	</div>
	<ul class="kmae-trust-card__stats">
		<li>
			<?php
			printf(
				/* translators: %d: deal count */
				esc_html__( '%d sikeres üzlet', 'ki-mit-adna-erte' ),
				(int) $trust['deals']
			);
			?>
		</li>
		<li>
			<?php
			printf(
				/* translators: %d: positive ratings */
				esc_html__( '%d pozitív értékelés', 'ki-mit-adna-erte' ),
				(int) $trust['positive']
			);
			?>
		</li>
	</ul>
	<?php if ( ! empty( $trust['badges'] ) ) : ?>
		<div class="kmae-trust-card__badges">
			<?php foreach ( $trust['badges'] as $badge ) : ?>
				<span class="kmae-trust-badge"><?php echo esc_html( $badge ); ?></span>
			<?php endforeach; ?>
		</div>
	<?php endif; ?>
</div>
