<?php
/**
 * Complete listing create/edit page layout.
 *
 * @package KMAE
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$cancel_url = $is_edit ? home_url( '/sajat-hirdetesek/' ) : KMAE_Back::browse_url();
?>

<div class="kmae-create-page kmae-listing-create<?php echo $is_edit ? ' is-editing' : ' is-creating'; ?>">
	<?php if ( $is_edit ) : ?>
		<header class="kmae-create-hero">
			<div class="kmae-create-hero__content">
				<span class="kmae-create-hero__eyebrow"><?php esc_html_e( 'Hirdetés szerkesztése', 'ki-mit-adna-erte' ); ?></span>
				<h1 class="kmae-create-hero__title"><?php esc_html_e( 'Tedd naprakésszé a hirdetésed', 'ki-mit-adna-erte' ); ?></h1>
				<p class="kmae-create-hero__lead"><?php esc_html_e( 'Ellenőrizd az adatokat, az eladás módját és a feltöltött fotókat.', 'ki-mit-adna-erte' ); ?></p>
			</div>
		</header>
	<?php endif; ?>

	<main class="kmae-create-main">
		<div class="kmae-create-notices">
			<?php if ( $is_awaiting ) : ?>
				<div class="kmae-create-notice kmae-create-notice--info">
					<span class="kmae-create-notice__icon" aria-hidden="true"><?php echo KMAE_Icons::render( 'info', array( 'size' => 20 ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
					<div>
						<strong><?php esc_html_e( 'A hirdetés fotókra vár', 'ki-mit-adna-erte' ); ?></strong>
						<p><?php esc_html_e( 'Az adatok már el vannak mentve. Készítsd el a kötelező autófotókat telefonról, majd mentsd újra a hirdetést.', 'ki-mit-adna-erte' ); ?></p>
					</div>
				</div>
			<?php endif; ?>

			<?php if ( ! $is_edit && is_wp_error( $can_create ) ) : ?>
				<div class="kmae-create-notice kmae-create-notice--error">
					<span class="kmae-create-notice__icon" aria-hidden="true"><?php echo KMAE_Icons::render( 'triangle-alert', array( 'size' => 20 ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
					<div>
						<strong><?php esc_html_e( 'Most nem adhatsz fel új hirdetést', 'ki-mit-adna-erte' ); ?></strong>
						<p><?php echo esc_html( $can_create->get_error_message() ); ?></p>
						<a href="<?php echo esc_url( home_url( '/sajat-hirdetesek/' ) ); ?>"><?php esc_html_e( 'Saját hirdetéseim megnyitása', 'ki-mit-adna-erte' ); ?> →</a>
					</div>
				</div>
			<?php else : ?>
				<?php if ( ! $is_edit && is_user_logged_in() && KMAE_Auth::is_company( get_current_user_id() ) ) : ?>
					<div class="kmae-create-notice kmae-create-notice--info">
						<span class="kmae-create-notice__icon" aria-hidden="true"><?php echo KMAE_Icons::render( 'badge-check', array( 'size' => 20 ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
						<div>
							<strong><?php esc_html_e( 'Céges / kereskedői fiók', 'ki-mit-adna-erte' ); ?></strong>
							<p><?php esc_html_e( 'Korlátlan számú hirdetést adhatsz fel. Sikeres eladás után az eladási összeg 1%-a az Albira díja.', 'ki-mit-adna-erte' ); ?></p>
						</div>
					</div>
				<?php endif; ?>

				<?php if ( ! empty( $mod_errors ) ) : ?>
					<div class="kmae-create-notice kmae-create-notice--error">
						<span class="kmae-create-notice__icon" aria-hidden="true"><?php echo KMAE_Icons::render( 'triangle-alert', array( 'size' => 20 ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
						<div>
							<strong><?php esc_html_e( 'A hirdetés javításra szorul', 'ki-mit-adna-erte' ); ?></strong>
							<ul>
								<?php foreach ( $mod_errors as $reason ) : ?>
									<li><?php echo esc_html( $reason ); ?></li>
								<?php endforeach; ?>
							</ul>
						</div>
					</div>
				<?php endif; ?>

				<?php if ( $error ) : ?>
					<div class="kmae-create-notice kmae-create-notice--error">
						<span class="kmae-create-notice__icon" aria-hidden="true"><?php echo KMAE_Icons::render( 'triangle-alert', array( 'size' => 20 ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
						<div><p><?php echo esc_html( $listing_error_messages[ $error ] ?? $listing_error_messages['missing_fields'] ); ?></p></div>
					</div>
				<?php endif; ?>

				<form method="post" enctype="multipart/form-data" class="kmae-form-wrap kmae-form kmae-create-form kmae-listing-form" id="kmae-listing-form" data-open-photos="<?php echo $open_photos ? '1' : '0'; ?>" data-awaiting="<?php echo $is_awaiting ? '1' : '0'; ?>" <?php echo $is_edit ? 'action="' . esc_url( $form_action ) . '"' : ''; ?>>
					<?php if ( $is_edit ) : ?>
						<?php wp_nonce_field( 'kmae_update_listing', 'kmae_update_listing_nonce' ); ?>
						<input type="hidden" name="action" value="kmae_update_listing" />
						<input type="hidden" name="kmae_listing_id" value="<?php echo esc_attr( $listing->ID ); ?>" />
						<input type="hidden" name="kmae_redirect" value="<?php echo esc_url( add_query_arg( 'kmae_edit', $listing->ID, home_url( '/hirdetes-feladasa/' ) ) ); ?>" />
					<?php else : ?>
						<?php wp_nonce_field( 'kmae_create_listing_nonce', 'kmae_create_listing_nonce' ); ?>
						<input type="hidden" name="kmae_action" value="create_listing" />
						<?php if ( KMAE_Photo_Motor::is_enabled() ) : ?>
							<input type="hidden" name="kmae_create_device" id="kmae_create_device" value="" />
						<?php endif; ?>
					<?php endif; ?>

					<?php if ( ! $is_edit && KMAE_Photo_Motor::is_enabled() ) : ?>
						<?php
						$device_back = class_exists( 'KMAE_Pages' ) ? KMAE_Pages::url( 'eladni' ) : home_url( '/eladni/' );
						$device_choices = array(
							array(
								'id'          => 'computer',
								'label'       => __( 'PC vagy laptop', 'ki-mit-adna-erte' ),
								'description' => __( 'Töltsd ki kényelmesen az adatokat. Mentés után telefonról készítheted el a fotókat.', 'ki-mit-adna-erte' ),
							),
							array(
								'id'          => 'phone',
								'label'       => __( 'Telefon vagy tablet', 'ki-mit-adna-erte' ),
								'description' => __( 'Az adatokat és a kötelező kamera-fotókat is ezen az eszközön készíted el.', 'ki-mit-adna-erte' ),
							),
						);
						?>
						<section class="kmae-create-device" id="kmae-device-step" aria-labelledby="kmae-device-title">
							<div class="kmae-create-device__head">
								<span class="kmae-create-step-label"><?php esc_html_e( 'Kezdés', 'ki-mit-adna-erte' ); ?></span>
								<h2 id="kmae-device-title"><?php esc_html_e( 'Hol készíted el a hirdetést?', 'ki-mit-adna-erte' ); ?></h2>
								<p><?php esc_html_e( 'Ez alapján állítjuk be a fotózás és a mentés menetét.', 'ki-mit-adna-erte' ); ?></p>
							</div>
							<div class="kmae-create-device__choices">
								<?php foreach ( $device_choices as $choice ) : ?>
									<button type="button" class="kmae-device-choice kmae-device-choice--<?php echo esc_attr( $choice['id'] ); ?>" data-kmae-device="<?php echo esc_attr( $choice['id'] ); ?>">
										<span class="kmae-device-choice__title"><?php echo esc_html( $choice['label'] ); ?></span>
										<span class="kmae-device-choice__art" aria-hidden="true"></span>
										<small class="kmae-device-choice__desc"><?php echo esc_html( $choice['description'] ); ?></small>
										<span class="kmae-device-choice__action" aria-hidden="true">
											<?php esc_html_e( 'Kiválasztom', 'ki-mit-adna-erte' ); ?>
											<?php echo KMAE_Icons::render( 'arrow-right', array( 'size' => 17 ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
										</span>
									</button>
								<?php endforeach; ?>
							</div>
							<aside class="kmae-create-info" aria-labelledby="kmae-create-info-title">
								<span class="kmae-create-info__icon" aria-hidden="true">
									<?php echo KMAE_Icons::render( 'sparkles', array( 'size' => 25 ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
								</span>
								<div class="kmae-create-info__content">
									<h2 id="kmae-create-info-title"><?php esc_html_e( 'Add fel az autódat egyszerűen', 'ki-mit-adna-erte' ); ?></h2>
									<p><?php esc_html_e( 'Végigvezetünk minden fontos lépésen. Adj meg pontos adatokat, válaszd ki az eladás módját, majd készíts jó minőségű fotókat.', 'ki-mit-adna-erte' ); ?></p>
									<div class="kmae-create-info__benefits" aria-label="<?php esc_attr_e( 'A hirdetés előnyei', 'ki-mit-adna-erte' ); ?>">
										<span><?php echo KMAE_Icons::render( 'clock', array( 'size' => 16 ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><?php esc_html_e( 'Néhány perc', 'ki-mit-adna-erte' ); ?></span>
										<span><?php echo KMAE_Icons::render( 'shield', array( 'size' => 16 ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><?php esc_html_e( 'Ellenőrzött folyamat', 'ki-mit-adna-erte' ); ?></span>
									</div>
								</div>
							</aside>
							<a class="kmae-create-back" href="<?php echo esc_url( $device_back ); ?>">
								<?php echo KMAE_Icons::render( 'arrow-left', array( 'size' => 16 ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
								<?php esc_html_e( 'Vissza az Eladói központhoz', 'ki-mit-adna-erte' ); ?>
							</a>
						</section>
					<?php endif; ?>

					<div class="kmae-create-fields" id="kmae-listing-fields" <?php echo ( ! $is_edit && KMAE_Photo_Motor::is_enabled() ) ? 'hidden' : ''; ?>>
						<nav class="kmae-create-progress" aria-label="<?php esc_attr_e( 'Hirdetés lépései', 'ki-mit-adna-erte' ); ?>">
							<span><b>1</b><?php esc_html_e( 'Autó adatai', 'ki-mit-adna-erte' ); ?></span>
							<span><b>2</b><?php esc_html_e( 'Hirdetés', 'ki-mit-adna-erte' ); ?></span>
							<span><b>3</b><?php esc_html_e( 'Eladás módja', 'ki-mit-adna-erte' ); ?></span>
							<span><b>4</b><?php esc_html_e( 'Fotók és mentés', 'ki-mit-adna-erte' ); ?></span>
						</nav>

						<section class="kmae-create-section" aria-labelledby="kmae-section-vehicle">
							<div class="kmae-create-section__head">
								<span class="kmae-create-section__number">01</span>
								<div>
									<h2 id="kmae-section-vehicle"><?php esc_html_e( 'Az autó legfontosabb adatai', 'ki-mit-adna-erte' ); ?></h2>
									<p><?php esc_html_e( 'A pontos adatok jobb találatokat és komolyabb érdeklődőket hoznak.', 'ki-mit-adna-erte' ); ?></p>
								</div>
							</div>
							<div class="kmae-create-section__body">
								<?php if ( $is_vehicle ) : ?>
									<?php include KMAE_PLUGIN_DIR . 'templates/partials/vehicle-form-fields.php'; ?>
								<?php else : ?>
									<div class="kmae-field">
										<label for="kmae_category"><?php esc_html_e( 'Kategória *', 'ki-mit-adna-erte' ); ?></label>
										<select name="kmae_category" id="kmae_category" required>
											<option value=""><?php esc_html_e( 'Válassz kategóriát', 'ki-mit-adna-erte' ); ?></option>
											<?php foreach ( $categories as $cat ) : ?>
												<option value="<?php echo esc_attr( $cat->term_id ); ?>" <?php selected( $current_cat_id, $cat->term_id ); ?>><?php echo esc_html( $cat->name ); ?></option>
											<?php endforeach; ?>
										</select>
									</div>
								<?php endif; ?>
								<?php if ( $is_vehicle ) : ?>
									<input type="hidden" name="kmae_category" value="<?php echo esc_attr( $launch_cat_id ); ?>" />
								<?php endif; ?>
							</div>
						</section>

						<section class="kmae-create-section" aria-labelledby="kmae-section-ad">
							<div class="kmae-create-section__head">
								<span class="kmae-create-section__number">02</span>
								<div>
									<h2 id="kmae-section-ad"><?php esc_html_e( 'A hirdetés tartalma', 'ki-mit-adna-erte' ); ?></h2>
									<p><?php esc_html_e( 'Mutasd be őszintén az autót, és add meg, hol tekinthető meg.', 'ki-mit-adna-erte' ); ?></p>
								</div>
							</div>
							<div class="kmae-create-section__body">
								<div class="kmae-field">
									<label for="kmae_title"><?php esc_html_e( 'Hirdetés címe *', 'ki-mit-adna-erte' ); ?></label>
									<input type="text" name="kmae_title" id="kmae_title" required value="<?php echo esc_attr( $title_val ); ?>" placeholder="<?php esc_attr_e( 'Például: BMW 320d, 2018, automata', 'ki-mit-adna-erte' ); ?>" />
									<?php if ( $is_vehicle ) : ?><p class="kmae-hint"><?php esc_html_e( 'A márka, modell és évjárat alapján címet is javaslunk, amit szabadon átírhatsz.', 'ki-mit-adna-erte' ); ?></p><?php endif; ?>
								</div>
								<div class="kmae-field">
									<label for="kmae_description"><?php esc_html_e( 'Részletes leírás *', 'ki-mit-adna-erte' ); ?></label>
									<textarea name="kmae_description" id="kmae_description" rows="7" required placeholder="<?php esc_attr_e( 'Írj a szerviztörténetről, használatról, extrákról és az autó előnyeiről…', 'ki-mit-adna-erte' ); ?>"><?php echo esc_textarea( $desc_val ); ?></textarea>
									<?php if ( KMAE_Moderation::is_enabled() ) : ?><p class="kmae-hint"><?php printf( esc_html__( 'Legalább %d karakter. Telefonszámot és e-mail-címet ne írj ide.', 'ki-mit-adna-erte' ), KMAE_Moderation::MIN_DESC_LENGTH ); ?></p><?php endif; ?>
								</div>
								<div class="kmae-field">
									<label for="kmae_known_defects"><?php esc_html_e( 'Ismert hibák', 'ki-mit-adna-erte' ); ?></label>
									<textarea name="kmae_known_defects" id="kmae_known_defects" rows="4" placeholder="<?php esc_attr_e( 'Például: karcolás a jobb sárvédőn, kisebb esztétikai hiba…', 'ki-mit-adna-erte' ); ?>"><?php echo esc_textarea( $defects_val ); ?></textarea>
									<p class="kmae-hint"><?php esc_html_e( 'Az őszinte leírás bizalmat épít, és kevesebb kellemetlen meglepetést okoz.', 'ki-mit-adna-erte' ); ?></p>
								</div>
								<div class="kmae-field-row">
									<div class="kmae-field">
										<label for="kmae_county"><?php esc_html_e( 'Megye *', 'ki-mit-adna-erte' ); ?></label>
										<select name="kmae_county" id="kmae_county" required>
											<option value=""><?php esc_html_e( 'Válassz megyét', 'ki-mit-adna-erte' ); ?></option>
											<?php foreach ( KMAE_Counties::get_all() as $slug => $label ) : ?>
												<option value="<?php echo esc_attr( $slug ); ?>" <?php selected( $county_val, $slug ); ?>><?php echo esc_html( $label ); ?></option>
											<?php endforeach; ?>
										</select>
									</div>
									<div class="kmae-field">
										<label for="kmae_city"><?php esc_html_e( 'Város *', 'ki-mit-adna-erte' ); ?></label>
										<input type="text" name="kmae_city" id="kmae_city" required value="<?php echo esc_attr( $city_val ); ?>" placeholder="<?php esc_attr_e( 'Például: Szeged', 'ki-mit-adna-erte' ); ?>" />
									</div>
								</div>
								<?php if ( ! $is_vehicle ) : ?>
									<div class="kmae-field">
										<label for="kmae_condition"><?php esc_html_e( 'Állapot', 'ki-mit-adna-erte' ); ?></label>
										<input type="text" name="kmae_condition" id="kmae_condition" value="<?php echo esc_attr( $is_edit ? get_post_meta( $listing->ID, '_kmae_condition', true ) : '' ); ?>" />
									</div>
								<?php endif; ?>
							</div>
						</section>

						<section class="kmae-create-section" aria-labelledby="kmae-section-sale">
							<div class="kmae-create-section__head">
								<span class="kmae-create-section__number">03</span>
								<div>
									<h2 id="kmae-section-sale"><?php esc_html_e( 'Ár és elfogadott ajánlatok', 'ki-mit-adna-erte' ); ?></h2>
									<p><?php esc_html_e( 'Döntsd el, fix árat kérsz, vagy megvárod a piac ajánlatait.', 'ki-mit-adna-erte' ); ?></p>
								</div>
							</div>
							<div class="kmae-create-section__body">
								<fieldset class="kmae-fieldset kmae-price-mode">
									<legend><?php esc_html_e( 'Árazás *', 'ki-mit-adna-erte' ); ?></legend>
									<div class="kmae-price-mode__options">
										<label class="kmae-price-mode__option">
											<input type="radio" name="kmae_price_mode" value="<?php echo esc_attr( KMAE_Seller::PRICE_FIXED ); ?>" data-kmae-price-mode="<?php echo esc_attr( KMAE_Seller::PRICE_FIXED ); ?>" <?php checked( $price_mode, KMAE_Seller::PRICE_FIXED ); ?> required />
											<span class="kmae-price-mode__text"><strong><?php esc_html_e( 'Fix árat kérek', 'ki-mit-adna-erte' ); ?></strong><span class="kmae-price-mode__desc"><?php esc_html_e( 'A vevő látja az árat, és ezt az összeget ajánlhatja meg.', 'ki-mit-adna-erte' ); ?></span></span>
										</label>
										<label class="kmae-price-mode__option">
											<input type="radio" name="kmae_price_mode" value="<?php echo esc_attr( KMAE_Seller::PRICE_OFFERS ); ?>" data-kmae-price-mode="<?php echo esc_attr( KMAE_Seller::PRICE_OFFERS ); ?>" <?php checked( $price_mode, KMAE_Seller::PRICE_OFFERS ); ?> required />
											<span class="kmae-price-mode__text"><strong><?php esc_html_e( 'Ajánlatokat várok', 'ki-mit-adna-erte' ); ?></strong><span class="kmae-price-mode__desc"><?php esc_html_e( 'Te adod meg a rejtett minimumot, a vevők pedig ajánlatot tesznek.', 'ki-mit-adna-erte' ); ?></span></span>
										</label>
									</div>
									<div class="kmae-field kmae-fixed-price-field" style="<?php echo KMAE_Seller::PRICE_FIXED === $price_mode ? '' : 'display:none;'; ?>">
										<label for="kmae_fixed_price"><?php esc_html_e( 'Fix ár (Ft) *', 'ki-mit-adna-erte' ); ?></label>
										<input type="number" name="kmae_fixed_price" id="kmae_fixed_price" min="1" step="1000" value="<?php echo esc_attr( $fixed_price_val > 0 ? $fixed_price_val : '' ); ?>" placeholder="3 500 000" />
									</div>
									<div class="kmae-field kmae-minimum-field" style="<?php echo KMAE_Seller::PRICE_OFFERS === $price_mode ? '' : 'display:none;'; ?>">
										<label for="kmae_minimum_cash"><?php esc_html_e( 'Rejtett minimum összeg (Ft) *', 'ki-mit-adna-erte' ); ?></label>
										<input type="number" name="kmae_minimum_cash" id="kmae_minimum_cash" min="0" step="1000" value="<?php echo esc_attr( $minimum_val > 0 ? $minimum_val : '' ); ?>" placeholder="3 200 000" />
										<p class="kmae-hint"><?php esc_html_e( 'Ezt csak te és az Albira rendszere látja.', 'ki-mit-adna-erte' ); ?></p>
									</div>
								</fieldset>

								<fieldset class="kmae-fieldset kmae-offer-types">
									<legend><?php esc_html_e( 'Mit fogadsz el érte? *', 'ki-mit-adna-erte' ); ?></legend>
									<p class="kmae-hint"><?php esc_html_e( 'Több lehetőséget is megjelölhetsz.', 'ki-mit-adna-erte' ); ?></p>
									<div class="kmae-create-option-grid">
										<?php foreach ( $offer_labels as $code => $label ) : ?>
											<label class="kmae-offer-type-option">
												<input type="checkbox" name="kmae_offer_types[]" value="<?php echo esc_attr( $code ); ?>" data-offer-type="<?php echo esc_attr( $code ); ?>" <?php checked( in_array( $code, $selected_types, true ) ); ?> />
												<span class="kmae-offer-type-option-text"><strong><?php echo esc_html( $label ); ?></strong><?php if ( ! empty( $offer_descs[ $code ] ) ) : ?><span class="kmae-offer-type-option-desc"><?php echo esc_html( $offer_descs[ $code ] ); ?></span><?php endif; ?></span>
											</label>
										<?php endforeach; ?>
									</div>
								</fieldset>

								<?php if ( ! $is_vehicle ) : ?>
									<fieldset class="kmae-fieldset kmae-trade-in-field" style="<?php echo in_array( KMAE_OFFER_TYPE_TRADE_IN, $selected_types, true ) ? '' : 'display:none;'; ?>">
										<legend><?php esc_html_e( 'Beszámítási kategóriák', 'ki-mit-adna-erte' ); ?></legend>
										<?php foreach ( $categories as $cat ) : ?><label class="kmae-checkbox"><input type="checkbox" name="kmae_trade_in_categories[]" value="<?php echo esc_attr( $cat->term_id ); ?>" <?php checked( in_array( $cat->term_id, $trade_in_cats, true ) ); ?> /><?php echo esc_html( $cat->name ); ?></label><?php endforeach; ?>
									</fieldset>
								<?php else : ?>
									<input type="hidden" name="kmae_trade_in_categories[]" value="<?php echo esc_attr( $launch_cat_id ); ?>" />
								<?php endif; ?>
							</div>
						</section>

						<section class="kmae-create-section" aria-labelledby="kmae-section-trust">
							<div class="kmae-create-section__head">
								<span class="kmae-create-section__number">04</span>
								<div>
									<h2 id="kmae-section-trust"><?php esc_html_e( 'Bizalom és eladói vállalások', 'ki-mit-adna-erte' ); ?></h2>
									<p><?php esc_html_e( 'Az opcionális vállalások segítenek kitűnni a hasonló hirdetések közül.', 'ki-mit-adna-erte' ); ?></p>
								</div>
							</div>
							<div class="kmae-create-section__body">
								<fieldset class="kmae-fieldset kmae-commitments">
									<legend class="screen-reader-text"><?php esc_html_e( 'Eladói vállalások', 'ki-mit-adna-erte' ); ?></legend>
									<div class="kmae-create-option-grid">
										<?php foreach ( KMAE_Seller::commitment_defs() as $code => $info ) : ?>
											<label class="kmae-commitment-option">
												<input type="checkbox" name="kmae_commitments[]" value="<?php echo esc_attr( $code ); ?>" <?php checked( in_array( $code, $commitments, true ) ); ?> />
												<span class="kmae-commitment-option__text"><strong><?php echo esc_html( $info['label'] ); ?></strong><span class="kmae-commitment-option__desc"><?php echo esc_html( $info['desc'] ); ?></span><?php if ( ! empty( $info['reward'] ) ) : ?><span class="kmae-commitment-option__reward"><?php echo esc_html( $info['reward'] ); ?></span><?php endif; ?></span>
											</label>
										<?php endforeach; ?>
										<?php foreach ( KMAE_Seller::extra_commitment_defs() as $code => $info ) : ?>
											<label class="kmae-commitment-option">
												<input type="checkbox" name="kmae_commitments[]" value="<?php echo esc_attr( $code ); ?>" data-kmae-commit="<?php echo esc_attr( $code ); ?>" <?php checked( in_array( $code, $commitments, true ) ); ?> />
												<span class="kmae-commitment-option__text"><strong><?php echo esc_html( $info['label'] ); ?></strong><span class="kmae-commitment-option__desc"><?php echo esc_html( $info['desc'] ); ?></span></span>
											</label>
										<?php endforeach; ?>
									</div>
									<div class="kmae-field kmae-extra-other-field" style="<?php echo in_array( KMAE_Seller::COMMIT_OTHER, $commitments, true ) ? '' : 'display:none;'; ?>">
										<label for="kmae_commit_extra_other"><?php esc_html_e( 'Egyéb vállalás leírása *', 'ki-mit-adna-erte' ); ?></label>
										<input type="text" name="kmae_commit_extra_other" id="kmae_commit_extra_other" value="<?php echo esc_attr( $extra_other_val ); ?>" maxlength="80" placeholder="<?php esc_attr_e( 'Például: új akkumulátor jár hozzá', 'ki-mit-adna-erte' ); ?>" />
									</div>
								</fieldset>
							</div>
						</section>

						<section class="kmae-create-section" aria-labelledby="kmae-section-finish">
							<div class="kmae-create-section__head">
								<span class="kmae-create-section__number">05</span>
								<div>
									<h2 id="kmae-section-finish"><?php esc_html_e( 'Fotók és közzététel', 'ki-mit-adna-erte' ); ?></h2>
									<p><?php esc_html_e( 'A végén ellenőrizd az adatokat, és készítsd el a hirdetés fotóit.', 'ki-mit-adna-erte' ); ?></p>
								</div>
							</div>
							<div class="kmae-create-section__body">
								<?php if ( $is_edit && ! empty( $gallery_ids ) && ! KMAE_Photo_Motor::is_enabled() ) : ?>
									<?php $listing_id = $listing->ID; include KMAE_PLUGIN_DIR . 'templates/partials/listing-gallery-manager.php'; ?>
								<?php endif; ?>

								<?php if ( ! KMAE_Photo_Motor::is_enabled() ) : ?>
									<div class="kmae-field">
										<label for="kmae_images"><?php echo $is_edit ? esc_html__( 'Új képek (opcionális, maximum 12 összesen)', 'ki-mit-adna-erte' ) : esc_html( sprintf( __( 'Képek * (minimum %d, maximum 12)', 'ki-mit-adna-erte' ), $min_images ) ); ?></label>
										<input type="file" name="kmae_images[]" id="kmae_images" accept="image/*" multiple <?php echo $is_edit ? '' : 'required'; ?> />
									</div>
								<?php else : ?>
									<?php
									$gate_slots = ( $is_edit && $listing ) ? KMAE_Photo_Motor::get_slots( $listing->ID ) : array();
									$gate_req_fill = 0;
									$gate_all_fill = 0;
									foreach ( array_keys( KMAE_Photo_Motor::required_slots() ) as $gk ) {
										if ( ! empty( $gate_slots[ $gk ] ) ) { $gate_req_fill++; $gate_all_fill++; }
									}
									foreach ( array_keys( KMAE_Photo_Motor::recommended_slots() ) as $gk ) {
										if ( ! empty( $gate_slots[ $gk ] ) ) { $gate_all_fill++; }
									}
									$gate_ready = $gate_req_fill >= KMAE_Photo_Motor::required_count();
									?>
									<div class="kmae-photo-gate" id="kmae-photo-gate" data-ready="<?php echo $gate_ready ? '1' : '0'; ?>" data-awaiting="<?php echo $is_awaiting ? '1' : '0'; ?>">
										<div class="kmae-photo-gate__icon" aria-hidden="true"><?php echo KMAE_Icons::render( 'car', array( 'size' => 26 ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
										<div class="kmae-photo-gate__summary">
											<strong><?php esc_html_e( 'Autófotók', 'ki-mit-adna-erte' ); ?></strong>
											<p class="kmae-hint" id="kmae-photo-gate-status"><?php printf( esc_html__( 'Kötelező: %1$d / %2$d · Összes: %3$d / %4$d', 'ki-mit-adna-erte' ), (int) $gate_req_fill, (int) KMAE_Photo_Motor::required_count(), (int) $gate_all_fill, (int) KMAE_Photo_Motor::recommended_total_count() ); ?></p>
											<p class="kmae-hint" id="kmae-photo-gate-hint"><?php esc_html_e( 'A fotókat az Albira kamera-folyamatával készítsd el.', 'ki-mit-adna-erte' ); ?></p>
											<p class="kmae-hint" id="kmae-photo-gate-computer-hint" hidden><?php esc_html_e( 'Most elmentheted az adatokat; a fotókat később telefonról készítheted el.', 'ki-mit-adna-erte' ); ?></p>
										</div>
										<button type="button" class="kmae-btn kmae-btn-primary" id="kmae-open-photo-step"><?php echo $gate_ready ? esc_html__( 'Fotók szerkesztése', 'ki-mit-adna-erte' ) : esc_html__( 'Fotók készítése', 'ki-mit-adna-erte' ); ?></button>
									</div>
								<?php endif; ?>

								<?php if ( ! $is_edit && KMAE_Moderation::is_enabled() ) : ?>
									<label class="kmae-checkbox kmae-moderation-consent">
										<input type="checkbox" name="kmae_moderation_consent" value="1" required />
										<span><?php esc_html_e( 'Elfogadom, hogy a rendszer közzététel előtt automatikusan ellenőrzi a hirdetés teljességét és minőségét.', 'ki-mit-adna-erte' ); ?></span>
									</label>
								<?php endif; ?>

								<div class="kmae-create-submit">
									<div>
										<strong><?php esc_html_e( 'Minden készen áll?', 'ki-mit-adna-erte' ); ?></strong>
										<p class="kmae-hint" id="kmae-listing-submit-hint"><?php esc_html_e( 'Ellenőrizd a kötelező mezőket, majd mentsd a hirdetést.', 'ki-mit-adna-erte' ); ?></p>
									</div>
									<div class="kmae-form-actions">
										<a href="<?php echo esc_url( $cancel_url ); ?>" class="kmae-btn kmae-btn-secondary"><?php esc_html_e( 'Mégse', 'ki-mit-adna-erte' ); ?></a>
										<button type="submit" class="kmae-btn kmae-btn-primary" id="kmae-listing-submit" <?php echo ( KMAE_Photo_Motor::is_enabled() && ! $is_edit ) ? 'disabled' : ''; ?>>
											<?php echo $is_edit ? esc_html__( 'Módosítások mentése', 'ki-mit-adna-erte' ) : esc_html__( 'Hirdetés mentése', 'ki-mit-adna-erte' ); ?>
										</button>
									</div>
								</div>
							</div>
						</section>
					</div>

					<?php if ( KMAE_Photo_Motor::is_enabled() ) : ?>
						<?php include KMAE_PLUGIN_DIR . 'templates/partials/listing-photo-motor.php'; ?>
					<?php endif; ?>
				</form>

				<div class="kmae-lightbox kmae-form-lightbox" hidden aria-hidden="true">
					<div class="kmae-lightbox-backdrop" data-close="1"></div>
					<div class="kmae-lightbox-inner">
						<button type="button" class="kmae-lightbox-close" aria-label="<?php esc_attr_e( 'Bezárás', 'ki-mit-adna-erte' ); ?>">&times;</button>
						<img src="" alt="" class="kmae-lightbox-img" />
					</div>
				</div>
			<?php endif; ?>
		</div>
	</main>
</div>
