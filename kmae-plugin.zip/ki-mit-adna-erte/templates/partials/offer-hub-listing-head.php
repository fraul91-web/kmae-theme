<?php
/**
 * Listing thumbnail for offer hub cards.
 *
 * @package KMAE
 * @var WP_Post $listing
 * @var string  $offer_thread_url
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$thumb_url = KMAE_Query::get_listing_thumbnail_url( $listing->ID, 'medium' );
$link_url  = ! empty( $offer_thread_url ) ? $offer_thread_url : get_permalink( $listing->ID );
?>
<a href="<?php echo esc_url( $link_url ); ?>" class="kmae-offer-hub-thumb">
	<?php if ( $thumb_url ) : ?>
		<img src="<?php echo esc_url( $thumb_url ); ?>" alt="" loading="lazy" width="96" height="96" />
	<?php else : ?>
		<span class="kmae-offer-hub-thumb-placeholder" aria-hidden="true"></span>
	<?php endif; ?>
</a>
