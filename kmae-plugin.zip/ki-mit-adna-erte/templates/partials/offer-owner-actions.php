<?php
/**
 * Owner offer actions: accept + counter-offer.
 *
 * @package KMAE
 * @var object $offer
 * @var int    $listing_id
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$user_id         = get_current_user_id();
$negotiation     = KMAE_Counter_Offers::get_negotiation_summary( $offer );
$status_labels   = KMAE_Counter_Offers::status_labels();
$counter_templates = KMAE_Taxonomies::counter_templates();
$can_accept      = KMAE_Counter_Offers::can_seller_accept( $offer, $user_id );
$can_counter     = KMAE_Counter_Offers::can_seller_counter( $offer, $user_id );
$hub_compact     = ! empty( $hub_compact );
?>
	<div class="kmae-offer-card" id="kmae-offer-<?php echo esc_attr( $offer->id ); ?>">
	<?php if ( ! $hub_compact ) : ?>
	<div class="kmae-offer-item kmae-offer-item-header">
		<div>
			<strong><?php echo esc_html( KMAE_Offers::get_offerer_display_name( $offer->offerer_id ) ); ?></strong>
			<?php if ( KMAE_Auth::is_company( (int) $offer->offerer_id ) ) : ?>
				<span class="kmae-badge kmae-badge-accepted"><?php esc_html_e( 'Céges vevő', 'ki-mit-adna-erte' ); ?></span>
			<?php endif; ?>
			<span class="kmae-offer-amount"><?php echo esc_html( KMAE_Offers::get_offer_summary( $offer ) ); ?></span>
			<?php
			$buyer_trust = KMAE_Trust::get_summary( (int) $offer->offerer_id );
			if ( $buyer_trust['score'] > 0 || $buyer_trust['deals'] > 0 ) :
				?>
				<span class="kmae-buyer-trust-chip">
					<?php
					printf(
						/* translators: 1: trust score, 2: deals */
						esc_html__( 'Vevő bizalom: %1$s · %2$d üzlet', 'ki-mit-adna-erte' ),
						$buyer_trust['score'] > 0 ? (string) (int) $buyer_trust['score'] : '—',
						(int) $buyer_trust['deals']
					);
					?>
				</span>
			<?php endif; ?>
		</div>
		<span class="kmae-badge kmae-badge-<?php echo esc_attr( $offer->status ); ?>">
			<?php echo esc_html( $status_labels[ $offer->status ] ?? $offer->status ); ?>
		</span>
	</div>
	<?php else : ?>
		<p class="kmae-hint kmae-offer-hub-status">
			<?php esc_html_e( 'Státusz:', 'ki-mit-adna-erte' ); ?>
			<span class="kmae-badge kmae-badge-<?php echo esc_attr( $offer->status ); ?>">
				<?php echo esc_html( $status_labels[ $offer->status ] ?? $offer->status ); ?>
			</span>
		</p>
	<?php endif; ?>

	<?php echo KMAE_Offers::render_offer_images( $offer->id ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>

	<?php if ( ! empty( $negotiation['counters'] ) ) : ?>
		<div class="kmae-negotiation-history">
			<?php foreach ( $negotiation['counters'] as $counter ) : ?>
				<div class="kmae-counter-msg <?php echo (int) $counter->user_id === $user_id ? 'kmae-counter-own' : 'kmae-counter-other'; ?>">
					<span class="kmae-counter-who">
						<?php echo (int) $counter->user_id === $user_id ? esc_html__( 'Te', 'ki-mit-adna-erte' ) : esc_html( KMAE_Offers::get_offerer_display_name( $counter->user_id ) ); ?>
					</span>
					<span class="kmae-counter-text"><?php echo esc_html( KMAE_Counter_Offers::format_counter_message( $counter ) ); ?></span>
				</div>
			<?php endforeach; ?>
		</div>
	<?php endif; ?>

	<?php if ( KMAE_Offers::STATUS_PENDING === $offer->status ) : ?>
		<div class="kmae-offer-actions">
			<?php if ( $can_accept ) : ?>
				<form method="post" class="kmae-inline-form">
					<?php wp_nonce_field( 'kmae_accept_offer_nonce', 'kmae_accept_offer_nonce' ); ?>
					<input type="hidden" name="kmae_action" value="accept_offer" />
					<input type="hidden" name="kmae_offer_id" value="<?php echo esc_attr( $offer->id ); ?>" />
					<button type="submit" class="kmae-btn kmae-btn-sm kmae-btn-primary"><?php esc_html_e( 'Áll az alku', 'ki-mit-adna-erte' ); ?></button>
				</form>
			<?php elseif ( is_wp_error( KMAE_Deal::assert_buyer_can_lock( (int) $offer->offerer_id, (int) $offer->id ) ) ) : ?>
				<p class="kmae-hint"><?php esc_html_e( 'Ennek a vevőnek már van másik „Áll az alku” folyamata — előbb azt kell lezárni.', 'ki-mit-adna-erte' ); ?></p>
			<?php endif; ?>

			<?php if ( $can_counter ) : ?>
				<details class="kmae-counter-details">
					<summary class="kmae-btn kmae-btn-sm kmae-btn-secondary"><?php esc_html_e( 'Ellenajánlat', 'ki-mit-adna-erte' ); ?></summary>
					<form method="post" class="kmae-form kmae-counter-form">
						<?php wp_nonce_field( 'kmae_counter_offer_nonce', 'kmae_counter_offer_nonce' ); ?>
						<input type="hidden" name="kmae_action" value="submit_counter_offer" />
						<input type="hidden" name="kmae_offer_id" value="<?php echo esc_attr( $offer->id ); ?>" />

						<div class="kmae-field">
							<label for="kmae_template_<?php echo esc_attr( $offer->id ); ?>"><?php esc_html_e( 'Válasz', 'ki-mit-adna-erte' ); ?></label>
							<select name="kmae_template_code" id="kmae_template_<?php echo esc_attr( $offer->id ); ?>" class="kmae-counter-template" required>
								<option value=""><?php esc_html_e( 'Válassz...', 'ki-mit-adna-erte' ); ?></option>
								<?php foreach ( $counter_templates as $code => $label ) : ?>
									<option value="<?php echo esc_attr( $code ); ?>"><?php echo esc_html( $label ); ?></option>
								<?php endforeach; ?>
							</select>
						</div>

						<div class="kmae-field kmae-counter-amount-field">
							<?php
							$name        = 'kmae_counter_amount';
							$id          = 'kmae_counter_amount_' . (int) $offer->id;
							$label       = __( 'Javasolt összeg (Ft) — opcionális', 'ki-mit-adna-erte' );
							$required    = false;
							$placeholder = '';
							$value       = '';
							include KMAE_PLUGIN_DIR . 'templates/partials/cash-amount-input.php';
							?>
						</div>

						<button type="submit" class="kmae-btn kmae-btn-sm kmae-btn-primary"><?php esc_html_e( 'Ellenajánlat küldése', 'ki-mit-adna-erte' ); ?></button>
						<p class="kmae-hint">
							<?php
							printf(
								/* translators: %d: remaining rounds */
								esc_html__( 'Hátralévő ellenajánlatod: %d', 'ki-mit-adna-erte' ),
								(int) $negotiation['rounds_left_seller']
							);
							?>
						</p>
					</form>
				</details>
			<?php elseif ( KMAE_Offers::STATUS_PENDING === $offer->status ) : ?>
				<p class="kmae-hint"><?php esc_html_e( 'Várd meg a vevő válaszát, vagy fogadd el az ajánlatot.', 'ki-mit-adna-erte' ); ?></p>
			<?php endif; ?>
		</div>
	<?php elseif ( KMAE_Offers::STATUS_ACCEPTED === $offer->status ) : ?>
		<?php if ( KMAE_Deal::is_viewing_deal( $offer ) ) : ?>
			<?php include KMAE_PLUGIN_DIR . 'templates/partials/deal-outcome.php'; ?>
			<?php include KMAE_PLUGIN_DIR . 'templates/partials/contact-unlock.php'; ?>
		<?php else : ?>
			<p class="kmae-notice kmae-notice-success kmae-notice-inline"><?php esc_html_e( 'Üzlet lezárva — ez az ajánlat elfogadva.', 'ki-mit-adna-erte' ); ?></p>
			<?php include KMAE_PLUGIN_DIR . 'templates/partials/contact-unlock.php'; ?>
		<?php endif; ?>
	<?php elseif ( KMAE_Offers::STATUS_PENDING === $offer->status && KMAE_Deal::is_locked( (int) $offer->listing_id ) ) : ?>
		<div class="kmae-notice kmae-notice-info kmae-notice-inline">
			<p><strong><?php esc_html_e( 'Áll az alku (másik érdeklődő)', 'ki-mit-adna-erte' ); ?></strong></p>
			<p><?php esc_html_e( 'Az eladó egy másik érdeklődővel megy megtekintésre. Ha az üzlet sikerül, ez az ajánlat tárgytalan lesz. Ha nem, folytathatjátok.', 'ki-mit-adna-erte' ); ?></p>
		</div>
	<?php endif; ?>
</div>
