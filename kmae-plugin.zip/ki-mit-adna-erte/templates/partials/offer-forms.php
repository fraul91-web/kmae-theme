<?php
/**
 * Offer submission forms — matched to listing offer types.
 *
 * @package KMAE
 * @var int   $listing_id
 * @var array $offer_types
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$type_labels = KMAE_Taxonomies::offer_type_labels();
$buyer_hints = KMAE_Taxonomies::offer_type_buyer_hints();

$tabs = array();
if ( in_array( KMAE_OFFER_TYPE_CASH, $offer_types, true ) ) {
	$tabs['cash'] = $type_labels[ KMAE_OFFER_TYPE_CASH ];
}
if ( in_array( KMAE_OFFER_TYPE_TRADE, $offer_types, true ) ) {
	$tabs['trade'] = $type_labels[ KMAE_OFFER_TYPE_TRADE ];
}
if ( in_array( KMAE_OFFER_TYPE_TRADE_PLUS_CASH, $offer_types, true ) ) {
	$tabs['trade_cash'] = $type_labels[ KMAE_OFFER_TYPE_TRADE_PLUS_CASH ];
}
if ( in_array( KMAE_OFFER_TYPE_TRADE_IN, $offer_types, true ) ) {
	$tabs['trade_in'] = $type_labels[ KMAE_OFFER_TYPE_TRADE_IN ];
}

$default_tab = ! empty( $tabs ) ? array_key_first( $tabs ) : 'cash';
$rounds_left = KMAE_MAX_COUNTER_ROUNDS;

$trade_in_cats = get_post_meta( $listing_id, '_kmae_trade_in_categories', true );
if ( ! is_array( $trade_in_cats ) ) {
	$trade_in_cats = array();
}
?>
<div class="kmae-offer-zone" data-kmae-offer-zone data-kmae-rounds-left="<?php echo esc_attr( $rounds_left ); ?>">
	<?php if ( empty( $tabs ) ) : ?>
		<p class="kmae-hint"><?php esc_html_e( 'Ez a hirdetés jelenleg nem fogad ajánlatot.', 'ki-mit-adna-erte' ); ?></p>
	<?php else : ?>
	<div class="kmae-offer-tabs" data-default-tab="<?php echo esc_attr( $default_tab ); ?>">
		<div class="kmae-tab-buttons">
			<?php
			$first = true;
			foreach ( $tabs as $tab_id => $tab_label ) :
				?>
				<button type="button" class="kmae-tab-btn <?php echo $first ? 'active' : ''; ?>" data-tab="<?php echo esc_attr( $tab_id ); ?>"><?php echo esc_html( $tab_label ); ?></button>
				<?php
				$first = false;
			endforeach;
			?>
		</div>

		<?php if ( isset( $tabs['cash'] ) ) : ?>
			<div class="kmae-tab-panel <?php echo 'cash' === $default_tab ? 'active' : ''; ?>" data-panel="cash">
				<?php if ( KMAE_Seller::is_fixed_price( $listing_id ) ) : ?>
					<?php $fixed_price = KMAE_Seller::get_fixed_price( $listing_id ); ?>
					<p class="kmae-offer-tab-hint">
						<?php
						printf(
							/* translators: %s: formatted fixed price */
							esc_html__( 'Az eladó fix árat adott meg: %s', 'ki-mit-adna-erte' ),
							esc_html( KMAE_Offers::format_cash( $fixed_price ) )
						);
						?>
					</p>
					<form method="post" class="kmae-form kmae-offer-form">
						<?php wp_nonce_field( 'kmae_offer_nonce', 'kmae_offer_nonce' ); ?>
						<input type="hidden" name="kmae_action" value="submit_cash_offer" />
						<input type="hidden" name="kmae_listing_id" value="<?php echo esc_attr( $listing_id ); ?>" />
						<input type="hidden" name="kmae_cash_amount" value="<?php echo esc_attr( $fixed_price ); ?>" />
						<?php include KMAE_PLUGIN_DIR . 'templates/partials/fair-buyer-pledge.php'; ?>
						<button type="submit" class="kmae-btn kmae-btn-primary">
							<?php
							printf(
								/* translators: %s: formatted price */
								esc_html__( 'Megadom érte: %s', 'ki-mit-adna-erte' ),
								esc_html( KMAE_Offers::format_cash( $fixed_price ) )
							);
							?>
						</button>
					</form>
				<?php else : ?>
					<p class="kmae-offer-tab-hint"><?php echo esc_html( $buyer_hints[ KMAE_OFFER_TYPE_CASH ] ); ?></p>
					<form method="post" class="kmae-form kmae-offer-form">
						<?php wp_nonce_field( 'kmae_offer_nonce', 'kmae_offer_nonce' ); ?>
						<input type="hidden" name="kmae_action" value="submit_cash_offer" />
						<input type="hidden" name="kmae_listing_id" value="<?php echo esc_attr( $listing_id ); ?>" />
						<div class="kmae-field">
							<?php
							$name        = 'kmae_cash_amount';
							$id          = 'kmae_cash_amount_' . (int) $listing_id;
							$label       = __( 'Készpénzes ajánlat (Ft)', 'ki-mit-adna-erte' );
							$required    = true;
							$placeholder = '';
							$value       = '';
							include KMAE_PLUGIN_DIR . 'templates/partials/cash-amount-input.php';
							?>
						</div>
						<?php include KMAE_PLUGIN_DIR . 'templates/partials/fair-buyer-pledge.php'; ?>
						<button type="submit" class="kmae-btn kmae-btn-primary"><?php esc_html_e( 'Ajánlat elküldése', 'ki-mit-adna-erte' ); ?></button>
					</form>
				<?php endif; ?>
			</div>
		<?php endif; ?>

		<?php if ( isset( $tabs['trade'] ) ) : ?>
			<div class="kmae-tab-panel <?php echo 'trade' === $default_tab ? 'active' : ''; ?>" data-panel="trade">
				<p class="kmae-offer-tab-hint"><?php echo esc_html( $buyer_hints[ KMAE_OFFER_TYPE_TRADE ] ); ?></p>
				<form method="post" enctype="multipart/form-data" class="kmae-form">
					<?php wp_nonce_field( 'kmae_trade_offer_nonce', 'kmae_trade_offer_nonce' ); ?>
					<input type="hidden" name="kmae_action" value="submit_trade_offer" />
					<input type="hidden" name="kmae_listing_id" value="<?php echo esc_attr( $listing_id ); ?>" />
					<input type="hidden" name="kmae_trade_mode" value="trade" />
					<div class="kmae-field">
						<label><?php esc_html_e( 'Mit ajánlasz cserébe? (kép)', 'ki-mit-adna-erte' ); ?></label>
						<input type="file" name="kmae_trade_images[]" accept="image/*" multiple required />
						<p class="kmae-hint"><?php esc_html_e( 'Azonos típusú termék — pl. autó képe autó ellenében.', 'ki-mit-adna-erte' ); ?></p>
					</div>
					<?php include KMAE_PLUGIN_DIR . 'templates/partials/fair-buyer-pledge.php'; ?>
					<button type="submit" class="kmae-btn kmae-btn-primary"><?php esc_html_e( 'Csere ajánlat küldése', 'ki-mit-adna-erte' ); ?></button>
				</form>
			</div>
		<?php endif; ?>

		<?php if ( isset( $tabs['trade_cash'] ) ) : ?>
			<div class="kmae-tab-panel <?php echo 'trade_cash' === $default_tab ? 'active' : ''; ?>" data-panel="trade_cash">
				<p class="kmae-offer-tab-hint"><?php echo esc_html( $buyer_hints[ KMAE_OFFER_TYPE_TRADE_PLUS_CASH ] ); ?></p>
				<form method="post" enctype="multipart/form-data" class="kmae-form">
					<?php wp_nonce_field( 'kmae_trade_offer_nonce', 'kmae_trade_offer_nonce' ); ?>
					<input type="hidden" name="kmae_action" value="submit_trade_offer" />
					<input type="hidden" name="kmae_listing_id" value="<?php echo esc_attr( $listing_id ); ?>" />
					<input type="hidden" name="kmae_trade_mode" value="trade_plus_cash" />
					<div class="kmae-field">
						<label><?php esc_html_e( 'Csere tárgy képe(i)', 'ki-mit-adna-erte' ); ?></label>
						<input type="file" name="kmae_trade_images[]" accept="image/*" multiple required />
						<p class="kmae-hint"><?php esc_html_e( 'Azonos típusú termék — pl. autó képe.', 'ki-mit-adna-erte' ); ?></p>
					</div>
					<div class="kmae-field">
						<?php
						$name        = 'kmae_extra_cash';
						$id          = 'kmae_extra_cash_' . (int) $listing_id;
						$label       = __( 'Ráfizetés (Ft) — ha szükséges', 'ki-mit-adna-erte' );
						$required    = false;
						$placeholder = '';
						$value       = '';
						include KMAE_PLUGIN_DIR . 'templates/partials/cash-amount-input.php';
						?>
					</div>
					<?php include KMAE_PLUGIN_DIR . 'templates/partials/fair-buyer-pledge.php'; ?>
					<button type="submit" class="kmae-btn kmae-btn-primary"><?php esc_html_e( 'Ajánlat küldése', 'ki-mit-adna-erte' ); ?></button>
				</form>
			</div>
		<?php endif; ?>

		<?php if ( isset( $tabs['trade_in'] ) ) : ?>
			<div class="kmae-tab-panel <?php echo 'trade_in' === $default_tab ? 'active' : ''; ?>" data-panel="trade_in">
				<p class="kmae-offer-tab-hint"><?php echo esc_html( $buyer_hints[ KMAE_OFFER_TYPE_TRADE_IN ] ); ?></p>
				<?php if ( ! empty( $trade_in_cats ) ) : ?>
					<div class="kmae-trade-in-accepted">
						<strong><?php esc_html_e( 'Eladó ezeket keresi:', 'ki-mit-adna-erte' ); ?></strong>
						<div class="kmae-type-tags">
							<?php
							foreach ( $trade_in_cats as $cat_id ) {
								$term = get_term( (int) $cat_id, 'kmae_category' );
								if ( $term && ! is_wp_error( $term ) ) {
									echo '<span class="kmae-type-tag">' . esc_html( $term->name ) . '</span>';
								}
							}
							?>
						</div>
					</div>
				<?php endif; ?>
				<form method="post" enctype="multipart/form-data" class="kmae-form">
					<?php wp_nonce_field( 'kmae_trade_offer_nonce', 'kmae_trade_offer_nonce' ); ?>
					<input type="hidden" name="kmae_action" value="submit_trade_offer" />
					<input type="hidden" name="kmae_listing_id" value="<?php echo esc_attr( $listing_id ); ?>" />
					<input type="hidden" name="kmae_trade_mode" value="trade_in" />
					<div class="kmae-field">
						<label><?php esc_html_e( 'Beszámítás tárgy képe(i)', 'ki-mit-adna-erte' ); ?></label>
						<input type="file" name="kmae_trade_images[]" accept="image/*" multiple required />
						<p class="kmae-hint"><?php esc_html_e( 'Küldd el a termék képeit — a fenti kategóriák egyikéből.', 'ki-mit-adna-erte' ); ?></p>
					</div>
					<div class="kmae-field">
						<?php
						$name        = 'kmae_extra_cash';
						$id          = 'kmae_trade_in_cash_' . (int) $listing_id;
						$label       = __( 'Plusz készpénz (Ft) — opcionális', 'ki-mit-adna-erte' );
						$required    = false;
						$placeholder = '';
						$value       = '';
						include KMAE_PLUGIN_DIR . 'templates/partials/cash-amount-input.php';
						?>
					</div>
					<?php include KMAE_PLUGIN_DIR . 'templates/partials/fair-buyer-pledge.php'; ?>
					<button type="submit" class="kmae-btn kmae-btn-primary"><?php esc_html_e( 'Beszámítási ajánlat küldése', 'ki-mit-adna-erte' ); ?></button>
				</form>
			</div>
		<?php endif; ?>
	</div>
	<?php endif; ?>
</div>
