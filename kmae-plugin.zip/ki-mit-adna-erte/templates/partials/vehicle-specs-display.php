<?php
/**
 * Vehicle specs display grid.
 *
 * @package KMAE
 * @var int $listing_id
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$rows = KMAE_Vehicle::get_display_rows( $listing_id );
if ( empty( $rows ) ) {
	return;
}
?>
<div class="kmae-vehicle-specs">
	<?php foreach ( $rows as $row ) : ?>
		<div class="kmae-vehicle-spec">
			<span class="kmae-vehicle-spec-label"><?php echo esc_html( $row['label'] ); ?></span>
			<span class="kmae-vehicle-spec-value"><?php echo esc_html( $row['value'] ); ?></span>
		</div>
	<?php endforeach; ?>
</div>
