<?php
/**
 * Withdraw pending offer (buyer only).
 *
 * @package KMAE
 * @var object $offer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$user_id = get_current_user_id();
if ( ! KMAE_Offers::can_withdraw( $offer, $user_id ) ) {
	return;
}
?>
<form
	method="post"
	class="kmae-withdraw-offer-form"
	onsubmit="return confirm('<?php echo esc_js( __( 'Biztosan visszavonod az ajánlatod? Ez végleges — erre a hirdetésre nem adhatsz több ajánlatot.', 'ki-mit-adna-erte' ) ); ?>');"
>
	<?php wp_nonce_field( 'kmae_withdraw_offer_nonce', 'kmae_withdraw_offer_nonce' ); ?>
	<input type="hidden" name="kmae_action" value="withdraw_offer" />
	<input type="hidden" name="kmae_offer_id" value="<?php echo esc_attr( $offer->id ); ?>" />
	<button type="submit" class="kmae-btn kmae-btn-sm kmae-btn-danger kmae-btn-withdraw">
		<?php esc_html_e( 'Ajánlat visszavonása', 'ki-mit-adna-erte' ); ?>
	</button>
</form>
