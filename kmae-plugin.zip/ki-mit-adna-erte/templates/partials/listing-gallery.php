<?php
/**
 * Listing image gallery.
 *
 * @package KMAE
 * @var int         $listing_id
 * @var string|null $gallery_class Extra CSS class(es), e.g. kmae-gallery--card.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$gallery_ids = KMAE_Query::get_gallery_ids( $listing_id );
if ( empty( $gallery_ids ) ) {
	return;
}

$lightbox_id = 'kmae-lightbox-' . $listing_id;
$extra_class = isset( $gallery_class ) ? trim( (string) $gallery_class ) : '';
$full_urls   = array();

foreach ( $gallery_ids as $aid ) {
	$url = KMAE_Images::get_url( $aid, 'full' );
	if ( $url ) {
		$full_urls[] = $url;
	}
}
?>
<div
	class="kmae-gallery<?php echo $extra_class ? ' ' . esc_attr( $extra_class ) : ''; ?>"
	data-full-urls="<?php echo esc_attr( wp_json_encode( $full_urls ) ); ?>"
>
	<?php if ( count( $gallery_ids ) > 1 ) : ?>
		<button type="button" class="kmae-gallery-nav kmae-gallery-prev" aria-label="<?php esc_attr_e( 'Előző kép', 'ki-mit-adna-erte' ); ?>">&#8249;</button>
		<button type="button" class="kmae-gallery-nav kmae-gallery-next" aria-label="<?php esc_attr_e( 'Következő kép', 'ki-mit-adna-erte' ); ?>">&#8250;</button>
	<?php endif; ?>

	<div class="kmae-gallery-stage">
		<?php foreach ( $gallery_ids as $i => $aid ) : ?>
			<?php
			$full_url = KMAE_Images::get_url( $aid, 'full' );
			if ( ! $full_url ) {
				continue;
			}
			?>
			<button
				type="button"
				class="kmae-gallery-slide <?php echo 0 === $i ? 'active' : ''; ?>"
				data-index="<?php echo esc_attr( $i ); ?>"
				data-full="<?php echo esc_url( $full_url ); ?>"
				aria-label="<?php esc_attr_e( 'Kép nagyítása', 'ki-mit-adna-erte' ); ?>"
			>
				<img
					src="<?php echo esc_url( $full_url ); ?>"
					alt=""
					class="kmae-gallery-img"
					loading="<?php echo 0 === $i ? 'eager' : 'lazy'; ?>"
					decoding="async"
				/>
			</button>
		<?php endforeach; ?>
	</div>

	<?php if ( count( $gallery_ids ) > 1 ) : ?>
		<div class="kmae-gallery-dots">
			<?php foreach ( $gallery_ids as $i => $aid ) : ?>
				<button type="button" class="kmae-gallery-dot <?php echo 0 === $i ? 'active' : ''; ?>" data-index="<?php echo esc_attr( $i ); ?>" aria-label="<?php echo esc_attr( sprintf( __( '%d. kép', 'ki-mit-adna-erte' ), $i + 1 ) ); ?>"></button>
			<?php endforeach; ?>
		</div>
		<span class="kmae-gallery-counter">1 / <?php echo esc_html( count( $gallery_ids ) ); ?></span>
	<?php endif; ?>

	<span class="kmae-gallery-zoom-hint"><?php esc_html_e( 'Kattints a nagyításhoz', 'ki-mit-adna-erte' ); ?></span>
</div>

<div class="kmae-lightbox" id="<?php echo esc_attr( $lightbox_id ); ?>" hidden aria-hidden="true" data-index="0">
	<div class="kmae-lightbox-backdrop" data-close="1"></div>
	<div class="kmae-lightbox-inner">
		<button type="button" class="kmae-lightbox-close" aria-label="<?php esc_attr_e( 'Bezárés', 'ki-mit-adna-erte' ); ?>">&times;</button>
		<button type="button" class="kmae-lightbox-nav kmae-lightbox-prev" aria-label="<?php esc_attr_e( 'Előző kép', 'ki-mit-adna-erte' ); ?>" hidden>&#8249;</button>
		<img src="" alt="" class="kmae-lightbox-img" />
		<button type="button" class="kmae-lightbox-nav kmae-lightbox-next" aria-label="<?php esc_attr_e( 'Következő kép', 'ki-mit-adna-erte' ); ?>" hidden>&#8250;</button>
	</div>
</div>
