<?php
/**
 * Cash amount text input with live thousands formatting.
 *
 * @package KMAE
 * @var string $name
 * @var string $id
 * @var bool   $required
 * @var string $placeholder
 * @var string $value
 * @var string $label Optional label text (renders label element when set).
 * @var string $class Extra input classes.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$required    = ! empty( $required );
$placeholder = isset( $placeholder ) ? $placeholder : '';
$value       = isset( $value ) ? $value : '';
$class       = isset( $class ) ? $class : '';
$input_class = trim( 'kmae-cash-input ' . $class );
?>
<?php if ( ! empty( $label ) ) : ?>
	<label for="<?php echo esc_attr( $id ); ?>"><?php echo esc_html( $label ); ?></label>
<?php endif; ?>
<input
	type="text"
	name="<?php echo esc_attr( $name ); ?>"
	id="<?php echo esc_attr( $id ); ?>"
	class="<?php echo esc_attr( $input_class ); ?>"
	data-kmae-cash-input
	inputmode="numeric"
	autocomplete="off"
	<?php echo $required ? 'required' : ''; ?>
	placeholder="<?php echo esc_attr( $placeholder ); ?>"
	value="<?php echo esc_attr( $value ); ?>"
/>
