<?php
/**
 * Áll az alku — viewing outcome (sikerült / nem sikerült).
 *
 * @package KMAE
 * @var object $offer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! KMAE_Deal::is_viewing_deal( $offer ) ) {
	return;
}

$user_id = get_current_user_id();
if ( ! KMAE_Deal::can_confirm( $offer, $user_id ) ) {
	return;
}
?>
<div class="kmae-deal-outcome">
	<div class="kmae-notice kmae-notice-info">
		<p><strong><?php esc_html_e( 'Áll az alku', 'ki-mit-adna-erte' ); ?></strong></p>
		<p><?php esc_html_e( 'Megállapodtatok — a vevő elmegy megnézni az autót. A többi érdeklődőt a rendszer értesítette. A találkozó után jelezd az eredményt:', 'ki-mit-adna-erte' ); ?></p>
	</div>

	<div class="kmae-deal-outcome__actions">
		<form method="post" class="kmae-inline-form">
			<?php wp_nonce_field( 'kmae_deal_success_nonce', 'kmae_deal_success_nonce' ); ?>
			<input type="hidden" name="kmae_action" value="deal_success" />
			<input type="hidden" name="kmae_offer_id" value="<?php echo esc_attr( $offer->id ); ?>" />
			<button type="submit" class="kmae-btn kmae-btn-primary"><?php esc_html_e( 'Sikerült az üzlet', 'ki-mit-adna-erte' ); ?></button>
		</form>
		<form method="post" class="kmae-inline-form">
			<?php wp_nonce_field( 'kmae_deal_failure_nonce', 'kmae_deal_failure_nonce' ); ?>
			<input type="hidden" name="kmae_action" value="deal_failure" />
			<input type="hidden" name="kmae_offer_id" value="<?php echo esc_attr( $offer->id ); ?>" />
			<button type="submit" class="kmae-btn kmae-btn-secondary"><?php esc_html_e( 'Nem sikerült', 'ki-mit-adna-erte' ); ?></button>
		</form>
	</div>
	<p class="kmae-hint"><?php esc_html_e( 'Ha sikerült: a hirdetés lezárul, a többi ajánlat tárgytalan. Ha nem: az alku feloldódik, folytathatjátok a tárgyalást.', 'ki-mit-adna-erte' ); ?></p>
</div>
