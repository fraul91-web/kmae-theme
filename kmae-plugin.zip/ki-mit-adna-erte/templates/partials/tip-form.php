<?php
/**
 * Seller tip form for a sold offer (tip goes to buyer).
 *
 * @package KMAE
 * @var object $offer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! KMAE_Tips::can_tip( $offer, get_current_user_id() ) ) {
	return;
}

$buyer   = get_userdata( (int) $offer->offerer_id );
$listing = get_post( $offer->listing_id );
$presets = KMAE_Tips::preset_amounts();
?>
<div class="kmae-tip-form">
	<h3><?php esc_html_e( 'Borravaló a vevőnek', 'ki-mit-adna-erte' ); ?></h3>
	<p class="kmae-hint">
		<?php
		printf(
			/* translators: 1: listing, 2: buyer name */
			esc_html__( 'Sikeres üzlet („%1$s”). A borravalót a vevő kapja (%2$s) — e-mailben értesítjük.', 'ki-mit-adna-erte' ),
			esc_html( $listing ? $listing->post_title : '' ),
			esc_html( $buyer ? KMAE_Offers::get_offerer_display_name( $buyer->ID ) : __( 'vevő', 'ki-mit-adna-erte' ) )
		);
		?>
	</p>
	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="kmae-form">
		<?php wp_nonce_field( 'kmae_send_tip', 'kmae_tip_nonce' ); ?>
		<input type="hidden" name="action" value="kmae_send_tip" />
		<input type="hidden" name="kmae_offer_id" value="<?php echo esc_attr( $offer->id ); ?>" />

		<fieldset class="kmae-fieldset">
			<legend><?php esc_html_e( 'Összeg', 'ki-mit-adna-erte' ); ?></legend>
			<div class="kmae-tip-presets">
				<?php foreach ( $presets as $i => $amt ) : ?>
					<label class="kmae-tip-preset">
						<input type="radio" name="kmae_tip_amount" value="<?php echo esc_attr( $amt ); ?>" <?php checked( 0 === $i ); ?> required />
						<span><?php echo esc_html( KMAE_Offers::format_cash( $amt ) ); ?></span>
					</label>
				<?php endforeach; ?>
			</div>
		</fieldset>

		<div class="kmae-field">
			<label for="kmae_tip_message_<?php echo esc_attr( $offer->id ); ?>"><?php esc_html_e( 'Üzenet (opcionális)', 'ki-mit-adna-erte' ); ?></label>
			<textarea name="kmae_tip_message" id="kmae_tip_message_<?php echo esc_attr( $offer->id ); ?>" rows="2" maxlength="300" placeholder="<?php esc_attr_e( 'Köszönöm a korrekt üzletet!', 'ki-mit-adna-erte' ); ?>"></textarea>
		</div>

		<button type="submit" class="kmae-btn kmae-btn-primary"><?php esc_html_e( 'Borravaló küldése', 'ki-mit-adna-erte' ); ?></button>
	</form>
</div>
