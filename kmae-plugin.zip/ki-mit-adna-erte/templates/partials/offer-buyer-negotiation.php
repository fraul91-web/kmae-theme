<?php
/**
 * Buyer negotiation: view counter-offers and respond.
 *
 * @package KMAE
 * @var object $offer
 * @var int    $listing_id
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$user_id       = get_current_user_id();
$negotiation   = KMAE_Counter_Offers::get_negotiation_summary( $offer );
$status_labels = KMAE_Counter_Offers::status_labels();
$latest        = $negotiation['latest'];
$can_revise    = KMAE_Counter_Offers::can_buyer_revise( $offer, $user_id );
$can_accept    = KMAE_Counter_Offers::can_buyer_accept( $offer, $user_id );
?>
<div class="kmae-buyer-negotiation">
	<?php if ( ! empty( $negotiation['counters'] ) ) : ?>
		<div class="kmae-negotiation-history">
			<h3><?php esc_html_e( 'Alkudozás', 'ki-mit-adna-erte' ); ?></h3>
			<?php foreach ( $negotiation['counters'] as $counter ) : ?>
				<div class="kmae-counter-msg <?php echo (int) $counter->user_id === $user_id ? 'kmae-counter-own' : 'kmae-counter-other'; ?>">
					<span class="kmae-counter-who">
						<?php echo (int) $counter->user_id === $user_id ? esc_html__( 'Te', 'ki-mit-adna-erte' ) : esc_html__( 'Eladó', 'ki-mit-adna-erte' ); ?>
					</span>
					<span class="kmae-counter-text"><?php echo esc_html( KMAE_Counter_Offers::format_counter_message( $counter ) ); ?></span>
				</div>
			<?php endforeach; ?>
		</div>
	<?php endif; ?>

	<?php if ( KMAE_Offers::STATUS_ACCEPTED === $offer->status ) : ?>
		<?php if ( KMAE_Deal::is_viewing_deal( $offer ) ) : ?>
			<?php include KMAE_PLUGIN_DIR . 'templates/partials/deal-outcome.php'; ?>
		<?php else : ?>
			<div class="kmae-notice kmae-notice-success">
				<?php esc_html_e( 'Üzlet lezárva — az ajánlat elfogadva.', 'ki-mit-adna-erte' ); ?>
			</div>
		<?php endif; ?>
	<?php elseif ( KMAE_Offers::STATUS_PENDING === $offer->status && $latest && KMAE_Counter_Offers::is_seller( $offer, $latest->user_id ) ) : ?>
		<div class="kmae-buyer-response">
			<h3><?php esc_html_e( 'Ellenajánlat érkezett', 'ki-mit-adna-erte' ); ?></h3>
			<p class="kmae-counter-latest"><?php echo esc_html( KMAE_Counter_Offers::format_counter_message( $latest ) ); ?></p>

			<?php if ( $can_accept ) : ?>
				<form method="post" class="kmae-inline-form">
					<?php wp_nonce_field( 'kmae_accept_offer_nonce', 'kmae_accept_offer_nonce' ); ?>
					<input type="hidden" name="kmae_action" value="accept_offer" />
					<input type="hidden" name="kmae_offer_id" value="<?php echo esc_attr( $offer->id ); ?>" />
					<button type="submit" class="kmae-btn kmae-btn-sm kmae-btn-primary">
						<?php
						if ( $latest->cash_amount > 0 ) {
							printf(
								/* translators: %s: amount */
								esc_html__( 'Áll az alku (%s)', 'ki-mit-adna-erte' ),
								esc_html( KMAE_Offers::format_cash( $latest->cash_amount ) )
							);
						} else {
							esc_html_e( 'Áll az alku', 'ki-mit-adna-erte' );
						}
						?>
					</button>
				</form>
			<?php elseif ( is_wp_error( KMAE_Deal::assert_buyer_can_lock( $user_id, (int) $offer->id ) ) ) : ?>
				<p class="kmae-hint"><?php esc_html_e( 'Már van egy „Áll az alku” folyamatban. Egyszerre csak egy autónál lehet.', 'ki-mit-adna-erte' ); ?></p>
			<?php endif; ?>

			<?php if ( $can_revise ) : ?>
				<form method="post" class="kmae-form kmae-revise-form">
					<?php wp_nonce_field( 'kmae_revise_offer_nonce', 'kmae_revise_offer_nonce' ); ?>
					<input type="hidden" name="kmae_action" value="revise_offer" />
					<input type="hidden" name="kmae_offer_id" value="<?php echo esc_attr( $offer->id ); ?>" />
					<div class="kmae-field">
						<?php
						$name        = 'kmae_cash_amount';
						$id          = 'kmae_revise_amount_' . (int) $offer->id;
						$label       = __( 'Új összeg (Ft)', 'ki-mit-adna-erte' );
						$required    = true;
						$placeholder = '';
						$value       = '';
						include KMAE_PLUGIN_DIR . 'templates/partials/cash-amount-input.php';
						?>
					</div>
					<button type="submit" class="kmae-btn kmae-btn-sm kmae-btn-secondary"><?php esc_html_e( 'Új összeget küldök', 'ki-mit-adna-erte' ); ?></button>
					<p class="kmae-hint">
						<?php
						printf(
							esc_html__( 'Hátralévő módosításod: %d', 'ki-mit-adna-erte' ),
							(int) $negotiation['rounds_left_buyer']
						);
						?>
					</p>
				</form>
			<?php else : ?>
				<p class="kmae-hint"><?php esc_html_e( 'Elérted a maximum alkudozási kört. Elfogadás vagy nincs üzlet.', 'ki-mit-adna-erte' ); ?></p>
			<?php endif; ?>
		</div>
	<?php elseif ( KMAE_Offers::STATUS_REJECTED === $offer->status ) : ?>
		<p class="kmae-hint"><?php esc_html_e( 'Az ajánlatod elutasításra került — az eladó másik ajánlatot fogadott el.', 'ki-mit-adna-erte' ); ?></p>
	<?php elseif ( KMAE_Offers::STATUS_WITHDRAWN === $offer->status ) : ?>
		<p class="kmae-hint"><?php esc_html_e( 'Visszavontad az ajánlatodat. Erre a hirdetésre nem adhatsz több ajánlatot.', 'ki-mit-adna-erte' ); ?></p>
	<?php elseif ( KMAE_Offers::STATUS_PENDING === $offer->status && KMAE_Deal::is_locked( (int) $offer->listing_id ) ) : ?>
		<div class="kmae-notice kmae-notice-info">
			<p><strong><?php esc_html_e( 'Áll az alku (másik érdeklődő)', 'ki-mit-adna-erte' ); ?></strong></p>
			<p><?php esc_html_e( 'Az eladó egy másik érdeklődővel megy megtekintésre. Ha sikerül az üzlet, az ajánlatod tárgytalan lesz. Ha nem, folytathatjátok.', 'ki-mit-adna-erte' ); ?></p>
		</div>
	<?php elseif ( KMAE_Offers::STATUS_PENDING === $offer->status ) : ?>
		<p class="kmae-hint"><?php esc_html_e( 'Várod az eladó válaszát...', 'ki-mit-adna-erte' ); ?></p>
	<?php endif; ?>

	<?php if ( KMAE_Offers::STATUS_ACCEPTED === $offer->status ) : ?>
		<?php include KMAE_PLUGIN_DIR . 'templates/partials/contact-unlock.php'; ?>
	<?php endif; ?>
</div>
