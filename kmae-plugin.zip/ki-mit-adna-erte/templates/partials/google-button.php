<?php
/**
 * Google-gomb a belépés és a regisztráció oldalon.
 *
 * Ugyanaz a folyamat mindkét helyen — a rendszer magától eldönti, hogy
 * belépés vagy új fiók következik —, de a felirat és a hely eltér, mert
 * más a látogató szándéka. Csak akkor jelenik meg, ha a kulcsok be vannak
 * állítva (Albira → Beállítások).
 *
 * @package KMAE
 * @var string $google_redirect Ahova belépés után visszatér (opcionális).
 * @var string $google_label    A gomb felirata (opcionális).
 * @var string $google_layout   'top' = a gomb az űrlap fölött, 'bottom' = alatta.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'KMAE_Google_Auth' ) || ! KMAE_Google_Auth::is_configured() ) {
	return;
}

$google_redirect = isset( $google_redirect ) ? $google_redirect : home_url( '/' );
$google_label    = isset( $google_label ) ? $google_label : __( 'Folytatás Google-fiókkal', 'ki-mit-adna-erte' );
$google_layout   = ( isset( $google_layout ) && 'top' === $google_layout ) ? 'top' : 'bottom';

/* Az elválasztó mindig az űrlap felé néz: fent lévő gombnál alatta,
   lent lévőnél fölötte. */
ob_start();
?>
	<p class="kmae-auth__or"><span><?php esc_html_e( 'vagy', 'ki-mit-adna-erte' ); ?></span></p>
<?php
$google_or = ob_get_clean();
?>
<div class="kmae-auth__social kmae-auth__social--<?php echo esc_attr( $google_layout ); ?>">
	<?php
	if ( 'bottom' === $google_layout ) {
		echo $google_or; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}
	?>

	<a class="kmae-google-btn" href="<?php echo esc_url( KMAE_Google_Auth::start_url( $google_redirect ) ); ?>" rel="nofollow">
		<span class="kmae-google-btn__mark" aria-hidden="true">
			<svg width="18" height="18" viewBox="0 0 18 18" xmlns="http://www.w3.org/2000/svg">
				<path fill="#4285F4" d="M17.64 9.2c0-.64-.06-1.25-.16-1.84H9v3.48h4.84a4.14 4.14 0 0 1-1.8 2.72v2.26h2.92c1.7-1.57 2.68-3.88 2.68-6.62z"/>
				<path fill="#34A853" d="M9 18c2.43 0 4.47-.8 5.96-2.18l-2.92-2.26c-.8.54-1.84.86-3.04.86-2.34 0-4.32-1.58-5.03-3.7H.96v2.33A9 9 0 0 0 9 18z"/>
				<path fill="#FBBC05" d="M3.97 10.72a5.4 5.4 0 0 1 0-3.44V4.95H.96a9 9 0 0 0 0 8.1l3.01-2.33z"/>
				<path fill="#EA4335" d="M9 3.58c1.32 0 2.5.45 3.44 1.35l2.58-2.58C13.46.9 11.43 0 9 0A9 9 0 0 0 .96 4.95l3.01 2.33C4.68 5.16 6.66 3.58 9 3.58z"/>
			</svg>
		</span>
		<span class="kmae-google-btn__label"><?php echo esc_html( $google_label ); ?></span>
	</a>

	<?php
	if ( 'top' === $google_layout ) {
		echo $google_or; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}
	?>
</div>
