<?php
/**
 * Chat footer: contact unlock only (waiting shown in timeline).
 *
 * @package KMAE
 * @var object $offer
 * @var int    $listing_id
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="kmae-chat-compose">
	<?php if ( KMAE_Offers::STATUS_ACCEPTED === $offer->status ) : ?>
		<div class="kmae-chat-compose-done">
			<?php if ( KMAE_Deal::is_viewing_deal( $offer ) ) : ?>
				<?php include KMAE_PLUGIN_DIR . 'templates/partials/deal-outcome.php'; ?>
			<?php endif; ?>
			<?php include KMAE_PLUGIN_DIR . 'templates/partials/contact-unlock.php'; ?>
		</div>
	<?php elseif ( KMAE_Offers::STATUS_PENDING === $offer->status && KMAE_Deal::is_locked( (int) $offer->listing_id ) ) : ?>
		<p class="kmae-chat-status-note"><?php esc_html_e( 'Áll az alku egy másik érdeklődővel — várakozás a megtekintés eredményére.', 'ki-mit-adna-erte' ); ?></p>
	<?php elseif ( KMAE_Offers::STATUS_REJECTED === $offer->status ) : ?>
		<p class="kmae-chat-status-note kmae-chat-status-note--closed"><?php esc_html_e( 'Ez az ajánlat már nem aktív.', 'ki-mit-adna-erte' ); ?></p>
	<?php elseif ( KMAE_Offers::STATUS_WITHDRAWN === $offer->status ) : ?>
		<p class="kmae-chat-status-note kmae-chat-status-note--closed"><?php esc_html_e( 'Az ajánlat visszavonásra került — az alkudozás lezárult.', 'ki-mit-adna-erte' ); ?></p>
	<?php endif; ?>
</div>
