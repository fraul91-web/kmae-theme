<?php
/**
 * Vehicle form fields (create/edit).
 *
 * @package KMAE
 * @var bool   $is_edit
 * @var WP_Post|null $listing
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$specs = $is_edit && $listing ? KMAE_Vehicle::get_specs( $listing->ID ) : array();
$brand_val = $specs['brand'] ?? '';
$model_val = $specs['model'] ?? '';
$year_val  = $specs['year'] ?? '';
$km_val    = $specs['mileage'] ?? '';
$fuel_val  = $specs['fuel'] ?? '';
$trans_val = $specs['transmission'] ?? '';
$body_val  = $specs['body'] ?? '';
$color_val = $specs['color'] ?? '';
$owners_val = $specs['owners'] ?? '';
$power_val  = $specs['power_kw'] ?? '';
$cc_val     = $specs['engine_cc'] ?? '';
$value_val  = $specs['value'] ?? '';
$cond_val   = $specs['condition'] ?? '';
?>
<fieldset class="kmae-fieldset kmae-vehicle-fieldset">
	<legend><?php esc_html_e( 'Autó adatai', 'ki-mit-adna-erte' ); ?></legend>
	<p class="kmae-hint"><?php esc_html_e( 'A pontos adatok segítenek — így többen ajánlanak, és kevesebb felesleges kérdés érkezik.', 'ki-mit-adna-erte' ); ?></p>

	<div class="kmae-field-row">
		<div class="kmae-field">
			<label for="kmae_vehicle_brand"><?php esc_html_e( 'Márka *', 'ki-mit-adna-erte' ); ?></label>
			<input type="text" name="kmae_vehicle_brand" id="kmae_vehicle_brand" list="kmae-vehicle-brands" required value="<?php echo esc_attr( $brand_val ); ?>" placeholder="<?php esc_attr_e( 'pl. Volkswagen', 'ki-mit-adna-erte' ); ?>" data-kmae-assist="brand" />
			<datalist id="kmae-vehicle-brands">
				<?php foreach ( KMAE_Vehicle::brand_suggestions() as $brand ) : ?>
					<option value="<?php echo esc_attr( $brand ); ?>"></option>
				<?php endforeach; ?>
			</datalist>
		</div>
		<div class="kmae-field">
			<label for="kmae_vehicle_model"><?php esc_html_e( 'Modell *', 'ki-mit-adna-erte' ); ?></label>
			<input type="text" name="kmae_vehicle_model" id="kmae_vehicle_model" required value="<?php echo esc_attr( $model_val ); ?>" placeholder="<?php esc_attr_e( 'pl. Golf 1.6 TDI', 'ki-mit-adna-erte' ); ?>" data-kmae-assist="model" />
		</div>
	</div>

	<div class="kmae-field-row">
		<div class="kmae-field">
			<label for="kmae_vehicle_year"><?php esc_html_e( 'Évjárat *', 'ki-mit-adna-erte' ); ?></label>
			<input type="number" name="kmae_vehicle_year" id="kmae_vehicle_year" required min="1950" max="<?php echo esc_attr( (int) gmdate( 'Y' ) + 1 ); ?>" value="<?php echo esc_attr( $year_val ); ?>" data-kmae-assist="year" />
		</div>
		<div class="kmae-field">
			<label for="kmae_vehicle_mileage"><?php esc_html_e( 'Km óra állás *', 'ki-mit-adna-erte' ); ?></label>
			<input type="number" name="kmae_vehicle_mileage" id="kmae_vehicle_mileage" required min="0" step="1" value="<?php echo esc_attr( $km_val ); ?>" placeholder="<?php esc_attr_e( 'pl. 145000', 'ki-mit-adna-erte' ); ?>" data-kmae-assist="mileage" />
		</div>
	</div>

	<div class="kmae-field-row">
		<div class="kmae-field">
			<label for="kmae_vehicle_fuel"><?php esc_html_e( 'Üzemanyag *', 'ki-mit-adna-erte' ); ?></label>
			<select name="kmae_vehicle_fuel" id="kmae_vehicle_fuel" required data-kmae-assist="fuel">
				<option value=""><?php esc_html_e( 'Válassz...', 'ki-mit-adna-erte' ); ?></option>
				<?php foreach ( KMAE_Vehicle::fuel_labels() as $code => $label ) : ?>
					<option value="<?php echo esc_attr( $code ); ?>" <?php selected( $fuel_val, $code ); ?>><?php echo esc_html( $label ); ?></option>
				<?php endforeach; ?>
			</select>
		</div>
		<div class="kmae-field">
			<label for="kmae_vehicle_transmission"><?php esc_html_e( 'Váltó *', 'ki-mit-adna-erte' ); ?></label>
			<select name="kmae_vehicle_transmission" id="kmae_vehicle_transmission" required data-kmae-assist="transmission">
				<option value=""><?php esc_html_e( 'Válassz...', 'ki-mit-adna-erte' ); ?></option>
				<?php foreach ( KMAE_Vehicle::transmission_labels() as $code => $label ) : ?>
					<option value="<?php echo esc_attr( $code ); ?>" <?php selected( $trans_val, $code ); ?>><?php echo esc_html( $label ); ?></option>
				<?php endforeach; ?>
			</select>
		</div>
	</div>

	<div class="kmae-field-row">
		<div class="kmae-field">
			<label for="kmae_vehicle_body"><?php esc_html_e( 'Kivitel *', 'ki-mit-adna-erte' ); ?></label>
			<select name="kmae_vehicle_body" id="kmae_vehicle_body" required data-kmae-assist="body">
				<option value=""><?php esc_html_e( 'Válassz...', 'ki-mit-adna-erte' ); ?></option>
				<?php foreach ( KMAE_Vehicle::body_types() as $code => $info ) : ?>
					<option value="<?php echo esc_attr( $code ); ?>" <?php selected( $body_val, $code ); ?>><?php echo esc_html( $info['label'] ); ?></option>
				<?php endforeach; ?>
			</select>
		</div>
		<div class="kmae-field">
			<label for="kmae_vehicle_owners"><?php esc_html_e( 'Tulajdonosok száma *', 'ki-mit-adna-erte' ); ?></label>
			<input type="number" name="kmae_vehicle_owners" id="kmae_vehicle_owners" required min="1" max="20" value="<?php echo esc_attr( $owners_val ?: 1 ); ?>" data-kmae-assist="owners" />
		</div>
	</div>

	<div class="kmae-field-row">
		<div class="kmae-field">
			<label for="kmae_vehicle_value"><?php esc_html_e( 'Autó becsült értéke (Ft) *', 'ki-mit-adna-erte' ); ?></label>
			<input type="number" name="kmae_vehicle_value" id="kmae_vehicle_value" required min="100000" step="50000" value="<?php echo esc_attr( $value_val ); ?>" placeholder="<?php esc_attr_e( 'pl. 3500000', 'ki-mit-adna-erte' ); ?>" data-kmae-assist="value" />
			<p class="kmae-hint"><?php esc_html_e( 'Ez alapján találnak rád a csere/alkú keresők — csak a szűréshez kell, nem fix ár.', 'ki-mit-adna-erte' ); ?></p>
		</div>
	</div>

	<div class="kmae-field-row">
		<div class="kmae-field">
			<label for="kmae_vehicle_color"><?php esc_html_e( 'Szín', 'ki-mit-adna-erte' ); ?></label>
			<input type="text" name="kmae_vehicle_color" id="kmae_vehicle_color" value="<?php echo esc_attr( $color_val ); ?>" placeholder="<?php esc_attr_e( 'pl. Fekete metál', 'ki-mit-adna-erte' ); ?>" />
		</div>
		<div class="kmae-field">
			<label for="kmae_condition"><?php esc_html_e( 'Állapot *', 'ki-mit-adna-erte' ); ?></label>
			<select name="kmae_condition" id="kmae_condition" required data-kmae-assist="condition">
				<option value=""><?php esc_html_e( 'Válassz...', 'ki-mit-adna-erte' ); ?></option>
				<?php foreach ( KMAE_Vehicle::condition_labels() as $code => $label ) : ?>
					<option value="<?php echo esc_attr( $code ); ?>" <?php selected( $cond_val, $code ); ?>><?php echo esc_html( $label ); ?></option>
				<?php endforeach; ?>
			</select>
		</div>
	</div>

	<div class="kmae-field-row">
		<div class="kmae-field">
			<label for="kmae_vehicle_power_kw"><?php esc_html_e( 'Teljesítmény (kW)', 'ki-mit-adna-erte' ); ?></label>
			<input type="number" name="kmae_vehicle_power_kw" id="kmae_vehicle_power_kw" min="0" step="1" value="<?php echo esc_attr( $power_val ); ?>" placeholder="<?php esc_attr_e( 'pl. 85', 'ki-mit-adna-erte' ); ?>" />
		</div>
		<div class="kmae-field">
			<label for="kmae_vehicle_engine_cc"><?php esc_html_e( 'Hengerűrtartalom (cm³)', 'ki-mit-adna-erte' ); ?></label>
			<input type="number" name="kmae_vehicle_engine_cc" id="kmae_vehicle_engine_cc" min="0" step="1" value="<?php echo esc_attr( $cc_val ); ?>" placeholder="<?php esc_attr_e( 'pl. 1598', 'ki-mit-adna-erte' ); ?>" />
		</div>
	</div>
</fieldset>

<div class="kmae-listing-assistant" id="kmae-listing-assistant" hidden>
	<strong><?php esc_html_e( 'Ellenőrzés beküldés előtt', 'ki-mit-adna-erte' ); ?></strong>
	<ul class="kmae-assistant-list" id="kmae-assistant-list"></ul>
</div>
