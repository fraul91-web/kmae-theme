<?php
/**
 * Chat-style negotiation timeline.
 *
 * @package KMAE
 * @var object $offer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$user_id       = get_current_user_id();
$messages      = KMAE_Counter_Offers::get_chat_messages( $offer );
$action_state  = KMAE_Counter_Offers::get_chat_action_state( $offer, $user_id );
$is_seller     = KMAE_Counter_Offers::is_seller( $offer, $user_id );
$is_waiting    = ! empty( $action_state['is_waiting'] );
?>
<div class="kmae-chat-thread" id="kmae-chat-thread" role="log" aria-live="polite">
	<div class="kmae-chat-thread-start">
		<span><?php esc_html_e( 'Alkudozás kezdete', 'ki-mit-adna-erte' ); ?></span>
	</div>

	<?php foreach ( $messages as $index => $message ) : ?>
		<?php
		$is_own   = (int) $message->user_id === $user_id;
		$kind     = $message->kind ?? 'offer';
		$kind_lbl = KMAE_Counter_Offers::get_chat_kind_label( $kind );
		if ( $is_own ) {
			$who = __( 'Te', 'ki-mit-adna-erte' );
		} elseif ( $is_seller ) {
			$who = KMAE_Offers::get_offerer_display_name( $message->user_id );
		} else {
			$who = __( 'Eladó', 'ki-mit-adna-erte' );
		}
		$time = date_i18n( 'm.d. H:i', strtotime( $message->created_at ) );
		?>
		<div class="kmae-chat-msg <?php echo $is_own ? 'kmae-chat-msg--own' : 'kmae-chat-msg--other'; ?> kmae-chat-msg--<?php echo esc_attr( $kind ); ?>" data-kmae-chat-msg>
			<div class="kmae-chat-msg-meta">
				<span class="kmae-chat-kind kmae-chat-kind--<?php echo esc_attr( $kind ); ?>"><?php echo esc_html( $kind_lbl ); ?></span>
				<span class="kmae-chat-who"><?php echo esc_html( $who ); ?></span>
				<span class="kmae-chat-time"><?php echo esc_html( $time ); ?></span>
			</div>
			<div class="kmae-chat-bubble">
				<?php echo esc_html( $message->text ); ?>
			</div>
			<?php
			include KMAE_PLUGIN_DIR . 'templates/partials/offer-chat-message-actions.php';
			?>
		</div>
	<?php endforeach; ?>

	<?php if ( $is_waiting && KMAE_Offers::STATUS_PENDING === $offer->status ) : ?>
		<?php
		$last_message = ! empty( $messages ) ? end( $messages ) : null;
		$last_is_own    = $last_message && (int) $last_message->user_id === $user_id;
		if ( $is_seller && $last_is_own && 'counter' === ( $last_message->kind ?? '' ) ) {
			$waiting_title = __( 'Várjuk a partner válaszát', 'ki-mit-adna-erte' );
			$waiting_sub   = __( 'Ellenajánlatod elküldve — értesítünk, ha reagál.', 'ki-mit-adna-erte' );
		} elseif ( ! $is_seller && $last_is_own ) {
			$waiting_title = __( 'Várjuk a partner válaszát', 'ki-mit-adna-erte' );
			$waiting_sub   = __( 'Ajánlatod megérkezett — értesítünk, ha reagál.', 'ki-mit-adna-erte' );
		} else {
			$waiting_title = __( 'Várjuk a partner válaszát', 'ki-mit-adna-erte' );
			$waiting_sub   = __( 'Amint válaszol, értesítünk.', 'ki-mit-adna-erte' );
		}
		?>
		<div class="kmae-chat-waiting-banner" role="status">
			<div class="kmae-chat-waiting-icon" aria-hidden="true"><?php echo KMAE_Icons::render( 'clock', array( 'size' => 22 ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
			<div class="kmae-chat-waiting-copy">
				<strong><?php echo esc_html( $waiting_title ); ?></strong>
				<span><?php echo esc_html( $waiting_sub ); ?></span>
			</div>
		</div>
	<?php endif; ?>

	<?php if ( KMAE_Offers::STATUS_ACCEPTED === $offer->status ) : ?>
		<?php
		$viewer      = wp_get_current_user();
		$viewer_name = $viewer->display_name ? $viewer->display_name : $viewer->user_login;
		?>
		<div class="kmae-chat-event kmae-chat-event--success">
			<strong><?php printf( esc_html__( 'Gratulálunk, %s!', 'ki-mit-adna-erte' ), esc_html( $viewer_name ) ); ?></strong>
			<span>
				<?php
				if ( $is_seller ) {
					esc_html_e( 'Az érdeklődő immáron elfogadta az ajánlatodat. Sok sikert a továbbiakban!', 'ki-mit-adna-erte' );
				} else {
					esc_html_e( 'A partner immáron elfogadta az ajánlatodat. Sok sikert a továbbiakban!', 'ki-mit-adna-erte' );
				}
				?>
			</span>
			<span class="kmae-chat-event-note"><?php esc_html_e( 'Áll az alku — egyeztessetek megtekintést az elérhetőségeken, majd jelezzétek az eredményt!', 'ki-mit-adna-erte' ); ?></span>
		</div>
	<?php elseif ( KMAE_Offers::STATUS_REJECTED === $offer->status ) : ?>
		<div class="kmae-chat-event kmae-chat-event--danger">
			<strong><?php esc_html_e( 'Lezárva', 'ki-mit-adna-erte' ); ?></strong>
			<span><?php esc_html_e( 'Az eladó másik ajánlatot fogadott el.', 'ki-mit-adna-erte' ); ?></span>
		</div>
	<?php elseif ( KMAE_Offers::STATUS_WITHDRAWN === $offer->status ) : ?>
		<div class="kmae-chat-event kmae-chat-event--muted">
			<strong><?php esc_html_e( 'Visszavonva', 'ki-mit-adna-erte' ); ?></strong>
			<span>
				<?php
				if ( $is_seller ) {
					esc_html_e( 'Az érdeklődő visszavonta az ajánlatot — az alkudozás lezárult.', 'ki-mit-adna-erte' );
				} else {
					esc_html_e( 'Visszavontad az ajánlatodat — az alkudozás lezárult.', 'ki-mit-adna-erte' );
				}
				?>
			</span>
		</div>
	<?php endif; ?>
</div>
