<?php
/**
 * Inline actions on a chat message (accept / counter / revise).
 *
 * @package KMAE
 * @var object $offer
 * @var object $message
 * @var int    $index
 * @var array  $action_state
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$user_id           = get_current_user_id();
$active_index      = (int) $action_state['active_index'];
$can_accept        = ! empty( $action_state['can_accept'] );
$can_counter       = ! empty( $action_state['can_counter'] );
$can_revise        = ! empty( $action_state['can_revise'] );
$negotiation       = $action_state['negotiation'];
$latest            = $negotiation['latest'];
$counter_templates = KMAE_Taxonomies::counter_templates();
$is_active         = $index === $active_index;
$is_own            = (int) $message->user_id === $user_id;
$show_expired      = ! $is_own && KMAE_Offers::STATUS_PENDING === $offer->status && ! $is_active;

if ( $is_own || ( ! $is_active && ! $show_expired ) ) {
	return;
}

if ( $show_expired ) : ?>
	<div class="kmae-chat-msg-actions kmae-chat-msg-actions--expired">
		<span class="kmae-chat-btn kmae-chat-btn--inline kmae-chat-btn--expired"><?php esc_html_e( 'Áll az alku · lejárt', 'ki-mit-adna-erte' ); ?></span>
	</div>
	<?php
	return;
endif;

$accept_label = __( 'Áll az alku', 'ki-mit-adna-erte' );
if ( ! KMAE_Counter_Offers::is_seller( $offer, $user_id ) && $latest && $latest->cash_amount > 0 ) {
	$accept_label = sprintf(
		/* translators: %s: amount */
		__( 'Áll az alku · %s', 'ki-mit-adna-erte' ),
		KMAE_Offers::format_cash( $latest->cash_amount )
	);
}
$rounds_left = KMAE_Counter_Offers::is_seller( $offer, $user_id )
	? (int) $negotiation['rounds_left_seller']
	: (int) $negotiation['rounds_left_buyer'];
?>
<div class="kmae-chat-msg-actions" data-kmae-msg-actions>
	<?php if ( $can_accept ) : ?>
		<form method="post" class="kmae-chat-accept-form kmae-chat-accept-form--inline">
			<?php wp_nonce_field( 'kmae_accept_offer_nonce', 'kmae_accept_offer_nonce' ); ?>
			<input type="hidden" name="kmae_action" value="accept_offer" />
			<input type="hidden" name="kmae_offer_id" value="<?php echo esc_attr( $offer->id ); ?>" />
			<button type="submit" class="kmae-chat-btn kmae-chat-btn--accept kmae-chat-btn--inline"><?php echo esc_html( $accept_label ); ?></button>
		</form>
	<?php endif; ?>

	<?php if ( $can_counter ) : ?>
		<button
			type="button"
			class="kmae-chat-btn kmae-chat-btn--counter kmae-chat-btn--inline"
			data-kmae-counter-open
			data-kmae-rounds-left="<?php echo esc_attr( $rounds_left ); ?>"
			aria-controls="kmae-counter-panel-<?php echo esc_attr( $offer->id ); ?>-<?php echo esc_attr( $index ); ?>"
			aria-expanded="false"
		>
			<?php esc_html_e( 'Ellenajánlat', 'ki-mit-adna-erte' ); ?>
		</button>
	<?php endif; ?>

	<?php if ( $can_revise ) : ?>
		<button
			type="button"
			class="kmae-chat-btn kmae-chat-btn--revise kmae-chat-btn--inline"
			data-kmae-revise-open
			data-kmae-rounds-left="<?php echo esc_attr( $rounds_left ); ?>"
			aria-controls="kmae-revise-panel-<?php echo esc_attr( $offer->id ); ?>-<?php echo esc_attr( $index ); ?>"
			aria-expanded="false"
		>
			<?php esc_html_e( 'Új összeg', 'ki-mit-adna-erte' ); ?>
		</button>
	<?php endif; ?>
</div>

<?php if ( $can_counter ) : ?>
	<div
		id="kmae-counter-panel-<?php echo esc_attr( $offer->id ); ?>-<?php echo esc_attr( $index ); ?>"
		class="kmae-chat-counter-panel kmae-chat-counter-panel--inline"
		data-kmae-counter-panel
		hidden
	>
		<form method="post" class="kmae-counter-form">
			<?php wp_nonce_field( 'kmae_counter_offer_nonce', 'kmae_counter_offer_nonce' ); ?>
			<input type="hidden" name="kmae_action" value="submit_counter_offer" />
			<input type="hidden" name="kmae_offer_id" value="<?php echo esc_attr( $offer->id ); ?>" />
			<p class="kmae-chat-panel-hint"><?php esc_html_e( 'Válassz választ, opcionálisan adj meg összeget:', 'ki-mit-adna-erte' ); ?></p>
			<div class="kmae-counter-chips" role="radiogroup" aria-label="<?php esc_attr_e( 'Ellenajánlat sablon', 'ki-mit-adna-erte' ); ?>">
				<?php foreach ( $counter_templates as $code => $label ) : ?>
					<label class="kmae-counter-chip">
						<input type="radio" name="kmae_template_code" value="<?php echo esc_attr( $code ); ?>" required />
						<span><?php echo esc_html( $label ); ?></span>
					</label>
				<?php endforeach; ?>
			</div>
			<?php
			$name        = 'kmae_counter_amount';
			$id          = 'kmae_counter_amount_' . (int) $offer->id . '_' . (int) $index;
			$label       = '';
			$required    = false;
			$placeholder = __( 'Összeg Ft', 'ki-mit-adna-erte' );
			$value       = '';
			$class       = 'kmae-chat-input kmae-chat-input--inline';
			include KMAE_PLUGIN_DIR . 'templates/partials/cash-amount-input.php';
			?>
			<div class="kmae-chat-panel-actions">
				<button type="button" class="kmae-chat-btn kmae-chat-btn--ghost kmae-chat-btn--inline" data-kmae-counter-cancel><?php esc_html_e( 'Mégse', 'ki-mit-adna-erte' ); ?></button>
				<button type="submit" class="kmae-chat-btn kmae-chat-btn--send kmae-chat-btn--inline"><?php esc_html_e( 'Küldés', 'ki-mit-adna-erte' ); ?></button>
			</div>
			<span class="kmae-chat-rounds-badge">
				<?php
				printf(
					/* translators: %d: remaining rounds */
					esc_html__( '%d ellenajánlat maradt', 'ki-mit-adna-erte' ),
					(int) $rounds_left
				);
				?>
			</span>
		</form>
	</div>
<?php endif; ?>

<?php if ( $can_revise ) : ?>
	<div
		id="kmae-revise-panel-<?php echo esc_attr( $offer->id ); ?>-<?php echo esc_attr( $index ); ?>"
		class="kmae-chat-revise-panel kmae-chat-revise-panel--inline"
		data-kmae-revise-panel
		hidden
	>
		<form method="post" class="kmae-revise-form">
			<?php wp_nonce_field( 'kmae_revise_offer_nonce', 'kmae_revise_offer_nonce' ); ?>
			<input type="hidden" name="kmae_action" value="revise_offer" />
			<input type="hidden" name="kmae_offer_id" value="<?php echo esc_attr( $offer->id ); ?>" />
			<?php
			$name        = 'kmae_cash_amount';
			$id          = 'kmae_revise_amount_' . (int) $offer->id . '_' . (int) $index;
			$label       = '';
			$required    = true;
			$placeholder = __( 'Új összeg Ft', 'ki-mit-adna-erte' );
			$value       = '';
			$class       = 'kmae-chat-input kmae-chat-input--inline';
			include KMAE_PLUGIN_DIR . 'templates/partials/cash-amount-input.php';
			?>
			<div class="kmae-chat-panel-actions">
				<button type="button" class="kmae-chat-btn kmae-chat-btn--ghost kmae-chat-btn--inline" data-kmae-revise-cancel><?php esc_html_e( 'Mégse', 'ki-mit-adna-erte' ); ?></button>
				<button type="submit" class="kmae-chat-btn kmae-chat-btn--send kmae-chat-btn--inline"><?php esc_html_e( 'Küldés', 'ki-mit-adna-erte' ); ?></button>
			</div>
			<span class="kmae-chat-rounds-badge">
				<?php
				printf(
					esc_html__( '%d módosítás maradt', 'ki-mit-adna-erte' ),
					(int) $rounds_left
				);
				?>
			</span>
		</form>
	</div>
<?php endif; ?>
