<?php
/**
 * After purchase: continue shopping other cars?
 *
 * @package KMAE
 * @var int $continue_offer_id
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$sold_listing = null;
$sold_offer   = KMAE_Database::get_offer( $continue_offer_id );
if ( $sold_offer ) {
	$sold_listing = get_post( $sold_offer->listing_id );
}
$other_count = count( KMAE_Deal::get_buyer_other_pending_offers( get_current_user_id(), $continue_offer_id ) );
?>
<div class="kmae-continue-shopping">
	<div class="kmae-notice kmae-notice-info">
		<p><strong><?php esc_html_e( 'Szeretnél másik autót is vásárolni?', 'ki-mit-adna-erte' ); ?></strong></p>
		<p>
			<?php
			if ( $sold_listing ) {
				printf(
					/* translators: %s: listing title */
					esc_html__( 'Sikeresen megvetted: „%s”.', 'ki-mit-adna-erte' ),
					esc_html( $sold_listing->post_title )
				);
			}
			?>
			<?php if ( $other_count > 0 ) : ?>
				<?php
				printf(
					/* translators: %d: other pending talks */
					esc_html__( ' Még %d másik autós tárgyalásod van folyamatban.', 'ki-mit-adna-erte' ),
					(int) $other_count
				);
				?>
			<?php endif; ?>
		</p>
	</div>
	<div class="kmae-continue-shopping__actions">
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="kmae-inline-form">
			<?php wp_nonce_field( 'kmae_continue_shopping', 'kmae_continue_shopping_nonce' ); ?>
			<input type="hidden" name="action" value="kmae_continue_shopping" />
			<input type="hidden" name="kmae_choice" value="yes" />
			<button type="submit" class="kmae-btn kmae-btn-primary"><?php esc_html_e( 'Igen — folytatom az alkut', 'ki-mit-adna-erte' ); ?></button>
		</form>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="kmae-inline-form">
			<?php wp_nonce_field( 'kmae_continue_shopping', 'kmae_continue_shopping_nonce' ); ?>
			<input type="hidden" name="action" value="kmae_continue_shopping" />
			<input type="hidden" name="kmae_choice" value="no" />
			<button type="submit" class="kmae-btn kmae-btn-secondary"><?php esc_html_e( 'Nem — lezárom a többi tárgyalást', 'ki-mit-adna-erte' ); ?></button>
		</form>
	</div>
	<p class="kmae-hint">
		<?php
		if ( KMAE_Auth::is_company( get_current_user_id() ) ) {
			esc_html_e( 'Céges vevőként több autót is vehetsz. Ha „Nem”-et választasz, a többi eladó automatikusan megkapja: sikerült másik autóval megállapodnod, az ajánlatod tárgytalan.', 'ki-mit-adna-erte' );
		} else {
			esc_html_e( 'Ha „Nem”-et választasz, a többi eladó automatikusan megkapja: sikerült másik autóval megállapodnod, az ajánlatod tárgytalan.', 'ki-mit-adna-erte' );
		}
		?>
	</p>
</div>
