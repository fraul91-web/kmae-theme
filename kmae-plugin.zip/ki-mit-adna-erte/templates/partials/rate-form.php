<?php
/**
 * Rate the other party after a successful deal.
 *
 * @package KMAE
 * @var object $offer
 * @var array  $party rated_id + rated_role
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$rated_user = get_userdata( $party['rated_id'] );
$listing    = get_post( $offer->listing_id );
$criteria   = KMAE_Trust::criteria_for_rated_role( $party['rated_role'] );
$role_label = 'seller' === $party['rated_role']
	? __( 'eladót', 'ki-mit-adna-erte' )
	: __( 'vevőt', 'ki-mit-adna-erte' );
?>
<div class="kmae-rate-form-wrap">
	<h2><?php esc_html_e( 'Értékelés', 'ki-mit-adna-erte' ); ?></h2>
	<p class="kmae-subtitle">
		<?php
		printf(
			/* translators: 1: role (eladót/vevőt), 2: name, 3: listing title */
			esc_html__( 'Értékeld a(z) %1$s (%2$s) a „%3$s” üzlet után. Ebből épül a bizalmi szám.', 'ki-mit-adna-erte' ),
			esc_html( $role_label ),
			esc_html( $rated_user ? $rated_user->display_name : __( 'partner', 'ki-mit-adna-erte' ) ),
			esc_html( $listing ? $listing->post_title : '' )
		);
		?>
	</p>

	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="kmae-form kmae-rate-form">
		<?php wp_nonce_field( 'kmae_submit_rating', 'kmae_rating_nonce' ); ?>
		<input type="hidden" name="action" value="kmae_submit_rating" />
		<input type="hidden" name="kmae_offer_id" value="<?php echo esc_attr( $offer->id ); ?>" />

		<fieldset class="kmae-fieldset">
			<legend><?php esc_html_e( 'Sikerült az üzlet?', 'ki-mit-adna-erte' ); ?></legend>
			<label class="kmae-checkbox">
				<input type="checkbox" name="kmae_deal_ok" value="1" required checked />
				<?php esc_html_e( 'Igen — sikeresen lezárult az adás-vétel, minden rendben ment.', 'ki-mit-adna-erte' ); ?>
			</label>
		</fieldset>

		<fieldset class="kmae-fieldset">
			<legend><?php esc_html_e( 'Összbenyomás (1–5) *', 'ki-mit-adna-erte' ); ?></legend>
			<div class="kmae-rate-stars">
				<?php for ( $i = 5; $i >= 1; $i-- ) : ?>
					<label class="kmae-rate-star">
						<input type="radio" name="kmae_overall" value="<?php echo esc_attr( $i ); ?>" <?php checked( 5 === $i ); ?> required />
						<span><?php echo esc_html( (string) $i ); ?>★</span>
					</label>
				<?php endfor; ?>
			</div>
		</fieldset>

		<fieldset class="kmae-fieldset">
			<legend><?php esc_html_e( 'Részletek', 'ki-mit-adna-erte' ); ?></legend>
			<p class="kmae-hint"><?php esc_html_e( 'Jelöld, amivel egyetértesz (pozitív válasz = bizalom).', 'ki-mit-adna-erte' ); ?></p>
			<?php foreach ( $criteria as $key => $label ) : ?>
				<label class="kmae-checkbox">
					<input type="checkbox" name="kmae_criteria[<?php echo esc_attr( $key ); ?>]" value="1" checked />
					<?php echo esc_html( $label ); ?>
				</label>
			<?php endforeach; ?>
		</fieldset>

		<div class="kmae-field">
			<label for="kmae_rating_comment"><?php esc_html_e( 'Megjegyzés (opcionális)', 'ki-mit-adna-erte' ); ?></label>
			<textarea name="kmae_rating_comment" id="kmae_rating_comment" rows="3" maxlength="500" placeholder="<?php esc_attr_e( 'Rövid visszajelzés…', 'ki-mit-adna-erte' ); ?>"></textarea>
		</div>

		<button type="submit" class="kmae-btn kmae-btn-primary"><?php esc_html_e( 'Értékelés küldése', 'ki-mit-adna-erte' ); ?></button>
	</form>
</div>
