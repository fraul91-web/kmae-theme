<?php
/**
 * Structured offer hub card.
 *
 * @package KMAE
 * @var object  $offer
 * @var WP_Post $listing
 * @var string  $offer_thread_url
 * @var bool    $is_received
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$status_labels = KMAE_Counter_Offers::status_labels();
$last_preview  = KMAE_Counter_Offers::get_last_chat_preview( $offer );
$thumb_url     = KMAE_Query::get_listing_thumbnail_url( $listing->ID, 'medium' );
$user_id       = get_current_user_id();
$party_name    = $is_received
	? KMAE_Offers::get_offerer_display_name( $offer->offerer_id )
	: KMAE_Counter_Offers::get_other_party_name( $offer, $user_id );
$amount_summary = KMAE_Counter_Offers::get_current_amount_summary( $offer );
$alert_state    = KMAE_Database::get_offer_alert_state( $user_id, $offer );
$tile_classes   = array( 'kmae-offer-tile' );
if ( 'good' === $alert_state ) {
	$tile_classes[] = 'kmae-offer-tile--alert-good';
} elseif ( 'bad' === $alert_state ) {
	$tile_classes[] = 'kmae-offer-tile--alert-bad';
}
?>
<div class="kmae-offer-tile-wrap">
	<a href="<?php echo esc_url( $offer_thread_url ); ?>" class="<?php echo esc_attr( implode( ' ', $tile_classes ) ); ?>">
		<div class="kmae-offer-tile-media">
			<?php if ( $thumb_url ) : ?>
				<img src="<?php echo esc_url( $thumb_url ); ?>" alt="" loading="lazy" width="72" height="72" />
			<?php else : ?>
				<span class="kmae-offer-tile-media-placeholder" aria-hidden="true"></span>
			<?php endif; ?>
		</div>

		<div class="kmae-offer-tile-content">
			<div class="kmae-offer-tile-head">
				<div class="kmae-offer-tile-primary">
					<h4 class="kmae-offer-tile-party">
						<?php echo esc_html( $party_name ); ?>
						<?php if ( $is_received && KMAE_Auth::is_company( (int) $offer->offerer_id ) ) : ?>
							<span class="kmae-badge kmae-badge-accepted kmae-badge-inline"><?php esc_html_e( 'Cég', 'ki-mit-adna-erte' ); ?></span>
						<?php endif; ?>
					</h4>
					<p class="kmae-offer-tile-amount"><?php echo esc_html( $amount_summary ); ?></p>
				</div>
				<span class="kmae-badge kmae-badge-<?php echo esc_attr( $offer->status ); ?>">
					<?php echo esc_html( $status_labels[ $offer->status ] ?? $offer->status ); ?>
				</span>
			</div>

			<?php if ( $last_preview ) : ?>
				<div class="kmae-offer-tile-preview">
					<span class="kmae-offer-tile-preview-label">
						<?php
						if ( 'good' === $alert_state ) {
							esc_html_e( 'Friss üzenet', 'ki-mit-adna-erte' );
						} else {
							esc_html_e( 'Utolsó üzenet', 'ki-mit-adna-erte' );
						}
						?>
					</span>
					<p><?php echo esc_html( wp_trim_words( $last_preview, 14, '…' ) ); ?></p>
				</div>
			<?php endif; ?>

			<span class="kmae-offer-tile-cta"><?php esc_html_e( 'Beszélgetés megnyitása', 'ki-mit-adna-erte' ); ?></span>
		</div>
	</a>
	<a href="<?php echo esc_url( get_permalink( $listing->ID ) ); ?>" class="kmae-offer-tile-listing" target="_blank" rel="noopener">
		<?php echo esc_html( $listing->post_title ); ?> ↗
	</a>
</div>
