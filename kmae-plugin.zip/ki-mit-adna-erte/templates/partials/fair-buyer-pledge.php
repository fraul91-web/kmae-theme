<?php
/**
 * Fair buyer pledge checkbox (Tisztességes vevő).
 *
 * @package KMAE
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! is_user_logged_in() || ! KMAE_Auth::is_private_person( get_current_user_id() ) ) {
	return;
}
?>
<label class="kmae-checkbox kmae-fair-buyer-pledge">
	<input type="checkbox" name="kmae_fair_buyer" value="1" required />
	<span>
		<strong><?php esc_html_e( 'Tisztességes vevő vállalás', 'ki-mit-adna-erte' ); ?></strong>
		<span class="kmae-hint" style="display:block;margin:0.25rem 0 0;">
			<?php esc_html_e( 'Ha az autó a képeknek és a leírásnak megfelelő, komoly szándékkal elmegyek megnézni — és ha megfelel, meg is veszem.', 'ki-mit-adna-erte' ); ?>
		</span>
	</span>
</label>
