<?php
/**
 * Logged-in home hub — greeting and the three main cards.
 *
 * @package KMAE
 * @var array $dash
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$u = isset( $dash['urls'] ) && is_array( $dash['urls'] ) ? $dash['urls'] : array();

$cards = array(
	array(
		'mod'   => 'sell',
		'href'  => $u['hub_sell'] ?? home_url( '/eladni/' ),
		'title' => __( 'Eladni', 'ki-mit-adna-erte' ),
		'lead'  => __( 'Hirdetésfeladás, kezelés és beérkező ajánlatok', 'ki-mit-adna-erte' ),
		'icon'  => 'car',
	),
	array(
		'mod'   => 'buy',
		'href'  => $u['hub_buy'] ?? home_url( '/venni/' ),
		'title' => __( 'Venni', 'ki-mit-adna-erte' ),
		'lead'  => __( 'Böngészés és az elküldött ajánlataid', 'ki-mit-adna-erte' ),
		'icon'  => 'search',
	),
	array(
		'mod'   => 'stats',
		'href'  => $u['hub_stats'] ?? home_url( '/statisztikak/' ),
		'title' => __( 'Statisztikák', 'ki-mit-adna-erte' ),
		'lead'  => __( 'Értesítések, profil és beállítások', 'ki-mit-adna-erte' ),
		'icon'  => 'bar-chart',
	),
);
?>
<section class="kmae-hub" aria-label="<?php echo esc_attr__( 'Főmenü', 'ki-mit-adna-erte' ); ?>">
	<header class="kmae-hub__intro">
		<h1 class="kmae-hub__hello">
			<?php
			printf(
				/* translators: %s: display name */
				wp_kses(
					__( 'Szia, <span class="kmae-hub__hello-name">%s</span>!', 'ki-mit-adna-erte' ),
					array( 'span' => array( 'class' => true ) )
				),
				esc_html( $dash['name'] ?? '' )
			);
			?>
		</h1>
		<p class="kmae-hub__question"><?php esc_html_e( 'Mit szeretnél ma csinálni?', 'ki-mit-adna-erte' ); ?></p>
	</header>

	<div class="kmae-hub__grid">
		<?php foreach ( $cards as $card ) : ?>
			<a
				class="kmae-hub__card kmae-hub__card--<?php echo esc_attr( $card['mod'] ); ?>"
				href="<?php echo esc_url( $card['href'] ); ?>"
				aria-label="<?php echo esc_attr( $card['title'] ); ?>"
			>
				<span class="kmae-hub__card-icon" aria-hidden="true">
					<?php echo class_exists( 'KMAE_Icons' ) ? KMAE_Icons::render( $card['icon'], array( 'size' => 28 ) ) : ''; ?>
				</span>
				<span class="kmae-hub__card-copy">
					<span class="kmae-hub__card-title"><?php echo esc_html( $card['title'] ); ?></span>
					<span class="kmae-hub__card-lead"><?php echo esc_html( $card['lead'] ); ?></span>
					<span class="kmae-hub__card-cta"><?php esc_html_e( 'Megnyitás', 'ki-mit-adna-erte' ); ?> →</span>
				</span>
			</a>
		<?php endforeach; ?>
	</div>
</section>
