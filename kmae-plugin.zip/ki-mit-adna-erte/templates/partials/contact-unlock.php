<?php
/**
 * Contact details after accepted offer.
 *
 * @package KMAE
 * @var object $offer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( KMAE_Offers::STATUS_ACCEPTED !== $offer->status || ! is_user_logged_in() ) {
	return;
}

$viewer_id = get_current_user_id();
$listing   = get_post( $offer->listing_id );
if ( ! $listing ) {
	return;
}

$seller_id = (int) $listing->post_author;
$buyer_id  = (int) $offer->offerer_id;
if ( ! in_array( $viewer_id, array( $seller_id, $buyer_id ), true ) ) {
	return;
}

if ( ! KMAE_Contact::can_view( $offer, $viewer_id ) ) {
	return;
}

$other_id = KMAE_Contact::get_other_party_id( $offer, $viewer_id );
$contact  = KMAE_Contact::get_contact_details( $other_id );
?>
<div class="kmae-contact-box">
	<h3><?php esc_html_e( 'Kapcsolatfelvétel', 'ki-mit-adna-erte' ); ?></h3>
	<div class="kmae-notice kmae-notice-success">
		<p><strong><?php echo esc_html( $contact['name'] ); ?></strong></p>
		<?php if ( ! empty( $contact['phone'] ) ) : ?>
			<p><?php esc_html_e( 'Telefon:', 'ki-mit-adna-erte' ); ?> <a href="tel:<?php echo esc_attr( $contact['phone'] ); ?>"><?php echo esc_html( $contact['phone'] ); ?></a></p>
		<?php else : ?>
			<p class="kmae-hint"><?php esc_html_e( 'A másik fél még nem adott meg telefonszámot a profiljában.', 'ki-mit-adna-erte' ); ?></p>
		<?php endif; ?>
		<p><?php esc_html_e( 'E-mail:', 'ki-mit-adna-erte' ); ?> <a href="mailto:<?php echo esc_attr( $contact['email'] ); ?>"><?php echo esc_html( $contact['email'] ); ?></a></p>
	</div>
</div>
