<?php
/**
 * Listing create/edit form data preparation.
 *
 * @package KMAE
 * @var string       $mode    create|edit
 * @var WP_Post|null $listing Edit mode only.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$is_vehicle     = KMAE_Vehicle::is_vehicle_launch();
$categories     = KMAE_Launch::get_available_categories();
$offer_labels   = KMAE_Taxonomies::offer_type_labels();
$offer_descs    = KMAE_Taxonomies::offer_type_descriptions();
$error          = isset( $_GET['kmae_error'] ) ? sanitize_text_field( wp_unslash( $_GET['kmae_error'] ) ) : '';
$is_edit        = 'edit' === $mode && $listing instanceof WP_Post;
$mod_errors     = array();
$launch_cat_id  = KMAE_Launch::get_launch_category_id();

if ( is_user_logged_in() && ( ! $is_edit || 'moderation_failed' === $error ) ) {
	$mod_errors = KMAE_Moderation::pull_errors_for_user( get_current_user_id() );
}

$title_val       = $is_edit ? $listing->post_title : '';
$desc_val        = $is_edit ? $listing->post_content : '';
$county_val      = $is_edit ? get_post_meta( $listing->ID, '_kmae_county', true ) : '';
$city_val        = $is_edit ? get_post_meta( $listing->ID, '_kmae_city', true ) : '';
$selected_types  = $is_edit ? KMAE_Meta::get_offer_types( $listing->ID ) : array();
$trade_in_cats   = $is_edit ? get_post_meta( $listing->ID, '_kmae_trade_in_categories', true ) : array();
$minimum_val     = $is_edit && ( $private = KMAE_Database::get_private_data( $listing->ID ) ) ? (float) $private->minimum_cash : 0;
$current_cat     = $is_edit ? wp_get_object_terms( $listing->ID, 'kmae_category', array( 'fields' => 'ids' ) ) : array();
$current_cat_id  = ! empty( $current_cat ) && ! is_wp_error( $current_cat ) ? (int) $current_cat[0] : $launch_cat_id;
$gallery_ids     = $is_edit ? KMAE_Query::get_gallery_ids( $listing->ID ) : array();
$price_mode      = $is_edit ? KMAE_Seller::get_price_mode( $listing->ID ) : '';
$fixed_price_val = $is_edit ? KMAE_Seller::get_fixed_price( $listing->ID ) : 0;
$defects_val     = $is_edit ? KMAE_Seller::get_known_defects( $listing->ID ) : '';
$commitments     = $is_edit ? KMAE_Seller::get_commitments( $listing->ID ) : array();
$extra_other_val = $is_edit ? KMAE_Seller::get_extra_other( $listing->ID ) : '';
$can_create      = ( ! $is_edit && is_user_logged_in() ) ? KMAE_Seller::can_create_listing( get_current_user_id() ) : true;

if ( ! is_array( $trade_in_cats ) ) {
	$trade_in_cats = array();
}

if ( $is_vehicle && $launch_cat_id && empty( $trade_in_cats ) ) {
	$trade_in_cats = array( $launch_cat_id );
}

$form_action = $is_edit ? admin_url( 'admin-post.php' ) : '';
$min_images  = KMAE_Moderation::is_enabled() ? KMAE_Moderation::MIN_IMAGES : 1;

$listing_error_messages = array(
	'upload_failed'         => __( 'A kép feltöltése nem sikerült. Ellenőrizd a fájlméretet, és próbáld újra.', 'ki-mit-adna-erte' ),
	'moderation_failed'     => __( 'A hirdetés nem felelt meg az automatikus ellenőrzésnek. Javítsd a hibákat, és küldd be újra.', 'ki-mit-adna-erte' ),
	'private_listing_limit' => __( 'Magánszemélyként egyszerre csak egy aktív hirdetésed lehet.', 'ki-mit-adna-erte' ),
	'price_mode_required'   => __( 'Válaszd ki, hogyan szeretnéd árazni az autót.', 'ki-mit-adna-erte' ),
	'fixed_price_required'  => __( 'Add meg a fix árat.', 'ki-mit-adna-erte' ),
	'minimum_required'      => __( 'Add meg a rejtett minimum összeget.', 'ki-mit-adna-erte' ),
	'extra_other_required'  => __( 'Írd le az egyéb vállalást.', 'ki-mit-adna-erte' ),
	'photo_slots_required'  => __( 'A hét kötelező fotót mind el kell készíteni.', 'ki-mit-adna-erte' ),
	'photo_quality_failed'  => __( 'Egy vagy több fotó nem felelt meg a minőségi ellenőrzésnek.', 'ki-mit-adna-erte' ),
	'device_required'       => __( 'Válaszd ki, milyen eszközön készíted a hirdetést.', 'ki-mit-adna-erte' ),
	'missing_fields'        => __( 'Tölts ki minden kötelező mezőt.', 'ki-mit-adna-erte' ),
);

$edit_status = ( $is_edit && $listing ) ? KMAE_Meta::get_status( $listing->ID ) : '';
$is_awaiting = KMAE_Meta::STATUS_AWAITING_PHOTOS === $edit_status;
$open_photos = $is_awaiting || ( isset( $_GET['kmae_photos'] ) && '1' === sanitize_text_field( wp_unslash( $_GET['kmae_photos'] ) ) );

include KMAE_PLUGIN_DIR . 'templates/partials/listing-form-layout.php';
