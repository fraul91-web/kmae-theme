<?php
/**
 * Privacy policy stub.
 *
 * @package KMAE
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="kmae-stub">
	<h1><?php esc_html_e( 'Adatvédelem', 'ki-mit-adna-erte' ); ?></h1>
	<p class="kmae-stub__lead"><?php esc_html_e( 'Itt lesz az Albira adatvédelmi tájékoztatója. A végleges szöveg később kerül ide.', 'ki-mit-adna-erte' ); ?></p>

	<section class="kmae-stub__section">
		<h2><?php esc_html_e( 'Áttekintés', 'ki-mit-adna-erte' ); ?></h2>
		<p><?php esc_html_e( 'Tiszteletben tartjuk az adataidat. Az adatkezelés részleteit hamarosan közzétesszük ezen az oldalon.', 'ki-mit-adna-erte' ); ?></p>
	</section>
</div>
