<?php
/**
 * User profile — phone for contact unlock.
 *
 * @package KMAE
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$user    = wp_get_current_user();
$phone   = get_user_meta( $user->ID, 'kmae_phone', true );
$profile = KMAE_Auth::get_profile( $user->ID );
$premium = KMAE_Premium::is_active( $user->ID );
$success = isset( $_GET['kmae_success'] ) ? sanitize_text_field( wp_unslash( $_GET['kmae_success'] ) ) : '';
$error   = isset( $_GET['kmae_error'] ) ? sanitize_text_field( wp_unslash( $_GET['kmae_error'] ) ) : '';
$profile_url = get_permalink();
?>
<div class="kmae-profile">
	<h2><?php esc_html_e( 'Profilom', 'ki-mit-adna-erte' ); ?></h2>

	<?php if ( 'profile_saved' === $success ) : ?>
		<div class="kmae-notice kmae-notice-success"><?php esc_html_e( 'Profil mentve.', 'ki-mit-adna-erte' ); ?></div>
	<?php endif; ?>

	<?php if ( 'premium_active' === $success ) : ?>
		<div class="kmae-notice kmae-notice-success"><?php esc_html_e( 'Szupertag aktiválva!', 'ki-mit-adna-erte' ); ?></div>
	<?php endif; ?>

	<?php if ( 'tip_sent' === $success ) : ?>
		<div class="kmae-notice kmae-notice-success"><?php esc_html_e( 'Borravaló elküldve — a vevő e-mailben értesült.', 'ki-mit-adna-erte' ); ?></div>
	<?php endif; ?>

	<?php if ( 'detailing_claimed' === $success ) : ?>
		<div class="kmae-notice kmae-notice-success"><?php esc_html_e( 'Autókozmetikai kedvezményed ebben a hónapban feljegyezve. A partnerlista hamarosan a fiókodban lesz.', 'ki-mit-adna-erte' ); ?></div>
	<?php endif; ?>

	<?php if ( 'rating_saved' === $success ) : ?>
		<div class="kmae-notice kmae-notice-success"><?php esc_html_e( 'Köszönjük az értékelést! A bizalmi szám frissült.', 'ki-mit-adna-erte' ); ?></div>
	<?php endif; ?>

	<?php if ( 'continue_no' === $success ) : ?>
		<div class="kmae-notice kmae-notice-success"><?php esc_html_e( 'A többi tárgyalást lezártuk, az eladókat értesítettük.', 'ki-mit-adna-erte' ); ?></div>
	<?php endif; ?>

	<?php if ( 'fee_paid' === $success ) : ?>
		<div class="kmae-notice kmae-notice-success"><?php esc_html_e( 'Albira díj rendezve — köszönjük!', 'ki-mit-adna-erte' ); ?></div>
	<?php endif; ?>

	<?php if ( 'deal_success' === $success ) : ?>
		<div class="kmae-notice kmae-notice-success"><?php esc_html_e( 'Üzlet lezárva — az autó elkelt. Értékeld a másik felet lent!', 'ki-mit-adna-erte' ); ?></div>
	<?php endif; ?>

	<?php if ( 'nonce_failed' === $error ) : ?>
		<div class="kmae-notice kmae-notice-error"><?php esc_html_e( 'A mentés nem sikerült — frissítsd az oldalt és próbáld újra.', 'ki-mit-adna-erte' ); ?></div>
	<?php endif; ?>

	<?php if ( 'already_rated' === $error ) : ?>
		<div class="kmae-notice kmae-notice-error"><?php esc_html_e( 'Ezt az üzletet már értékelted.', 'ki-mit-adna-erte' ); ?></div>
	<?php endif; ?>

	<?php if ( 'deal_ok_required' === $error ) : ?>
		<div class="kmae-notice kmae-notice-error"><?php esc_html_e( 'Erősítsd meg, hogy sikerült az üzlet.', 'ki-mit-adna-erte' ); ?></div>
	<?php endif; ?>

	<?php if ( 'overall_required' === $error ) : ?>
		<div class="kmae-notice kmae-notice-error"><?php esc_html_e( 'Válassz 1–5 csillagos értékelést.', 'ki-mit-adna-erte' ); ?></div>
	<?php endif; ?>

	<?php if ( 'forbidden' === $error || 'not_sold' === $error || 'invalid_offer' === $error ) : ?>
		<div class="kmae-notice kmae-notice-error"><?php esc_html_e( 'Ez az üzlet most nem értékelhető.', 'ki-mit-adna-erte' ); ?></div>
	<?php endif; ?>

	<?php if ( 'company_name_required' === $error ) : ?>
		<div class="kmae-notice kmae-notice-error"><?php esc_html_e( 'Add meg a cégnevet.', 'ki-mit-adna-erte' ); ?></div>
	<?php endif; ?>

	<?php if ( 'payment_required' === $error ) : ?>
		<div class="kmae-notice kmae-notice-error"><?php esc_html_e( 'A díjfizetés hamarosan elérhető.', 'ki-mit-adna-erte' ); ?></div>
	<?php endif; ?>

	<?php if ( 'detailing_unavailable' === $error ) : ?>
		<div class="kmae-notice kmae-notice-error"><?php esc_html_e( 'Ebben a hónapban már felhasználtad az autókozmetikai kedvezményt, vagy nincs aktív Szupertagod.', 'ki-mit-adna-erte' ); ?></div>
	<?php endif; ?>

	<?php if ( 'cannot_tip' === $error || 'tip_too_small' === $error ) : ?>
		<div class="kmae-notice kmae-notice-error"><?php esc_html_e( 'A borravaló most nem küldhető — ellenőrizd az összeget és az üzletet.', 'ki-mit-adna-erte' ); ?></div>
	<?php endif; ?>

	<?php if ( $premium ) : ?>
		<div class="kmae-notice kmae-notice-success"><?php esc_html_e( 'Szupertag aktív', 'ki-mit-adna-erte' ); ?></div>
	<?php endif; ?>

	<?php
	$trust_user_id = $user->ID;
	include KMAE_PLUGIN_DIR . 'templates/partials/trust-card.php';

	$continue_offer_id = KMAE_Deal::get_continue_offer_id( $user->ID );
	if ( $continue_offer_id ) {
		include KMAE_PLUGIN_DIR . 'templates/partials/continue-shopping.php';
		echo '<hr class="kmae-divider" />';
	}

	if ( KMAE_Auth::is_company( $user->ID ) && ! empty( KMAE_Company::get_fees_for_seller( $user->ID ) ) ) {
		include KMAE_PLUGIN_DIR . 'templates/partials/company-fees.php';
		echo '<hr class="kmae-divider" />';
	}
	?>

	<?php
	$rate_offer_id = isset( $_GET['kmae_rate'] ) ? absint( $_GET['kmae_rate'] ) : 0;
	if ( $rate_offer_id ) {
		$rate_offer = KMAE_Database::get_offer( $rate_offer_id );
		$party      = $rate_offer ? KMAE_Trust::resolve_rated_party( $rate_offer, $user->ID ) : null;
		if ( $rate_offer && ! is_wp_error( $party ) && ! KMAE_Trust::has_rated( $rate_offer_id, $user->ID ) ) {
			$offer = $rate_offer;
			include KMAE_PLUGIN_DIR . 'templates/partials/rate-form.php';
			echo '<hr class="kmae-divider" />';
		} elseif ( $rate_offer && KMAE_Trust::has_rated( $rate_offer_id, $user->ID ) ) {
			echo '<div class="kmae-notice kmae-notice-info"><p>' . esc_html__( 'Ezt az üzletet már értékelted.', 'ki-mit-adna-erte' ) . '</p></div>';
		}
	}

	$pending_ratings = KMAE_Trust::get_pending_for_user( $user->ID );
	if ( ! empty( $pending_ratings ) && ! $rate_offer_id ) :
		?>
		<div class="kmae-pending-ratings">
			<h3><?php esc_html_e( 'Függő értékelések', 'ki-mit-adna-erte' ); ?></h3>
			<p class="kmae-hint"><?php esc_html_e( 'Lezárt üzleteid után értékeld a másik felet — így épül a bizalmi szám.', 'ki-mit-adna-erte' ); ?></p>
			<ul class="kmae-pending-ratings__list">
				<?php foreach ( $pending_ratings as $pending ) : ?>
					<?php $plisting = get_post( $pending->listing_id ); ?>
					<li>
						<span><?php echo esc_html( $plisting ? $plisting->post_title : __( 'Hirdetés', 'ki-mit-adna-erte' ) ); ?></span>
						<a class="kmae-btn kmae-btn-sm kmae-btn-primary" href="<?php echo esc_url( KMAE_Trust::rate_url( $pending->id ) ); ?>">
							<?php esc_html_e( 'Értékelem', 'ki-mit-adna-erte' ); ?>
						</a>
					</li>
				<?php endforeach; ?>
			</ul>
		</div>
		<hr class="kmae-divider" />
	<?php endif; ?>

	<?php
	$pending_tips = KMAE_Tips::get_pending_for_seller( $user->ID );
	if ( ! empty( $pending_tips ) ) :
		?>
		<div class="kmae-pending-tips">
			<h3><?php esc_html_e( 'Borravaló', 'ki-mit-adna-erte' ); ?></h3>
			<p class="kmae-hint"><?php esc_html_e( 'Sikeres eladás után küldhetsz borravalót — mindig a vevő kapja, e-mailben.', 'ki-mit-adna-erte' ); ?></p>
			<?php
			foreach ( $pending_tips as $tip_offer ) {
				$offer = $tip_offer;
				include KMAE_PLUGIN_DIR . 'templates/partials/tip-form.php';
			}
			?>
		</div>
		<hr class="kmae-divider" />
	<?php endif; ?>

	<p class="kmae-hint">
		<a href="<?php echo esc_url( KMAE_Pages::url( 'oktatas' ) ); ?>"><?php esc_html_e( 'Oktatórendszer — tippek vevőknek és eladóknak', 'ki-mit-adna-erte' ); ?></a>
	</p>

	<div class="kmae-verification-status">
		<p class="kmae-hint">
			<?php esc_html_e( 'Fiók típusa:', 'ki-mit-adna-erte' ); ?>
			<span class="kmae-badge kmae-badge-accepted"><?php echo esc_html( KMAE_Auth::account_type_label( $user->ID ) ); ?></span>
		</p>
		<p class="kmae-hint">
			<?php esc_html_e( 'E-mail:', 'ki-mit-adna-erte' ); ?>
			<span class="kmae-badge <?php echo ! empty( $profile->email_verified ) ? 'kmae-badge-accepted' : 'kmae-badge-pending'; ?>">
				<?php echo ! empty( $profile->email_verified ) ? esc_html__( 'Megerősítve', 'ki-mit-adna-erte' ) : esc_html__( 'Nincs megerősítve', 'ki-mit-adna-erte' ); ?>
			</span>
		</p>
		<p class="kmae-hint">
			<?php esc_html_e( 'Telefon:', 'ki-mit-adna-erte' ); ?>
			<span class="kmae-badge <?php echo ! empty( $profile->phone_verified ) ? 'kmae-badge-accepted' : 'kmae-badge-pending'; ?>">
				<?php echo ! empty( $profile->phone_verified ) ? esc_html__( 'Megerősítve', 'ki-mit-adna-erte' ) : esc_html__( 'Nincs megerősítve', 'ki-mit-adna-erte' ); ?>
			</span>
		</p>
	</div>

	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="kmae-form">
		<?php wp_nonce_field( 'kmae_save_profile', 'kmae_profile_nonce' ); ?>
		<input type="hidden" name="action" value="kmae_save_profile" />
		<input type="hidden" name="kmae_redirect" value="<?php echo esc_url( $profile_url ); ?>" />
		<div class="kmae-field">
			<label for="kmae_display_name"><?php echo KMAE_Auth::is_company( $user->ID ) ? esc_html__( 'Cégnév', 'ki-mit-adna-erte' ) : esc_html__( 'Megjelenített név', 'ki-mit-adna-erte' ); ?></label>
			<?php if ( KMAE_Auth::is_company( $user->ID ) ) : ?>
				<input type="hidden" name="kmae_display_name" value="<?php echo esc_attr( KMAE_Company::get_company_name( $user->ID ) ); ?>" />
				<input type="text" name="kmae_company_name" id="kmae_display_name" value="<?php echo esc_attr( KMAE_Company::get_company_name( $user->ID ) ); ?>" required />
				<p class="kmae-hint"><?php esc_html_e( 'Ez a név jelenik meg a kereskedői profilodon és a hirdetéseiden.', 'ki-mit-adna-erte' ); ?></p>
			<?php else : ?>
				<input type="text" name="kmae_display_name" id="kmae_display_name" value="<?php echo esc_attr( $user->display_name ); ?>" required />
				<p class="kmae-hint"><?php esc_html_e( 'Ez a név jelenik meg az ajánlatoknál (nem a belépési felhasználóneved).', 'ki-mit-adna-erte' ); ?></p>
			<?php endif; ?>
		</div>
		<?php if ( KMAE_Auth::is_company( $user->ID ) ) : ?>
			<div class="kmae-field-row">
				<div class="kmae-field">
					<label for="kmae_company_tax_id"><?php esc_html_e( 'Adószám', 'ki-mit-adna-erte' ); ?></label>
					<input type="text" name="kmae_company_tax_id" id="kmae_company_tax_id" value="<?php echo esc_attr( KMAE_Company::get_tax_id( $user->ID ) ); ?>" />
				</div>
				<div class="kmae-field">
					<label for="kmae_company_address"><?php esc_html_e( 'Székhely / telephely', 'ki-mit-adna-erte' ); ?></label>
					<input type="text" name="kmae_company_address" id="kmae_company_address" value="<?php echo esc_attr( KMAE_Company::get_address( $user->ID ) ); ?>" />
				</div>
			</div>
		<?php endif; ?>
		<div class="kmae-field">
			<label for="kmae_phone"><?php esc_html_e( 'Telefonszám (privát)', 'ki-mit-adna-erte' ); ?></label>
			<input type="tel" name="kmae_phone" id="kmae_phone" value="<?php echo esc_attr( $phone ); ?>" placeholder="+36 30 123 4567" />
			<p class="kmae-hint"><?php esc_html_e( 'Csak kapcsolatfeloldás után látja a másik fél.', 'ki-mit-adna-erte' ); ?></p>
		</div>
		<button type="submit" class="kmae-btn kmae-btn-primary"><?php esc_html_e( 'Mentés', 'ki-mit-adna-erte' ); ?></button>
	</form>

	<hr class="kmae-divider" />

	<div class="kmae-supertag">
		<h3><?php esc_html_e( 'Szupertag', 'ki-mit-adna-erte' ); ?></h3>
		<ul class="kmae-supertag__benefits">
			<li><?php esc_html_e( 'Minden aktív hirdetésed kiemelést kap (5× gyakrabban a böngészőben)', 'ki-mit-adna-erte' ); ?></li>
			<li><?php esc_html_e( 'Havonta 1 autókozmetika szerződött partnereknél', 'ki-mit-adna-erte' ); ?></li>
			<li><?php esc_html_e( 'Kedvezmény az autókozmetikánál', 'ki-mit-adna-erte' ); ?></li>
			<li><?php esc_html_e( 'Eladói kiemelés: fix összegű boost — sikeres eladásnál a céges 1% díj továbbra is érvényes', 'ki-mit-adna-erte' ); ?></li>
		</ul>
		<?php if ( ! $premium ) : ?>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<?php wp_nonce_field( 'kmae_activate_premium', 'kmae_premium_nonce' ); ?>
				<input type="hidden" name="action" value="kmae_activate_premium" />
				<input type="hidden" name="kmae_redirect" value="<?php echo esc_url( $profile_url ); ?>" />
				<button type="submit" class="kmae-btn kmae-btn-secondary">
					<?php
					printf(
						esc_html__( 'Szupertag — %s / hó', 'ki-mit-adna-erte' ),
						esc_html( KMAE_Settings::format_price( KMAE_Settings::premium_monthly_price() ) )
					);
					?>
				</button>
			</form>
		<?php else : ?>
			<?php if ( KMAE_Premium::can_claim_detailing( $user->ID ) ) : ?>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="kmae-inline-form">
					<?php wp_nonce_field( 'kmae_claim_detailing', 'kmae_detailing_nonce' ); ?>
					<input type="hidden" name="action" value="kmae_claim_detailing" />
					<button type="submit" class="kmae-btn kmae-btn-sm kmae-btn-primary"><?php esc_html_e( 'Havi autókozmetika igénylése', 'ki-mit-adna-erte' ); ?></button>
				</form>
			<?php else : ?>
				<p class="kmae-hint"><?php esc_html_e( 'A havi autókozmetikai kedvezményedet már felhasználtad, vagy a következő hónapban újraindul.', 'ki-mit-adna-erte' ); ?></p>
			<?php endif; ?>
		<?php endif; ?>
	</div>

	<?php
	$back_url   = KMAE_Back::home_url();
	$back_label = KMAE_Back::home_label();
	include KMAE_PLUGIN_DIR . 'templates/partials/page-back.php';
	?>
</div>
