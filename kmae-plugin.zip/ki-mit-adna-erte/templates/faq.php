<?php
/**
 * FAQ page stub.
 *
 * @package KMAE
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="kmae-stub">
	<h1><?php esc_html_e( 'Gyakori kérdések', 'ki-mit-adna-erte' ); ?></h1>
	<p class="kmae-stub__lead"><?php esc_html_e( 'A leggyakoribb kérdések gyűjtőhelye. A tartalom folyamatosan bővül.', 'ki-mit-adna-erte' ); ?></p>

	<section class="kmae-stub__section">
		<h2><?php esc_html_e( 'Hogyan működik az ajánlattétel?', 'ki-mit-adna-erte' ); ?></h2>
		<p><?php esc_html_e( 'Kiválasztasz egy autót, ajánlatot adsz, majd az eladóval a rendszeren belül tárgyaltok. A kapcsolat a megállapodás után nyílik meg.', 'ki-mit-adna-erte' ); ?></p>
	</section>

	<section class="kmae-stub__section">
		<h2><?php esc_html_e( 'Mennyibe kerül a használat?', 'ki-mit-adna-erte' ); ?></h2>
		<p><?php esc_html_e( 'Magánszemélyként a böngészés és az ajánlattétel alapból elérhető. Céges eladóknál sikeres eladás után 1% Albira díj érvényes.', 'ki-mit-adna-erte' ); ?></p>
	</section>

	<section class="kmae-stub__section">
		<h2><?php esc_html_e( 'Hol találom a Hogyan működik? oldalt?', 'ki-mit-adna-erte' ); ?></h2>
		<p>
			<a href="<?php echo esc_url( KMAE_Pages::url( 'hogyan-mukodik' ) ); ?>">
				<?php esc_html_e( 'Nyisd meg a Hogyan működik? oldalt', 'ki-mit-adna-erte' ); ?>
			</a>
		</p>
	</section>
</div>
