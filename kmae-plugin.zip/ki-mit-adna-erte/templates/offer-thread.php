<?php
/**
 * Dedicated offer negotiation thread (chat room).
 *
 * @package KMAE
 * @var object $offer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$user_id          = get_current_user_id();
$listing          = get_post( $offer->listing_id );
$listing_id       = $listing ? (int) $listing->ID : 0;
$status_labels    = KMAE_Counter_Offers::status_labels();
$thumb_url        = $listing_id ? KMAE_Query::get_listing_thumbnail_url( $listing_id, 'medium' ) : '';
$success          = isset( $_GET['kmae_success'] ) ? sanitize_text_field( wp_unslash( $_GET['kmae_success'] ) ) : '';
$error            = isset( $_GET['kmae_error'] ) ? sanitize_text_field( wp_unslash( $_GET['kmae_error'] ) ) : '';
$party_name       = KMAE_Counter_Offers::get_other_party_name( $offer, $user_id );
$amount_summary   = KMAE_Counter_Offers::get_current_amount_summary( $offer );
$show_status_footer = in_array( $offer->status, array( KMAE_Offers::STATUS_ACCEPTED, KMAE_Offers::STATUS_REJECTED, KMAE_Offers::STATUS_WITHDRAWN ), true );
$show_withdraw      = KMAE_Offers::can_withdraw( $offer, $user_id );
$show_chat_footer   = $show_status_footer || $show_withdraw;
$success_messages = array(
	'counter_sent'     => __( 'Ellenajánlat elküldve.', 'ki-mit-adna-erte' ),
	'offer_revised'    => __( 'Ajánlat módosítva.', 'ki-mit-adna-erte' ),
	'offer_accepted'   => __( 'Áll az alku! Egyeztessetek megtekintést — utána jelezzétek, sikerült-e.', 'ki-mit-adna-erte' ),
	'deal_success'     => __( 'Üzlet lezárva — az autó elkelt.', 'ki-mit-adna-erte' ),
	'deal_failure'     => __( 'A találkozó nem vezetett üzlethez. Az alku feloldódott, folytathatjátok.', 'ki-mit-adna-erte' ),
	'offer_withdrawn'  => __( 'Az ajánlat visszavonva.', 'ki-mit-adna-erte' ),
);
?>
<div class="kmae-offer-thread kmae-offer-thread--room"
	data-kmae-live-page="offer_thread"
	data-kmae-offer-id="<?php echo esc_attr( (string) $offer->id ); ?>"
	data-kmae-live-fingerprint="<?php echo esc_attr( KMAE_Live_Page::get_fingerprint( 'offer_thread', array( 'offer_id' => (int) $offer->id ) ) ); ?>">
	<p class="kmae-thread-back">
		<a href="<?php echo esc_url( KMAE_Pages::offers_page_url() ); ?>" class="kmae-btn kmae-btn-sm kmae-btn-secondary"><?php esc_html_e( 'Vissza az ajánlatokhoz', 'ki-mit-adna-erte' ); ?></a>
	</p>

	<div class="kmae-chat-shell">
		<header class="kmae-chat-shell-header">
			<?php if ( $thumb_url ) : ?>
				<img src="<?php echo esc_url( $thumb_url ); ?>" alt="" class="kmae-chat-shell-thumb" width="56" height="56" loading="lazy" />
			<?php endif; ?>
			<div class="kmae-chat-shell-header-text">
				<h2 class="kmae-chat-shell-party-name"><?php echo esc_html( $party_name ); ?></h2>
				<p class="kmae-chat-shell-amount-line"><?php echo esc_html( $amount_summary ); ?></p>
				<?php if ( $listing ) : ?>
					<p class="kmae-chat-shell-listing-line">
						<a href="<?php echo esc_url( get_permalink( $listing_id ) ); ?>" target="_blank" rel="noopener">
							<?php echo esc_html( $listing->post_title ); ?> ↗
						</a>
					</p>
				<?php endif; ?>
			</div>
			<span class="kmae-badge kmae-badge-<?php echo esc_attr( $offer->status ); ?> kmae-chat-shell-badge">
				<?php echo esc_html( $status_labels[ $offer->status ] ?? $offer->status ); ?>
			</span>
		</header>

		<?php if ( $success && isset( $success_messages[ $success ] ) ) : ?>
			<div class="kmae-chat-flash kmae-chat-flash--success"><?php echo esc_html( $success_messages[ $success ] ); ?></div>
		<?php endif; ?>

		<?php if ( $error ) : ?>
			<div class="kmae-chat-flash kmae-chat-flash--error"><?php esc_html_e( 'A művelet nem sikerült. Próbáld újra.', 'ki-mit-adna-erte' ); ?></div>
		<?php endif; ?>

		<div class="kmae-chat-shell-body">
			<?php echo KMAE_Offers::render_offer_images( $offer->id ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			<?php include KMAE_PLUGIN_DIR . 'templates/partials/offer-chat-timeline.php'; ?>
		</div>

		<?php if ( $show_chat_footer ) : ?>
		<footer class="kmae-chat-shell-footer">
			<?php if ( $show_withdraw ) : ?>
				<div class="kmae-chat-shell-withdraw">
					<?php include KMAE_PLUGIN_DIR . 'templates/partials/offer-withdraw-form.php'; ?>
				</div>
			<?php endif; ?>
			<?php if ( $show_status_footer ) : ?>
				<?php include KMAE_PLUGIN_DIR . 'templates/partials/offer-chat-actions.php'; ?>
			<?php endif; ?>
		</footer>
		<?php endif; ?>
	</div>
</div>
