<?php
/**
 * Notifications inbox stub.
 *
 * @package KMAE
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="kmae-stub">
	<h1><?php esc_html_e( 'Értesítések', 'ki-mit-adna-erte' ); ?></h1>
	<p class="kmae-stub__lead"><?php esc_html_e( 'Itt jelennek meg majd az ajánlatokról, üzenetekről és hirdetésállapotról szóló értesítések.', 'ki-mit-adna-erte' ); ?></p>

	<section class="kmae-stub__section">
		<h2><?php esc_html_e( 'Még nincs értesítés', 'ki-mit-adna-erte' ); ?></h2>
		<p><?php esc_html_e( 'Amint érkezik új ajánlat vagy frissítés, itt fogod látni. Addig az e-mail értesítések továbbra is működnek.', 'ki-mit-adna-erte' ); ?></p>
	</section>

	<?php
	$back_url   = KMAE_Back::home_url();
	$back_label = KMAE_Back::home_label();
	include KMAE_PLUGIN_DIR . 'templates/partials/page-back.php';
	?>
</div>
