<?php
/**
 * My listings template.
 *
 * @package KMAE
 * @var array $listings
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$success = isset( $_GET['kmae_success'] ) ? sanitize_text_field( wp_unslash( $_GET['kmae_success'] ) ) : '';
$error   = isset( $_GET['kmae_error'] ) ? sanitize_text_field( wp_unslash( $_GET['kmae_error'] ) ) : '';
?>
<div class="kmae-my-listings">
	<h2><?php esc_html_e( 'Saját hirdetéseim', 'ki-mit-adna-erte' ); ?></h2>

	<?php if ( is_user_logged_in() && KMAE_Auth::is_company( get_current_user_id() ) ) : ?>
		<p class="kmae-hint"><?php esc_html_e( 'Céges fiók: korlátlan hirdetés. Minden autó külön alkufolyamat. Sikeres eladás után 1% Albira díj.', 'ki-mit-adna-erte' ); ?></p>
	<?php elseif ( is_user_logged_in() && KMAE_Auth::is_private_person( get_current_user_id() ) ) : ?>
		<p class="kmae-hint"><?php esc_html_e( 'Magánszemélyként egyszerre egy aktív hirdetésed lehet.', 'ki-mit-adna-erte' ); ?></p>
	<?php endif; ?>

	<?php if ( 'listing_created' === $success ) : ?>
		<div class="kmae-notice kmae-notice-success">
			<?php esc_html_e( 'Autó hirdetésed sikeresen közzétételre került!', 'ki-mit-adna-erte' ); ?>
		</div>
	<?php endif; ?>

	<?php if ( 'listing_awaiting_photos' === $success ) : ?>
		<div class="kmae-notice kmae-notice-success">
			<?php esc_html_e( 'Hirdetés mentve: 📸 Fotó feltöltésre vár. Később telefonon készítsd el az autófotókat — addig nem jelenik meg a vevőknek.', 'ki-mit-adna-erte' ); ?>
		</div>
	<?php endif; ?>

	<?php if ( 'listing_activated' === $success ) : ?>
		<div class="kmae-notice kmae-notice-success">
			<?php esc_html_e( 'Fotók mentve — a hirdetés mostantól 🟢 Aktív, és megjelenik a böngészésben.', 'ki-mit-adna-erte' ); ?>
		</div>
	<?php endif; ?>

	<?php if ( 'listing_updated' === $success ) : ?>
		<div class="kmae-notice kmae-notice-success">
			<?php esc_html_e( 'A hirdetés módosításai mentve.', 'ki-mit-adna-erte' ); ?>
		</div>
	<?php endif; ?>

	<?php if ( 'listing_deleted' === $success ) : ?>
		<div class="kmae-notice kmae-notice-success">
			<?php esc_html_e( 'A hirdetés törölve.', 'ki-mit-adna-erte' ); ?>
		</div>
	<?php endif; ?>

	<?php if ( 'listing_reactivated' === $success ) : ?>
		<div class="kmae-notice kmae-notice-success">
			<?php esc_html_e( 'A hirdetés újra aktív — ismét megjelenik a böngészésben.', 'ki-mit-adna-erte' ); ?>
		</div>
	<?php endif; ?>

	<?php if ( 'listing_locked' === $error ) : ?>
		<div class="kmae-notice kmae-notice-error">
			<?php esc_html_e( 'Ez a hirdetés archivált — jelenleg nem módosítható.', 'ki-mit-adna-erte' ); ?>
		</div>
	<?php elseif ( 'not_allowed' === $error ) : ?>
		<div class="kmae-notice kmae-notice-error">
			<?php esc_html_e( 'A hirdetés még nem aktiválható újra, vagy már lejárt az idő.', 'ki-mit-adna-erte' ); ?>
		</div>
	<?php elseif ( $error ) : ?>
		<div class="kmae-notice kmae-notice-error">
			<?php esc_html_e( 'A művelet nem sikerült. Próbáld újra.', 'ki-mit-adna-erte' ); ?>
		</div>
	<?php endif; ?>

	<?php if ( empty( $listings ) ) : ?>
		<div class="kmae-empty">
			<p><?php esc_html_e( 'Még nincs hirdetésed.', 'ki-mit-adna-erte' ); ?></p>
			<a href="<?php echo esc_url( home_url( '/hirdetes-feladasa/' ) ); ?>" class="kmae-btn kmae-btn-primary"><?php esc_html_e( 'Első hirdetés feladása', 'ki-mit-adna-erte' ); ?></a>
		</div>
	<?php else : ?>
		<div class="kmae-listing-cards">
			<?php foreach ( $listings as $listing ) : ?>
				<?php
				$status        = KMAE_Meta::get_status( $listing->ID );
				$lifecycle     = KMAE_Listings::get_archive_lifecycle( $listing->ID );
				$edit_url      = add_query_arg( 'kmae_edit', $listing->ID, home_url( '/hirdetes-feladasa/' ) );
				$view_url      = get_permalink( $listing->ID );
				$gallery_ids   = KMAE_Query::get_gallery_ids( $listing->ID );
				$thumb_id      = ! empty( $gallery_ids ) ? (int) $gallery_ids[0] : (int) get_post_thumbnail_id( $listing->ID );
				$thumb         = $thumb_id ? KMAE_Images::get_url( $thumb_id, 'medium' ) : '';
				$status_labels = KMAE_Meta::status_labels();
				$can_edit      = KMAE_Listings::can_edit_listing( $listing->ID );
				$can_delete    = KMAE_Listings::can_delete_listing( $listing->ID );
				$can_reactivate = KMAE_Listings::can_reactivate_listing( $listing->ID );
				$photos_url    = add_query_arg(
					array(
						'kmae_edit'   => $listing->ID,
						'kmae_photos' => '1',
					),
					home_url( '/hirdetes-feladasa/' )
				);
				?>
				<div class="kmae-listing-card <?php echo $lifecycle ? 'kmae-listing-card--archived' : ''; ?>">
					<a href="<?php echo esc_url( KMAE_Meta::STATUS_AWAITING_PHOTOS === $status ? $photos_url : $view_url ); ?>" class="kmae-card-thumb-link">
						<?php if ( $thumb ) : ?>
							<div class="kmae-image-frame">
								<img src="<?php echo esc_url( $thumb ); ?>" alt="" class="kmae-card-image" loading="lazy" />
							</div>
						<?php else : ?>
							<div class="kmae-card-image kmae-no-image"></div>
						<?php endif; ?>
					</a>
					<div class="kmae-card-body">
						<h3>
							<a href="<?php echo esc_url( KMAE_Meta::STATUS_AWAITING_PHOTOS === $status ? $photos_url : $view_url ); ?>" class="kmae-card-title-link">
								<?php echo esc_html( $listing->post_title ); ?>
							</a>
						</h3>
						<?php if ( KMAE_Vehicle::is_vehicle_launch() ) : ?>
							<?php $swipe_sub = KMAE_Vehicle::get_swipe_subtitle( $listing->ID ); ?>
							<?php if ( $swipe_sub ) : ?><p class="kmae-card-specs"><?php echo esc_html( $swipe_sub ); ?></p><?php endif; ?>
						<?php endif; ?>
						<span class="kmae-badge kmae-badge-<?php echo esc_attr( $status ); ?>"><?php echo esc_html( $status_labels[ $status ] ?? $status ); ?></span>

						<?php if ( KMAE_Meta::STATUS_AWAITING_PHOTOS === $status ) : ?>
							<p class="kmae-listing-archive-note kmae-listing-archive-note--warn">
								<?php esc_html_e( 'A hirdetés még nem publikus. Készítsd el a kötelező autófotókat telefonnal.', 'ki-mit-adna-erte' ); ?>
							</p>
						<?php endif; ?>

						<?php if ( $lifecycle && 'locked' === $lifecycle['phase'] ) : ?>
							<p class="kmae-listing-archive-note">
								<?php
								printf(
									esc_html(
										_n(
											'Üzletkötés után archiválva. %d nap múlva újraaktiválható.',
											'Üzletkötés után archiválva. %d nap múlva újraaktiválható.',
											(int) $lifecycle['days_until_reactivate'],
											'ki-mit-adna-erte'
										)
									),
									(int) $lifecycle['days_until_reactivate']
								);
								?>
							</p>
						<?php elseif ( $lifecycle && 'reactivate' === $lifecycle['phase'] ) : ?>
							<p class="kmae-listing-archive-note kmae-listing-archive-note--warn">
								<?php
								printf(
									esc_html(
										_n(
											'Újraaktiválhatod %d napig — utána a rendszer törli.',
											'Újraaktiválhatod %d napig — utána a rendszer törli.',
											(int) $lifecycle['days_until_delete'],
											'ki-mit-adna-erte'
										)
									),
									(int) $lifecycle['days_until_delete']
								);
								?>
							</p>
						<?php endif; ?>

						<div class="kmae-card-actions">
							<?php if ( KMAE_Meta::STATUS_AWAITING_PHOTOS === $status ) : ?>
								<a href="<?php echo esc_url( $photos_url ); ?>" class="kmae-btn kmae-btn-sm kmae-btn-primary"><?php esc_html_e( 'Fotók készítése', 'ki-mit-adna-erte' ); ?></a>
							<?php else : ?>
								<a href="<?php echo esc_url( get_permalink( $listing->ID ) ); ?>" class="kmae-btn kmae-btn-sm"><?php esc_html_e( 'Megtekintés', 'ki-mit-adna-erte' ); ?></a>
							<?php endif; ?>

							<?php if ( $can_edit && KMAE_Meta::STATUS_AWAITING_PHOTOS !== $status ) : ?>
								<a href="<?php echo esc_url( $edit_url ); ?>" class="kmae-btn kmae-btn-sm kmae-btn-secondary"><?php esc_html_e( 'Szerkesztés', 'ki-mit-adna-erte' ); ?></a>
							<?php elseif ( $can_edit && KMAE_Meta::STATUS_AWAITING_PHOTOS === $status ) : ?>
								<a href="<?php echo esc_url( $edit_url ); ?>" class="kmae-btn kmae-btn-sm kmae-btn-secondary"><?php esc_html_e( 'Adatok szerkesztése', 'ki-mit-adna-erte' ); ?></a>
							<?php endif; ?>

							<?php if ( $can_reactivate ) : ?>
								<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline;" onsubmit="return confirm('<?php echo esc_js( __( 'Újraaktiválod a hirdetést? Ismét megjelenik a böngészésben.', 'ki-mit-adna-erte' ) ); ?>');">
									<?php wp_nonce_field( 'kmae_reactivate_listing', 'kmae_reactivate_listing_nonce' ); ?>
									<input type="hidden" name="action" value="kmae_reactivate_listing" />
									<input type="hidden" name="kmae_listing_id" value="<?php echo esc_attr( $listing->ID ); ?>" />
									<button type="submit" class="kmae-btn kmae-btn-sm kmae-btn-primary"><?php esc_html_e( 'Újraaktiválás', 'ki-mit-adna-erte' ); ?></button>
								</form>
							<?php endif; ?>

							<?php if ( $can_delete ) : ?>
								<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline;" onsubmit="return confirm('<?php echo esc_js( __( 'Biztosan törlöd a hirdetést? Ez nem vonható vissza.', 'ki-mit-adna-erte' ) ); ?>');">
									<?php wp_nonce_field( 'kmae_delete_listing', 'kmae_delete_listing_nonce' ); ?>
									<input type="hidden" name="action" value="kmae_delete_listing" />
									<input type="hidden" name="kmae_listing_id" value="<?php echo esc_attr( $listing->ID ); ?>" />
									<button type="submit" class="kmae-btn kmae-btn-sm kmae-btn-danger"><?php esc_html_e( 'Törlés', 'ki-mit-adna-erte' ); ?></button>
								</form>
							<?php endif; ?>

							<?php if ( 'active' === $status && ! KMAE_Premium::is_featured( $listing->ID ) ) : ?>
								<form method="post" style="display:inline;">
									<?php wp_nonce_field( 'kmae_feature_listing_nonce', 'kmae_feature_listing_nonce' ); ?>
									<input type="hidden" name="kmae_action" value="feature_listing" />
									<input type="hidden" name="kmae_listing_id" value="<?php echo esc_attr( $listing->ID ); ?>" />
									<button type="submit" class="kmae-btn kmae-btn-sm kmae-btn-secondary" title="<?php esc_attr_e( 'A kiemelt hirdetés 5× gyakrabban jelenik meg a böngészőben.', 'ki-mit-adna-erte' ); ?>">
										<?php esc_html_e( 'Kiemelés (5×)', 'ki-mit-adna-erte' ); ?>
									</button>
								</form>
							<?php endif; ?>
						</div>
					</div>
				</div>
			<?php endforeach; ?>
		</div>
	<?php endif; ?>

	<?php
	$back_url   = KMAE_Back::home_url();
	$back_label = KMAE_Back::home_label();
	include KMAE_PLUGIN_DIR . 'templates/partials/page-back.php';
	?>
</div>
