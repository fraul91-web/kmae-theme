<?php
/**
 * Public contact form.
 *
 * @package KMAE
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$error   = isset( $_GET['kmae_error'] ) ? sanitize_text_field( wp_unslash( $_GET['kmae_error'] ) ) : '';
$success = isset( $_GET['kmae_success'] ) ? sanitize_text_field( wp_unslash( $_GET['kmae_success'] ) ) : '';

$error_messages = array(
	'nonce_failed'   => __( 'A munkamenet lejárt — frissítsd az oldalt és próbáld újra.', 'ki-mit-adna-erte' ),
	'missing_fields' => __( 'Kérjük, töltsd ki a nevet, az érvényes e-mail címet és az üzenetet.', 'ki-mit-adna-erte' ),
	'message_short'  => __( 'Az üzenet legyen legalább 10 karakter.', 'ki-mit-adna-erte' ),
	'message_long'   => __( 'Az üzenet túl hosszú (max. 5000 karakter).', 'ki-mit-adna-erte' ),
	'rate_limited'   => __( 'Túl sok üzenetet küldtél rövid időn belül. Próbáld újra később.', 'ki-mit-adna-erte' ),
	'send_failed'    => __( 'Az üzenet küldése nem sikerült. Próbáld újra pár perc múlva.', 'ki-mit-adna-erte' ),
);

$prefill_name  = '';
$prefill_email = '';
if ( is_user_logged_in() ) {
	$user          = wp_get_current_user();
	$prefill_name  = $user->display_name ? $user->display_name : '';
	$prefill_email = $user->user_email ? $user->user_email : '';
}

$topics = array(
	'altalanos' => __( 'Általános kérdés', 'ki-mit-adna-erte' ),
	'fiok'      => __( 'Fiók / belépés', 'ki-mit-adna-erte' ),
	'hirdetes'  => __( 'Hirdetés', 'ki-mit-adna-erte' ),
	'ajanlat'   => __( 'Ajánlat / alkudozás', 'ki-mit-adna-erte' ),
	'technikai' => __( 'Technikai hiba', 'ki-mit-adna-erte' ),
	'egyeb'     => __( 'Egyéb', 'ki-mit-adna-erte' ),
);
?>
<div class="kmae-auth kmae-auth--contact">
	<header class="kmae-auth__header">
		<p class="kmae-auth__eyebrow"><?php esc_html_e( 'Elérhetőség', 'ki-mit-adna-erte' ); ?></p>
		<h2 class="kmae-auth__title"><?php esc_html_e( 'Írj nekünk', 'ki-mit-adna-erte' ); ?></h2>
		<p class="kmae-auth__lead"><?php esc_html_e( 'Kérdésed van az Albiráról, a hirdetésről vagy a fiókodról? Küldd el az üzeneted — válaszolunk.', 'ki-mit-adna-erte' ); ?></p>
	</header>

	<?php if ( $success && 'contact_sent' === $success ) : ?>
		<div class="kmae-notice kmae-notice-success" role="status">
			<?php esc_html_e( 'Köszönjük! Az üzeneted elküldtük. Hamarosan jelentkezünk.', 'ki-mit-adna-erte' ); ?>
		</div>
	<?php endif; ?>

	<?php if ( $error && isset( $error_messages[ $error ] ) ) : ?>
		<div class="kmae-notice kmae-notice-error" role="alert"><?php echo esc_html( $error_messages[ $error ] ); ?></div>
	<?php endif; ?>

	<?php if ( ! ( $success && 'contact_sent' === $success ) ) : ?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="kmae-form kmae-auth__form" novalidate>
			<?php wp_nonce_field( 'kmae_contact_form', 'kmae_contact_form_nonce' ); ?>
			<input type="hidden" name="action" value="kmae_contact_form" />

			<p class="kmae-contact__hp" aria-hidden="true">
				<label for="kmae_website"><?php esc_html_e( 'Weboldal', 'ki-mit-adna-erte' ); ?></label>
				<input type="text" name="kmae_website" id="kmae_website" value="" tabindex="-1" autocomplete="off" />
			</p>

			<div class="kmae-field-row">
				<div class="kmae-field">
					<label for="kmae_contact_name"><?php esc_html_e( 'Név *', 'ki-mit-adna-erte' ); ?></label>
					<input
						type="text"
						name="kmae_contact_name"
						id="kmae_contact_name"
						required
						maxlength="120"
						autocomplete="name"
						placeholder="<?php echo esc_attr__( 'Teljes neved', 'ki-mit-adna-erte' ); ?>"
						value="<?php echo esc_attr( $prefill_name ); ?>"
					/>
				</div>
				<div class="kmae-field">
					<label for="kmae_contact_email"><?php esc_html_e( 'E-mail *', 'ki-mit-adna-erte' ); ?></label>
					<input
						type="email"
						name="kmae_contact_email"
						id="kmae_contact_email"
						required
						autocomplete="email"
						placeholder="nev@email.hu"
						value="<?php echo esc_attr( $prefill_email ); ?>"
					/>
				</div>
			</div>

			<div class="kmae-field">
				<label for="kmae_contact_topic"><?php esc_html_e( 'Téma', 'ki-mit-adna-erte' ); ?></label>
				<select name="kmae_contact_topic" id="kmae_contact_topic">
					<?php foreach ( $topics as $value => $label ) : ?>
						<option value="<?php echo esc_attr( $value ); ?>"><?php echo esc_html( $label ); ?></option>
					<?php endforeach; ?>
				</select>
			</div>

			<div class="kmae-field">
				<label for="kmae_contact_message"><?php esc_html_e( 'Üzenet *', 'ki-mit-adna-erte' ); ?></label>
				<textarea
					name="kmae_contact_message"
					id="kmae_contact_message"
					required
					rows="6"
					minlength="10"
					maxlength="5000"
					placeholder="<?php echo esc_attr__( 'Írd le röviden, miben segíthetünk…', 'ki-mit-adna-erte' ); ?>"
				></textarea>
			</div>

			<button type="submit" class="kmae-btn kmae-btn-primary kmae-btn--register kmae-auth__submit">
				<?php esc_html_e( 'Üzenet küldése', 'ki-mit-adna-erte' ); ?>
			</button>
		</form>
	<?php else : ?>
		<p class="kmae-auth__back">
			<a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Vissza a főoldalra', 'ki-mit-adna-erte' ); ?></a>
		</p>
	<?php endif; ?>

	<p class="kmae-contact__meta">
		<?php esc_html_e( 'Általában 1–2 munkanapon belül válaszolunk.', 'ki-mit-adna-erte' ); ?>
		<?php if ( KMAE_Pages::url( 'gyik' ) ) : ?>
			<a href="<?php echo esc_url( KMAE_Pages::url( 'gyik' ) ); ?>"><?php esc_html_e( 'Gyakori kérdések', 'ki-mit-adna-erte' ); ?></a>
		<?php endif; ?>
	</p>
</div>
