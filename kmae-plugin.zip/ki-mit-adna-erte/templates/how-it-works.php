<?php
/**
 * How it works — sellers / buyers flows + video cards.
 *
 * @package KMAE
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$seller_steps = array(
	array(
		'title' => __( 'Hirdetés létrehozása', 'ki-mit-adna-erte' ),
		'text'  => __( 'Add meg az autó adatait, töltsd fel a képeket, és mi segítünk a pontos kitöltésben.', 'ki-mit-adna-erte' ),
		'icon'  => 'plus',
	),
	array(
		'title' => __( 'Ellenőrzés', 'ki-mit-adna-erte' ),
		'text'  => __( 'Rendszerünk több lépésben ellenőrzi a hirdetést, hogy kiszűrjük a gyanús vagy hiányos tartalmakat.', 'ki-mit-adna-erte' ),
		'icon'  => 'shield',
	),
	array(
		'title' => __( 'Kapcsolatfelvétel', 'ki-mit-adna-erte' ),
		'text'  => __( 'Az érdeklődők egyszerűen felveszik veled a kapcsolatot a rendszer üzenetfelületén keresztül.', 'ki-mit-adna-erte' ),
		'icon'  => 'chat',
	),
	array(
		'title' => __( 'Megállapodás', 'ki-mit-adna-erte' ),
		'text'  => __( 'Egyezzetek meg a részletekben. Lehetőséged van rögzíteni a megbeszélt feltételeket.', 'ki-mit-adna-erte' ),
		'icon'  => 'handshake',
	),
	array(
		'title' => __( 'Sikeres eladás', 'ki-mit-adna-erte' ),
		'text'  => __( 'Az adás-vétel lezárása után értékeld a vevőt, ezzel segíted a közösség megbízhatóságát.', 'ki-mit-adna-erte' ),
		'icon'  => 'check',
	),
);

$buyer_steps = array(
	array(
		'title' => __( 'Keresés és szűrés', 'ki-mit-adna-erte' ),
		'text'  => __( 'Használd a részletes szűrőket, hogy gyorsan megtaláld, amit keresel.', 'ki-mit-adna-erte' ),
		'icon'  => 'search',
	),
	array(
		'title' => __( 'Hirdetés megtekintése', 'ki-mit-adna-erte' ),
		'text'  => __( 'Átlátható információk, valós képek és ellenőrzött hirdetések várnak.', 'ki-mit-adna-erte' ),
		'icon'  => 'list',
	),
	array(
		'title' => __( 'Kapcsolatfelvétel', 'ki-mit-adna-erte' ),
		'text'  => __( 'Lépj kapcsolatba az eladóval egyszerűen, a rendszer üzenetfelületén keresztül.', 'ki-mit-adna-erte' ),
		'icon'  => 'chat',
	),
	array(
		'title' => __( 'Megtekintés', 'ki-mit-adna-erte' ),
		'text'  => __( 'Nézd meg az autót, ellenőrizd a részleteket, tegyél fel kérdéseket.', 'ki-mit-adna-erte' ),
		'icon'  => 'car',
	),
	array(
		'title' => __( 'Biztonságos vásárlás', 'ki-mit-adna-erte' ),
		'text'  => __( 'Egyeztesd a részleteket, zárjátok le az adás-vételt, értékeld az eladót.', 'ki-mit-adna-erte' ),
		'icon'  => 'shield',
	),
);

$trust_items = array(
	array(
		'title' => __( 'Több biztonság', 'ki-mit-adna-erte' ),
		'text'  => __( 'Többlépcsős ellenőrzés és szigorú szűrők a biztonságért.', 'ki-mit-adna-erte' ),
		'icon'  => 'shield',
	),
	array(
		'title' => __( 'Gyorsabb üzlet', 'ki-mit-adna-erte' ),
		'text'  => __( 'Kevesebb időpazarlás, több valódi érdeklődő.', 'ki-mit-adna-erte' ),
		'icon'  => 'zap',
	),
	array(
		'title' => __( 'Valódi kapcsolatok', 'ki-mit-adna-erte' ),
		'text'  => __( 'Közvetlen kommunikáció valódi emberek között.', 'ki-mit-adna-erte' ),
		'icon'  => 'users',
	),
	array(
		'title' => __( 'Átláthatóság', 'ki-mit-adna-erte' ),
		'text'  => __( 'Részletes adatok, nyomon követhető folyamat.', 'ki-mit-adna-erte' ),
		'icon'  => 'lock',
	),
	array(
		'title' => __( 'Megbízható közösség', 'ki-mit-adna-erte' ),
		'text'  => __( 'Értékelések és visszajelzések, amire számíthatsz.', 'ki-mit-adna-erte' ),
		'icon'  => 'star',
	),
);

/**
 * Inline step / trust icons for the how-it-works page.
 *
 * @param string $name Icon key.
 */
if ( ! function_exists( 'kmae_how_icon' ) ) {
	function kmae_how_icon( $name ) {
		$icons = array(
			'plus'      => '<path d="M12 5v14"/><path d="M5 12h14"/>',
			'shield'    => '<path d="M12 3l8 3v6c0 5-3.5 8.5-8 10-4.5-1.5-8-5-8-10V6l8-3z"/><path d="m9 12 2 2 4-4"/>',
			'chat'      => '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>',
			'handshake' => '<path d="m11 17 2 2a1 1 0 1 0 3-3"/><path d="m14 14 2.5 2.5a1 1 0 1 0 3-3l-3.88-3.88a3 3 0 0 0-4.24 0l-.88.88a1 1 0 1 1-3-3l2.81-2.81a5.79 5.79 0 0 1 7.06-.87l.47.28a2 2 0 0 0 1.42.25L21 4"/><path d="m21 3 1 11h-2"/><path d="M3 3 2 14l6.5 6.5a1 1 0 1 0 3-3"/><path d="M3 4h8"/>',
			'check'     => '<path d="M20 6 9 17l-5-5"/>',
			'search'    => '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
			'list'      => '<path d="M8 6h13"/><path d="M8 12h13"/><path d="M8 18h13"/><path d="M3 6h.01"/><path d="M3 12h.01"/><path d="M3 18h.01"/>',
			'car'       => '<path d="M19 17h2c.6 0 1-.4 1-1v-3c0-.9-.7-1.7-1.5-1.9C18.7 10.6 16 10 16 10s-1.3-1.4-2.2-2.3c-.5-.4-1.1-.7-1.8-.7H5c-.6 0-1.1.4-1.4.9l-1.4 2.9A3.7 3.7 0 0 0 2 12v4c0 .6.4 1 1 1h2"/><circle cx="7" cy="17" r="2"/><path d="M9 17h6"/><circle cx="17" cy="17" r="2"/>',
			'zap'       => '<path d="M13 2 4 14h7l-1 8 9-12h-7l1-8z"/>',
			'users'     => '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
			'lock'      => '<rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>',
			'star'      => '<path d="M12 3l2.4 4.9 5.4.8-3.9 3.8.9 5.4L12 15.9 7.2 18l.9-5.4L4.2 8.7l5.4-.8L12 3z"/>',
			'tag'       => '<path d="M12 2H3v9l9 9 9-9-9-9z"/><circle cx="7.5" cy="7.5" r="1.5"/>',
		);

		$path = isset( $icons[ $name ] ) ? $icons[ $name ] : $icons['check'];

		printf(
			'<svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">%s</svg>',
			$path // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG paths.
		);
	}
}

/**
 * Render a role flow row.
 *
 * @param string            $role         seller|buyer.
 * @param string            $title        Section title.
 * @param string            $subtitle     Section explanatory line.
 * @param string            $heading_icon Icon for heading.
 * @param array<int, array> $steps        Steps.
 * @param string            $video_id     YouTube id or empty.
 * @param string            $video_label  CTA under play.
 */
if ( ! function_exists( 'kmae_how_render_flow' ) ) {
	function kmae_how_render_flow( $role, $title, $subtitle, $heading_icon, $steps, $video_id, $video_label ) {
		$has_video = (bool) $video_id;
		?>
		<section class="kmae-how-flow kmae-how-flow--<?php echo esc_attr( $role ); ?>" aria-labelledby="kmae-how-<?php echo esc_attr( $role ); ?>-title">
			<div class="kmae-how-flow__main">
				<header class="kmae-how-flow__header">
					<span class="kmae-how-flow__badge" aria-hidden="true">
						<?php kmae_how_icon( $heading_icon ); ?>
					</span>
					<div class="kmae-how-flow__heading">
						<h2 id="kmae-how-<?php echo esc_attr( $role ); ?>-title" class="kmae-how-flow__title"><?php echo esc_html( $title ); ?></h2>
						<p class="kmae-how-flow__subtitle"><?php echo esc_html( $subtitle ); ?></p>
					</div>
				</header>

				<ol class="kmae-how-steps">
					<?php foreach ( $steps as $index => $step ) : ?>
						<li class="kmae-how-steps__item">
							<span class="kmae-how-steps__num" aria-hidden="true"><?php echo esc_html( (string) ( $index + 1 ) ); ?></span>
							<span class="kmae-how-steps__icon" aria-hidden="true">
								<?php kmae_how_icon( $step['icon'] ); ?>
							</span>
							<strong class="kmae-how-steps__label"><?php echo esc_html( $step['title'] ); ?></strong>
							<p class="kmae-how-steps__text"><?php echo esc_html( $step['text'] ); ?></p>
						</li>
					<?php endforeach; ?>
				</ol>
			</div>

			<div class="kmae-how-video">
				<?php if ( $has_video ) : ?>
					<button
						type="button"
						class="kmae-how-video__card"
						data-kmae-video-id="<?php echo esc_attr( $video_id ); ?>"
						data-kmae-video-role="<?php echo esc_attr( $role ); ?>"
						aria-label="<?php echo esc_attr( $video_label ); ?>"
					>
						<span class="kmae-how-video__play" aria-hidden="true">
							<svg width="28" height="28" viewBox="0 0 28 28" fill="none" xmlns="http://www.w3.org/2000/svg">
								<path d="M10 7.5v13l12-6.5-12-6.5z" fill="currentColor"/>
							</svg>
						</span>
						<span class="kmae-how-video__caption"><?php echo esc_html( $video_label ); ?></span>
					</button>
				<?php else : ?>
					<div class="kmae-how-video__card kmae-how-video__card--empty" aria-disabled="true">
						<span class="kmae-how-video__play kmae-how-video__play--muted" aria-hidden="true">
							<svg width="28" height="28" viewBox="0 0 28 28" fill="none" xmlns="http://www.w3.org/2000/svg">
								<path d="M10 7.5v13l12-6.5-12-6.5z" fill="currentColor"/>
							</svg>
						</span>
						<span class="kmae-how-video__caption"><?php esc_html_e( 'Videó hamarosan', 'ki-mit-adna-erte' ); ?></span>
					</div>
				<?php endif; ?>
			</div>
		</section>
		<?php
	}
}
?>
<div class="kmae-how-page">
	<header class="kmae-how-page__intro">
		<h1 class="kmae-how-page__title"><?php esc_html_e( 'Hogyan működik?', 'ki-mit-adna-erte' ); ?></h1>
		<p class="kmae-how-page__lead"><?php esc_html_e( 'Egyszerű lépések. Biztonságos adás-vétel.', 'ki-mit-adna-erte' ); ?></p>
	</header>

	<?php
	kmae_how_render_flow(
		'seller',
		__( 'Eladóknak', 'ki-mit-adna-erte' ),
		__( 'Gyors és biztonságos értékesítés lépésről lépésre.', 'ki-mit-adna-erte' ),
		'tag',
		$seller_steps,
		$seller_video_id,
		__( 'Nézd meg videón, hogyan működik eladóként!', 'ki-mit-adna-erte' )
	);

	kmae_how_render_flow(
		'buyer',
		__( 'Vevőknek', 'ki-mit-adna-erte' ),
		__( 'Találd meg álmaid autóját egyszerűen és biztonságosan.', 'ki-mit-adna-erte' ),
		'car',
		$buyer_steps,
		$buyer_video_id,
		__( 'Nézd meg videón, hogyan működik vevőként!', 'ki-mit-adna-erte' )
	);
	?>

	<aside class="kmae-how-trust" aria-label="<?php esc_attr_e( 'Miért Albira?', 'ki-mit-adna-erte' ); ?>">
		<ul class="kmae-how-trust__list">
			<?php foreach ( $trust_items as $item ) : ?>
				<li class="kmae-how-trust__item">
					<span class="kmae-how-trust__icon" aria-hidden="true"><?php kmae_how_icon( $item['icon'] ); ?></span>
					<span class="kmae-how-trust__copy">
						<strong class="kmae-how-trust__label"><?php echo esc_html( $item['title'] ); ?></strong>
						<span class="kmae-how-trust__text"><?php echo esc_html( $item['text'] ); ?></span>
					</span>
				</li>
			<?php endforeach; ?>
		</ul>
	</aside>

	<p class="kmae-how-edu-link">
		<a class="kmae-btn kmae-btn-secondary" href="<?php echo esc_url( KMAE_Pages::url( 'oktatas' ) ); ?>">
			<?php esc_html_e( 'Oktatórendszer — részletes tippek vevőknek és eladóknak', 'ki-mit-adna-erte' ); ?>
		</a>
	</p>
</div>

<div class="kmae-video-lightbox" id="kmae-video-lightbox" hidden>
	<div class="kmae-video-lightbox__backdrop" data-kmae-video-close></div>
	<div class="kmae-video-lightbox__dialog" role="dialog" aria-modal="true" aria-label="<?php esc_attr_e( 'Videó lejátszó', 'ki-mit-adna-erte' ); ?>">
		<button type="button" class="kmae-video-lightbox__close" data-kmae-video-close aria-label="<?php esc_attr_e( 'Bezárás', 'ki-mit-adna-erte' ); ?>">
			<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
				<path d="M18 6 6 18"/><path d="m6 6 12 12"/>
			</svg>
		</button>
		<div class="kmae-video-lightbox__frame">
			<iframe
				id="kmae-video-iframe"
				title="<?php esc_attr_e( 'YouTube videó', 'ki-mit-adna-erte' ); ?>"
				src=""
				allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
				allowfullscreen
				referrerpolicy="strict-origin-when-cross-origin"
			></iframe>
		</div>
	</div>
</div>
