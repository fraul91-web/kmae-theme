<?php
/**
 * Offers hub: sent (left) and received (right).
 *
 * @package KMAE
 * @var array $sent_offers
 * @var array $received_offers
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$has_sent     = ! empty( $sent_offers );
$has_received = ! empty( $received_offers );
$has_any      = $has_sent || $has_received;
?>
<div class="kmae-my-offers kmae-offers-hub"
	data-kmae-live-page="offers_hub"
	data-kmae-live-fingerprint="<?php echo esc_attr( KMAE_Live_Page::get_fingerprint( 'offers_hub' ) ); ?>">
	<h2><?php esc_html_e( 'Ajánlatok', 'ki-mit-adna-erte' ); ?></h2>

	<?php if ( is_user_logged_in() && KMAE_Auth::is_company( get_current_user_id() ) ) : ?>
		<p class="kmae-hint">
			<?php esc_html_e( 'Céges vevőként több autóval is tárgyalhatsz párhuzamosan, de egyszerre csak egy autónál lehet „Áll az alku”. Sikeres vásárlás után megkérdezzük, szeretnél-e másik autót is.', 'ki-mit-adna-erte' ); ?>
		</p>
	<?php endif; ?>

	<?php if ( ! $has_any ) : ?>
		<div class="kmae-empty">
			<p><?php esc_html_e( 'Még nincs elküldött vagy kapott ajánlatod.', 'ki-mit-adna-erte' ); ?></p>
			<a href="<?php echo esc_url( home_url( '/hirdetesek/' ) ); ?>" class="kmae-btn kmae-btn-primary"><?php esc_html_e( 'Böngészés', 'ki-mit-adna-erte' ); ?></a>
		</div>
	<?php else : ?>
		<div class="kmae-offers-columns">
			<section class="kmae-offers-col kmae-offers-col--sent" aria-labelledby="kmae-offers-sent-heading">
				<h3 id="kmae-offers-sent-heading"><?php esc_html_e( 'Elküldött', 'ki-mit-adna-erte' ); ?></h3>
				<?php if ( ! $has_sent ) : ?>
					<p class="kmae-hint kmae-offers-col-empty"><?php esc_html_e( 'Még nem adtál ajánlatot.', 'ki-mit-adna-erte' ); ?></p>
				<?php else : ?>
					<div class="kmae-offers-grid">
						<?php foreach ( $sent_offers as $offer ) : ?>
							<?php
							$listing = get_post( $offer->listing_id );
							if ( ! $listing ) {
								continue;
							}
							$offer_thread_url = KMAE_Pages::offer_thread_url( $offer->id );
							$is_received        = false;
							include KMAE_PLUGIN_DIR . 'templates/partials/offer-hub-card.php';
							?>
						<?php endforeach; ?>
					</div>
				<?php endif; ?>
			</section>

			<div class="kmae-offers-columns-gap" aria-hidden="true"></div>

			<section class="kmae-offers-col kmae-offers-col--received" aria-labelledby="kmae-offers-received-heading">
				<h3 id="kmae-offers-received-heading"><?php esc_html_e( 'Kapott', 'ki-mit-adna-erte' ); ?></h3>
				<?php if ( ! $has_received ) : ?>
					<p class="kmae-hint kmae-offers-col-empty"><?php esc_html_e( 'Még nem kaptál ajánlatot a hirdetéseidre.', 'ki-mit-adna-erte' ); ?></p>
				<?php else : ?>
					<div class="kmae-offers-grid">
						<?php foreach ( $received_offers as $offer ) : ?>
							<?php
							$listing = get_post( $offer->listing_id );
							if ( ! $listing ) {
								continue;
							}
							$offer_thread_url = KMAE_Pages::offer_thread_url( $offer->id );
							$is_received        = true;
							include KMAE_PLUGIN_DIR . 'templates/partials/offer-hub-card.php';
							?>
						<?php endforeach; ?>
					</div>
				<?php endif; ?>
			</section>
		</div>
	<?php endif; ?>

	<?php
	$back_url   = KMAE_Back::home_url();
	$back_label = KMAE_Back::home_label();
	include KMAE_PLUGIN_DIR . 'templates/partials/page-back.php';
	?>
</div>
