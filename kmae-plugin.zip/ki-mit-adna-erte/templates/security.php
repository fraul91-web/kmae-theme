<?php
/**
 * Security & trust page stub.
 *
 * @package KMAE
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$user_id = get_current_user_id();
?>
<div class="kmae-stub">
	<h1><?php esc_html_e( 'Biztonság és bizalom', 'ki-mit-adna-erte' ); ?></h1>
	<p class="kmae-stub__lead"><?php esc_html_e( 'Az Albira biztonsági és bizalmi funkciói itt lesznek egy helyen. Most a keret készült el.', 'ki-mit-adna-erte' ); ?></p>

	<section class="kmae-stub__section">
		<h2><?php esc_html_e( 'Fiók hitelesítése', 'ki-mit-adna-erte' ); ?></h2>
		<ul>
			<li><?php esc_html_e( 'Telefonszám ellenőrzése', 'ki-mit-adna-erte' ); ?></li>
			<li><?php esc_html_e( 'E-mail ellenőrzése', 'ki-mit-adna-erte' ); ?></li>
			<li><?php esc_html_e( 'Személyazonosság (később)', 'ki-mit-adna-erte' ); ?></li>
		</ul>
	</section>

	<section class="kmae-stub__section">
		<h2><?php esc_html_e( 'Bizalmi szint', 'ki-mit-adna-erte' ); ?></h2>
		<p><?php esc_html_e( 'A bizalmi számod és az értékeléseid a profilodon már elérhetők.', 'ki-mit-adna-erte' ); ?></p>
		<?php if ( $user_id && class_exists( 'KMAE_Trust' ) ) : ?>
			<?php
			$trust_user_id = $user_id;
			include KMAE_PLUGIN_DIR . 'templates/partials/trust-card.php';
			?>
		<?php endif; ?>
	</section>

	<section class="kmae-stub__section">
		<h2><?php esc_html_e( 'Biztonsági információk', 'ki-mit-adna-erte' ); ?></h2>
		<p><?php esc_html_e( 'Tippek a biztonságos ajánlattételhez és találkozókhoz — hamarosan részletesebben.', 'ki-mit-adna-erte' ); ?></p>
	</section>

	<?php
	$back_url   = KMAE_Back::home_url();
	$back_label = KMAE_Back::home_label();
	include KMAE_PLUGIN_DIR . 'templates/partials/page-back.php';
	?>
</div>
