<?php
/**
 * Terms of use stub.
 *
 * @package KMAE
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="kmae-stub">
	<h1><?php esc_html_e( 'Felhasználási feltételek', 'ki-mit-adna-erte' ); ?></h1>
	<p class="kmae-stub__lead"><?php esc_html_e( 'Ez az oldal a felhasználási feltételek helye. A végleges jogi szöveg később kerül ide.', 'ki-mit-adna-erte' ); ?></p>

	<section class="kmae-stub__section">
		<h2><?php esc_html_e( 'Áttekintés', 'ki-mit-adna-erte' ); ?></h2>
		<p><?php esc_html_e( 'Az Albira használatával elfogadod a platform szabályait. A részletes feltételek közzététele folyamatban van.', 'ki-mit-adna-erte' ); ?></p>
	</section>
</div>
