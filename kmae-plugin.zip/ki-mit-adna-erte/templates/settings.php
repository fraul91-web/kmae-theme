<?php
/**
 * Settings page stub.
 *
 * @package KMAE
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="kmae-stub">
	<h1><?php esc_html_e( 'Beállítások', 'ki-mit-adna-erte' ); ?></h1>
	<p class="kmae-stub__lead"><?php esc_html_e( 'Itt fogod kezelni a fiókod beállításait. A részletes vezérlők a következő frissítésekben érkeznek.', 'ki-mit-adna-erte' ); ?></p>

	<section class="kmae-stub__section">
		<h2><?php esc_html_e( 'Értesítések', 'ki-mit-adna-erte' ); ?></h2>
		<p><?php esc_html_e( 'E-mail és alkalmazáson belüli értesítések be- és kikapcsolása.', 'ki-mit-adna-erte' ); ?></p>
	</section>

	<section class="kmae-stub__section">
		<h2><?php esc_html_e( 'Jelszó és e-mail', 'ki-mit-adna-erte' ); ?></h2>
		<p><?php esc_html_e( 'Jelszó módosítása és e-mail cím frissítése.', 'ki-mit-adna-erte' ); ?></p>
	</section>

	<section class="kmae-stub__section">
		<h2><?php esc_html_e( 'Adatvédelem és megjelenítés', 'ki-mit-adna-erte' ); ?></h2>
		<p><?php esc_html_e( 'Adatvédelmi preferenciák és megjelenítési beállítások.', 'ki-mit-adna-erte' ); ?></p>
	</section>

	<?php
	$back_url   = KMAE_Back::home_url();
	$back_label = KMAE_Back::home_label();
	include KMAE_PLUGIN_DIR . 'templates/partials/page-back.php';
	?>
</div>
