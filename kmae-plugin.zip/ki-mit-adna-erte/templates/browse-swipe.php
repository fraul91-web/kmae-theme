<?php
/**
 * Tinder-style swipe browse (after wizard).
 *
 * @package KMAE
 * @var array  $listings
 * @var array  $wizard_summary
 * @var string $browse_base_url
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$is_vehicle_wizard = KMAE_Vehicle::is_vehicle_launch() && ! empty( $wizard_summary['mod'] );
$restart_keys      = $is_vehicle_wizard
	? array( 'megye', 'kivitel', 'mod', 'ertek', 'max_kp', 'kp_min', 'kp_max', 'step' )
	: array( 'megye', 'tipus', 'kategoria' );
$restart_url       = remove_query_arg( $restart_keys, $browse_base_url );
$offer_labels      = KMAE_Taxonomies::offer_type_labels();
?>
<div class="kmae-swipe-browse">
	<div class="kmae-wizard-summary">
		<div class="kmae-wizard-summary-tags">
			<?php if ( $is_vehicle_wizard ) : ?>
				<?php
				$modes = KMAE_Vehicle::browse_mode_labels();
				if ( ! empty( $wizard_summary['county'] ) ) :
					?>
					<span class="kmae-summary-tag"><?php echo esc_html( KMAE_Counties::get_label( $wizard_summary['county'] ) ); ?></span>
				<?php endif; ?>
				<?php if ( ! empty( $wizard_summary['bodies'] ) ) : ?>
					<span class="kmae-summary-tag"><?php echo esc_html( KMAE_Browse::bodies_label( $wizard_summary['bodies'] ) ); ?></span>
				<?php endif; ?>
				<?php if ( ! empty( $wizard_summary['mod'] ) ) : ?>
					<span class="kmae-summary-tag kmae-summary-tag--accent"><?php echo esc_html( $modes[ $wizard_summary['mod'] ] ?? $wizard_summary['mod'] ); ?></span>
				<?php endif; ?>
			<?php else : ?>
				<?php
				$county_slug = $wizard_summary['county'] ?? '';
				$type_slug   = $wizard_summary['type'] ?? 'mind';
				$type_label  = 'mind' === $type_slug ? __( 'Mind', 'ki-mit-adna-erte' ) : ( $offer_labels[ $type_slug ] ?? $type_slug );
				?>
				<span class="kmae-summary-tag"><?php echo esc_html( KMAE_Counties::get_label( $county_slug ) ); ?></span>
				<span class="kmae-summary-tag"><?php echo esc_html( $type_label ); ?></span>
			<?php endif; ?>
		</div>
		<a href="<?php echo esc_url( $restart_url ); ?>" class="kmae-btn kmae-btn-secondary kmae-btn-sm kmae-wizard-summary__restart"><?php esc_html_e( 'Új keresés', 'ki-mit-adna-erte' ); ?></a>
	</div>

	<div class="kmae-browse-header">
		<p class="kmae-browse-header__eyebrow"><?php esc_html_e( 'Böngészés', 'ki-mit-adna-erte' ); ?></p>
		<h2><?php esc_html_e( 'Autók böngészése', 'ki-mit-adna-erte' ); ?></h2>
		<p class="kmae-subtitle"><?php esc_html_e( 'Húzd jobbra, ha érdekel — balra, ha nem.', 'ki-mit-adna-erte' ); ?></p>
	</div>

	<?php if ( empty( $listings ) ) : ?>
		<div class="kmae-swipe-empty">
			<div class="kmae-swipe-empty__card">
				<span class="kmae-swipe-empty__icon" aria-hidden="true"><?php echo KMAE_Icons::render( 'search', array( 'size' => 28 ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
				<h3 class="kmae-swipe-empty__title"><?php esc_html_e( 'Nincs találat', 'ki-mit-adna-erte' ); ?></h3>
				<p class="kmae-swipe-empty__text"><?php esc_html_e( 'Nincs találat a kiválasztott szűrőkre. Próbálj más értéket vagy kivitelt.', 'ki-mit-adna-erte' ); ?></p>
				<a href="<?php echo esc_url( $restart_url ); ?>" class="kmae-btn kmae-btn-primary"><?php esc_html_e( 'Új keresés', 'ki-mit-adna-erte' ); ?></a>
			</div>
		</div>
	<?php else : ?>
		<div class="kmae-swipe-stack" id="kmae-swipe-stack">
			<?php foreach ( $listings as $i => $listing ) : ?>
				<?php
				$thumb    = KMAE_Query::get_listing_thumbnail_url( $listing->ID, 'full' );
				$types    = KMAE_Meta::get_offer_types( $listing->ID );
				$labels   = array_map( fn( $t ) => $offer_labels[ $t ] ?? $t, $types );
				$featured = KMAE_Premium::is_featured( $listing->ID );
				$loc      = KMAE_Counties::format_listing_location( $listing->ID );
				$subtitle = KMAE_Vehicle::get_swipe_subtitle( $listing->ID );
				$value    = KMAE_Vehicle::get_vehicle_value( $listing->ID );
				?>
				<div class="kmae-swipe-card" data-index="<?php echo esc_attr( $i ); ?>" data-listing-id="<?php echo esc_attr( $listing->ID ); ?>">
					<div class="kmae-swipe-card-photo">
						<?php if ( $thumb ) : ?>
							<img src="<?php echo esc_url( $thumb ); ?>" alt="" class="kmae-card-image" loading="<?php echo 0 === $i ? 'eager' : 'lazy'; ?>" decoding="async" />
						<?php else : ?>
							<div class="kmae-no-photo"><?php esc_html_e( 'Nincs kép', 'ki-mit-adna-erte' ); ?></div>
						<?php endif; ?>
					</div>
					<div class="kmae-swipe-card-info">
						<?php if ( $featured ) : ?><span class="kmae-featured-badge"><?php esc_html_e( 'Kiemelt', 'ki-mit-adna-erte' ); ?></span><?php endif; ?>
						<h3><?php echo esc_html( $listing->post_title ); ?></h3>
						<?php if ( KMAE_Seller::is_fixed_price( $listing->ID ) ) : ?>
							<p class="kmae-swipe-value"><?php echo esc_html( KMAE_Offers::format_cash( KMAE_Seller::get_fixed_price( $listing->ID ) ) ); ?></p>
						<?php elseif ( $value ) : ?>
							<p class="kmae-swipe-value"><?php echo esc_html( KMAE_Vehicle::format_value( $value ) ); ?></p>
						<?php elseif ( KMAE_Seller::PRICE_OFFERS === KMAE_Seller::get_price_mode( $listing->ID ) ) : ?>
							<p class="kmae-swipe-value"><?php esc_html_e( 'Ajánlatokat vár', 'ki-mit-adna-erte' ); ?></p>
						<?php endif; ?>
						<?php
						$listing_id = $listing->ID;
						include KMAE_PLUGIN_DIR . 'templates/partials/listing-pledge-badges.php';
						?>
						<?php if ( $subtitle ) : ?><p class="kmae-swipe-specs"><?php echo esc_html( $subtitle ); ?></p><?php endif; ?>
						<?php if ( $loc ) : ?><p class="kmae-swipe-location"><?php echo esc_html( $loc ); ?></p><?php endif; ?>
						<div class="kmae-type-tags">
							<?php foreach ( $labels as $label ) : ?>
								<span class="kmae-type-tag"><?php echo esc_html( $label ); ?></span>
							<?php endforeach; ?>
						</div>
						<a href="<?php echo esc_url( get_permalink( $listing->ID ) ); ?>" class="kmae-btn kmae-btn-primary kmae-swipe-cta"><?php esc_html_e( 'Részletek / Ajánlat', 'ki-mit-adna-erte' ); ?></a>
					</div>
				</div>
			<?php endforeach; ?>
		</div>
		<div class="kmae-swipe-controls">
			<button type="button" class="kmae-swipe-btn kmae-swipe-pass" id="kmae-swipe-pass" title="<?php esc_attr_e( 'Következő', 'ki-mit-adna-erte' ); ?>"><?php echo KMAE_Icons::render( 'x', array( 'size' => 22 ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></button>
			<button type="button" class="kmae-swipe-btn kmae-swipe-like" id="kmae-swipe-like" title="<?php esc_attr_e( 'Megnézem', 'ki-mit-adna-erte' ); ?>"><?php echo KMAE_Icons::render( 'heart', array( 'size' => 22 ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></button>
		</div>
	<?php endif; ?>
</div>
