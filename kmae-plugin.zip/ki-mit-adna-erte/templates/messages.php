<?php
/**
 * Messages inbox stub.
 *
 * @package KMAE
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="kmae-stub">
	<h1><?php esc_html_e( 'Üzenetek', 'ki-mit-adna-erte' ); ?></h1>
	<p class="kmae-stub__lead"><?php esc_html_e( 'Az üzenetközpont helye. Most az ajánlat beszélgetések az Ajánlataim oldalon érhetők el.', 'ki-mit-adna-erte' ); ?></p>

	<section class="kmae-stub__section">
		<h2><?php esc_html_e( 'Ajánlat beszélgetések', 'ki-mit-adna-erte' ); ?></h2>
		<p><?php esc_html_e( 'A folyamatban lévő tárgyalásaidat az Ajánlataim oldalon találod.', 'ki-mit-adna-erte' ); ?></p>
		<p style="margin-top:10px;">
			<a class="kmae-btn kmae-btn-primary" href="<?php echo esc_url( KMAE_Pages::url( 'ajanlatok' ) ); ?>">
				<?php esc_html_e( 'Ajánlataim', 'ki-mit-adna-erte' ); ?>
			</a>
		</p>
	</section>

	<?php
	$back_url   = KMAE_Back::home_url();
	$back_label = KMAE_Back::home_label();
	include KMAE_PLUGIN_DIR . 'templates/partials/page-back.php';
	?>
</div>
