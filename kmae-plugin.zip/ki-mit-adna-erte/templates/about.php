<?php
/**
 * About page — Rólunk.
 *
 * @package KMAE
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$checklist = array(
	__( 'Kevesebb félreértés.', 'ki-mit-adna-erte' ),
	__( 'Kevesebb hiábavaló telefonhívás.', 'ki-mit-adna-erte' ),
	__( 'Kevesebb felesleges utazás.', 'ki-mit-adna-erte' ),
	__( 'Kevesebb megtévesztő hirdetés.', 'ki-mit-adna-erte' ),
	__( 'Több átláthatóság.', 'ki-mit-adna-erte' ),
	__( 'Több bizalom.', 'ki-mit-adna-erte' ),
	__( 'És egy sokkal egyszerűbb adásvételi folyamat.', 'ki-mit-adna-erte' ),
);
?>
<div class="kmae-about">
	<section class="kmae-about__hero">
		<div class="kmae-about__hero-copy">
			<p class="kmae-about__eyebrow"><?php esc_html_e( 'Rólunk', 'ki-mit-adna-erte' ); ?></p>
			<h1 class="kmae-about__title">
				<?php esc_html_e( 'Nem egy újabb autós oldalt akartunk létrehozni.', 'ki-mit-adna-erte' ); ?>
			</h1>
			<div class="kmae-about__lead">
				<p><?php esc_html_e( 'Autót venni vagy eladni ma már sok helyen lehet. Mégis ugyanazokkal a problémákkal találkozunk újra és újra: félrevezető hirdetések, felesleges beszélgetések, elvesztegetett idő.', 'ki-mit-adna-erte' ); ?></p>
				<p><?php esc_html_e( 'Mi egy olyan rendszert akartunk létrehozni, ami egyszerűbbé, átláthatóbbá és biztonságosabbá teszi ezt a folyamatot.', 'ki-mit-adna-erte' ); ?></p>
			</div>
		</div>

		<ul class="kmae-about__snippets">
			<li class="kmae-about__snippet">
				<span class="kmae-about__snippet-icon" aria-hidden="true">
					<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
				</span>
				<div>
					<strong><?php esc_html_e( 'Kik vagyunk?', 'ki-mit-adna-erte' ); ?></strong>
					<p><?php esc_html_e( 'Testvérek vagyunk. Nem egy hatalmas cég, hanem egy kis csapat, akik maguk is átélték ezeket a helyzeteket.', 'ki-mit-adna-erte' ); ?></p>
				</div>
			</li>
			<li class="kmae-about__snippet">
				<span class="kmae-about__snippet-icon" aria-hidden="true">
					<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.5"/></svg>
				</span>
				<div>
					<strong><?php esc_html_e( 'Miért hoztuk létre az Albirát?', 'ki-mit-adna-erte' ); ?></strong>
					<p><?php esc_html_e( 'Mert hiszünk abban, hogy a kis fejlesztések is hatalmas különbséget tudnak okozni.', 'ki-mit-adna-erte' ); ?></p>
				</div>
			</li>
			<li class="kmae-about__snippet">
				<span class="kmae-about__snippet-icon" aria-hidden="true">
					<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.1-3.1a6 6 0 0 1-7.9 7.9l-6.9 6.9a2.1 2.1 0 0 1-3-3l6.9-6.9a6 6 0 0 1 7.9-7.9z"/></svg>
				</span>
				<div>
					<strong><?php esc_html_e( 'Nem akarunk mindent újra feltalálni.', 'ki-mit-adna-erte' ); ?></strong>
					<p><?php esc_html_e( 'Ami jól működik, azt megtartjuk. Amit évek óta rosszul csinálnak, azt megjavítjuk.', 'ki-mit-adna-erte' ); ?></p>
				</div>
			</li>
		</ul>
	</section>

	<section class="kmae-about__grid kmae-about__grid--3" aria-label="<?php esc_attr_e( 'Rólunk részletek', 'ki-mit-adna-erte' ); ?>">
		<article class="kmae-about__card">
			<h2><?php esc_html_e( 'Kik vagyunk?', 'ki-mit-adna-erte' ); ?></h2>
			<p><?php esc_html_e( 'Az Albira egy saját tapasztalatokból és hosszú beszélgetésekből nőtt ki. Újra és újra ugyanazokkal a problémákkal találkoztunk, amikor autót akartunk venni vagy eladni.', 'ki-mit-adna-erte' ); ?></p>
			<p><?php esc_html_e( 'Egyszer csak azt mondtuk: ha ennyire zavar minket, akkor oldjuk meg magunk.', 'ki-mit-adna-erte' ); ?></p>
		</article>

		<article class="kmae-about__card">
			<h2><?php esc_html_e( 'Miért hoztuk létre az Albirát?', 'ki-mit-adna-erte' ); ?></h2>
			<p><?php esc_html_e( 'Azért, hogy az autó adásvétele végre ne legyen feleslegesen bonyolult. A célunk egyszerű:', 'ki-mit-adna-erte' ); ?></p>
			<ul class="kmae-about__checks">
				<?php foreach ( $checklist as $item ) : ?>
					<li>
						<span class="kmae-about__check" aria-hidden="true">
							<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>
						</span>
						<span><?php echo esc_html( $item ); ?></span>
					</li>
				<?php endforeach; ?>
			</ul>
		</article>

		<article class="kmae-about__card">
			<h2><?php esc_html_e( 'Nem akarunk mindent újra feltalálni.', 'ki-mit-adna-erte' ); ?></h2>
			<p><?php esc_html_e( 'Nem akarunk mindent újra feltalálni. Ami jól működik, azt megtartjuk. Amit évek óta rosszul csinálnak, azt megjavítjuk.', 'ki-mit-adna-erte' ); ?></p>
			<p><?php esc_html_e( 'Minden döntésnél ezt kérdezzük meg magunktól:', 'ki-mit-adna-erte' ); ?></p>
			<blockquote class="kmae-about__quote">
				<?php esc_html_e( 'Valóban könnyebb lesz ettől az autó eladása vagy megvásárlása?', 'ki-mit-adna-erte' ); ?>
			</blockquote>
		</article>
	</section>

	<section class="kmae-about__grid kmae-about__grid--2" aria-label="<?php esc_attr_e( 'Céljaink', 'ki-mit-adna-erte' ); ?>">
		<article class="kmae-about__card kmae-about__card--wide">
			<span class="kmae-about__card-icon" aria-hidden="true">
				<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"/><path d="M21 3v5h-5"/><path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"/><path d="M8 16H3v5"/></svg>
			</span>
			<h2><?php esc_html_e( 'Folyamatosan építjük', 'ki-mit-adna-erte' ); ?></h2>
			<p><?php esc_html_e( 'Az Albira nem egy kész, lezárt rendszer. Folyamatosan fejlődik. Figyeljük a visszajelzéseket, és olyan funkciókat építünk, amik valóban számítanak.', 'ki-mit-adna-erte' ); ?></p>
			<p><?php esc_html_e( 'Nem azért fejlesztünk, hogy „legyen valami új”. Hanem azért, hogy jobb legyen az egész folyamat.', 'ki-mit-adna-erte' ); ?></p>
		</article>

		<article class="kmae-about__card kmae-about__card--wide">
			<span class="kmae-about__card-icon" aria-hidden="true">
				<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
			</span>
			<h2><?php esc_html_e( 'Ez a célunk', 'ki-mit-adna-erte' ); ?></h2>
			<p><?php esc_html_e( 'Egy olyan közösséget építünk, ahol a bizalom természetes. Nem ígérünk csodát. Nem mondjuk, hogy minden tökéletes lesz.', 'ki-mit-adna-erte' ); ?></p>
			<p>
				<?php esc_html_e( 'De mindent megteszünk azért, hogy', 'ki-mit-adna-erte' ); ?>
				<strong class="kmae-about__accent"><?php esc_html_e( 'egyszerűbbé, átláthatóbbá és biztonságosabbá tenni az autó adásvételét.', 'ki-mit-adna-erte' ); ?></strong>
			</p>
		</article>
	</section>

	<aside class="kmae-about__banner">
		<span class="kmae-about__banner-icon" aria-hidden="true">
			<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3l8 3v6c0 5-3.5 8.5-8 10-4.5-1.5-8-5-8-10V6l8-3z"/><path d="m9 12 2 2 4-4"/></svg>
		</span>
		<p><?php esc_html_e( 'Hisszük, hogy az autó adásvétele lehet egyszerű, gyors és biztonságos. Ezért dolgozunk minden nap.', 'ki-mit-adna-erte' ); ?></p>
	</aside>
</div>
