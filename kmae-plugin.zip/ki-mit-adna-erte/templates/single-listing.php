<?php
/**
 * Single listing template.
 *
 * @package KMAE
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

while ( have_posts() ) :
	the_post();
	$listing_id   = get_the_ID();
	$status       = KMAE_Meta::get_status( $listing_id );
	$offer_types  = KMAE_Meta::get_offer_types( $listing_id );
	$type_labels  = KMAE_Taxonomies::offer_type_labels();
	$location     = KMAE_Counties::format_listing_location( $listing_id );
	$condition    = get_post_meta( $listing_id, '_kmae_condition', true );
	$is_owner     = is_user_logged_in() && (int) get_the_author_meta( 'ID' ) === get_current_user_id();
	$offers       = $is_owner ? KMAE_Database::get_offers_for_listing( $listing_id ) : array();
	$user_offer      = is_user_logged_in() ? KMAE_Database::get_active_user_offer_for_listing( $listing_id, get_current_user_id() ) : null;
	$withdrawn_offer = is_user_logged_in() ? KMAE_Database::get_withdrawn_user_offer_for_listing( $listing_id, get_current_user_id() ) : null;
	$has_offer       = ! empty( $user_offer );
	$success      = isset( $_GET['kmae_success'] ) ? sanitize_text_field( wp_unslash( $_GET['kmae_success'] ) ) : '';
	$error        = isset( $_GET['kmae_error'] ) ? sanitize_text_field( wp_unslash( $_GET['kmae_error'] ) ) : '';
	$status_labels = KMAE_Counter_Offers::status_labels();
	$success_messages = array(
		'offer_sent'        => __( 'Ajánlat elküldve.', 'ki-mit-adna-erte' ),
		'counter_sent'      => __( 'Ellenajánlat elküldve.', 'ki-mit-adna-erte' ),
		'offer_revised'     => __( 'Új összeget küldtél.', 'ki-mit-adna-erte' ),
		'offer_accepted'    => __( 'Áll az alku! Egyeztessetek megtekintést — utána jelezzétek, sikerült-e.', 'ki-mit-adna-erte' ),
		'deal_success'      => __( 'Üzlet lezárva — az autó elkelt.', 'ki-mit-adna-erte' ),
		'deal_failure'      => __( 'A találkozó nem vezetett üzlethez. Az alku feloldódott, folytathatjátok.', 'ki-mit-adna-erte' ),
		'offer_withdrawn'   => __( 'Az ajánlatod visszavonva.', 'ki-mit-adna-erte' ),
		'contact_unlocked'  => __( 'Kapcsolat feloldva!', 'ki-mit-adna-erte' ),
	);
	$error_messages = array(
		'buyer_deal_locked'   => __( 'Egyszerre csak egy autónál lehet „Áll az alku”.', 'ki-mit-adna-erte' ),
		'fair_buyer_required' => __( 'A tisztességes vevő vállalás elfogadása kötelező.', 'ki-mit-adna-erte' ),
		'deal_locked'         => __( 'Ezen a hirdetésen már „Áll az alku”.', 'ki-mit-adna-erte' ),
	);
	$live_attrs = '';
	if ( is_user_logged_in() && ( $is_owner || $has_offer || $withdrawn_offer ) ) {
		$live_attrs = sprintf(
			' data-kmae-live-page="single_listing" data-kmae-listing-id="%1$d" data-kmae-live-fingerprint="%2$s"',
			$listing_id,
			esc_attr( KMAE_Live_Page::get_fingerprint( 'single_listing', array( 'listing_id' => $listing_id ) ) )
		);
	}
	?>
	<article class="kmae-single-listing"<?php echo $live_attrs; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
		<?php include KMAE_PLUGIN_DIR . 'templates/partials/listing-gallery.php'; ?>

		<div class="kmae-single-content">
			<?php if ( KMAE_Premium::is_featured( $listing_id ) ) : ?>
				<span class="kmae-featured-badge"><?php esc_html_e( 'Kiemelt hirdetés', 'ki-mit-adna-erte' ); ?></span>
			<?php endif; ?>

			<h1><?php the_title(); ?></h1>

			<?php if ( KMAE_Seller::is_fixed_price( $listing_id ) ) : ?>
				<p class="kmae-fixed-price-display">
					<span class="kmae-fixed-price-label"><?php esc_html_e( 'Fix ár', 'ki-mit-adna-erte' ); ?></span>
					<strong><?php echo esc_html( KMAE_Offers::format_cash( KMAE_Seller::get_fixed_price( $listing_id ) ) ); ?></strong>
				</p>
			<?php elseif ( KMAE_Seller::PRICE_OFFERS === KMAE_Seller::get_price_mode( $listing_id ) ) : ?>
				<p class="kmae-offers-awaiting"><?php esc_html_e( 'Ajánlatokat vár', 'ki-mit-adna-erte' ); ?></p>
			<?php endif; ?>

			<div class="kmae-single-meta">
				<?php if ( $location ) : ?><span><?php echo esc_html( $location ); ?></span><?php endif; ?>
			</div>

			<?php
			include KMAE_PLUGIN_DIR . 'templates/partials/vehicle-specs-display.php';
			include KMAE_PLUGIN_DIR . 'templates/partials/listing-pledge-badges.php';
			$trust_user_id = (int) get_the_author_meta( 'ID' );
			include KMAE_PLUGIN_DIR . 'templates/partials/trust-card.php';
			?>

			<div class="kmae-type-tags">
				<?php foreach ( $offer_types as $type ) : ?>
					<span class="kmae-type-tag"><?php echo esc_html( $type_labels[ $type ] ?? $type ); ?></span>
				<?php endforeach; ?>
			</div>

			<div class="kmae-single-description"><?php the_content(); ?></div>

			<?php
			$known_defects = KMAE_Seller::get_known_defects( $listing_id );
			if ( $known_defects !== '' ) :
				?>
				<div class="kmae-known-defects">
					<strong><?php esc_html_e( 'Ismert hibák', 'ki-mit-adna-erte' ); ?></strong>
					<p><?php echo esc_html( $known_defects ); ?></p>
				</div>
			<?php endif; ?>

			<?php
			$trade_in_cats = get_post_meta( $listing_id, '_kmae_trade_in_categories', true );
			if ( is_array( $trade_in_cats ) && ! empty( $trade_in_cats ) && in_array( KMAE_OFFER_TYPE_TRADE_IN, $offer_types, true ) ) :
				?>
				<div class="kmae-trade-in-info">
					<strong><?php esc_html_e( 'Beszámítok:', 'ki-mit-adna-erte' ); ?></strong>
					<?php
					foreach ( $trade_in_cats as $cat_id ) {
						$term = get_term( $cat_id, 'kmae_category' );
						if ( $term && ! is_wp_error( $term ) ) {
							echo '<span class="kmae-type-tag">' . esc_html( $term->name ) . '</span>';
						}
					}
					?>
				</div>
			<?php endif; ?>

			<?php if ( $success && isset( $success_messages[ $success ] ) ) : ?>
				<div class="kmae-notice kmae-notice-success"><?php echo esc_html( $success_messages[ $success ] ); ?></div>
			<?php endif; ?>

			<?php if ( $error ) : ?>
				<div class="kmae-notice kmae-notice-error"><?php echo esc_html( $error_messages[ $error ] ?? $error ); ?></div>
			<?php endif; ?>

			<?php if ( ! $is_owner && KMAE_Meta::STATUS_ACTIVE === $status ) : ?>
				<div class="kmae-offer-section">
					<?php if ( $withdrawn_offer ) : ?>
						<div class="kmae-notice kmae-notice-info">
							<p><strong><?php esc_html_e( 'Ajánlat visszavonva', 'ki-mit-adna-erte' ); ?></strong></p>
							<p><?php esc_html_e( 'Visszavontad az ajánlatodat erre a hirdetésre. Ez végleges — nem adhatsz új ajánlatot.', 'ki-mit-adna-erte' ); ?></p>
						</div>
					<?php elseif ( $has_offer ) : ?>
						<div class="kmae-offer-sent-summary">
							<p><?php esc_html_e( 'Ajánlatod:', 'ki-mit-adna-erte' ); ?> <strong><?php echo esc_html( KMAE_Offers::get_offer_summary( $user_offer ) ); ?></strong></p>
							<?php echo KMAE_Offers::render_offer_images( $user_offer->id ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
							<p class="kmae-hint">
								<?php esc_html_e( 'Státusz:', 'ki-mit-adna-erte' ); ?>
								<span class="kmae-badge kmae-badge-<?php echo esc_attr( $user_offer->status ); ?>">
									<?php echo esc_html( $status_labels[ $user_offer->status ] ?? $user_offer->status ); ?>
								</span>
							</p>
						</div>
						<?php include KMAE_PLUGIN_DIR . 'templates/partials/offer-buyer-negotiation.php'; ?>
						<?php include KMAE_PLUGIN_DIR . 'templates/partials/offer-withdraw-form.php'; ?>
					<?php else : ?>
						<h2><?php esc_html_e( 'Ajánlatot teszek', 'ki-mit-adna-erte' ); ?></h2>
						<?php if ( ! is_user_logged_in() ) : ?>
							<p><a href="<?php echo esc_url( KMAE_Auth::login_url( get_permalink() ) ); ?>" class="kmae-btn kmae-btn-primary"><?php esc_html_e( 'Bejelentkezés', 'ki-mit-adna-erte' ); ?></a></p>
						<?php else : ?>
							<?php include KMAE_PLUGIN_DIR . 'templates/partials/offer-forms.php'; ?>
						<?php endif; ?>
					<?php endif; ?>
				</div>
			<?php endif; ?>

			<?php if ( $is_owner && ! empty( $offers ) ) : ?>
				<p class="kmae-hint kmae-owner-offers-link">
					<a href="<?php echo esc_url( KMAE_Pages::offer_thread_url( $offers[0]->id ) ); ?>" class="kmae-btn kmae-btn-sm kmae-btn-secondary">
						<?php
						printf(
							/* translators: %d: number of offers */
							esc_html__( 'Kapott ajánlatok (%d) — megtekintés', 'ki-mit-adna-erte' ),
							count( $offers )
						);
						?>
					</a>
				</p>
			<?php endif; ?>
		</div>

		<?php
		$back_url = KMAE_Back::listing_back_url();
		include KMAE_PLUGIN_DIR . 'templates/partials/page-back.php';
		?>
	</article>
	<?php
endwhile;

get_footer();
