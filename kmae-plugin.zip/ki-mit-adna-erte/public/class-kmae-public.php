<?php
/**
 * Frontend assets and form handlers.
 *
 * @package KMAE
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class KMAE_Public {

	public function __construct() {
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue' ) );
		add_action( 'init', array( $this, 'handle_forms' ) );
		add_action( 'wp_ajax_kmae_browse_pass', array( $this, 'ajax_browse_pass' ) );
		add_action( 'wp_ajax_kmae_poll_page', array( $this, 'ajax_poll_page' ) );
		add_action( 'wp_footer', array( $this, 'render_rounds_modal' ) );
		add_action( 'admin_post_kmae_save_profile', array( $this, 'admin_save_profile' ) );
		add_action( 'admin_post_kmae_activate_premium', array( $this, 'admin_activate_premium' ) );
		add_action( 'admin_post_kmae_send_tip', array( $this, 'admin_send_tip' ) );
		add_action( 'admin_post_kmae_claim_detailing', array( $this, 'admin_claim_detailing' ) );
		add_action( 'admin_post_kmae_update_listing', array( $this, 'admin_update_listing' ) );
		add_action( 'admin_post_kmae_delete_listing', array( $this, 'admin_delete_listing' ) );
		add_action( 'admin_post_kmae_reactivate_listing', array( $this, 'admin_reactivate_listing' ) );
		add_action( 'template_redirect', array( $this, 'block_nonpublic_listings' ) );
		add_action( 'admin_post_kmae_login', array( $this, 'admin_login' ) );
		add_action( 'admin_post_nopriv_kmae_login', array( $this, 'admin_login' ) );
		add_action( 'admin_post_kmae_register', array( $this, 'admin_register' ) );
		add_action( 'admin_post_nopriv_kmae_register', array( $this, 'admin_register' ) );
		add_action( 'admin_post_kmae_lost_password', array( $this, 'admin_lost_password' ) );
		add_action( 'admin_post_nopriv_kmae_lost_password', array( $this, 'admin_lost_password' ) );
		add_action( 'admin_post_kmae_reset_password', array( $this, 'admin_reset_password' ) );
		add_action( 'admin_post_nopriv_kmae_reset_password', array( $this, 'admin_reset_password' ) );
		add_action( 'admin_post_kmae_contact_form', array( $this, 'admin_contact_form' ) );
		add_action( 'admin_post_nopriv_kmae_contact_form', array( $this, 'admin_contact_form' ) );
		add_action( 'admin_post_kmae_submit_rating', array( $this, 'admin_submit_rating' ) );
		add_action( 'admin_post_kmae_continue_shopping', array( $this, 'admin_continue_shopping' ) );
		add_action( 'admin_post_kmae_pay_company_fee', array( $this, 'admin_pay_company_fee' ) );
	}

	public function enqueue() {
		wp_enqueue_style( 'kmae-public', KMAE_PLUGIN_URL . 'assets/css/public.css', array(), KMAE_VERSION );
		wp_enqueue_script( 'kmae-public', KMAE_PLUGIN_URL . 'assets/js/public.js', array(), KMAE_VERSION, true );
		wp_enqueue_script( 'kmae-swipe', KMAE_PLUGIN_URL . 'assets/js/swipe.js', array(), KMAE_VERSION, true );
		wp_enqueue_script( 'kmae-map', KMAE_PLUGIN_URL . 'assets/js/map.js', array(), KMAE_VERSION, true );

		if ( KMAE_Vehicle::is_vehicle_launch() ) {
			wp_enqueue_script( 'kmae-listing-assistant', KMAE_PLUGIN_URL . 'assets/js/listing-assistant.js', array(), KMAE_VERSION, true );
			wp_enqueue_script( 'kmae-browse-wizard', KMAE_PLUGIN_URL . 'assets/js/browse-wizard.js', array(), KMAE_VERSION, true );
			wp_enqueue_script( 'kmae-photo-motor', KMAE_PLUGIN_URL . 'assets/js/photo-motor.js', array(), KMAE_VERSION, true );
		}

		wp_localize_script(
			'kmae-public',
			'kmaePublic',
			array(
				'roundsWarningLast'  => KMAE_Counter_Offers::get_rounds_warning_message( 1 ),
				'roundsWarningMulti' => __( 'Vigyázz! Csak %d alkudozási lehetőséged van — komolyan vedd. Ha elfogynak, a rendszer leállítja az alkudozást.', 'ki-mit-adna-erte' ),
				'maxCounterRounds'   => KMAE_MAX_COUNTER_ROUNDS,
				'livePoll'           => is_user_logged_in()
					? array(
						'ajaxUrl'  => admin_url( 'admin-ajax.php' ),
						'nonce'    => wp_create_nonce( 'kmae_poll_page' ),
						'interval' => 30000,
					)
					: null,
			)
		);

		if ( is_user_logged_in() ) {
			wp_localize_script(
				'kmae-swipe',
				'kmaeSwipe',
				array(
					'ajaxUrl' => admin_url( 'admin-ajax.php' ),
					'nonce'   => wp_create_nonce( 'kmae_browse_pass' ),
				)
			);
		}
	}

	/**
	 * Hide awaiting-photos listings from non-owners.
	 */
	public function block_nonpublic_listings() {
		if ( ! is_singular( 'kmae_listing' ) ) {
			return;
		}

		$listing_id = get_queried_object_id();
		if ( ! $listing_id || KMAE_Meta::STATUS_AWAITING_PHOTOS !== KMAE_Meta::get_status( $listing_id ) ) {
			return;
		}

		$author_id = (int) get_post_field( 'post_author', $listing_id );
		$is_owner  = is_user_logged_in() && get_current_user_id() === $author_id;
		if ( $is_owner || current_user_can( 'manage_options' ) ) {
			return;
		}

		wp_safe_redirect( home_url( '/hirdetesek/' ) );
		exit;
	}

	public function ajax_browse_pass() {
		check_ajax_referer( 'kmae_browse_pass', 'nonce' );

		if ( ! is_user_logged_in() ) {
			wp_send_json_error( array( 'message' => 'auth' ), 403 );
		}

		$listing_id = isset( $_POST['listing_id'] ) ? absint( $_POST['listing_id'] ) : 0;
		if ( ! $listing_id || 'kmae_listing' !== get_post_type( $listing_id ) ) {
			wp_send_json_error( array( 'message' => 'invalid' ), 400 );
		}

		KMAE_Browse::record_pass( get_current_user_id(), $listing_id );
		wp_send_json_success();
	}

	public function ajax_poll_page() {
		check_ajax_referer( 'kmae_poll_page', 'nonce' );

		if ( ! is_user_logged_in() ) {
			wp_send_json_error( array( 'message' => 'auth' ), 403 );
		}

		$context = isset( $_POST['context'] ) ? sanitize_text_field( wp_unslash( $_POST['context'] ) ) : '';
		$args    = array();

		if ( 'offer_thread' === $context ) {
			$args['offer_id'] = isset( $_POST['offer_id'] ) ? absint( $_POST['offer_id'] ) : 0;
		} elseif ( 'single_listing' === $context ) {
			$args['listing_id'] = isset( $_POST['listing_id'] ) ? absint( $_POST['listing_id'] ) : 0;
		}

		wp_send_json_success(
			array(
				'fingerprint' => KMAE_Live_Page::get_fingerprint( $context, $args ),
			)
		);
	}

	public function render_rounds_modal() {
		if ( ! is_user_logged_in() ) {
			return;
		}
		?>
		<div id="kmae-rounds-modal" class="kmae-rounds-modal" hidden>
			<div class="kmae-rounds-modal-backdrop"></div>
			<div class="kmae-rounds-modal-box" role="alertdialog" aria-modal="true" aria-labelledby="kmae-rounds-modal-title">
				<button type="button" class="kmae-rounds-modal-close" aria-label="<?php esc_attr_e( 'Bezár', 'ki-mit-adna-erte' ); ?>"><?php echo KMAE_Icons::render( 'x', array( 'size' => 18 ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></button>
				<div class="kmae-rounds-modal-icon" aria-hidden="true"><?php echo KMAE_Icons::render( 'triangle-alert', array( 'size' => 24 ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
				<strong id="kmae-rounds-modal-title" class="kmae-rounds-modal-title"><?php esc_html_e( 'Fontos!', 'ki-mit-adna-erte' ); ?></strong>
				<div class="kmae-rounds-modal-count" data-kmae-rounds-count aria-hidden="true"></div>
				<p class="kmae-rounds-modal-count-label" data-kmae-rounds-count-label></p>
				<p class="kmae-rounds-modal-text" data-kmae-rounds-text></p>
			</div>
		</div>
		<?php
	}

	public function handle_forms() {
		if ( ! isset( $_POST['kmae_action'] ) ) {
			return;
		}

		if ( ! is_user_logged_in() ) {
			return;
		}

		$action = sanitize_text_field( wp_unslash( $_POST['kmae_action'] ) );

		if ( 'create_listing' === $action ) {
			$this->process_create_listing();
		}

		if ( 'submit_cash_offer' === $action ) {
			$this->process_cash_offer();
		}

		if ( 'submit_counter_offer' === $action ) {
			$this->process_counter_offer();
		}

		if ( 'revise_offer' === $action ) {
			$this->process_revise_offer();
		}

		if ( 'accept_offer' === $action ) {
			$this->process_accept_offer();
		}

		if ( 'deal_success' === $action ) {
			$this->process_deal_success();
		}

		if ( 'deal_failure' === $action ) {
			$this->process_deal_failure();
		}

		if ( 'withdraw_offer' === $action ) {
			$this->process_withdraw_offer();
		}

		if ( 'submit_trade_offer' === $action ) {
			$this->process_trade_offer();
		}

		if ( 'unlock_contact' === $action ) {
			$this->process_unlock_contact();
		}

		if ( 'feature_listing' === $action ) {
			$this->process_feature_listing();
		}
	}

	private function verify_nonce( $field ) {
		return isset( $_POST[ $field ] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST[ $field ] ) ), $field );
	}

	private function verify_nonce_action( $field, $action ) {
		return isset( $_POST[ $field ] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST[ $field ] ) ), $action );
	}

	private function get_profile_redirect_url() {
		if ( ! empty( $_POST['kmae_redirect'] ) ) {
			return esc_url_raw( wp_unslash( $_POST['kmae_redirect'] ) );
		}
		return home_url( '/profil/' );
	}

	private function redirect_profile( $code, $is_error = false ) {
		$key = $is_error ? 'kmae_error' : 'kmae_success';
		wp_safe_redirect( add_query_arg( $key, $code, $this->get_profile_redirect_url() ) );
		exit;
	}

	public function admin_save_profile() {
		if ( ! is_user_logged_in() ) {
			wp_safe_redirect( wp_login_url( $this->get_profile_redirect_url() ) );
			exit;
		}

		if ( ! $this->verify_nonce_action( 'kmae_profile_nonce', 'kmae_save_profile' ) ) {
			$this->redirect_profile( 'nonce_failed', true );
		}

		$user_id      = get_current_user_id();
		$display_name = isset( $_POST['kmae_display_name'] ) ? sanitize_text_field( wp_unslash( $_POST['kmae_display_name'] ) ) : '';
		$phone        = isset( $_POST['kmae_phone'] ) ? sanitize_text_field( wp_unslash( $_POST['kmae_phone'] ) ) : '';

		if ( ! empty( $display_name ) ) {
			wp_update_user(
				array(
					'ID'           => $user_id,
					'display_name' => $display_name,
				)
			);
		}

		update_user_meta( $user_id, 'kmae_phone', $phone );
		KMAE_Auth::sync_phone( $user_id, $phone );

		if ( KMAE_Auth::is_company( $user_id ) ) {
			$company_result = KMAE_Company::save_profile_fields(
				$user_id,
				array(
					'company_name' => isset( $_POST['kmae_company_name'] ) ? wp_unslash( $_POST['kmae_company_name'] ) : $display_name,
					'tax_id'       => isset( $_POST['kmae_company_tax_id'] ) ? wp_unslash( $_POST['kmae_company_tax_id'] ) : '',
					'address'      => isset( $_POST['kmae_company_address'] ) ? wp_unslash( $_POST['kmae_company_address'] ) : '',
				)
			);
			if ( is_wp_error( $company_result ) ) {
				$this->redirect_profile( $company_result->get_error_code(), true );
			}
		}

		$this->redirect_profile( 'profile_saved' );
	}

	public function admin_submit_rating() {
		if ( ! is_user_logged_in() ) {
			wp_safe_redirect( wp_login_url( home_url( '/profil/' ) ) );
			exit;
		}

		if ( ! $this->verify_nonce_action( 'kmae_rating_nonce', 'kmae_submit_rating' ) ) {
			$this->redirect_profile( 'nonce_failed', true );
		}

		$offer_id = isset( $_POST['kmae_offer_id'] ) ? absint( $_POST['kmae_offer_id'] ) : 0;
		$result   = KMAE_Trust::submit(
			$offer_id,
			get_current_user_id(),
			array(
				'overall'  => isset( $_POST['kmae_overall'] ) ? absint( $_POST['kmae_overall'] ) : 0,
				'criteria' => isset( $_POST['kmae_criteria'] ) ? wp_unslash( $_POST['kmae_criteria'] ) : array(), // phpcs:ignore
				'comment'  => isset( $_POST['kmae_rating_comment'] ) ? wp_unslash( $_POST['kmae_rating_comment'] ) : '',
				'deal_ok'  => ! empty( $_POST['kmae_deal_ok'] ),
			)
		);

		if ( is_wp_error( $result ) ) {
			$this->redirect_profile( $result->get_error_code(), true );
		}

		$this->redirect_profile( 'rating_saved' );
	}

	public function admin_continue_shopping() {
		if ( ! is_user_logged_in() ) {
			wp_safe_redirect( wp_login_url( home_url( '/profil/' ) ) );
			exit;
		}

		if ( ! $this->verify_nonce_action( 'kmae_continue_shopping_nonce', 'kmae_continue_shopping' ) ) {
			$this->redirect_profile( 'nonce_failed', true );
		}

		$choice = isset( $_POST['kmae_choice'] ) ? sanitize_key( wp_unslash( $_POST['kmae_choice'] ) ) : '';
		$user_id = get_current_user_id();

		if ( 'yes' === $choice ) {
			$result = KMAE_Deal::continue_shopping( $user_id );
			if ( is_wp_error( $result ) ) {
				$this->redirect_profile( $result->get_error_code(), true );
			}
			wp_safe_redirect( add_query_arg( 'kmae_success', 'continue_yes', home_url( '/hirdetesek/' ) ) );
			exit;
		}

		if ( 'no' === $choice ) {
			$result = KMAE_Deal::stop_shopping( $user_id );
			if ( is_wp_error( $result ) ) {
				$this->redirect_profile( $result->get_error_code(), true );
			}
			$this->redirect_profile( 'continue_no' );
		}

		$this->redirect_profile( 'nonce_failed', true );
	}

	public function admin_pay_company_fee() {
		if ( ! is_user_logged_in() ) {
			wp_safe_redirect( wp_login_url( home_url( '/profil/' ) ) );
			exit;
		}

		if ( ! $this->verify_nonce_action( 'kmae_pay_fee_nonce', 'kmae_pay_company_fee' ) ) {
			$this->redirect_profile( 'nonce_failed', true );
		}

		$fee_id = isset( $_POST['kmae_fee_id'] ) ? absint( $_POST['kmae_fee_id'] ) : 0;
		$result = KMAE_Company::mark_paid( $fee_id, get_current_user_id() );
		if ( is_wp_error( $result ) ) {
			$this->redirect_profile( $result->get_error_code(), true );
		}

		$this->redirect_profile( 'fee_paid' );
	}

	public function admin_login() {
		if ( ! $this->verify_nonce_action( 'kmae_login_nonce', 'kmae_login' ) ) {
			wp_safe_redirect( add_query_arg( 'kmae_error', 'nonce_failed', KMAE_Auth::login_url() ) );
			exit;
		}

		$email    = isset( $_POST['kmae_login_email'] ) ? sanitize_text_field( wp_unslash( $_POST['kmae_login_email'] ) ) : '';
		$password = isset( $_POST['kmae_login_password'] ) ? wp_unslash( $_POST['kmae_login_password'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$remember = ! empty( $_POST['kmae_remember'] );
		$redirect = ! empty( $_POST['kmae_redirect'] ) ? esc_url_raw( wp_unslash( $_POST['kmae_redirect'] ) ) : home_url( '/' );

		if ( empty( $email ) || empty( $password ) ) {
			wp_safe_redirect( add_query_arg( 'kmae_error', 'missing_fields', KMAE_Auth::login_url( $redirect ) ) );
			exit;
		}

		$result = KMAE_Auth::login( $email, $password, $remember );
		if ( is_wp_error( $result ) ) {
			wp_safe_redirect( add_query_arg( 'kmae_error', $result->get_error_code(), KMAE_Auth::login_url( $redirect ) ) );
			exit;
		}

		wp_safe_redirect( $redirect );
		exit;
	}

	public function admin_register() {
		if ( ! $this->verify_nonce_action( 'kmae_register_nonce', 'kmae_register' ) ) {
			wp_safe_redirect( add_query_arg( 'kmae_error', 'nonce_failed', KMAE_Auth::register_url() ) );
			exit;
		}

		if ( empty( $_POST['kmae_terms'] ) ) {
			wp_safe_redirect( add_query_arg( 'kmae_error', 'terms_required', KMAE_Auth::register_url() ) );
			exit;
		}

		if ( empty( $_POST['kmae_email_news'] ) || empty( $_POST['kmae_email_offers'] ) ) {
			wp_safe_redirect( add_query_arg( 'kmae_error', 'email_prefs_required', KMAE_Auth::register_url() ) );
			exit;
		}

		$result = KMAE_Auth::register(
			array(
				'display_name'     => isset( $_POST['kmae_display_name'] ) ? wp_unslash( $_POST['kmae_display_name'] ) : '',
				'email'            => isset( $_POST['kmae_email'] ) ? wp_unslash( $_POST['kmae_email'] ) : '',
				'phone'            => isset( $_POST['kmae_phone'] ) ? wp_unslash( $_POST['kmae_phone'] ) : '',
				'password'         => isset( $_POST['kmae_password'] ) ? wp_unslash( $_POST['kmae_password'] ) : '',
				'password_confirm' => isset( $_POST['kmae_password_confirm'] ) ? wp_unslash( $_POST['kmae_password_confirm'] ) : '',
				'account_type'     => isset( $_POST['kmae_account_type'] ) ? wp_unslash( $_POST['kmae_account_type'] ) : '',
				'company_name'     => isset( $_POST['kmae_company_name'] ) ? wp_unslash( $_POST['kmae_company_name'] ) : '',
				'tax_id'           => isset( $_POST['kmae_company_tax_id'] ) ? wp_unslash( $_POST['kmae_company_tax_id'] ) : '',
				'address'          => isset( $_POST['kmae_company_address'] ) ? wp_unslash( $_POST['kmae_company_address'] ) : '',
				'email_news'       => ! empty( $_POST['kmae_email_news'] ),
				'email_offers'     => ! empty( $_POST['kmae_email_offers'] ),
			)
		);

		if ( is_wp_error( $result ) ) {
			wp_safe_redirect( add_query_arg( 'kmae_error', $result->get_error_code(), KMAE_Auth::register_url() ) );
			exit;
		}

		wp_safe_redirect( add_query_arg( 'kmae_success', 'registered', KMAE_Auth::login_url() ) );
		exit;
	}

	public function admin_lost_password() {
		if ( ! $this->verify_nonce_action( 'kmae_lost_password_nonce', 'kmae_lost_password' ) ) {
			wp_safe_redirect( add_query_arg( 'kmae_error', 'nonce_failed', KMAE_Auth::lost_password_url() ) );
			exit;
		}

		$email  = isset( $_POST['kmae_email'] ) ? wp_unslash( $_POST['kmae_email'] ) : '';
		$result = KMAE_Auth::request_password_reset( $email );

		if ( is_wp_error( $result ) ) {
			wp_safe_redirect( add_query_arg( 'kmae_error', $result->get_error_code(), KMAE_Auth::lost_password_url() ) );
			exit;
		}

		wp_safe_redirect( add_query_arg( 'kmae_success', 'reset_sent', KMAE_Auth::login_url() ) );
		exit;
	}

	public function admin_reset_password() {
		if ( ! $this->verify_nonce_action( 'kmae_reset_password_nonce', 'kmae_reset_password' ) ) {
			wp_safe_redirect( add_query_arg( 'kmae_error', 'nonce_failed', KMAE_Auth::lost_password_url() ) );
			exit;
		}

		$key   = isset( $_POST['kmae_reset_key'] ) ? sanitize_text_field( wp_unslash( $_POST['kmae_reset_key'] ) ) : '';
		$login = isset( $_POST['kmae_reset_login'] ) ? sanitize_text_field( wp_unslash( $_POST['kmae_reset_login'] ) ) : '';
		$pass1 = isset( $_POST['kmae_password'] ) ? wp_unslash( $_POST['kmae_password'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$pass2 = isset( $_POST['kmae_password_confirm'] ) ? wp_unslash( $_POST['kmae_password_confirm'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized

		$result = KMAE_Auth::reset_password_with_key( $login, $key, $pass1, $pass2 );
		if ( is_wp_error( $result ) ) {
			$redirect = KMAE_Auth::reset_password_url( $key, $login );
			wp_safe_redirect( add_query_arg( 'kmae_error', $result->get_error_code(), $redirect ) );
			exit;
		}

		wp_safe_redirect( add_query_arg( 'kmae_success', 'password_set', KMAE_Auth::login_url() ) );
		exit;
	}

	/**
	 * Public contact form → email inbox.
	 */
	public function admin_contact_form() {
		$redirect = KMAE_Pages::url( 'kapcsolat' );
		if ( ! $redirect ) {
			$redirect = home_url( '/kapcsolat/' );
		}

		if ( ! $this->verify_nonce_action( 'kmae_contact_form_nonce', 'kmae_contact_form' ) ) {
			wp_safe_redirect( add_query_arg( 'kmae_error', 'nonce_failed', $redirect ) );
			exit;
		}

		// Honeypot: bots fill this; humans never see it.
		$honeypot = isset( $_POST['kmae_website'] ) ? trim( (string) wp_unslash( $_POST['kmae_website'] ) ) : '';
		if ( '' !== $honeypot ) {
			wp_safe_redirect( add_query_arg( 'kmae_success', 'contact_sent', $redirect ) );
			exit;
		}

		$ip_key = 'kmae_contact_' . md5( isset( $_SERVER['REMOTE_ADDR'] ) ? (string) wp_unslash( $_SERVER['REMOTE_ADDR'] ) : 'unknown' );
		$hits   = (int) get_transient( $ip_key );
		if ( $hits >= 5 ) {
			wp_safe_redirect( add_query_arg( 'kmae_error', 'rate_limited', $redirect ) );
			exit;
		}

		$name    = isset( $_POST['kmae_contact_name'] ) ? sanitize_text_field( wp_unslash( $_POST['kmae_contact_name'] ) ) : '';
		$email   = isset( $_POST['kmae_contact_email'] ) ? sanitize_email( wp_unslash( $_POST['kmae_contact_email'] ) ) : '';
		$topic   = isset( $_POST['kmae_contact_topic'] ) ? sanitize_text_field( wp_unslash( $_POST['kmae_contact_topic'] ) ) : '';
		$message = isset( $_POST['kmae_contact_message'] ) ? sanitize_textarea_field( wp_unslash( $_POST['kmae_contact_message'] ) ) : '';

		$allowed_topics = array(
			'altalanos'   => __( 'Általános kérdés', 'ki-mit-adna-erte' ),
			'fiok'        => __( 'Fiók / belépés', 'ki-mit-adna-erte' ),
			'hirdetes'    => __( 'Hirdetés', 'ki-mit-adna-erte' ),
			'ajanlat'     => __( 'Ajánlat / alkudozás', 'ki-mit-adna-erte' ),
			'technikai'   => __( 'Technikai hiba', 'ki-mit-adna-erte' ),
			'egyeb'       => __( 'Egyéb', 'ki-mit-adna-erte' ),
		);

		if ( '' === $name || '' === $email || '' === $message || ! is_email( $email ) ) {
			wp_safe_redirect( add_query_arg( 'kmae_error', 'missing_fields', $redirect ) );
			exit;
		}

		if ( ! isset( $allowed_topics[ $topic ] ) ) {
			$topic = 'altalanos';
		}

		if ( function_exists( 'mb_strlen' ) ) {
			$msg_len = mb_strlen( $message );
		} else {
			$msg_len = strlen( $message );
		}

		if ( $msg_len < 10 ) {
			wp_safe_redirect( add_query_arg( 'kmae_error', 'message_short', $redirect ) );
			exit;
		}

		if ( $msg_len > 5000 ) {
			wp_safe_redirect( add_query_arg( 'kmae_error', 'message_long', $redirect ) );
			exit;
		}

		$to      = KMAE_Settings::contact_form_email();
		$subject = sprintf(
			/* translators: 1: site name, 2: topic label */
			__( '[%1$s] Kapcsolat: %2$s', 'ki-mit-adna-erte' ),
			wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ),
			$allowed_topics[ $topic ]
		);

		$body_lines = array(
			__( 'Új üzenet érkezett a kapcsolat űrlapról.', 'ki-mit-adna-erte' ),
			'',
			sprintf( __( 'Név: %s', 'ki-mit-adna-erte' ), $name ),
			sprintf( __( 'E-mail: %s', 'ki-mit-adna-erte' ), $email ),
			sprintf( __( 'Téma: %s', 'ki-mit-adna-erte' ), $allowed_topics[ $topic ] ),
			'',
			__( 'Üzenet:', 'ki-mit-adna-erte' ),
			$message,
			'',
			sprintf( __( 'Oldal: %s', 'ki-mit-adna-erte' ), home_url( '/kapcsolat/' ) ),
			sprintf( __( 'Időpont: %s', 'ki-mit-adna-erte' ), wp_date( 'Y-m-d H:i:s' ) ),
		);

		$headers = array(
			sprintf( 'Reply-To: %s <%s>', $name, $email ),
		);

		$sent = KMAE_Brand::send_mail( $to, $subject, implode( "\n", $body_lines ), $headers );

		set_transient( $ip_key, $hits + 1, HOUR_IN_SECONDS );

		if ( ! $sent ) {
			wp_safe_redirect( add_query_arg( 'kmae_error', 'send_failed', $redirect ) );
			exit;
		}

		wp_safe_redirect( add_query_arg( 'kmae_success', 'contact_sent', $redirect ) );
		exit;
	}

	public function admin_activate_premium() {
		if ( ! is_user_logged_in() ) {
			wp_safe_redirect( wp_login_url( $this->get_profile_redirect_url() ) );
			exit;
		}

		if ( ! $this->verify_nonce_action( 'kmae_premium_nonce', 'kmae_activate_premium' ) ) {
			$this->redirect_profile( 'nonce_failed', true );
		}

		$result = KMAE_Premium::activate_demo( get_current_user_id() );
		if ( is_wp_error( $result ) ) {
			$this->redirect_profile( $result->get_error_code(), true );
		}

		$this->redirect_profile( 'premium_active' );
	}

	public function admin_send_tip() {
		if ( ! is_user_logged_in() ) {
			wp_safe_redirect( wp_login_url( home_url( '/profil/' ) ) );
			exit;
		}

		if ( ! $this->verify_nonce_action( 'kmae_tip_nonce', 'kmae_send_tip' ) ) {
			$this->redirect_profile( 'nonce_failed', true );
		}

		$offer_id = isset( $_POST['kmae_offer_id'] ) ? absint( $_POST['kmae_offer_id'] ) : 0;
		$amount   = isset( $_POST['kmae_tip_amount'] ) ? KMAE_Offers::parse_amount_input( $_POST['kmae_tip_amount'] ) : 0;
		$message  = isset( $_POST['kmae_tip_message'] ) ? wp_unslash( $_POST['kmae_tip_message'] ) : '';

		$result = KMAE_Tips::send( $offer_id, get_current_user_id(), $amount, $message );
		if ( is_wp_error( $result ) ) {
			$this->redirect_profile( $result->get_error_code(), true );
		}

		$this->redirect_profile( 'tip_sent' );
	}

	public function admin_claim_detailing() {
		if ( ! is_user_logged_in() ) {
			wp_safe_redirect( wp_login_url( home_url( '/profil/' ) ) );
			exit;
		}

		if ( ! $this->verify_nonce_action( 'kmae_detailing_nonce', 'kmae_claim_detailing' ) ) {
			$this->redirect_profile( 'nonce_failed', true );
		}

		$result = KMAE_Premium::claim_detailing( get_current_user_id() );
		if ( is_wp_error( $result ) ) {
			$this->redirect_profile( $result->get_error_code(), true );
		}

		$this->redirect_profile( 'detailing_claimed' );
	}

	private function get_listings_redirect_url() {
		return home_url( '/sajat-hirdetesek/' );
	}

	public function admin_update_listing() {
		if ( ! is_user_logged_in() ) {
			wp_safe_redirect( wp_login_url( home_url( '/hirdetes-feladasa/' ) ) );
			exit;
		}

		if ( ! $this->verify_nonce_action( 'kmae_update_listing_nonce', 'kmae_update_listing' ) ) {
			wp_safe_redirect( add_query_arg( 'kmae_error', 'nonce_failed', $this->get_listings_redirect_url() ) );
			exit;
		}

		$listing_id = isset( $_POST['kmae_listing_id'] ) ? absint( $_POST['kmae_listing_id'] ) : 0;
		if ( ! KMAE_Listings::user_owns_listing( $listing_id, get_current_user_id() ) ) {
			wp_safe_redirect( add_query_arg( 'kmae_error', 'forbidden', $this->get_listings_redirect_url() ) );
			exit;
		}

		if ( ! KMAE_Listings::can_edit_listing( $listing_id ) ) {
			wp_safe_redirect( add_query_arg( 'kmae_error', 'listing_locked', $this->get_listings_redirect_url() ) );
			exit;
		}

		$title = isset( $_POST['kmae_title'] ) ? sanitize_text_field( wp_unslash( $_POST['kmae_title'] ) ) : '';
		$desc  = isset( $_POST['kmae_description'] ) ? wp_kses_post( wp_unslash( $_POST['kmae_description'] ) ) : '';
		$county = isset( $_POST['kmae_county'] ) ? sanitize_text_field( wp_unslash( $_POST['kmae_county'] ) ) : '';
		$city   = isset( $_POST['kmae_city'] ) ? sanitize_text_field( wp_unslash( $_POST['kmae_city'] ) ) : '';

		if ( empty( $title ) || empty( $desc ) || ! KMAE_Counties::validate_listing_location( $county, $city ) ) {
			$redirect = ! empty( $_POST['kmae_redirect'] ) ? esc_url_raw( wp_unslash( $_POST['kmae_redirect'] ) ) : add_query_arg( 'kmae_edit', $listing_id, home_url( '/hirdetes-feladasa/' ) );
			wp_safe_redirect( add_query_arg( 'kmae_error', 'missing_fields', $redirect ) );
			exit;
		}

		$status      = KMAE_Meta::get_status( $listing_id );
		$is_awaiting = KMAE_Meta::STATUS_AWAITING_PHOTOS === $status;

		if ( KMAE_Moderation::is_enabled() ) {
			$vehicle_data = KMAE_Vehicle::parse_post_data();
			$vehicle_data['title']       = $title;
			$vehicle_data['description'] = wp_strip_all_tags( $desc );
			$existing_gallery            = KMAE_Query::get_gallery_ids( $listing_id );
			$new_images                  = KMAE_Moderation::count_uploaded_images();
			$image_count                 = count( $existing_gallery ) + $new_images;
			if ( $image_count < KMAE_Moderation::MIN_IMAGES ) {
				$image_count = max( $image_count, count( $existing_gallery ) );
			}
			$require_images = ! $is_awaiting;
			$moderation     = KMAE_Moderation::validate( $vehicle_data, max( $image_count, count( $existing_gallery ) ), $require_images );
			if ( is_wp_error( $moderation ) ) {
				$redirect = ! empty( $_POST['kmae_redirect'] ) ? esc_url_raw( wp_unslash( $_POST['kmae_redirect'] ) ) : add_query_arg( 'kmae_edit', $listing_id, home_url( '/hirdetes-feladasa/' ) );
				$reasons  = $moderation->get_error_data()['reasons'] ?? array( $moderation->get_error_message() );
				KMAE_Moderation::stash_errors_for_user( get_current_user_id(), $reasons );
				wp_safe_redirect( add_query_arg( 'kmae_error', 'moderation_failed', $redirect ) );
				exit;
			}
		}

		wp_update_post(
			array(
				'ID'           => $listing_id,
				'post_title'   => $title,
				'post_content' => $desc,
			)
		);

		$meta_saved = KMAE_Listings::save_meta_from_post( $listing_id, false );
		if ( is_wp_error( $meta_saved ) ) {
			$redirect = ! empty( $_POST['kmae_redirect'] ) ? esc_url_raw( wp_unslash( $_POST['kmae_redirect'] ) ) : add_query_arg( 'kmae_edit', $listing_id, home_url( '/hirdetes-feladasa/' ) );
			wp_safe_redirect( add_query_arg( 'kmae_error', $meta_saved->get_error_code(), $redirect ) );
			exit;
		}

		$redirect = ! empty( $_POST['kmae_redirect'] ) ? esc_url_raw( wp_unslash( $_POST['kmae_redirect'] ) ) : add_query_arg( 'kmae_edit', $listing_id, home_url( '/hirdetes-feladasa/' ) );

		if ( KMAE_Photo_Motor::is_enabled() ) {
			$photos_complete = KMAE_Photo_Motor::count_required_filled( $listing_id ) >= KMAE_Photo_Motor::required_count();
			$has_new_photos  = KMAE_Photo_Motor::has_any_upload();

			if ( $is_awaiting && ! $has_new_photos && ! $photos_complete ) {
				// Allow saving listing details from computer without photos yet.
				wp_safe_redirect( add_query_arg( 'kmae_success', 'listing_updated', $this->get_listings_redirect_url() ) );
				exit;
			}

			$photo_ok = KMAE_Photo_Motor::validate_request( $listing_id, false );
			if ( is_wp_error( $photo_ok ) ) {
				$reasons = $photo_ok->get_error_data()['reasons'] ?? array( $photo_ok->get_error_message() );
				KMAE_Moderation::stash_errors_for_user( get_current_user_id(), is_array( $reasons ) ? $reasons : array( $photo_ok->get_error_message() ) );
				wp_safe_redirect( add_query_arg( 'kmae_error', 'photo_slots_required', $redirect ) );
				exit;
			}

			$gallery = KMAE_Listings::handle_image_uploads( $listing_id, KMAE_Query::get_gallery_ids( $listing_id ) );
			if ( is_wp_error( $gallery ) ) {
				$reasons = $gallery->get_error_data()['reasons'] ?? array( $gallery->get_error_message() );
				KMAE_Moderation::stash_errors_for_user( get_current_user_id(), $reasons );
				wp_safe_redirect( add_query_arg( 'kmae_error', 'photo_quality_failed', $redirect ) );
				exit;
			}

			if ( $is_awaiting ) {
				if ( KMAE_Listings::activate_if_photos_ready( $listing_id ) ) {
					wp_safe_redirect( add_query_arg( 'kmae_success', 'listing_activated', $this->get_listings_redirect_url() ) );
					exit;
				}
				wp_safe_redirect( add_query_arg( 'kmae_error', 'photo_slots_required', $redirect ) );
				exit;
			}
		} else {
			$existing = KMAE_Query::get_gallery_ids( $listing_id );
			$existing = KMAE_Listings::apply_gallery_edits( $listing_id, $existing );
			KMAE_Listings::handle_image_uploads( $listing_id, $existing );
		}

		wp_safe_redirect( add_query_arg( 'kmae_success', 'listing_updated', $this->get_listings_redirect_url() ) );
		exit;
	}

	public function admin_delete_listing() {
		if ( ! is_user_logged_in() ) {
			wp_safe_redirect( wp_login_url( $this->get_listings_redirect_url() ) );
			exit;
		}

		if ( ! $this->verify_nonce_action( 'kmae_delete_listing_nonce', 'kmae_delete_listing' ) ) {
			wp_safe_redirect( add_query_arg( 'kmae_error', 'nonce_failed', $this->get_listings_redirect_url() ) );
			exit;
		}

		$listing_id = isset( $_POST['kmae_listing_id'] ) ? absint( $_POST['kmae_listing_id'] ) : 0;
		if ( ! KMAE_Listings::can_delete_listing( $listing_id ) ) {
			wp_safe_redirect( add_query_arg( 'kmae_error', 'listing_locked', $this->get_listings_redirect_url() ) );
			exit;
		}

		$result     = KMAE_Listings::delete_listing( $listing_id, get_current_user_id() );

		if ( is_wp_error( $result ) ) {
			wp_safe_redirect( add_query_arg( 'kmae_error', $result->get_error_code(), $this->get_listings_redirect_url() ) );
			exit;
		}

		wp_safe_redirect( add_query_arg( 'kmae_success', 'listing_deleted', $this->get_listings_redirect_url() ) );
		exit;
	}

	public function admin_reactivate_listing() {
		if ( ! is_user_logged_in() ) {
			wp_safe_redirect( wp_login_url( $this->get_listings_redirect_url() ) );
			exit;
		}

		if ( ! $this->verify_nonce_action( 'kmae_reactivate_listing_nonce', 'kmae_reactivate_listing' ) ) {
			wp_safe_redirect( add_query_arg( 'kmae_error', 'nonce_failed', $this->get_listings_redirect_url() ) );
			exit;
		}

		$listing_id = isset( $_POST['kmae_listing_id'] ) ? absint( $_POST['kmae_listing_id'] ) : 0;
		$result     = KMAE_Listings::reactivate_listing( $listing_id, get_current_user_id() );

		if ( is_wp_error( $result ) ) {
			wp_safe_redirect( add_query_arg( 'kmae_error', $result->get_error_code(), $this->get_listings_redirect_url() ) );
			exit;
		}

		wp_safe_redirect( add_query_arg( 'kmae_success', 'listing_reactivated', $this->get_listings_redirect_url() ) );
		exit;
	}

	private function process_create_listing() {
		if ( ! $this->verify_nonce( 'kmae_create_listing_nonce' ) ) {
			return;
		}

		$user_id = get_current_user_id();
		$title   = isset( $_POST['kmae_title'] ) ? sanitize_text_field( wp_unslash( $_POST['kmae_title'] ) ) : '';
		$desc    = isset( $_POST['kmae_description'] ) ? wp_kses_post( wp_unslash( $_POST['kmae_description'] ) ) : '';
		$county  = isset( $_POST['kmae_county'] ) ? sanitize_text_field( wp_unslash( $_POST['kmae_county'] ) ) : '';
		$city    = isset( $_POST['kmae_city'] ) ? sanitize_text_field( wp_unslash( $_POST['kmae_city'] ) ) : '';
		$device  = isset( $_POST['kmae_create_device'] ) ? sanitize_key( wp_unslash( $_POST['kmae_create_device'] ) ) : '';
		$referer = wp_get_referer() ?: home_url( '/hirdetes-feladasa/' );

		$can_create = KMAE_Seller::can_create_listing( $user_id );
		if ( is_wp_error( $can_create ) ) {
			wp_safe_redirect( add_query_arg( 'kmae_error', $can_create->get_error_code(), $referer ) );
			exit;
		}

		if ( empty( $title ) || empty( $desc ) || ! KMAE_Counties::validate_listing_location( $county, $city ) ) {
			wp_safe_redirect( add_query_arg( 'kmae_error', 'missing_fields', $referer ) );
			exit;
		}

		if ( empty( $_POST['kmae_price_mode'] ) ) {
			wp_safe_redirect( add_query_arg( 'kmae_error', 'price_mode_required', $referer ) );
			exit;
		}

		if ( KMAE_Moderation::is_enabled() && empty( $_POST['kmae_moderation_consent'] ) ) {
			wp_safe_redirect( add_query_arg( 'kmae_error', 'missing_fields', $referer ) );
			exit;
		}

		$photo_motor   = KMAE_Photo_Motor::is_enabled();
		$defer_photos  = false;
		if ( $photo_motor ) {
			if ( ! in_array( $device, array( 'computer', 'phone', 'tablet' ), true ) ) {
				wp_safe_redirect( add_query_arg( 'kmae_error', 'device_required', $referer ) );
				exit;
			}
			$defer_photos = ( 'computer' === $device );
		}

		$vehicle_data = KMAE_Vehicle::parse_post_data();
		$vehicle_data['title']       = $title;
		$vehicle_data['description'] = wp_strip_all_tags( $desc );
		$image_count                 = KMAE_Moderation::count_uploaded_images();
		$moderation                  = KMAE_Moderation::validate( $vehicle_data, $image_count, ! $defer_photos );

		if ( is_wp_error( $moderation ) ) {
			$reasons = $moderation->get_error_data()['reasons'] ?? array( $moderation->get_error_message() );
			KMAE_Moderation::stash_errors_for_user( $user_id, $reasons );
			wp_safe_redirect( add_query_arg( 'kmae_error', 'moderation_failed', $referer ) );
			exit;
		}

		if ( $photo_motor && ! $defer_photos ) {
			$photo_ok = KMAE_Photo_Motor::validate_request( 0, true );
			if ( is_wp_error( $photo_ok ) ) {
				$reasons = $photo_ok->get_error_data()['reasons'] ?? array( $photo_ok->get_error_message() );
				KMAE_Moderation::stash_errors_for_user( $user_id, is_array( $reasons ) ? $reasons : array( $photo_ok->get_error_message() ) );
				wp_safe_redirect( add_query_arg( 'kmae_error', 'photo_slots_required', $referer ) );
				exit;
			}
		}

		$initial_status = $defer_photos ? KMAE_Meta::STATUS_AWAITING_PHOTOS : KMAE_Meta::STATUS_ACTIVE;

		$post_id = wp_insert_post(
			array(
				'post_title'   => $title,
				'post_content' => $desc,
				'post_type'    => 'kmae_listing',
				'post_status'  => 'publish',
				'post_author'  => $user_id,
			)
		);

		if ( is_wp_error( $post_id ) ) {
			wp_safe_redirect( add_query_arg( 'kmae_error', 'create_failed', $referer ) );
			exit;
		}

		$meta_saved = KMAE_Listings::save_meta_from_post( $post_id, true, $initial_status );
		if ( is_wp_error( $meta_saved ) ) {
			wp_delete_post( $post_id, true );
			wp_safe_redirect( add_query_arg( 'kmae_error', $meta_saved->get_error_code(), $referer ) );
			exit;
		}

		if ( $device ) {
			update_post_meta( $post_id, '_kmae_create_device', $device );
		}

		if ( $defer_photos ) {
			wp_safe_redirect( add_query_arg( 'kmae_success', 'listing_awaiting_photos', home_url( '/sajat-hirdetesek/' ) ) );
			exit;
		}

		$gallery = KMAE_Listings::handle_image_uploads( $post_id, array() );
		if ( is_wp_error( $gallery ) ) {
			$reasons = $gallery->get_error_data()['reasons'] ?? array( $gallery->get_error_message() );
			KMAE_Moderation::stash_errors_for_user( $user_id, $reasons );
			wp_delete_post( $post_id, true );
			wp_safe_redirect( add_query_arg( 'kmae_error', 'photo_quality_failed', $referer ) );
			exit;
		}

		if ( empty( $gallery ) || ( $photo_motor && KMAE_Photo_Motor::count_required_filled( $post_id ) < KMAE_Photo_Motor::required_count() ) ) {
			wp_delete_post( $post_id, true );
			wp_safe_redirect( add_query_arg( 'kmae_error', 'upload_failed', $referer ) );
			exit;
		}

		do_action( 'kmae_listing_published', $post_id );

		wp_safe_redirect( add_query_arg( 'kmae_success', 'listing_created', home_url( '/sajat-hirdetesek/' ) ) );
		exit;
	}

	private function process_cash_offer() {
		if ( ! $this->verify_nonce( 'kmae_offer_nonce' ) ) {
			return;
		}

		$listing_id = isset( $_POST['kmae_listing_id'] ) ? absint( $_POST['kmae_listing_id'] ) : 0;
		$amount     = isset( $_POST['kmae_cash_amount'] ) ? KMAE_Offers::parse_amount_input( $_POST['kmae_cash_amount'] ) : 0;

		$result = KMAE_Offers::submit_cash_offer( $listing_id, get_current_user_id(), $amount );

		if ( is_wp_error( $result ) ) {
			wp_safe_redirect( add_query_arg( 'kmae_error', $result->get_error_code(), wp_get_referer() ) );
			exit;
		}

		wp_safe_redirect( add_query_arg( 'kmae_success', 'offer_sent', wp_get_referer() ) );
		exit;
	}

	private function process_counter_offer() {
		if ( ! $this->verify_nonce( 'kmae_counter_offer_nonce' ) ) {
			return;
		}

		$offer_id       = isset( $_POST['kmae_offer_id'] ) ? absint( $_POST['kmae_offer_id'] ) : 0;
		$template_code  = isset( $_POST['kmae_template_code'] ) ? sanitize_text_field( wp_unslash( $_POST['kmae_template_code'] ) ) : '';
		$counter_amount = isset( $_POST['kmae_counter_amount'] ) ? KMAE_Offers::parse_amount_input( $_POST['kmae_counter_amount'] ) : 0;

		$result = KMAE_Counter_Offers::submit_seller_counter(
			$offer_id,
			get_current_user_id(),
			$template_code,
			$counter_amount > 0 ? $counter_amount : null
		);

		if ( is_wp_error( $result ) ) {
			wp_safe_redirect( add_query_arg( 'kmae_error', $result->get_error_code(), wp_get_referer() ) );
			exit;
		}

		wp_safe_redirect( add_query_arg( 'kmae_success', 'counter_sent', wp_get_referer() ) );
		exit;
	}

	private function process_revise_offer() {
		if ( ! $this->verify_nonce( 'kmae_revise_offer_nonce' ) ) {
			return;
		}

		$offer_id = isset( $_POST['kmae_offer_id'] ) ? absint( $_POST['kmae_offer_id'] ) : 0;
		$amount   = isset( $_POST['kmae_cash_amount'] ) ? KMAE_Offers::parse_amount_input( $_POST['kmae_cash_amount'] ) : 0;

		$result = KMAE_Counter_Offers::submit_buyer_revision( $offer_id, get_current_user_id(), $amount );

		if ( is_wp_error( $result ) ) {
			wp_safe_redirect( add_query_arg( 'kmae_error', $result->get_error_code(), wp_get_referer() ) );
			exit;
		}

		wp_safe_redirect( add_query_arg( 'kmae_success', 'offer_revised', wp_get_referer() ) );
		exit;
	}

	private function process_accept_offer() {
		if ( ! $this->verify_nonce( 'kmae_accept_offer_nonce' ) ) {
			return;
		}

		$offer_id = isset( $_POST['kmae_offer_id'] ) ? absint( $_POST['kmae_offer_id'] ) : 0;
		$result   = KMAE_Counter_Offers::accept_offer( $offer_id, get_current_user_id() );

		if ( is_wp_error( $result ) ) {
			wp_safe_redirect( add_query_arg( 'kmae_error', $result->get_error_code(), wp_get_referer() ) );
			exit;
		}

		wp_safe_redirect( add_query_arg( 'kmae_success', 'offer_accepted', wp_get_referer() ) );
		exit;
	}

	private function process_deal_success() {
		if ( ! $this->verify_nonce( 'kmae_deal_success_nonce' ) ) {
			return;
		}

		$offer_id = isset( $_POST['kmae_offer_id'] ) ? absint( $_POST['kmae_offer_id'] ) : 0;
		$result   = KMAE_Deal::confirm_success( $offer_id, get_current_user_id() );

		if ( is_wp_error( $result ) ) {
			wp_safe_redirect( add_query_arg( 'kmae_error', $result->get_error_code(), wp_get_referer() ) );
			exit;
		}

		wp_safe_redirect( add_query_arg( 'kmae_success', 'deal_success', KMAE_Trust::rate_url( $offer_id ) ) );
		exit;
	}

	private function process_deal_failure() {
		if ( ! $this->verify_nonce( 'kmae_deal_failure_nonce' ) ) {
			return;
		}

		$offer_id = isset( $_POST['kmae_offer_id'] ) ? absint( $_POST['kmae_offer_id'] ) : 0;
		$result   = KMAE_Deal::confirm_failure( $offer_id, get_current_user_id() );

		if ( is_wp_error( $result ) ) {
			wp_safe_redirect( add_query_arg( 'kmae_error', $result->get_error_code(), wp_get_referer() ) );
			exit;
		}

		wp_safe_redirect( add_query_arg( 'kmae_success', 'deal_failure', wp_get_referer() ) );
		exit;
	}

	private function process_withdraw_offer() {
		if ( ! $this->verify_nonce( 'kmae_withdraw_offer_nonce' ) ) {
			return;
		}

		$offer_id = isset( $_POST['kmae_offer_id'] ) ? absint( $_POST['kmae_offer_id'] ) : 0;
		$result   = KMAE_Offers::withdraw_offer( $offer_id, get_current_user_id() );

		if ( is_wp_error( $result ) ) {
			wp_safe_redirect( add_query_arg( 'kmae_error', $result->get_error_code(), wp_get_referer() ) );
			exit;
		}

		wp_safe_redirect( add_query_arg( 'kmae_success', 'offer_withdrawn', wp_get_referer() ) );
		exit;
	}

	private function process_trade_offer() {
		if ( ! $this->verify_nonce( 'kmae_trade_offer_nonce' ) ) {
			return;
		}

		require_once ABSPATH . 'wp-admin/includes/image.php';
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';

		$listing_id = isset( $_POST['kmae_listing_id'] ) ? absint( $_POST['kmae_listing_id'] ) : 0;
		$mode       = isset( $_POST['kmae_trade_mode'] ) ? sanitize_text_field( wp_unslash( $_POST['kmae_trade_mode'] ) ) : 'trade';
		$extra_cash = 0;
		if ( in_array( $mode, array( 'trade_plus_cash', 'trade_in' ), true ) && isset( $_POST['kmae_extra_cash'] ) ) {
			$extra_cash = KMAE_Offers::parse_amount_input( $_POST['kmae_extra_cash'] );
		}
		$attachment_ids = array();

		if ( ! empty( $_FILES['kmae_trade_images']['name'][0] ) ) {
			$files = $_FILES['kmae_trade_images'];
			for ( $i = 0; $i < min( count( $files['name'] ), 6 ); $i++ ) {
				if ( empty( $files['name'][ $i ] ) ) {
					continue;
				}
				$_FILES['kmae_trade_single'] = array(
					'name'     => $files['name'][ $i ],
					'type'     => $files['type'][ $i ],
					'tmp_name' => $files['tmp_name'][ $i ],
					'error'    => $files['error'][ $i ],
					'size'     => $files['size'][ $i ],
				);
				$aid = media_handle_upload( 'kmae_trade_single', $listing_id );
				if ( ! is_wp_error( $aid ) ) {
					$attachment_ids[] = $aid;
				}
			}
		}

		$result = KMAE_Offers::submit_trade_offer(
			$listing_id,
			get_current_user_id(),
			$attachment_ids,
			$mode,
			$extra_cash
		);

		if ( is_wp_error( $result ) ) {
			wp_safe_redirect( add_query_arg( 'kmae_error', $result->get_error_code(), wp_get_referer() ) );
			exit;
		}

		wp_safe_redirect( add_query_arg( 'kmae_success', 'offer_sent', wp_get_referer() ) );
		exit;
	}

	private function process_unlock_contact() {
		if ( ! $this->verify_nonce( 'kmae_unlock_contact_nonce' ) ) {
			return;
		}

		$offer_id = isset( $_POST['kmae_offer_id'] ) ? absint( $_POST['kmae_offer_id'] ) : 0;
		$result   = KMAE_Contact::unlock( $offer_id, get_current_user_id() );

		if ( is_wp_error( $result ) ) {
			wp_safe_redirect( add_query_arg( 'kmae_error', $result->get_error_code(), wp_get_referer() ) );
			exit;
		}

		wp_safe_redirect( add_query_arg( 'kmae_success', 'contact_unlocked', wp_get_referer() ) );
		exit;
	}

	private function process_feature_listing() {
		if ( ! $this->verify_nonce( 'kmae_feature_listing_nonce' ) ) {
			return;
		}

		$listing_id = isset( $_POST['kmae_listing_id'] ) ? absint( $_POST['kmae_listing_id'] ) : 0;
		$listing    = get_post( $listing_id );

		if ( ! $listing || (int) $listing->post_author !== get_current_user_id() ) {
			return;
		}

		if ( KMAE_Settings::demo_payments_enabled() ) {
			KMAE_Premium::feature_listing( $listing_id, 7 );
			update_post_meta( $listing_id, '_kmae_featured_reason', 'paid_boost' );
		}

		wp_safe_redirect( add_query_arg( 'kmae_success', 'listing_featured', wp_get_referer() ) );
		exit;
	}
}
