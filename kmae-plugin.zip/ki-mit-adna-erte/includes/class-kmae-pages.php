<?php
/**
 * Required frontend pages and content injection fallback.
 *
 * @package KMAE
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class KMAE_Pages {

	const PAGES = array(
		'belepes'           => array(
			'title'     => 'Bejelentkezés',
			'shortcode' => 'kmae_login',
			'template'  => 'form-login.php',
		),
		'regisztracio'      => array(
			'title'     => 'Regisztráció',
			'shortcode' => 'kmae_register',
			'template'  => 'form-register.php',
		),
		'hirdetes-feladasa' => array(
			'title'     => 'Hirdetés feladása',
			'shortcode' => 'kmae_create_listing',
		),
		'sajat-hirdetesek'  => array(
			'title'     => 'Saját hirdetéseim',
			'shortcode' => 'kmae_my_listings',
		),
		'hirdetesek'        => array(
			'title'     => 'Böngészés',
			'shortcode' => 'kmae_browse',
		),
		'kezdolap'          => array(
			'title'     => 'Kezdőlap',
			'shortcode' => 'kmae_landing',
		),
		'ajanlatok'         => array(
			'title'     => 'Ajánlatok',
			'shortcode' => 'kmae_my_offers',
		),
		'profil'            => array(
			'title'     => 'Profil',
			'shortcode' => 'kmae_profile',
		),
		'hogyan-mukodik'    => array(
			'title'     => 'Hogyan működik?',
			'shortcode' => 'kmae_how_it_works',
		),
		'rolunk'            => array(
			'title'     => 'Rólunk',
			'shortcode' => 'kmae_about',
		),
		'oktatas'           => array(
			'title'     => 'Oktatás',
			'shortcode' => 'kmae_education',
		),
		'beallitasok'       => array(
			'title'     => 'Beállítások',
			'shortcode' => 'kmae_settings',
		),
		'biztonsag'         => array(
			'title'     => 'Biztonság és bizalom',
			'shortcode' => 'kmae_security',
		),
		'gyik'              => array(
			'title'     => 'Gyakori kérdések',
			'shortcode' => 'kmae_faq',
		),
		'kapcsolat'         => array(
			'title'     => 'Kapcsolat',
			'shortcode' => 'kmae_contact',
		),
		'feltetelek'        => array(
			'title'     => 'Felhasználási feltételek',
			'shortcode' => 'kmae_terms',
		),
		'adatvedelem'       => array(
			'title'     => 'Adatvédelem',
			'shortcode' => 'kmae_privacy',
		),
		'ertesitesek'       => array(
			'title'     => 'Értesítések',
			'shortcode' => 'kmae_notifications',
		),
		'uzenetek'          => array(
			'title'     => 'Üzenetek',
			'shortcode' => 'kmae_messages',
		),
		'eladni'            => array(
			'title'     => 'Eladni',
			'shortcode' => 'kmae_hub_sell',
		),
		'venni'             => array(
			'title'     => 'Venni',
			'shortcode' => 'kmae_hub_buy',
		),
		'statisztikak'      => array(
			'title'     => 'Statisztikák, értesítések',
			'shortcode' => 'kmae_hub_stats',
		),
	);

	const OFFERS_PAGE_SLUG = 'ajanlatok';

	public function __construct() {
		add_filter( 'the_content', array( $this, 'inject_page_content' ), 9 );
		add_action( 'template_redirect', array( __CLASS__, 'mark_offers_seen_on_visit' ), 1 );
		add_action( 'template_redirect', array( __CLASS__, 'redirect_legacy_offers_page' ) );
		add_filter( 'body_class', array( __CLASS__, 'offer_thread_body_class' ) );
		add_action( 'init', array( __CLASS__, 'maybe_ensure_pages' ), 20 );
	}

	/**
	 * Create/update shortcode pages after plugin updates (without re-activation).
	 */
	public static function maybe_ensure_pages() {
		$stored = get_option( 'kmae_pages_version', '' );
		if ( $stored === KMAE_VERSION ) {
			return;
		}
		self::ensure_pages();
		update_option( 'kmae_pages_version', KMAE_VERSION );
	}

	/**
	 * Full-page chat room styling when viewing a single offer thread.
	 */
	public static function offer_thread_body_class( $classes ) {
		if ( ! is_user_logged_in() || ! self::is_offers_page() ) {
			return $classes;
		}

		$offer_id = isset( $_GET['kmae_offer'] ) ? absint( $_GET['kmae_offer'] ) : 0;
		if ( $offer_id ) {
			$classes[] = 'kmae-offer-thread-active';
		}

		return $classes;
	}

	/**
	 * Mark a single offer thread as read when opened.
	 */
	public static function mark_offers_seen_on_visit() {
		if ( ! is_user_logged_in() || ! self::is_offers_page() ) {
			return;
		}

		$offer_id = isset( $_GET['kmae_offer'] ) ? absint( $_GET['kmae_offer'] ) : 0;
		if ( ! $offer_id ) {
			return;
		}

		$offer = KMAE_Database::get_offer( $offer_id );
		if ( ! $offer || ! KMAE_Counter_Offers::user_can_access( $offer, get_current_user_id() ) ) {
			return;
		}

		KMAE_Database::mark_offer_seen( get_current_user_id(), $offer_id );
	}

	/**
	 * Whether the current request is the offers hub page.
	 */
	public static function is_offers_page() {
		if ( is_page( self::OFFERS_PAGE_SLUG ) ) {
			return true;
		}

		$path = wp_parse_url( $_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH );
		if ( ! is_string( $path ) ) {
			return false;
		}

		return str_starts_with(
			trailingslashit( $path ),
			trailingslashit( '/' . self::OFFERS_PAGE_SLUG )
		);
	}

	public static function browse_page_url() {
		return self::url( 'hirdetesek' );
	}

	public static function offers_page_url() {
		return self::url( self::OFFERS_PAGE_SLUG );
	}

	public static function offer_thread_url( $offer_id ) {
		return add_query_arg( 'kmae_offer', absint( $offer_id ), self::offers_page_url() );
	}

	/**
	 * Permalink for a registered shortcode page (by slug key in PAGES).
	 * Falls back to /{slug}/ if the page is missing.
	 *
	 * @param string $slug Page slug key from self::PAGES.
	 * @return string
	 */
	public static function url( $slug ) {
		$slug = sanitize_title( $slug );
		if ( '' === $slug ) {
			return home_url( '/' );
		}

		$page = get_page_by_path( $slug );
		if ( $page instanceof WP_Post && 'publish' === $page->post_status ) {
			$link = get_permalink( $page );
			if ( $link ) {
				return $link;
			}
		}

		return home_url( '/' . $slug . '/' );
	}

	/**
	 * Shortcode tag for a registered page slug, or empty string.
	 *
	 * @param string $slug Page slug.
	 * @return string
	 */
	public static function shortcode_for( $slug ) {
		return isset( self::PAGES[ $slug ]['shortcode'] ) ? self::PAGES[ $slug ]['shortcode'] : '';
	}

	/**
	 * 301 from old slug after rename.
	 */
	public static function redirect_legacy_offers_page() {
		$path = wp_parse_url( $_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH );
		if ( ! is_string( $path ) ) {
			return;
		}
		$legacy = '/sajat-ajanlataim';
		if ( str_starts_with( trailingslashit( $path ), trailingslashit( $legacy ) ) ) {
			wp_safe_redirect( self::offers_page_url(), 301 );
			exit;
		}
	}

	public static function ensure_pages() {
		self::migrate_offers_page_slug();
		foreach ( self::PAGES as $slug => $config ) {
			self::ensure_page( $slug, $config['title'], $config['shortcode'] );
		}
		self::ensure_front_page();
	}

	/**
	 * Rename legacy offers page slug on existing installs.
	 */
	private static function migrate_offers_page_slug() {
		$old_page = get_page_by_path( 'sajat-ajanlataim' );
		$new_page = get_page_by_path( self::OFFERS_PAGE_SLUG );

		if ( ! $old_page ) {
			return;
		}

		if ( $new_page && (int) $old_page->ID !== (int) $new_page->ID ) {
			wp_trash_post( $old_page->ID );
			return;
		}

		wp_update_post(
			array(
				'ID'         => $old_page->ID,
				'post_name'  => self::OFFERS_PAGE_SLUG,
				'post_title' => 'Ajánlatok',
			)
		);
	}

	/**
	 * Set dedicated landing page as site front page; browse lives at /hirdetesek/.
	 */
	public static function ensure_front_page() {
		self::ensure_page( 'kezdolap', 'Kezdőlap', 'kmae_landing' );

		$landing = get_page_by_path( 'kezdolap' );
		if ( ! $landing ) {
			return;
		}

		$current_front = (int) get_option( 'page_on_front', 0 );
		if ( $current_front === (int) $landing->ID ) {
			return;
		}

		update_option( 'show_on_front', 'page' );
		update_option( 'page_on_front', (int) $landing->ID );
	}

	private static function ensure_page( $slug, $title, $shortcode ) {
		$existing = get_page_by_path( $slug );
		$content  = '[' . $shortcode . ']';

		if ( $existing ) {
			if ( $existing->post_title !== $title ) {
				wp_update_post(
					array(
						'ID'         => $existing->ID,
						'post_title' => $title,
					)
				);
			}
			// Fix pages where shortcode shows as plain text (wrong block type).
			if ( false === strpos( $existing->post_content, $shortcode ) ) {
				wp_update_post(
					array(
						'ID'           => $existing->ID,
						'post_content' => $content,
					)
				);
			}
			return $existing->ID;
		}

		return wp_insert_post(
			array(
				'post_title'   => $title,
				'post_name'    => $slug,
				'post_content' => $content,
				'post_status'  => 'publish',
				'post_type'    => 'page',
			)
		);
	}

	public function inject_page_content( $content ) {
		if ( ! is_singular( 'page' ) || ! in_the_loop() || ! is_main_query() ) {
			return $content;
		}

		$post = get_post();
		if ( ! $post || ! isset( self::PAGES[ $post->post_name ] ) ) {
			return $content;
		}

		$config = self::PAGES[ $post->post_name ];

		// Auth pages: always render template directly (works even if shortcode block fails).
		if ( ! empty( $config['template'] ) ) {
			ob_start();
			include KMAE_PLUGIN_DIR . 'templates/' . $config['template'];
			return ob_get_clean();
		}

		$shortcode = $config['shortcode'];

		// Hub menus must always render — don't rely on stored page content alone.
		if ( in_array( $shortcode, array( 'kmae_hub_sell', 'kmae_hub_buy', 'kmae_hub_stats' ), true ) ) {
			return do_shortcode( '[' . $shortcode . ']' );
		}

		// Other pages: force shortcode processing if content looks broken.
		if ( has_shortcode( $content, $shortcode ) ) {
			return do_shortcode( $content );
		}

		if ( false !== strpos( $content, '[' . $shortcode . ']' ) ) {
			return do_shortcode( '[' . $shortcode . ']' );
		}

		return $content;
	}
}
