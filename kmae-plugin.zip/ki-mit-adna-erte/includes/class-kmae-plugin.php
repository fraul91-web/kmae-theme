<?php
/**
 * Main plugin orchestrator.
 *
 * @package KMAE
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class KMAE_Plugin {

	public function run() {
		KMAE_Activator::maybe_upgrade();
		KMAE_Brand::init();
		KMAE_Auth::init();
		KMAE_Notifications::init();
		KMAE_Listings::init();
		KMAE_Dashboard::init();

		new KMAE_Post_Types();
		new KMAE_Taxonomies();
		new KMAE_Meta();

		if ( is_admin() ) {
			require_once KMAE_PLUGIN_DIR . 'admin/class-kmae-admin.php';
			new KMAE_Admin();
		}

		require_once KMAE_PLUGIN_DIR . 'public/class-kmae-public.php';
		require_once KMAE_PLUGIN_DIR . 'public/class-kmae-shortcodes.php';
		new KMAE_Public();
		new KMAE_Shortcodes();
		new KMAE_Pages();
		new KMAE_Nav();
	}
}
