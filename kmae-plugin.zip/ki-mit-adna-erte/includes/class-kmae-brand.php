<?php
/**
 * Official Albira brand assets and HTML mail wrapper.
 *
 * @package KMAE
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class KMAE_Brand {

	const LOGO_GUEST = 'https://albira.hu/wp-content/uploads/2026/08/albira-logo-belepes-elott.webp';
	const LOGO_APP   = 'https://albira.hu/wp-content/uploads/2026/08/albira-logo-belepes-utan.webp';

	public static function init() {
		add_filter( 'wp_mail', array( __CLASS__, 'ensure_html_headers' ) );
	}

	public static function logo_guest() {
		return self::LOGO_GUEST;
	}

	public static function logo_app() {
		return self::LOGO_APP;
	}

	/**
	 * Guest logo before login, official logo after.
	 *
	 * @param string $variant guest|app|auto.
	 * @return string
	 */
	public static function logo_url( $variant = 'auto' ) {
		if ( 'guest' === $variant ) {
			return self::LOGO_GUEST;
		}
		if ( 'app' === $variant ) {
			return self::LOGO_APP;
		}

		return is_user_logged_in() ? self::LOGO_APP : self::LOGO_GUEST;
	}

	public static function html_content_type() {
		return 'text/html';
	}

	/**
	 * Send a branded HTML email with the official (logged-in) logo.
	 *
	 * @param string|array $to      Recipient(s).
	 * @param string       $subject Subject.
	 * @param string       $body    Plain-text body.
	 * @param string|array $headers Extra headers.
	 * @return bool
	 */
	public static function send_mail( $to, $subject, $body, $headers = array() ) {
		$html    = self::wrap_email( $body );
		$headers = is_array( $headers ) ? $headers : array_filter( array_map( 'trim', explode( "\n", (string) $headers ) ) );
		$headers = array_values(
			array_filter(
				$headers,
				static function ( $header ) {
					return is_string( $header ) && '' !== $header && stripos( $header, 'Content-Type:' ) !== 0;
				}
			)
		);
		array_unshift( $headers, 'Content-Type: text/html; charset=UTF-8' );

		return wp_mail( $to, $subject, $html, $headers );
	}

	/**
	 * @param string $text Plain text.
	 * @return string
	 */
	public static function wrap_email( $text ) {
		$logo = esc_url( self::LOGO_APP );
		$home = esc_url( home_url( '/' ) );
		$html = self::format_email_body( $text );

		return '<!DOCTYPE html>
<html lang="hu">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Albira</title>
</head>
<body style="margin:0;padding:0;background:#f4f7fb;">
<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background:#f4f7fb;">
	<tr>
		<td align="center" style="padding:28px 16px;">
			<table role="presentation" width="560" cellspacing="0" cellpadding="0" style="max-width:560px;width:100%;background:#ffffff;border-radius:16px;">
				<tr>
					<td style="padding:28px 32px 12px;">
						<a href="' . $home . '" style="text-decoration:none;">
							<img src="' . $logo . '" alt="Albira" width="180" style="display:block;width:180px;max-width:100%;height:auto;border:0;" />
						</a>
					</td>
				</tr>
				<tr>
					<td style="padding:8px 32px 32px;font-family:Arial,Helvetica,sans-serif;font-size:15px;line-height:1.65;color:#1f2a44;">
						' . $html . '
					</td>
				</tr>
			</table>
		</td>
	</tr>
</table>
</body>
</html>';
	}

	/**
	 * If the body already contains the official logo, force HTML content-type.
	 *
	 * @param array $args wp_mail args.
	 * @return array
	 */
	public static function ensure_html_headers( $args ) {
		if ( empty( $args['message'] ) || ! is_string( $args['message'] ) ) {
			return $args;
		}

		if ( false === strpos( $args['message'], 'albira-logo-belepes-utan.webp' ) ) {
			return $args;
		}

		$headers = isset( $args['headers'] ) ? $args['headers'] : array();
		if ( is_string( $headers ) ) {
			$headers = array_filter( array_map( 'trim', explode( "\n", $headers ) ) );
		}
		if ( ! is_array( $headers ) ) {
			$headers = array();
		}

		$has_html = false;
		foreach ( $headers as $header ) {
			if ( is_string( $header ) && stripos( $header, 'text/html' ) !== false ) {
				$has_html = true;
				break;
			}
		}

		if ( ! $has_html ) {
			$headers[]       = 'Content-Type: text/html; charset=UTF-8';
			$args['headers'] = $headers;
		}

		return $args;
	}

	/**
	 * @param string $text Plain text.
	 * @return string
	 */
	private static function format_email_body( $text ) {
		$html = esc_html( (string) $text );
		$html = preg_replace(
			'~(https?://[^\s<]+)~',
			'<a href="$1" style="color:#317efa;text-decoration:underline;">$1</a>',
			$html
		);

		return nl2br( $html );
	}
}
