<?php
/**
 * Counter-offer and negotiation logic.
 *
 * @package KMAE
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class KMAE_Counter_Offers {

	const TEMPLATE_BUYER_REVISION = 'buyer_revision';

	public static function status_labels() {
		return array(
			'pending'   => __( 'Függőben', 'ki-mit-adna-erte' ),
			'accepted'  => __( 'Elfogadva', 'ki-mit-adna-erte' ),
			'rejected'  => __( 'Elutasítva', 'ki-mit-adna-erte' ),
			'withdrawn' => __( 'Visszavonva', 'ki-mit-adna-erte' ),
		);
	}

	public static function get_listing_seller_id( $offer ) {
		$listing = get_post( $offer->listing_id );
		return $listing ? (int) $listing->post_author : 0;
	}

	public static function is_seller( $offer, $user_id ) {
		return self::get_listing_seller_id( $offer ) === (int) $user_id;
	}

	public static function is_buyer( $offer, $user_id ) {
		return (int) $offer->offerer_id === (int) $user_id;
	}

	public static function count_user_counters( $offer_id, $user_id ) {
		return KMAE_Database::count_counter_offers_by_user( $offer_id, $user_id );
	}

	public static function can_seller_counter( $offer, $user_id ) {
		if ( KMAE_Offers::STATUS_PENDING !== $offer->status || ! self::is_seller( $offer, $user_id ) ) {
			return false;
		}
		if ( KMAE_Deal::is_locked( (int) $offer->listing_id ) ) {
			return false;
		}
		if ( self::count_user_counters( $offer->id, $user_id ) >= KMAE_MAX_COUNTER_ROUNDS ) {
			return false;
		}
		$latest = KMAE_Database::get_latest_counter_offer( $offer->id );
		if ( ! $latest ) {
			return true;
		}
		return (int) $latest->user_id === (int) $offer->offerer_id;
	}

	public static function can_buyer_revise( $offer, $user_id ) {
		if ( KMAE_Offers::STATUS_PENDING !== $offer->status || ! self::is_buyer( $offer, $user_id ) ) {
			return false;
		}
		if ( KMAE_Deal::is_locked( (int) $offer->listing_id ) ) {
			return false;
		}
		if ( self::count_user_counters( $offer->id, $user_id ) >= KMAE_MAX_COUNTER_ROUNDS ) {
			return false;
		}
		$latest = KMAE_Database::get_latest_counter_offer( $offer->id );
		if ( ! $latest ) {
			return false;
		}
		return self::is_seller( $offer, $latest->user_id );
	}

	public static function can_seller_accept( $offer, $user_id ) {
		if ( KMAE_Offers::STATUS_PENDING !== $offer->status || ! self::is_seller( $offer, $user_id ) ) {
			return false;
		}
		if ( KMAE_Deal::is_locked( (int) $offer->listing_id ) ) {
			return false;
		}
		$buyer_ok = KMAE_Deal::assert_buyer_can_lock( (int) $offer->offerer_id, (int) $offer->id );
		return ! is_wp_error( $buyer_ok );
	}

	public static function can_buyer_accept( $offer, $user_id ) {
		if ( KMAE_Offers::STATUS_PENDING !== $offer->status || ! self::is_buyer( $offer, $user_id ) ) {
			return false;
		}
		if ( KMAE_Deal::is_locked( (int) $offer->listing_id ) ) {
			return false;
		}
		$buyer_ok = KMAE_Deal::assert_buyer_can_lock( (int) $user_id, (int) $offer->id );
		if ( is_wp_error( $buyer_ok ) ) {
			return false;
		}
		$latest = KMAE_Database::get_latest_counter_offer( $offer->id );
		return $latest && self::is_seller( $offer, $latest->user_id );
	}

	public static function submit_seller_counter( $offer_id, $seller_id, $template_code, $cash_amount = null ) {
		global $wpdb;

		$offer = KMAE_Database::get_offer( $offer_id );
		if ( ! $offer ) {
			return new WP_Error( 'invalid_offer', __( 'Érvénytelen ajánlat.', 'ki-mit-adna-erte' ) );
		}

		if ( ! self::can_seller_counter( $offer, $seller_id ) ) {
			return new WP_Error( 'cannot_counter', __( 'Most nem küldhetsz ellenajánlatot.', 'ki-mit-adna-erte' ) );
		}

		$templates = KMAE_Taxonomies::counter_templates();
		if ( ! isset( $templates[ $template_code ] ) ) {
			return new WP_Error( 'invalid_template', __( 'Érvénytelen ellenajánlat típus.', 'ki-mit-adna-erte' ) );
		}

		$round = self::count_user_counters( $offer_id, $seller_id ) + 1;

		$inserted = $wpdb->insert(
			KMAE_Database::table( 'counter_offers' ),
			array(
				'offer_id'      => $offer_id,
				'user_id'       => $seller_id,
				'template_code' => $template_code,
				'cash_amount'   => $cash_amount > 0 ? $cash_amount : null,
				'status'        => 'pending',
				'round_number'  => $round,
			),
			array( '%d', '%d', '%s', '%f', '%s', '%d' )
		);

		if ( false === $inserted ) {
			return new WP_Error( 'db_error', __( 'Az ellenajánlat mentése sikertelen.', 'ki-mit-adna-erte' ) );
		}

		$wpdb->update(
			KMAE_Database::table( 'offers' ),
			array( 'counter_rounds' => (int) $offer->counter_rounds + 1 ),
			array( 'id' => $offer_id ),
			array( '%d' ),
			array( '%d' )
		);

		do_action( 'kmae_new_counter_offer', $wpdb->insert_id, $offer_id, $seller_id );

		return $wpdb->insert_id;
	}

	public static function submit_buyer_revision( $offer_id, $buyer_id, $new_amount ) {
		global $wpdb;

		$offer = KMAE_Database::get_offer( $offer_id );
		if ( ! $offer ) {
			return new WP_Error( 'invalid_offer', __( 'Érvénytelen ajánlat.', 'ki-mit-adna-erte' ) );
		}

		if ( ! self::can_buyer_revise( $offer, $buyer_id ) ) {
			return new WP_Error( 'cannot_revise', __( 'Most nem módosíthatod az ajánlatot.', 'ki-mit-adna-erte' ) );
		}

		if ( $new_amount <= 0 ) {
			return new WP_Error( 'invalid_amount', __( 'Érvénytelen összeg.', 'ki-mit-adna-erte' ) );
		}

		$round = self::count_user_counters( $offer_id, $buyer_id ) + 1;

		$wpdb->update(
			KMAE_Database::table( 'offers' ),
			array(
				'cash_amount'    => $new_amount,
				'counter_rounds' => (int) $offer->counter_rounds + 1,
			),
			array( 'id' => $offer_id ),
			array( '%f', '%d' ),
			array( '%d' )
		);

		$inserted = $wpdb->insert(
			KMAE_Database::table( 'counter_offers' ),
			array(
				'offer_id'      => $offer_id,
				'user_id'       => $buyer_id,
				'template_code' => self::TEMPLATE_BUYER_REVISION,
				'cash_amount'   => $new_amount,
				'status'        => 'pending',
				'round_number'  => $round,
			),
			array( '%d', '%d', '%s', '%f', '%s', '%d' )
		);

		if ( false === $inserted ) {
			return new WP_Error( 'db_error', __( 'Az ajánlat módosítása sikertelen.', 'ki-mit-adna-erte' ) );
		}

		do_action( 'kmae_buyer_revised_offer', $offer_id, $buyer_id, $new_amount );

		return $offer_id;
	}

	public static function accept_offer( $offer_id, $user_id ) {
		global $wpdb;

		$offer = KMAE_Database::get_offer( $offer_id );
		if ( ! $offer || KMAE_Offers::STATUS_PENDING !== $offer->status ) {
			return new WP_Error( 'invalid_offer', __( 'Ez az ajánlat már nem elfogadható.', 'ki-mit-adna-erte' ) );
		}

		$is_seller = self::is_seller( $offer, $user_id );
		$is_buyer  = self::is_buyer( $offer, $user_id );

		if ( ! $is_seller && ! $is_buyer ) {
			return new WP_Error( 'forbidden', __( 'Nincs jogosultságod ehhez.', 'ki-mit-adna-erte' ) );
		}

		if ( $is_buyer && ! self::can_buyer_accept( $offer, $user_id ) ) {
			return new WP_Error( 'cannot_accept', __( 'Most nem fogadhatod el.', 'ki-mit-adna-erte' ) );
		}

		if ( KMAE_Deal::is_locked( (int) $offer->listing_id ) ) {
			return new WP_Error(
				'deal_locked',
				__( 'Ezen a hirdetésen már „Áll az alku” — várj a megtekintés eredményére.', 'ki-mit-adna-erte' )
			);
		}

		$buyer_id   = (int) $offer->offerer_id;
		$buyer_lock = KMAE_Deal::assert_buyer_can_lock( $buyer_id, (int) $offer_id );
		if ( is_wp_error( $buyer_lock ) ) {
			return $buyer_lock;
		}

		$final_amount = $offer->cash_amount;
		if ( $is_buyer ) {
			$latest = KMAE_Database::get_latest_counter_offer( $offer_id );
			if ( $latest && $latest->cash_amount > 0 ) {
				$final_amount = $latest->cash_amount;
			}
		}

		$wpdb->update(
			KMAE_Database::table( 'offers' ),
			array(
				'status'      => KMAE_Offers::STATUS_ACCEPTED,
				'cash_amount' => $final_amount,
			),
			array( 'id' => $offer_id ),
			array( '%s', '%f' ),
			array( '%d' )
		);

		// Soft lock: do not reject others yet — wait for viewing outcome („Áll az alku”).
		KMAE_Contact::unlock_accepted_deal( $offer_id, self::get_listing_seller_id( $offer ), (int) $offer->offerer_id );

		do_action( 'kmae_offer_accepted', $offer_id, $user_id );

		return $offer_id;
	}

	/**
	 * Reject all other pending offers on the same listing.
	 *
	 * @param bool $fire_hooks When false, skip kmae_offer_rejected (e.g. sold path uses listing_closed).
	 */
	public static function reject_other_offers( $listing_id, $accepted_offer_id, $fire_hooks = true ) {
		$offers = KMAE_Database::get_offers_for_listing( $listing_id );

		foreach ( $offers as $other ) {
			if ( (int) $other->id === (int) $accepted_offer_id ) {
				continue;
			}
			if ( KMAE_Offers::STATUS_PENDING !== $other->status ) {
				continue;
			}

			KMAE_Database::update_offer_status( $other->id, KMAE_Offers::STATUS_REJECTED );
			if ( $fire_hooks ) {
				do_action( 'kmae_offer_rejected', $other->id, $listing_id, $accepted_offer_id );
			}
		}
	}

	public static function format_counter_message( $counter ) {
		if ( self::TEMPLATE_BUYER_REVISION === $counter->template_code ) {
			return sprintf(
				/* translators: %s: cash amount */
				__( 'Új ajánlat: %s', 'ki-mit-adna-erte' ),
				KMAE_Offers::format_cash( $counter->cash_amount )
			);
		}

		$templates = KMAE_Taxonomies::counter_templates();
		$message   = $templates[ $counter->template_code ] ?? $counter->template_code;

		if ( $counter->cash_amount > 0 ) {
			$message .= ' — ' . KMAE_Offers::format_cash( $counter->cash_amount );
		}

		return $message;
	}

	public static function get_negotiation_summary( $offer ) {
		$counters = KMAE_Database::get_counter_offers( $offer->id );
		$latest   = ! empty( $counters ) ? end( $counters ) : null;

		return array(
			'counters'           => $counters,
			'latest'             => $latest,
			'seller_rounds'      => self::count_user_counters( $offer->id, self::get_listing_seller_id( $offer ) ),
			'buyer_rounds'       => self::count_user_counters( $offer->id, $offer->offerer_id ),
			'rounds_left_seller' => max( 0, KMAE_MAX_COUNTER_ROUNDS - self::count_user_counters( $offer->id, self::get_listing_seller_id( $offer ) ) ),
			'rounds_left_buyer'  => max( 0, KMAE_MAX_COUNTER_ROUNDS - self::count_user_counters( $offer->id, $offer->offerer_id ) ),
		);
	}

	public static function user_can_access( $offer, $user_id ) {
		if ( ! $offer || ! $user_id ) {
			return false;
		}
		return self::is_seller( $offer, $user_id ) || self::is_buyer( $offer, $user_id );
	}

	/**
	 * Chat timeline: initial offer + counter messages.
	 *
	 * @return object[]
	 */
	public static function get_chat_messages( $offer ) {
		$messages = array();

		$messages[] = (object) array(
			'user_id'    => (int) $offer->offerer_id,
			'text'       => sprintf(
				/* translators: %s: offer summary */
				__( 'Ajánlatot tett: %s', 'ki-mit-adna-erte' ),
				KMAE_Offers::get_offer_summary( $offer )
			),
			'created_at' => $offer->created_at,
			'kind'       => 'offer',
			'source'     => 'offer',
			'source_id'  => (int) $offer->id,
		);

		foreach ( KMAE_Database::get_counter_offers( $offer->id ) as $counter ) {
			$messages[] = (object) array(
				'user_id'    => (int) $counter->user_id,
				'text'       => self::format_counter_message( $counter ),
				'created_at' => $counter->created_at,
				'kind'       => self::TEMPLATE_BUYER_REVISION === $counter->template_code ? 'revision' : 'counter',
				'source'     => 'counter',
				'source_id'  => (int) $counter->id,
			);
		}

		return $messages;
	}

	/**
	 * Which timeline message can be acted on, and what actions are available.
	 *
	 * @return array{
	 *   active_index: int,
	 *   is_waiting: bool,
	 *   can_accept: bool,
	 *   can_counter: bool,
	 *   can_revise: bool,
	 *   negotiation: array
	 * }
	 */
	public static function get_chat_action_state( $offer, $user_id ) {
		$negotiation  = self::get_negotiation_summary( $offer );
		$messages     = self::get_chat_messages( $offer );
		$can_accept   = self::is_seller( $offer, $user_id )
			? self::can_seller_accept( $offer, $user_id )
			: self::can_buyer_accept( $offer, $user_id );
		$can_counter  = self::can_seller_counter( $offer, $user_id );
		$can_revise   = self::can_buyer_revise( $offer, $user_id );
		$active_index = -1;
		$is_waiting   = false;

		if ( KMAE_Offers::STATUS_PENDING !== $offer->status || empty( $messages ) ) {
			return compact( 'active_index', 'is_waiting', 'can_accept', 'can_counter', 'can_revise', 'negotiation' );
		}

		$last_index = count( $messages ) - 1;
		$last_msg   = $messages[ $last_index ];

		if ( (int) $last_msg->user_id === (int) $user_id ) {
			$is_waiting = true;
		} else {
			for ( $i = $last_index; $i >= 0; $i-- ) {
				if ( (int) $messages[ $i ]->user_id !== (int) $user_id ) {
					$active_index = $i;
					break;
				}
			}
		}

		if ( $active_index >= 0 && ! $can_accept && ! $can_counter && ! $can_revise ) {
			$active_index = -1;
			$is_waiting   = true;
		}

		return compact( 'active_index', 'is_waiting', 'can_accept', 'can_counter', 'can_revise', 'negotiation' );
	}

	public static function get_current_amount_summary( $offer ) {
		$negotiation = self::get_negotiation_summary( $offer );
		if ( ! empty( $negotiation['latest'] ) && $negotiation['latest']->cash_amount > 0 ) {
			return KMAE_Offers::format_cash( $negotiation['latest']->cash_amount );
		}

		return KMAE_Offers::get_offer_summary( $offer );
	}

	public static function get_last_chat_preview( $offer ) {
		$messages = self::get_chat_messages( $offer );
		if ( empty( $messages ) ) {
			return '';
		}
		return end( $messages )->text;
	}

	public static function get_chat_kind_label( $kind ) {
		$labels = array(
			'offer'    => __( 'Ajánlat', 'ki-mit-adna-erte' ),
			'counter'  => __( 'Ellenajánlat', 'ki-mit-adna-erte' ),
			'revision' => __( 'Módosítás', 'ki-mit-adna-erte' ),
		);
		return $labels[ $kind ] ?? __( 'Üzenet', 'ki-mit-adna-erte' );
	}

	public static function get_other_party_name( $offer, $viewer_id ) {
		if ( self::is_seller( $offer, $viewer_id ) ) {
			return KMAE_Offers::get_offerer_display_name( $offer->offerer_id );
		}
		$seller_id = self::get_listing_seller_id( $offer );
		if ( class_exists( 'KMAE_Company' ) && KMAE_Auth::is_company( $seller_id ) ) {
			return KMAE_Company::get_company_name( $seller_id );
		}
		$seller = get_userdata( $seller_id );
		return $seller ? $seller->display_name : __( 'Eladó', 'ki-mit-adna-erte' );
	}

	/**
	 * Popup copy for remaining negotiation rounds.
	 */
	public static function get_rounds_warning_message( $rounds_left ) {
		$rounds_left = (int) $rounds_left;
		if ( $rounds_left <= 1 ) {
			return __( 'Vigyázz! Ez az utolsó lehetőséged — jól gondold át! Utána a rendszer leállítja az alkudozást.', 'ki-mit-adna-erte' );
		}

		return sprintf(
			/* translators: %d: remaining negotiation rounds */
			__( 'Vigyázz! Csak %d alkudozási lehetőséged van — komolyan vedd. Ha elfogynak, a rendszer leállítja az alkudozást.', 'ki-mit-adna-erte' ),
			$rounds_left
		);
	}

	/**
	 * Used / remaining round counts for the progress meter.
	 *
	 * @return array{rounds_left:int,rounds_used:int,max:int}
	 */
	public static function get_rounds_meter( $rounds_left, $max = null ) {
		$max         = null === $max ? KMAE_MAX_COUNTER_ROUNDS : (int) $max;
		$rounds_left = max( 0, (int) $rounds_left );
		$rounds_used = max( 0, $max - $rounds_left );

		return array(
			'rounds_left' => $rounds_left,
			'rounds_used' => $rounds_used,
			'max'         => $max,
		);
	}

	public static function get_user_rounds_left( $offer, $user_id ) {
		$negotiation = self::get_negotiation_summary( $offer );
		if ( self::is_seller( $offer, $user_id ) ) {
			return (int) $negotiation['rounds_left_seller'];
		}
		if ( self::is_buyer( $offer, $user_id ) ) {
			return (int) $negotiation['rounds_left_buyer'];
		}
		return 0;
	}
}
