<?php
/**
 * Contact unlock after accepted offer (monetization gate).
 *
 * @package KMAE
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class KMAE_Contact {

	public static function is_unlocked( $offer_id, $user_id ) {
		if ( KMAE_Premium::is_active( $user_id ) ) {
			return true;
		}
		return KMAE_Database::has_contact_unlock( $offer_id, $user_id );
	}

	public static function can_view( $offer, $viewer_id ) {
		if ( KMAE_Offers::STATUS_ACCEPTED !== $offer->status ) {
			return false;
		}
		$listing   = get_post( $offer->listing_id );
		$seller_id = $listing ? (int) $listing->post_author : 0;
		$buyer_id  = (int) $offer->offerer_id;

		if ( ! in_array( (int) $viewer_id, array( $seller_id, $buyer_id ), true ) ) {
			return false;
		}

		// Elfogadott ajánlatnál mindkét fél azonnal látja a kapcsolatot.
		return true;
	}

	/**
	 * Record contact unlock for both parties (audit trail).
	 */
	public static function unlock_accepted_deal( $offer_id, $seller_id, $buyer_id ) {
		KMAE_Database::create_contact_unlock( $offer_id, $seller_id );
		KMAE_Database::create_contact_unlock( $offer_id, $buyer_id );
	}

	public static function unlock( $offer_id, $user_id ) {
		$offer = KMAE_Database::get_offer( $offer_id );
		if ( ! $offer || KMAE_Offers::STATUS_ACCEPTED !== $offer->status ) {
			return new WP_Error( 'invalid', __( 'Csak elfogadott ajánlatnál oldható fel a kapcsolat.', 'ki-mit-adna-erte' ) );
		}

		if ( KMAE_Premium::is_active( $user_id ) ) {
			KMAE_Database::create_contact_unlock( $offer_id, $user_id );
			return true;
		}

		if ( self::is_unlocked( $offer_id, $user_id ) ) {
			return true;
		}

		if ( ! KMAE_Settings::demo_payments_enabled() ) {
			return new WP_Error( 'payment_required', __( 'Fizetés szükséges — integráció hamarosan.', 'ki-mit-adna-erte' ) );
		}

		KMAE_Database::create_contact_unlock( $offer_id, $user_id );
		return true;
	}

	public static function get_contact_details( $user_id ) {
		$user = get_userdata( $user_id );
		if ( ! $user ) {
			return array();
		}
		$phone = get_user_meta( $user_id, 'kmae_phone', true );
		return array(
			'name'  => $user->display_name ?: $user->user_login,
			'phone' => $phone,
			'email' => $user->user_email,
		);
	}

	public static function get_other_party_id( $offer, $viewer_id ) {
		$listing = get_post( $offer->listing_id );
		if ( ! $listing ) {
			return 0;
		}
		$seller_id = (int) $listing->post_author;
		return (int) $viewer_id === $seller_id ? (int) $offer->offerer_id : $seller_id;
	}
}
