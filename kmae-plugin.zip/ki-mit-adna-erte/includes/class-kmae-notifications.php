<?php
/**
 * Email notifications.
 *
 * @package KMAE
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class KMAE_Notifications {

	public static function init() {
		add_action( 'kmae_new_offer', array( __CLASS__, 'on_new_offer' ), 10, 3 );
		add_action( 'kmae_new_counter_offer', array( __CLASS__, 'on_counter_offer' ), 10, 3 );
		add_action( 'kmae_buyer_revised_offer', array( __CLASS__, 'on_buyer_revision' ), 10, 3 );
		add_action( 'kmae_offer_accepted', array( __CLASS__, 'on_offer_accepted' ), 10, 2 );
		add_action( 'kmae_deal_locked', array( __CLASS__, 'on_deal_locked' ), 10, 2 );
		add_action( 'kmae_deal_failed', array( __CLASS__, 'on_deal_failed' ), 10, 3 );
		add_action( 'kmae_deal_success', array( 'KMAE_Trust', 'on_deal_success' ), 10, 3 );
		add_action( 'kmae_offer_rejected', array( __CLASS__, 'on_offer_rejected' ), 10, 3 );
		add_action( 'kmae_offer_withdrawn', array( __CLASS__, 'on_offer_withdrawn' ), 10, 2 );
	}

	public static function on_new_offer( $offer_id, $listing_id, $offerer_id ) {
		unset( $offerer_id );

		$listing = get_post( $listing_id );
		if ( ! $listing ) {
			return;
		}
		$seller = get_userdata( $listing->post_author );
		$offer  = KMAE_Database::get_offer( $offer_id );
		if ( ! $seller || ! $offer ) {
			return;
		}

		$subject = sprintf(
			/* translators: %s: listing title */
			__( 'Új ajánlat: %s', 'ki-mit-adna-erte' ),
			$listing->post_title
		);
		$body = sprintf(
			__( "Szia!\n\nAjánlatot kaptál a „%1\$s” hirdetésedre.\n\nMegtekintésért nyisd meg a beszélgetést:\n%2\$s\n\n— Albira", 'ki-mit-adna-erte' ),
			$listing->post_title,
			KMAE_Pages::offer_thread_url( $offer_id )
		);
		self::send_offer_email( (int) $listing->post_author, $subject, $body );
	}

	public static function on_counter_offer( $counter_id, $offer_id, $seller_id ) {
		unset( $seller_id );

		$offer   = KMAE_Database::get_offer( $offer_id );
		$counter = KMAE_Database::get_counter_offer( $counter_id );
		if ( ! $offer || ! $counter ) {
			return;
		}
		$listing = get_post( $offer->listing_id );
		if ( ! $listing ) {
			return;
		}

		$subject = sprintf(
			__( 'Ellenajánlat: %s', 'ki-mit-adna-erte' ),
			$listing->post_title
		);
		$body = sprintf(
			__( "Szia!\n\nEllenajánlat érkezett: %1\$s\n\nHirdetés: %2\$s\n\nVálaszolj itt: %3\$s\n\n— Albira", 'ki-mit-adna-erte' ),
			KMAE_Counter_Offers::format_counter_message( $counter ),
			$listing->post_title,
			KMAE_Pages::offer_thread_url( $offer_id )
		);
		self::send_offer_email( (int) $offer->offerer_id, $subject, $body );
	}

	public static function on_buyer_revision( $offer_id, $buyer_id, $new_amount ) {
		unset( $buyer_id );

		$offer   = KMAE_Database::get_offer( $offer_id );
		$listing = $offer ? get_post( $offer->listing_id ) : null;
		if ( ! $offer || ! $listing ) {
			return;
		}

		$subject = sprintf( __( 'Módosított ajánlat: %s', 'ki-mit-adna-erte' ), $listing->post_title );
		$body    = sprintf(
			__( "Szia!\n\nA vevő új összeget ajánlott: %1\$s\n\nHirdetés: %2\$s\n\nMegtekintés: %3\$s\n\n— Albira", 'ki-mit-adna-erte' ),
			KMAE_Offers::format_cash( $new_amount ),
			$listing->post_title,
			KMAE_Pages::offer_thread_url( $offer_id )
		);
		self::send_offer_email( (int) $listing->post_author, $subject, $body );
	}

	public static function on_offer_accepted( $offer_id, $user_id ) {
		unset( $user_id );

		$offer   = KMAE_Database::get_offer( $offer_id );
		$listing = $offer ? get_post( $offer->listing_id ) : null;
		if ( ! $offer || ! $listing ) {
			return;
		}

		$seller_id = (int) $listing->post_author;
		$buyer_id  = (int) $offer->offerer_id;

		// Viewing-phase deal: contacts + meet instruction.
		self::send_viewing_deal_email( $seller_id, $listing, KMAE_Contact::get_contact_details( $buyer_id ), true );
		self::send_viewing_deal_email( $buyer_id, $listing, KMAE_Contact::get_contact_details( $seller_id ), false );
	}

	/**
	 * Soft-hold mail to other pending interest after Áll az alku.
	 *
	 * @param int $offer_id   Locked offer.
	 * @param int $listing_id Listing.
	 */
	public static function on_deal_locked( $offer_id, $listing_id ) {
		$listing = get_post( $listing_id );
		$locked  = KMAE_Database::get_offer( $offer_id );
		if ( ! $listing || ! $locked ) {
			return;
		}

		$offers = KMAE_Database::get_offers_for_listing( $listing_id );
		foreach ( $offers as $offer ) {
			if ( (int) $offer->id === (int) $offer_id ) {
				continue;
			}
			if ( KMAE_Offers::STATUS_PENDING !== $offer->status ) {
				continue;
			}

			$subject = sprintf(
				/* translators: %s: listing title */
				__( 'Áll az alku — várakozás: %s', 'ki-mit-adna-erte' ),
				$listing->post_title
			);
			$body = sprintf(
				__( "Szia!\n\nEgy másik érdeklődővel sikerült megállapodni, aki elmegy megnézni az autót („%1\$s”). Ha sikerül az üzlet, sajnos tárgytalan az ajánlatod. Ha nem sikerül, folytatjuk a tárgyalást.\n\n— Albira", 'ki-mit-adna-erte' ),
				$listing->post_title
			);
			self::send_offer_email( (int) $offer->offerer_id, $subject, $body );
		}

		// Company buyer: soft-hold sellers of other cars they are negotiating.
		$buyer_id = (int) $locked->offerer_id;
		if ( KMAE_Auth::is_company( $buyer_id ) ) {
			self::notify_buyer_other_sellers_hold( $buyer_id, $offer_id );
		}
	}

	/**
	 * Company buyer locked one car — tell other pending sellers they may become moot.
	 *
	 * @param int $buyer_id        Buyer.
	 * @param int $locked_offer_id Locked offer.
	 */
	public static function notify_buyer_other_sellers_hold( $buyer_id, $locked_offer_id ) {
		$others = KMAE_Deal::get_buyer_other_pending_offers( $buyer_id, $locked_offer_id );
		foreach ( $others as $offer ) {
			$other_listing = get_post( $offer->listing_id );
			if ( ! $other_listing ) {
				continue;
			}

			$subject = sprintf(
				/* translators: %s: listing title */
				__( 'Várakozás — másik autó megtekintése: %s', 'ki-mit-adna-erte' ),
				$other_listing->post_title
			);
			$body = sprintf(
				__( "Szia!\n\nEgy másik autóval sikerült megállapodnom, elmegyek megnézni. Ha sikerül az üzlet, sajnos tárgytalan az ajánlatom a „%1\$s” hirdetésre. Ha nem sikerül, folytatjuk a tárgyalást. Hamarosan jelentkezem.\n\n— Albira", 'ki-mit-adna-erte' ),
				$other_listing->post_title
			);
			self::send_offer_email( (int) $other_listing->post_author, $subject, $body );
		}
	}

	/**
	 * Viewing failed — notify other pending buyers.
	 *
	 * @param int $offer_id   Offer that failed viewing.
	 * @param int $listing_id Listing.
	 * @param int $user_id    Actor.
	 */
	public static function on_deal_failed( $offer_id, $listing_id, $user_id ) {
		unset( $user_id );

		$listing = get_post( $listing_id );
		$offer   = KMAE_Database::get_offer( $offer_id );
		if ( ! $listing || ! $offer ) {
			return;
		}

		// Parties on the failed deal.
		$subject_parties = sprintf(
			__( 'A találkozó nem vezetett üzlethez: %s', 'ki-mit-adna-erte' ),
			$listing->post_title
		);
		$body_parties = sprintf(
			__( "Szia!\n\nA megtekintés után nem született üzlet a „%1\$s” hirdetésnél. Az „Áll az alku” feloldódott — a tárgyalást folytathatjátok.\n\nBeszélgetés: %2\$s\n\n— Albira", 'ki-mit-adna-erte' ),
			$listing->post_title,
			KMAE_Pages::offer_thread_url( $offer_id )
		);
		self::send_offer_email( (int) $listing->post_author, $subject_parties, $body_parties );
		self::send_offer_email( (int) $offer->offerer_id, $subject_parties, $body_parties );

		$offers = KMAE_Database::get_offers_for_listing( $listing_id );
		foreach ( $offers as $other ) {
			if ( (int) $other->id === (int) $offer_id ) {
				continue;
			}
			if ( KMAE_Offers::STATUS_PENDING !== $other->status ) {
				continue;
			}

			$subject = sprintf(
				__( 'Újra elérhető: %s', 'ki-mit-adna-erte' ),
				$listing->post_title
			);
			$body = sprintf(
				__( "Szia!\n\nA találkozó nem vezetett üzlethez. A jármű („%1\$s”) továbbra is elérhető, a tárgyalást folytathatjátok.\n\nBeszélgetés: %2\$s\n\n— Albira", 'ki-mit-adna-erte' ),
				$listing->post_title,
				KMAE_Pages::offer_thread_url( $other->id )
			);
			self::send_offer_email( (int) $other->offerer_id, $subject, $body );
		}

		// Company buyer: tell other sellers talks can continue.
		$buyer_id = (int) $offer->offerer_id;
		if ( KMAE_Auth::is_company( $buyer_id ) ) {
			self::notify_buyer_other_sellers_resume( $buyer_id, $offer_id );
		}
	}

	/**
	 * After failed viewing: company buyer's other pending sellers can continue.
	 *
	 * @param int $buyer_id        Buyer.
	 * @param int $failed_offer_id Failed offer.
	 */
	public static function notify_buyer_other_sellers_resume( $buyer_id, $failed_offer_id ) {
		$others = KMAE_Deal::get_buyer_other_pending_offers( $buyer_id, $failed_offer_id );
		foreach ( $others as $offer ) {
			$other_listing = get_post( $offer->listing_id );
			if ( ! $other_listing ) {
				continue;
			}

			$subject = sprintf(
				/* translators: %s: listing title */
				__( 'Folytathatjuk: %s', 'ki-mit-adna-erte' ),
				$other_listing->post_title
			);
			$body = sprintf(
				__( "Szia!\n\nA korábbi ajánlatom a „%1\$s” hirdetésre továbbra is érvényes — folytathatjuk a tárgyalást.\n\nBeszélgetés: %2\$s\n\n— Albira", 'ki-mit-adna-erte' ),
				$other_listing->post_title,
				KMAE_Pages::offer_thread_url( (int) $offer->id )
			);
			self::send_offer_email( (int) $other_listing->post_author, $subject, $body );
		}
	}

	/**
	 * @param int    $recipient_id User.
	 * @param WP_Post $listing Listing.
	 * @param array  $contact Contact details.
	 * @param bool   $is_seller Recipient is seller.
	 */
	private static function send_viewing_deal_email( $recipient_id, $listing, $contact, $is_seller ) {
		if ( empty( $contact ) ) {
			return;
		}

		$subject = sprintf(
			/* translators: %s: listing title */
			__( 'Áll az alku — megtekintés: %s', 'ki-mit-adna-erte' ),
			$listing->post_title
		);

		$phone_line = ! empty( $contact['phone'] )
			? sprintf( __( 'Telefon: %s', 'ki-mit-adna-erte' ), $contact['phone'] )
			: __( 'Telefon: (még nincs megadva a profilban)', 'ki-mit-adna-erte' );

		$role_line = $is_seller
			? __( 'Egyeztessetek találkozót. Utána jelezd a rendszerben: sikerült-e az üzlet.', 'ki-mit-adna-erte' )
			: __( 'Egyeztessetek találkozót a megtekintéshez. Az eladó (vagy te) visszajelz a rendszerben a találkozó után.', 'ki-mit-adna-erte' );

		$body = sprintf(
			__( "Szia!\n\nÁll az alku a „%1\$s” hirdetésnél — a felek elmegynek megnézni az autót.\n\n%2\$s\n\nMásik fél elérhetősége:\nNév: %3\$s\n%4\$s\nE-mail: %5\$s\n\n— Albira", 'ki-mit-adna-erte' ),
			$listing->post_title,
			$role_line,
			$contact['name'],
			$phone_line,
			$contact['email']
		);

		self::send_offer_email( $recipient_id, $subject, $body );
	}

	public static function on_offer_rejected( $offer_id, $listing_id, $accepted_offer_id ) {
		unset( $accepted_offer_id );

		$offer   = KMAE_Database::get_offer( $offer_id );
		$listing = get_post( $listing_id );
		if ( ! $offer || ! $listing ) {
			return;
		}

		$subject = sprintf(
			/* translators: %s: listing title */
			__( 'Ajánlat elutasítva: %s', 'ki-mit-adna-erte' ),
			$listing->post_title
		);
		$body = sprintf(
			__( "Szia!\n\nA „%1\$s” hirdetésre adott ajánlatod elutasításra került, mert az eladó másik ajánlatot fogadott el.\n\nKöszönjük az érdeklődésed — nézz körül más hirdetéseink között!\n\n%2\$s\n\n— Albira", 'ki-mit-adna-erte' ),
			$listing->post_title,
			home_url( '/hirdetesek/' )
		);
		self::send_offer_email( (int) $offer->offerer_id, $subject, $body );
	}

	public static function on_offer_withdrawn( $offer_id, $user_id ) {
		unset( $user_id );

		$offer   = KMAE_Database::get_offer( $offer_id );
		$listing = $offer ? get_post( $offer->listing_id ) : null;
		if ( ! $offer || ! $listing ) {
			return;
		}

		$buyer_name = KMAE_Offers::get_offerer_display_name( $offer->offerer_id );
		$subject    = sprintf(
			/* translators: %s: listing title */
			__( 'Ajánlat visszavonva: %s', 'ki-mit-adna-erte' ),
			$listing->post_title
		);
		$body       = sprintf(
			__( "Szia!\n\n%1\$s visszavonta a „%2\$s” hirdetésedre adott ajánlatát — meggondolta magát.\n\nAz alkudozás ezzel lezárult.\n\n— Albira", 'ki-mit-adna-erte' ),
			$buyer_name,
			$listing->post_title
		);
		self::send_offer_email( (int) $listing->post_author, $subject, $body );
	}

	/**
	 * Notify everyone who sent an offer before the listing is removed.
	 *
	 * @param array<object> $offers
	 */
	public static function on_listing_deleted( $listing_id, $listing, $offers ) {
		unset( $listing_id );

		if ( ! $listing || empty( $offers ) ) {
			return;
		}

		$notified = array();
		foreach ( $offers as $offer ) {
			$user_id = (int) $offer->offerer_id;
			if ( isset( $notified[ $user_id ] ) ) {
				continue;
			}
			$notified[ $user_id ] = true;

			$subject = sprintf(
				/* translators: %s: listing title */
				__( 'Hirdetés törölve: %s', 'ki-mit-adna-erte' ),
				$listing->post_title
			);
			$body    = sprintf(
				__( "Szia!\n\nSajnáljuk — az eladó törölte a „%1\$s” hirdetést, amire ajánlatot adtál. Az alkudozás ezzel véget ért.\n\nNézz körül más hirdetéseink között:\n%2\$s\n\n— Albira", 'ki-mit-adna-erte' ),
				$listing->post_title,
				home_url( '/hirdetesek/' )
			);
			self::send_offer_email( $user_id, $subject, $body );
		}
	}

	private static function send_deal_email( $recipient_id, $listing, $contact ) {
		if ( empty( $contact ) ) {
			return;
		}

		$subject = sprintf(
			/* translators: %s: listing title */
			__( 'Ajánlat elfogadva — elérhetőségek: %s', 'ki-mit-adna-erte' ),
			$listing->post_title
		);

		$phone_line = ! empty( $contact['phone'] )
			? sprintf( __( 'Telefon: %s', 'ki-mit-adna-erte' ), $contact['phone'] )
			: __( 'Telefon: (még nincs megadva a profilban)', 'ki-mit-adna-erte' );

		$body = sprintf(
			__( "Szia!\n\nAz ajánlat elfogadva! Íme a másik fél elérhetősége:\n\nNév: %1\$s\n%2\$s\nE-mail: %3\$s\n\nHirdetés: %4\$s\n\n— Albira", 'ki-mit-adna-erte' ),
			$contact['name'],
			$phone_line,
			$contact['email'],
			$listing->post_title
		);

		self::send_offer_email( $recipient_id, $subject, $body );
	}

	public static function listing_closed( $listing_id ) {
		$listing = get_post( $listing_id );
		if ( ! $listing ) {
			return;
		}

		$offers   = KMAE_Database::get_offers_for_listing( $listing_id );
		$notified = array();

		foreach ( $offers as $offer ) {
			$user_id = (int) $offer->offerer_id;
			if ( isset( $notified[ $user_id ] ) ) {
				continue;
			}
			$notified[ $user_id ] = true;

			$subject = sprintf( __( 'A termék elkelt: %s', 'ki-mit-adna-erte' ), $listing->post_title );
			$body    = sprintf(
				__( "Szia!\n\nA „%1\$s” hirdetés lezárult — az üzlet megszületett.\n\nKöszönjük az ajánlatod!\n\n— Albira", 'ki-mit-adna-erte' ),
				$listing->post_title
			);
			self::send_offer_email( $user_id, $subject, $body );
		}
	}

	/**
	 * Ask user to rate the other party after a successful deal.
	 *
	 * @param int     $user_id User.
	 * @param int     $offer_id Offer.
	 * @param WP_Post $listing Listing.
	 */
	public static function request_rating( $user_id, $offer_id, $listing ) {
		$subject = sprintf(
			/* translators: %s: listing title */
			__( 'Értékeld a másik felet: %s', 'ki-mit-adna-erte' ),
			$listing->post_title
		);
		$body = sprintf(
			__( "Szia!\n\nAz üzlet lezárult a „%1\$s” hirdetésnél. Kérjük, értékeld a másik felet — ebből épül a bizalmi szám.\n\nÉrtékelés: %2\$s\n\n— Albira", 'ki-mit-adna-erte' ),
			$listing->post_title,
			KMAE_Trust::rate_url( $offer_id )
		);
		self::send_offer_email( (int) $user_id, $subject, $body );
	}

	/**
	 * Tip email to buyer.
	 *
	 * @param int    $offer_id Offer.
	 * @param float  $amount   Tip amount.
	 * @param string $message  Optional note.
	 */
	public static function tip_received( $offer_id, $amount, $message = '' ) {
		$offer   = KMAE_Database::get_offer( $offer_id );
		$listing = $offer ? get_post( $offer->listing_id ) : null;
		if ( ! $offer || ! $listing ) {
			return;
		}

		$buyer_id = (int) $offer->offerer_id;
		$subject  = sprintf(
			/* translators: %s: listing title */
			__( 'Borravalót kaptál: %s', 'ki-mit-adna-erte' ),
			$listing->post_title
		);
		$body = sprintf(
			__( "Szia!\n\nSikeres üzlet után borravalót kaptál a „%1\$s” hirdetéshez.\nÖsszeg: %2\$s\n", 'ki-mit-adna-erte' ),
			$listing->post_title,
			KMAE_Offers::format_cash( $amount )
		);
		if ( $message ) {
			$body .= "\n" . __( 'Üzenet:', 'ki-mit-adna-erte' ) . ' ' . $message . "\n";
		}
		$body .= "\n— Albira";
		self::send_offer_email( $buyer_id, $subject, $body );
	}

	/**
	 * Buyer bought another car — notify seller on withdrawn talks.
	 *
	 * @param int $offer_id Withdrawn offer.
	 */
	public static function buyer_found_other_car( $offer_id ) {
		$offer   = KMAE_Database::get_offer( $offer_id );
		$listing = $offer ? get_post( $offer->listing_id ) : null;
		if ( ! $offer || ! $listing ) {
			return;
		}

		$subject = sprintf(
			/* translators: %s: listing title */
			__( 'Ajánlat tárgytalan: %s', 'ki-mit-adna-erte' ),
			$listing->post_title
		);
		$body = sprintf(
			__( "Szia!\n\nSajnálom, sikerült másik autóval megállapodnom, ezért az ajánlatom a „%1\$s” hirdetésre tárgytalan.\n\nKöszönöm a tárgyalást!\n\n— Albira", 'ki-mit-adna-erte' ),
			$listing->post_title
		);
		self::send_offer_email( (int) $listing->post_author, $subject, $body );
	}

	/**
	 * Company seller owes 1% after successful sale.
	 *
	 * @param int   $offer_id Offer.
	 * @param float $fee      Fee amount.
	 */
	public static function company_fee_due( $offer_id, $fee ) {
		$offer   = KMAE_Database::get_offer( $offer_id );
		$listing = $offer ? get_post( $offer->listing_id ) : null;
		if ( ! $offer || ! $listing ) {
			return;
		}

		$subject = sprintf(
			/* translators: %s: listing title */
			__( 'Albira díj (1%%): %s', 'ki-mit-adna-erte' ),
			$listing->post_title
		);
		$body = sprintf(
			__( "Szia!\n\nSikeres eladás a „%1\$s” hirdetésnél.\nEladási összeg: %2\$s\nAlbira díj (1%%): %3\$s\n\nA díjat a profilodon tudod rendezni.\nProfil: %4\$s\n\n— Albira", 'ki-mit-adna-erte' ),
			$listing->post_title,
			KMAE_Offers::format_cash( (float) $offer->cash_amount ),
			KMAE_Company::format_fee( $fee ),
			home_url( '/profil/' )
		);
		self::send_offer_email( (int) $listing->post_author, $subject, $body );
	}

	private static function send_offer_email( $user_id, $subject, $body ) {
		if ( ! KMAE_Auth::wants_offer_emails( $user_id ) ) {
			return false;
		}

		$user = get_userdata( $user_id );
		if ( ! $user ) {
			return false;
		}

		return KMAE_Brand::send_mail( $user->user_email, $subject, $body );
	}
}
