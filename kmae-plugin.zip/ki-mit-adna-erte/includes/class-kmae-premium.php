<?php
/**
 * Super Premium / Szupertag subscription + featured boost helpers.
 *
 * @package KMAE
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class KMAE_Premium {

	const META_DETAILING_MONTH = 'kmae_detailing_claim_month';

	public static function is_active( $user_id ) {
		$row = KMAE_Database::get_premium( $user_id );
		if ( ! $row || 'active' !== $row->status ) {
			return false;
		}
		if ( $row->expires_at && strtotime( $row->expires_at ) < time() ) {
			return false;
		}
		return true;
	}

	public static function activate( $user_id, $days = 30 ) {
		$expires = gmdate( 'Y-m-d H:i:s', time() + ( $days * DAY_IN_SECONDS ) );
		$result  = KMAE_Database::set_premium( $user_id, 'active', $expires );
		self::feature_all_active_listings( $user_id );
		return $result;
	}

	public static function activate_demo( $user_id ) {
		if ( ! KMAE_Settings::demo_payments_enabled() ) {
			return new WP_Error( 'payment_required', __( 'Szupertag aktiválás — fizetés hamarosan.', 'ki-mit-adna-erte' ) );
		}
		self::activate( $user_id, 30 );
		return true;
	}

	/**
	 * Feature every active listing of a Szupertag member.
	 *
	 * @param int $user_id User.
	 * @param int $days    Featured duration.
	 */
	public static function feature_all_active_listings( $user_id, $days = 30 ) {
		$query = new WP_Query(
			array(
				'post_type'      => 'kmae_listing',
				'author'         => (int) $user_id,
				'posts_per_page' => 100,
				'fields'         => 'ids',
				'post_status'    => 'publish',
				'meta_query'     => array(
					array(
						'key'   => '_kmae_status',
						'value' => KMAE_Meta::STATUS_ACTIVE,
					),
				),
			)
		);
		foreach ( (array) $query->posts as $listing_id ) {
			self::feature_listing( (int) $listing_id, $days );
			update_post_meta( (int) $listing_id, '_kmae_featured_reason', 'supertag' );
		}
	}

	/**
	 * When Szupertag member publishes/activates a listing, auto-feature it.
	 *
	 * @param int $listing_id Listing.
	 */
	public static function maybe_auto_feature_listing( $listing_id ) {
		$listing = get_post( $listing_id );
		if ( ! $listing || 'kmae_listing' !== $listing->post_type ) {
			return;
		}
		if ( ! self::is_active( (int) $listing->post_author ) ) {
			return;
		}
		if ( KMAE_Meta::STATUS_ACTIVE !== KMAE_Meta::get_status( $listing_id ) ) {
			return;
		}
		self::feature_listing( $listing_id, 30 );
		update_post_meta( $listing_id, '_kmae_featured_reason', 'supertag' );
	}

	/**
	 * Monthly detailing benefit available?
	 *
	 * @param int $user_id User.
	 * @return bool
	 */
	public static function can_claim_detailing( $user_id ) {
		if ( ! self::is_active( $user_id ) ) {
			return false;
		}
		$month = gmdate( 'Y-m' );
		return get_user_meta( $user_id, self::META_DETAILING_MONTH, true ) !== $month;
	}

	/**
	 * Claim monthly detailing perk (partner booking is offline for now).
	 *
	 * @param int $user_id User.
	 * @return true|WP_Error
	 */
	public static function claim_detailing( $user_id ) {
		if ( ! self::can_claim_detailing( $user_id ) ) {
			return new WP_Error( 'detailing_unavailable', __( 'Ebben a hónapban már felhasználtad az autókozmetikai kedvezményt, vagy nincs aktív Szupertagod.', 'ki-mit-adna-erte' ) );
		}
		update_user_meta( $user_id, self::META_DETAILING_MONTH, gmdate( 'Y-m' ) );
		return true;
	}

	public static function featured_until( $listing_id ) {
		$until = get_post_meta( $listing_id, '_kmae_featured_until', true );
		return $until && strtotime( $until ) > time() ? $until : false;
	}

	public static function is_featured( $listing_id ) {
		return (bool) self::featured_until( $listing_id );
	}

	public static function feature_listing( $listing_id, $days = 7 ) {
		$until = gmdate( 'Y-m-d H:i:s', time() + ( $days * DAY_IN_SECONDS ) );
		update_post_meta( $listing_id, '_kmae_featured_until', $until );
		update_post_meta( $listing_id, '_kmae_featured', 1 );
		return $until;
	}

	/**
	 * How many times a featured listing should appear in swipe decks.
	 *
	 * @return int
	 */
	public static function featured_browse_weight() {
		return 5;
	}

	/**
	 * Expand featured listings so they show up more often (swipe / decks).
	 *
	 * @param array<int, WP_Post> $listings Listings.
	 * @return array<int, WP_Post>
	 */
	public static function weight_featured_listings( $listings ) {
		$weight = self::featured_browse_weight();
		$out    = array();
		foreach ( (array) $listings as $post ) {
			$times = self::is_featured( $post->ID ) ? $weight : 1;
			for ( $i = 0; $i < $times; $i++ ) {
				$out[] = $post;
			}
		}
		return $out;
	}
}
