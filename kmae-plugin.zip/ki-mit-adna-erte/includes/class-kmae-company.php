<?php
/**
 * Company / dealership seller rules: unlimited listings, 1% success fee.
 *
 * @package KMAE
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class KMAE_Company {

	const FEE_RATE = 0.01;

	const META_COMPANY_NAME    = 'kmae_company_name';
	const META_COMPANY_TAX_ID  = 'kmae_company_tax_id';
	const META_COMPANY_ADDRESS = 'kmae_company_address';

	const STATUS_PENDING = 'pending';
	const STATUS_PAID    = 'paid';
	const STATUS_WAIVED  = 'waived';

	/**
	 * @param int $user_id User.
	 * @return string
	 */
	public static function get_company_name( $user_id ) {
		$name = get_user_meta( $user_id, self::META_COMPANY_NAME, true );
		if ( $name ) {
			return (string) $name;
		}
		$user = get_userdata( $user_id );
		return $user ? (string) $user->display_name : '';
	}

	/**
	 * @param int $user_id User.
	 * @return string
	 */
	public static function get_tax_id( $user_id ) {
		return (string) get_user_meta( $user_id, self::META_COMPANY_TAX_ID, true );
	}

	/**
	 * @param int $user_id User.
	 * @return string
	 */
	public static function get_address( $user_id ) {
		return (string) get_user_meta( $user_id, self::META_COMPANY_ADDRESS, true );
	}

	/**
	 * Public seller label (company name or personal display name).
	 *
	 * @param int $user_id User.
	 * @return string
	 */
	public static function seller_display_name( $user_id ) {
		if ( KMAE_Auth::is_company( $user_id ) ) {
			return self::get_company_name( $user_id );
		}
		$user = get_userdata( $user_id );
		return $user ? (string) $user->display_name : '';
	}

	/**
	 * Save company fields from POST (register / profile).
	 *
	 * @param int   $user_id User.
	 * @param array $data    Keys: company_name, tax_id, address.
	 * @return true|WP_Error
	 */
	public static function save_profile_fields( $user_id, $data ) {
		if ( ! KMAE_Auth::is_company( $user_id ) ) {
			return true;
		}

		$name    = isset( $data['company_name'] ) ? sanitize_text_field( (string) $data['company_name'] ) : '';
		$tax_id  = isset( $data['tax_id'] ) ? sanitize_text_field( (string) $data['tax_id'] ) : '';
		$address = isset( $data['address'] ) ? sanitize_text_field( (string) $data['address'] ) : '';

		if ( '' === $name ) {
			return new WP_Error( 'company_name_required', __( 'Add meg a cégnevet.', 'ki-mit-adna-erte' ) );
		}

		update_user_meta( $user_id, self::META_COMPANY_NAME, $name );
		update_user_meta( $user_id, self::META_COMPANY_TAX_ID, $tax_id );
		update_user_meta( $user_id, self::META_COMPANY_ADDRESS, $address );

		wp_update_user(
			array(
				'ID'           => $user_id,
				'display_name' => $name,
			)
		);

		return true;
	}

	/**
	 * Fee amount for a sold offer (1% of cash).
	 *
	 * @param object $offer Offer row.
	 * @return float
	 */
	public static function calculate_fee_amount( $offer ) {
		$sale = isset( $offer->cash_amount ) ? (float) $offer->cash_amount : 0;
		if ( $sale <= 0 ) {
			return 0.0;
		}
		return round( $sale * self::FEE_RATE, 0 );
	}

	/**
	 * Create pending 1% fee after company sale (idempotent per offer).
	 *
	 * @param int $offer_id Offer.
	 * @param int $listing_id Listing.
	 * @param int $actor_id Who confirmed (unused).
	 */
	public static function on_deal_success( $offer_id, $listing_id, $actor_id = 0 ) {
		unset( $actor_id );
		$offer   = KMAE_Database::get_offer( $offer_id );
		$listing = get_post( $listing_id );
		if ( ! $offer || ! $listing ) {
			return;
		}

		$seller_id = (int) $listing->post_author;
		if ( ! KMAE_Auth::is_company( $seller_id ) ) {
			return;
		}

		if ( self::get_fee_by_offer( $offer_id ) ) {
			return;
		}

		$sale = (float) $offer->cash_amount;
		$fee  = self::calculate_fee_amount( $offer );

		global $wpdb;
		$wpdb->insert(
			KMAE_Database::table( 'seller_fees' ),
			array(
				'offer_id'    => (int) $offer_id,
				'listing_id'  => (int) $listing_id,
				'seller_id'   => $seller_id,
				'sale_amount' => $sale,
				'fee_amount'  => $fee,
				'fee_rate'    => self::FEE_RATE,
				'status'      => self::STATUS_PENDING,
			),
			array( '%d', '%d', '%d', '%f', '%f', '%f', '%s' )
		);

		do_action( 'kmae_company_fee_created', (int) $wpdb->insert_id, $offer_id, $seller_id );
		KMAE_Notifications::company_fee_due( $offer_id, $fee );
	}

	/**
	 * @param int $offer_id Offer.
	 * @return object|null
	 */
	public static function get_fee_by_offer( $offer_id ) {
		global $wpdb;
		return $wpdb->get_row(
			$wpdb->prepare(
				'SELECT * FROM ' . KMAE_Database::table( 'seller_fees' ) . ' WHERE offer_id = %d LIMIT 1',
				(int) $offer_id
			)
		);
	}

	/**
	 * @param int    $seller_id Seller.
	 * @param string $status    Optional filter.
	 * @return array<object>
	 */
	public static function get_fees_for_seller( $seller_id, $status = '' ) {
		global $wpdb;
		$table = KMAE_Database::table( 'seller_fees' );
		if ( $status ) {
			return $wpdb->get_results(
				$wpdb->prepare(
					"SELECT * FROM {$table} WHERE seller_id = %d AND status = %s ORDER BY created_at DESC",
					(int) $seller_id,
					$status
				)
			);
		}
		return $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$table} WHERE seller_id = %d ORDER BY created_at DESC",
				(int) $seller_id
			)
		);
	}

	/**
	 * Demo / mark fee paid.
	 *
	 * @param int $fee_id  Fee row.
	 * @param int $user_id Actor.
	 * @return true|WP_Error
	 */
	public static function mark_paid( $fee_id, $user_id ) {
		global $wpdb;
		$fee = $wpdb->get_row(
			$wpdb->prepare(
				'SELECT * FROM ' . KMAE_Database::table( 'seller_fees' ) . ' WHERE id = %d',
				(int) $fee_id
			)
		);
		if ( ! $fee ) {
			return new WP_Error( 'invalid_fee', __( 'Érvénytelen díj.', 'ki-mit-adna-erte' ) );
		}
		if ( (int) $fee->seller_id !== (int) $user_id && ! current_user_can( 'manage_options' ) ) {
			return new WP_Error( 'forbidden', __( 'Nincs jogosultságod ehhez.', 'ki-mit-adna-erte' ) );
		}
		if ( self::STATUS_PAID === $fee->status ) {
			return true;
		}
		if ( ! KMAE_Settings::demo_payments_enabled() && ! current_user_can( 'manage_options' ) ) {
			return new WP_Error( 'payment_required', __( 'A díjfizetés hamarosan elérhető.', 'ki-mit-adna-erte' ) );
		}

		$wpdb->update(
			KMAE_Database::table( 'seller_fees' ),
			array(
				'status'  => self::STATUS_PAID,
				'paid_at' => current_time( 'mysql' ),
			),
			array( 'id' => (int) $fee_id ),
			array( '%s', '%s' ),
			array( '%d' )
		);

		return true;
	}

	/**
	 * Format HUF for fee notices.
	 *
	 * @param float $amount Amount.
	 * @return string
	 */
	public static function format_fee( $amount ) {
		return number_format( (float) $amount, 0, ',', ' ' ) . ' Ft';
	}
}
