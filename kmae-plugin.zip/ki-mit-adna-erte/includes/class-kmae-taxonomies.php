<?php
/**
 * Taxonomies: category + accepted offer types on listing.
 *
 * @package KMAE
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class KMAE_Taxonomies {

	public function __construct() {
		add_action( 'init', array( $this, 'register' ), 0 );
		add_action( 'init', array( $this, 'maybe_seed_categories' ), 20 );
	}

	public function register() {
		self::register_taxonomy();
	}

	public static function register_taxonomy() {
		register_taxonomy(
			'kmae_category',
			'kmae_listing',
			array(
				'labels'            => array(
					'name'          => __( 'Kategóriák', 'ki-mit-adna-erte' ),
					'singular_name' => __( 'Kategória', 'ki-mit-adna-erte' ),
				),
				'hierarchical'      => true,
				'public'            => true,
				'rewrite'           => array( 'slug' => 'kategoria' ),
				'show_admin_column' => true,
				'show_in_rest'      => true,
			)
		);
	}

	/**
	 * Ensure default categories exist (activation + fallback on init).
	 */
	public function maybe_seed_categories() {
		if ( ! taxonomy_exists( 'kmae_category' ) ) {
			return;
		}

		$existing = get_terms(
			array(
				'taxonomy'   => 'kmae_category',
				'hide_empty' => false,
				'fields'     => 'ids',
			)
		);

		if ( is_wp_error( $existing ) || empty( $existing ) ) {
			self::seed_categories();
		}
	}

	public static function seed_categories() {
		$categories = array(
			'jarmu'       => 'Jármű',
			'ingatlan'    => 'Ingatlan',
			'elektronika' => 'Elektronika',
			'telefon'     => 'Telefon',
			'laptop'      => 'Laptop',
			'gyujtemeny'  => 'Gyűjtemény',
			'otthon'      => 'Otthon',
			'sport'       => 'Sport',
			'ruhazat'     => 'Ruházat',
			'egyeb'       => 'Egyéb',
		);

		foreach ( $categories as $slug => $name ) {
			if ( ! term_exists( $slug, 'kmae_category' ) ) {
				wp_insert_term( $name, 'kmae_category', array( 'slug' => $slug ) );
			}
		}
	}

	/**
	 * Get human-readable offer type labels.
	 */
	public static function offer_type_labels() {
		return array(
			KMAE_OFFER_TYPE_CASH           => __( 'Készpénz', 'ki-mit-adna-erte' ),
			KMAE_OFFER_TYPE_TRADE          => __( 'Csere (1:1)', 'ki-mit-adna-erte' ),
			KMAE_OFFER_TYPE_TRADE_PLUS_CASH => __( 'Csere + ráfizetés', 'ki-mit-adna-erte' ),
			KMAE_OFFER_TYPE_TRADE_IN       => __( 'Beszámítás', 'ki-mit-adna-erte' ),
		);
	}

	/**
	 * Seller-facing descriptions when creating a listing.
	 */
	public static function offer_type_descriptions() {
		if ( KMAE_Vehicle::is_vehicle_launch() ) {
			return array(
				KMAE_OFFER_TYPE_CASH            => __( 'Készpénzes ajánlatokat fogadsz az autódra. Beállíthatsz rejtett minimumot is.', 'ki-mit-adna-erte' ),
				KMAE_OFFER_TYPE_TRADE           => __( 'Autó csere autóra (1:1) — képeket kapsz ajánlatként.', 'ki-mit-adna-erte' ),
				KMAE_OFFER_TYPE_TRADE_PLUS_CASH => __( 'Autó csere autóra + ráfizetés, ha szükséges.', 'ki-mit-adna-erte' ),
				KMAE_OFFER_TYPE_TRADE_IN        => __( 'Másik autó beszámítása — opcionálisan készpénz is jöhet.', 'ki-mit-adna-erte' ),
			);
		}

		return array(
			KMAE_OFFER_TYPE_CASH            => __( 'Készpénzes ajánlatokat fogadsz. Beállíthatsz rejtett minimumot is.', 'ki-mit-adna-erte' ),
			KMAE_OFFER_TYPE_TRADE           => __( 'Csak azonos termék cserélhető — pl. autót autóra. Képeket kapsz ajánlatként.', 'ki-mit-adna-erte' ),
			KMAE_OFFER_TYPE_TRADE_PLUS_CASH => __( 'Azonos termék, pl. autót autóra — és ráfizetés, ha szükséges.', 'ki-mit-adna-erte' ),
			KMAE_OFFER_TYPE_TRADE_IN        => __( 'Kiválaszthatod, milyen termékek érdekelnek — plusz készpénz is lehet.', 'ki-mit-adna-erte' ),
		);
	}

	/**
	 * Buyer-facing hints on the offer form tabs.
	 */
	public static function offer_type_buyer_hints() {
		if ( KMAE_Vehicle::is_vehicle_launch() ) {
			return array(
				KMAE_OFFER_TYPE_CASH            => __( 'Add meg, mennyit ajánlasz készpénzben az autóért.', 'ki-mit-adna-erte' ),
				KMAE_OFFER_TYPE_TRADE           => __( 'Autó cseréje autóra — csak képet küldhetsz (a saját autód).', 'ki-mit-adna-erte' ),
				KMAE_OFFER_TYPE_TRADE_PLUS_CASH => __( 'Autó képe + ráfizetés, ha szükséges.', 'ki-mit-adna-erte' ),
				KMAE_OFFER_TYPE_TRADE_IN        => __( 'Saját autód képe beszámításként — opcionálisan készpénzzel is.', 'ki-mit-adna-erte' ),
			);
		}

		return array(
			KMAE_OFFER_TYPE_CASH            => __( 'Add meg, mennyit ajánlasz készpénzben.', 'ki-mit-adna-erte' ),
			KMAE_OFFER_TYPE_TRADE           => __( 'Azonos típusú termék cseréje — pl. autót autóra. Csak képet küldhetsz, szöveget nem.', 'ki-mit-adna-erte' ),
			KMAE_OFFER_TYPE_TRADE_PLUS_CASH => __( 'Azonos típusú termék képe + ráfizetés, ha szükséges (pl. autó autóra + kp).', 'ki-mit-adna-erte' ),
			KMAE_OFFER_TYPE_TRADE_IN        => __( 'Az eladó által kért kategóriából küldhetsz képes ajánlatot — opcionálisan készpénzzel is.', 'ki-mit-adna-erte' ),
		);
	}

	/**
	 * Counter-offer template labels (seller responses).
	 */
	public static function counter_templates() {
		return array(
			'too_low'           => __( 'Túl kevés, dobj még rá.', 'ki-mit-adna-erte' ),
			'close'             => __( 'Közel jársz.', 'ki-mit-adna-erte' ),
			'not_equivalent'    => __( 'Ez nem egyenértékű.', 'ki-mit-adna-erte' ),
			'better_trade'      => __( 'Drágább cserét keresek.', 'ki-mit-adna-erte' ),
			'more_cash'         => __( 'Több ráfizetéssel érdekel.', 'ki-mit-adna-erte' ),
			'different_item'    => __( 'Másik tárgyat ajánlj.', 'ki-mit-adna-erte' ),
		);
	}
}
