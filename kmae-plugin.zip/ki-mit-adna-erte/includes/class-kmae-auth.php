<?php
/**
 * User registration, login, and profile storage.
 *
 * @package KMAE
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class KMAE_Auth {

	const ACCOUNT_PRIVATE = 'private';
	const ACCOUNT_COMPANY = 'company';

	public static function login_url( $redirect = '' ) {
		$url = class_exists( 'KMAE_Pages' ) ? KMAE_Pages::url( 'belepes' ) : home_url( '/belepes/' );
		if ( $redirect ) {
			$url = add_query_arg( 'redirect_to', rawurlencode( $redirect ), $url );
		}
		return $url;
	}

	public static function register_url() {
		return class_exists( 'KMAE_Pages' ) ? KMAE_Pages::url( 'regisztracio' ) : home_url( '/regisztracio/' );
	}

	/**
	 * Branded lost-password URL.
	 *
	 * @return string
	 */
	public static function lost_password_url() {
		return add_query_arg( 'kmae_view', 'lost', self::login_url() );
	}

	/**
	 * Branded password-reset URL (from email link).
	 *
	 * @param string $key   Reset key.
	 * @param string $login User login.
	 * @return string
	 */
	public static function reset_password_url( $key, $login ) {
		return add_query_arg(
			array(
				'kmae_view' => 'reset',
				'key'       => (string) $key,
				'login'     => (string) $login,
			),
			self::login_url()
		);
	}

	public static function init() {
		add_filter( 'map_meta_cap', array( __CLASS__, 'map_listing_caps' ), 10, 4 );
		add_filter( 'lostpassword_url', array( __CLASS__, 'filter_lostpassword_url' ), 10, 2 );
		add_filter( 'retrieve_password_message', array( __CLASS__, 'filter_reset_message' ), 10, 4 );
		add_action( 'login_init', array( __CLASS__, 'redirect_wp_password_screens' ) );
	}

	/**
	 * Point WP lost-password links to the branded login page.
	 *
	 * @param string $url Lost password URL.
	 * @return string
	 */
	public static function filter_lostpassword_url( $url, $redirect = '' ) {
		return self::lost_password_url();
	}

	/**
	 * Replace default wp-login reset link in the email.
	 *
	 * @param string  $message    Email body.
	 * @param string  $key        Reset key.
	 * @param string  $user_login User login.
	 * @param WP_User $user_data  User object.
	 * @return string
	 */
	public static function filter_reset_message( $message, $key, $user_login, $user_data ) {
		unset( $message, $user_data );

		$branded = self::reset_password_url( $key, $user_login );
		$site    = wp_specialchars_decode( get_option( 'blogname' ), ENT_QUOTES );

		$text = sprintf(
			/* translators: 1: site name, 2: user login, 3: reset URL */
			__(
				"Valaki jelszó-visszaállítást kért a(z) %1\$s oldalon erre a fiókra:\n\nFelhasználó: %2\$s\n\nHa nem te kérted, hagyd figyelmen kívül ezt a levelet.\n\nÚj jelszó megadásához nyisd meg ezt a linket:\n%3\$s\n",
				'ki-mit-adna-erte'
			),
			$site,
			$user_login,
			$branded
		);

		return class_exists( 'KMAE_Brand' ) ? KMAE_Brand::wrap_email( $text ) : $text;
	}

	/**
	 * Keep users on branded screens instead of wp-login.php password flows.
	 */
	public static function redirect_wp_password_screens() {
		if ( is_user_logged_in() ) {
			return;
		}

		$action = isset( $_REQUEST['action'] ) ? sanitize_key( wp_unslash( $_REQUEST['action'] ) ) : '';

		if ( in_array( $action, array( 'lostpassword', 'retrievepassword' ), true ) ) {
			wp_safe_redirect( self::lost_password_url() );
			exit;
		}

		if ( in_array( $action, array( 'rp', 'resetpass' ), true ) ) {
			$key   = isset( $_GET['key'] ) ? sanitize_text_field( wp_unslash( $_GET['key'] ) ) : '';
			$login = isset( $_GET['login'] ) ? sanitize_text_field( wp_unslash( $_GET['login'] ) ) : '';
			if ( $key && $login ) {
				wp_safe_redirect( self::reset_password_url( $key, $login ) );
				exit;
			}
			wp_safe_redirect( self::lost_password_url() );
			exit;
		}
	}

	/**
	 * Send password reset email for an address.
	 *
	 * @param string $email Email.
	 * @return true|WP_Error Always true on unknown email (no enumeration).
	 */
	public static function request_password_reset( $email ) {
		$email = sanitize_email( $email );
		if ( ! is_email( $email ) ) {
			return new WP_Error( 'invalid_email', __( 'Érvénytelen e-mail cím.', 'ki-mit-adna-erte' ) );
		}

		$user = get_user_by( 'email', $email );
		if ( ! $user ) {
			return true;
		}

		$key = get_password_reset_key( $user );
		if ( is_wp_error( $key ) ) {
			return $key;
		}

		$site    = wp_specialchars_decode( get_option( 'blogname' ), ENT_QUOTES );
		$subject = sprintf(
			/* translators: %s: site name */
			__( '[%s] Jelszó visszaállítása', 'ki-mit-adna-erte' ),
			$site
		);
		$body = sprintf(
			/* translators: 1: site name, 2: user login, 3: reset URL */
			__(
				"Valaki jelszó-visszaállítást kért a(z) %1\$s oldalon erre a fiókra:\n\nFelhasználó: %2\$s\n\nHa nem te kérted, hagyd figyelmen kívül ezt a levelet.\n\nÚj jelszó megadásához nyisd meg ezt a linket:\n%3\$s\n",
				'ki-mit-adna-erte'
			),
			$site,
			$user->user_login,
			self::reset_password_url( $key, $user->user_login )
		);

		KMAE_Brand::send_mail( $user->user_email, $subject, $body );

		return true;
	}

	/**
	 * Set a new password using WP reset key.
	 *
	 * @param string $login User login.
	 * @param string $key   Reset key.
	 * @param string $pass1 New password.
	 * @param string $pass2 Confirm password.
	 * @return true|WP_Error
	 */
	public static function reset_password_with_key( $login, $key, $pass1, $pass2 ) {
		$login = sanitize_text_field( $login );
		$key   = sanitize_text_field( $key );

		if ( '' === $login || '' === $key ) {
			return new WP_Error( 'invalid_key', __( 'Érvénytelen vagy lejárt visszaállító link.', 'ki-mit-adna-erte' ) );
		}

		$user = check_password_reset_key( $key, $login );
		if ( is_wp_error( $user ) ) {
			return new WP_Error( 'invalid_key', __( 'Érvénytelen vagy lejárt visszaállító link.', 'ki-mit-adna-erte' ) );
		}

		if ( strlen( (string) $pass1 ) < 8 ) {
			return new WP_Error( 'weak_password', __( 'A jelszónak legalább 8 karakter hosszúnak kell lennie.', 'ki-mit-adna-erte' ) );
		}

		if ( (string) $pass1 !== (string) $pass2 ) {
			return new WP_Error( 'password_mismatch', __( 'A két jelszó nem egyezik.', 'ki-mit-adna-erte' ) );
		}

		reset_password( $user, $pass1 );
		return true;
	}

	/**
	 * Allowed account types (magánszemély / cég).
	 *
	 * @return array<string, string> slug => label
	 */
	public static function account_types() {
		return array(
			self::ACCOUNT_PRIVATE => __( 'Magánszemély', 'ki-mit-adna-erte' ),
			self::ACCOUNT_COMPANY => __( 'Cég / autókereskedés', 'ki-mit-adna-erte' ),
		);
	}

	/**
	 * @param string $type Raw type.
	 * @return string Normalized type.
	 */
	public static function sanitize_account_type( $type ) {
		$type = sanitize_key( (string) $type );
		$allowed = array_keys( self::account_types() );
		return in_array( $type, $allowed, true ) ? $type : self::ACCOUNT_PRIVATE;
	}

	/**
	 * @param int $user_id User ID.
	 * @return string private|company
	 */
	public static function get_account_type( $user_id ) {
		$profile = self::get_profile( $user_id );
		if ( ! empty( $profile->account_type ) ) {
			return self::sanitize_account_type( $profile->account_type );
		}
		$meta = get_user_meta( $user_id, 'kmae_account_type', true );
		return self::sanitize_account_type( $meta );
	}

	public static function is_company( $user_id ) {
		return self::ACCOUNT_COMPANY === self::get_account_type( $user_id );
	}

	public static function is_private_person( $user_id ) {
		return self::ACCOUNT_PRIVATE === self::get_account_type( $user_id );
	}

	/**
	 * Human-readable account type label.
	 *
	 * @param int $user_id User ID.
	 * @return string
	 */
	public static function account_type_label( $user_id ) {
		$type   = self::get_account_type( $user_id );
		$labels = self::account_types();
		return isset( $labels[ $type ] ) ? $labels[ $type ] : $labels[ self::ACCOUNT_PRIVATE ];
	}

	/**
	 * Subscribers need upload_files for listing photos.
	 */
	public static function ensure_subscriber_caps() {
		$role = get_role( 'subscriber' );
		if ( $role && ! $role->has_cap( 'upload_files' ) ) {
			$role->add_cap( 'upload_files' );
		}
	}

	/**
	 * Authors may edit/delete their own listings without edit_posts cap.
	 *
	 * @param array<string> $caps
	 * @return array<string>
	 */
	public static function map_listing_caps( $caps, $cap, $user_id, $args ) {
		$listing_caps = array( 'edit_post', 'delete_post', 'read_post' );
		if ( ! in_array( $cap, $listing_caps, true ) || empty( $args[0] ) ) {
			return $caps;
		}

		$post = get_post( (int) $args[0] );
		if ( ! $post || 'kmae_listing' !== $post->post_type ) {
			return $caps;
		}

		if ( (int) $post->post_author === (int) $user_id ) {
			return array( 'read' );
		}

		return $caps;
	}

	public static function register( $data ) {
		global $wpdb;

		$display_name  = isset( $data['display_name'] ) ? sanitize_text_field( $data['display_name'] ) : '';
		$email         = isset( $data['email'] ) ? sanitize_email( $data['email'] ) : '';
		$phone         = isset( $data['phone'] ) ? sanitize_text_field( $data['phone'] ) : '';
		$password      = isset( $data['password'] ) ? $data['password'] : '';
		$password2     = isset( $data['password_confirm'] ) ? $data['password_confirm'] : '';
		$raw_account_type = isset( $data['account_type'] ) ? sanitize_key( (string) $data['account_type'] ) : '';

		if ( empty( $email ) || empty( $phone ) || empty( $password ) ) {
			return new WP_Error( 'missing_fields', __( 'Kérjük, tölts ki minden mezőt.', 'ki-mit-adna-erte' ) );
		}

		if ( ! isset( self::account_types()[ $raw_account_type ] ) ) {
			return new WP_Error( 'account_type_required', __( 'Válaszd ki, hogy magánszemély vagy cég vagy.', 'ki-mit-adna-erte' ) );
		}

		$account_type = $raw_account_type;

		if ( self::ACCOUNT_COMPANY === $account_type ) {
			$company_name = isset( $data['company_name'] ) ? sanitize_text_field( (string) $data['company_name'] ) : '';
			if ( '' === $company_name ) {
				return new WP_Error( 'company_name_required', __( 'Add meg a cégnevet.', 'ki-mit-adna-erte' ) );
			}
			$display_name = $company_name;
		} elseif ( empty( $display_name ) ) {
			return new WP_Error( 'missing_fields', __( 'Kérjük, tölts ki minden mezőt.', 'ki-mit-adna-erte' ) );
		}

		if ( ! is_email( $email ) ) {
			return new WP_Error( 'invalid_email', __( 'Érvénytelen e-mail cím.', 'ki-mit-adna-erte' ) );
		}

		if ( email_exists( $email ) ) {
			return new WP_Error( 'email_exists', __( 'Ez az e-mail cím már regisztrálva van.', 'ki-mit-adna-erte' ) );
		}

		if ( strlen( $password ) < 8 ) {
			return new WP_Error( 'weak_password', __( 'A jelszónak legalább 8 karakter hosszúnak kell lennie.', 'ki-mit-adna-erte' ) );
		}

		if ( $password !== $password2 ) {
			return new WP_Error( 'password_mismatch', __( 'A két jelszó nem egyezik.', 'ki-mit-adna-erte' ) );
		}

		if ( empty( $data['email_news'] ) || empty( $data['email_offers'] ) ) {
			return new WP_Error(
				'email_prefs_required',
				__( 'Az e-mail értesítések elfogadása kötelező a regisztrációhoz.', 'ki-mit-adna-erte' )
			);
		}

		$username = self::generate_username( $email );

		$user_id = wp_insert_user(
			array(
				'user_login'   => $username,
				'user_email'   => $email,
				'user_pass'    => $password,
				'display_name' => $display_name,
				'role'         => 'subscriber',
			)
		);

		if ( is_wp_error( $user_id ) ) {
			return $user_id;
		}

		update_user_meta( $user_id, 'kmae_phone', $phone );
		update_user_meta( $user_id, 'kmae_account_type', $account_type );

		if ( self::ACCOUNT_COMPANY === $account_type ) {
			KMAE_Company::save_profile_fields(
				$user_id,
				array(
					'company_name' => $display_name,
					'tax_id'       => isset( $data['tax_id'] ) ? $data['tax_id'] : '',
					'address'      => isset( $data['address'] ) ? $data['address'] : '',
				)
			);
		}

		$wpdb->replace(
			KMAE_Database::table( 'user_profiles' ),
			array(
				'user_id'        => $user_id,
				'phone'          => $phone,
				'account_type'   => $account_type,
				'email_verified' => 0,
				'phone_verified' => 0,
				'email_news'     => 1,
				'email_offers'   => 1,
			),
			array( '%d', '%s', '%s', '%d', '%d', '%d', '%d' )
		);

		return $user_id;
	}

	public static function login( $email_or_login, $password, $remember = false ) {
		$email_or_login = sanitize_text_field( $email_or_login );
		$user           = get_user_by( 'email', $email_or_login );

		if ( ! $user ) {
			$user = get_user_by( 'login', $email_or_login );
		}

		if ( ! $user ) {
			return new WP_Error( 'invalid_login', __( 'Hibás e-mail vagy jelszó.', 'ki-mit-adna-erte' ) );
		}

		$result = wp_signon(
			array(
				'user_login'    => $user->user_login,
				'user_password' => $password,
				'remember'      => $remember,
			),
			is_ssl()
		);

		if ( is_wp_error( $result ) ) {
			return new WP_Error( 'invalid_login', __( 'Hibás e-mail vagy jelszó.', 'ki-mit-adna-erte' ) );
		}

		return $result;
	}

	public static function get_profile( $user_id ) {
		global $wpdb;
		$row = $wpdb->get_row(
			$wpdb->prepare(
				'SELECT * FROM ' . KMAE_Database::table( 'user_profiles' ) . ' WHERE user_id = %d',
				$user_id
			)
		);

		if ( ! $row ) {
			$phone = get_user_meta( $user_id, 'kmae_phone', true );
			$type  = get_user_meta( $user_id, 'kmae_account_type', true );
			return (object) array(
				'user_id'        => $user_id,
				'phone'          => $phone ?: '',
				'account_type'   => self::sanitize_account_type( $type ),
				'email_verified' => 0,
				'phone_verified' => 0,
				'email_news'     => 0,
				'email_offers'   => 0,
			);
		}

		if ( empty( $row->account_type ) ) {
			$row->account_type = self::ACCOUNT_PRIVATE;
		}

		return $row;
	}

	public static function wants_offer_emails( $user_id ) {
		$profile = self::get_profile( $user_id );
		return ! empty( $profile->email_offers );
	}

	public static function wants_news_emails( $user_id ) {
		$profile = self::get_profile( $user_id );
		return ! empty( $profile->email_news );
	}

	public static function is_email_verified( $user_id ) {
		$profile = self::get_profile( $user_id );
		return ! empty( $profile->email_verified );
	}

	public static function is_phone_verified( $user_id ) {
		$profile = self::get_profile( $user_id );
		return ! empty( $profile->phone_verified );
	}

	public static function is_fully_verified( $user_id ) {
		return self::is_email_verified( $user_id ) && self::is_phone_verified( $user_id );
	}

	public static function sync_phone( $user_id, $phone ) {
		global $wpdb;
		$existing     = self::get_profile( $user_id );
		$account_type = self::sanitize_account_type( $existing->account_type ?? self::ACCOUNT_PRIVATE );
		$wpdb->replace(
			KMAE_Database::table( 'user_profiles' ),
			array(
				'user_id'        => $user_id,
				'phone'          => $phone,
				'account_type'   => $account_type,
				'email_verified' => (int) $existing->email_verified,
				'phone_verified' => (int) $existing->phone_verified,
				'email_news'     => (int) ( $existing->email_news ?? 0 ),
				'email_offers'   => (int) ( $existing->email_offers ?? 0 ),
			),
			array( '%d', '%s', '%s', '%d', '%d', '%d', '%d' )
		);
		update_user_meta( $user_id, 'kmae_phone', $phone );
		update_user_meta( $user_id, 'kmae_account_type', $account_type );
	}

	private static function generate_username( $email ) {
		$base = sanitize_user( current( explode( '@', $email ) ), true );
		if ( empty( $base ) ) {
			$base = 'user';
		}
		$username = $base;
		$i        = 1;
		while ( username_exists( $username ) ) {
			$username = $base . $i;
			$i++;
		}
		return $username;
	}
}
