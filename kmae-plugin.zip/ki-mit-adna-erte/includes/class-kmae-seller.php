<?php
/**
 * Private-seller listing rules: price mode, commitments, active-cycle limit.
 *
 * @package KMAE
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class KMAE_Seller {

	const PRICE_FIXED  = 'fixed';
	const PRICE_OFFERS = 'offers';

	const META_PRICE_MODE   = '_kmae_price_mode';
	const META_FIXED_PRICE  = '_kmae_fixed_price';
	const META_DEFECTS      = '_kmae_known_defects';
	const META_COMMITMENTS  = '_kmae_commitments';
	const META_EXTRA_OTHER  = '_kmae_commit_extra_other';
	const META_GUARANTEE_BOOST = '_kmae_onsite_guarantee_boosted';

	const COMMIT_PICKUP_24H         = 'pickup_24h';
	const COMMIT_ONSITE_GUARANTEE   = 'onsite_guarantee';
	const COMMIT_SPARE_WHEELS       = 'spare_wheels';
	const COMMIT_WITH_KEEPER        = 'with_keeper';
	const COMMIT_INDEPENDENT_MECH   = 'independent_mechanic';
	const COMMIT_OTHER              = 'other';

	/**
	 * @return array<string, string>
	 */
	public static function price_mode_labels() {
		return array(
			self::PRICE_FIXED  => __( 'Fix ár', 'ki-mit-adna-erte' ),
			self::PRICE_OFFERS => __( 'Ajánlatokat várok', 'ki-mit-adna-erte' ),
		);
	}

	/**
	 * Core optional seller pledges (checkboxes).
	 *
	 * @return array<string, array{label:string,desc:string,reward?:string}>
	 */
	public static function commitment_defs() {
		return array(
			self::COMMIT_PICKUP_24H       => array(
				'label'  => __( '24 órán belül elvihető', 'ki-mit-adna-erte' ),
				'desc'   => __( 'Ha a vevő 24 órán belül eljön, a megállapodott összegért eladod.', 'ki-mit-adna-erte' ),
				'reward' => '',
			),
			self::COMMIT_ONSITE_GUARANTEE => array(
				'label'  => __( 'Helyszíni garancia', 'ki-mit-adna-erte' ),
				'desc'   => __( 'Az autó megfelel a képeknek és a leírásnak. Eltérés esetén 10% engedmény.', 'ki-mit-adna-erte' ),
				'reward' => __( 'Jutalom: ingyenes kiemelés', 'ki-mit-adna-erte' ),
			),
		);
	}

	/**
	 * Extra pledges shown as badges.
	 *
	 * @return array<string, array{label:string,desc:string,badge:string}>
	 */
	public static function extra_commitment_defs() {
		return array(
			self::COMMIT_SPARE_WHEELS     => array(
				'label' => __( 'Plusz kerékgarnitúra', 'ki-mit-adna-erte' ),
				'desc'  => __( 'Pl. téli/nyári plusz garnitúra jár az autóval.', 'ki-mit-adna-erte' ),
				'badge' => __( '+ kerékgarnitúra', 'ki-mit-adna-erte' ),
			),
			self::COMMIT_WITH_KEEPER      => array(
				'label' => __( 'Üzembentartóival is vállalom', 'ki-mit-adna-erte' ),
				'desc'  => __( 'Az autó üzemben tartásával együtt is átadható.', 'ki-mit-adna-erte' ),
				'badge' => __( 'Üzembentartóval', 'ki-mit-adna-erte' ),
			),
			self::COMMIT_INDEPENDENT_MECH => array(
				'label' => __( 'Független szerelőhöz vihető', 'ki-mit-adna-erte' ),
				'desc'  => __( 'A vevő elviheti független szerelőhöz megnézni.', 'ki-mit-adna-erte' ),
				'badge' => __( 'Független szerelő', 'ki-mit-adna-erte' ),
			),
			self::COMMIT_OTHER            => array(
				'label' => __( 'Egyéb extra / ajándék', 'ki-mit-adna-erte' ),
				'desc'  => __( 'Írd le röviden, mit adsz még.', 'ki-mit-adna-erte' ),
				'badge' => __( 'Extra', 'ki-mit-adna-erte' ),
			),
		);
	}

	/**
	 * @param string $mode Raw.
	 * @return string
	 */
	public static function sanitize_price_mode( $mode ) {
		$mode = sanitize_key( (string) $mode );
		return isset( self::price_mode_labels()[ $mode ] ) ? $mode : self::PRICE_OFFERS;
	}

	/**
	 * @param int $listing_id Listing ID.
	 * @return string
	 */
	public static function get_price_mode( $listing_id ) {
		$mode = get_post_meta( $listing_id, self::META_PRICE_MODE, true );
		return self::sanitize_price_mode( $mode ?: self::PRICE_OFFERS );
	}

	/**
	 * @param int $listing_id Listing ID.
	 * @return float
	 */
	public static function get_fixed_price( $listing_id ) {
		return (float) get_post_meta( $listing_id, self::META_FIXED_PRICE, true );
	}

	/**
	 * @param int $listing_id Listing ID.
	 * @return bool
	 */
	public static function is_fixed_price( $listing_id ) {
		return self::PRICE_FIXED === self::get_price_mode( $listing_id );
	}

	/**
	 * @param int $listing_id Listing ID.
	 * @return string
	 */
	public static function get_known_defects( $listing_id ) {
		return (string) get_post_meta( $listing_id, self::META_DEFECTS, true );
	}

	/**
	 * @param int $listing_id Listing ID.
	 * @return array<int, string>
	 */
	public static function get_commitments( $listing_id ) {
		$raw = get_post_meta( $listing_id, self::META_COMMITMENTS, true );
		if ( ! is_array( $raw ) ) {
			return array();
		}
		$allowed = array_merge( array_keys( self::commitment_defs() ), array_keys( self::extra_commitment_defs() ) );
		return array_values( array_intersect( array_map( 'sanitize_key', $raw ), $allowed ) );
	}

	/**
	 * @param int    $listing_id Listing ID.
	 * @param string $code       Commitment code.
	 * @return bool
	 */
	public static function has_commitment( $listing_id, $code ) {
		return in_array( $code, self::get_commitments( $listing_id ), true );
	}

	/**
	 * @param int $listing_id Listing ID.
	 * @return string
	 */
	public static function get_extra_other( $listing_id ) {
		return (string) get_post_meta( $listing_id, self::META_EXTRA_OTHER, true );
	}

	/**
	 * Public badge rows for listing cards / single view.
	 *
	 * @param int $listing_id Listing ID.
	 * @return array<int, array{code:string,label:string,class:string}>
	 */
	public static function get_badge_rows( $listing_id ) {
		$rows = array();
		$defs = self::commitment_defs();
		$extras = self::extra_commitment_defs();

		if ( self::has_commitment( $listing_id, self::COMMIT_ONSITE_GUARANTEE ) ) {
			$rows[] = array(
				'code'  => self::COMMIT_ONSITE_GUARANTEE,
				'label' => __( 'Helyszíni garancia', 'ki-mit-adna-erte' ),
				'class' => 'kmae-pledge-badge--guarantee',
			);
		}
		if ( self::has_commitment( $listing_id, self::COMMIT_PICKUP_24H ) ) {
			$rows[] = array(
				'code'  => self::COMMIT_PICKUP_24H,
				'label' => __( '24 órán belül elvihető', 'ki-mit-adna-erte' ),
				'class' => 'kmae-pledge-badge--pickup',
			);
		}

		foreach ( $extras as $code => $info ) {
			if ( ! self::has_commitment( $listing_id, $code ) ) {
				continue;
			}
			$label = $info['badge'];
			if ( self::COMMIT_OTHER === $code ) {
				$other = self::get_extra_other( $listing_id );
				$label = $other !== '' ? $other : $info['badge'];
			}
			$rows[] = array(
				'code'  => $code,
				'label' => $label,
				'class' => 'kmae-pledge-badge--extra',
			);
		}

		unset( $defs );
		return $rows;
	}

	/**
	 * Active selling cycle = listing with status "active".
	 *
	 * @param int $user_id User ID.
	 * @return int
	 */
	public static function count_active_cycle_listings( $user_id ) {
		$query = new WP_Query(
			array(
				'post_type'              => 'kmae_listing',
				'post_status'            => 'publish',
				'author'                 => (int) $user_id,
				'posts_per_page'         => 1,
				'fields'                 => 'ids',
				'no_found_rows'          => false,
				'update_post_meta_cache' => false,
				'update_post_term_cache' => false,
				'meta_query'             => array(
					array(
						'key'     => '_kmae_status',
						'value'   => array(
							KMAE_Meta::STATUS_ACTIVE,
							KMAE_Meta::STATUS_AWAITING_PHOTOS,
							KMAE_Meta::STATUS_CLOSED,
						),
						'compare' => 'IN',
					),
				),
			)
		);
		return (int) $query->found_posts;
	}

	/**
	 * Private person: 1 active cycle at a time (not calendar month).
	 *
	 * @param int $user_id User ID.
	 * @return true|WP_Error
	 */
	public static function can_create_listing( $user_id ) {
		if ( ! KMAE_Auth::is_private_person( $user_id ) ) {
			return true;
		}
		if ( self::count_active_cycle_listings( $user_id ) >= 1 ) {
			return new WP_Error(
				'private_listing_limit',
				__( 'Magánszemélyként egyszerre csak egy aktív hirdetésed lehet. Ha az autó elkelt (vagy lezárod), újra feladhatsz.', 'ki-mit-adna-erte' )
			);
		}
		return true;
	}

	/**
	 * Validate + save price mode, defects, commitments from POST.
	 *
	 * @param int  $post_id Listing ID.
	 * @param bool $is_new  New listing.
	 * @return true|WP_Error
	 */
	public static function save_from_post( $post_id, $is_new = false ) {
		$mode = self::sanitize_price_mode( isset( $_POST['kmae_price_mode'] ) ? wp_unslash( $_POST['kmae_price_mode'] ) : '' );

		$fixed_price = isset( $_POST['kmae_fixed_price'] ) ? floatval( wp_unslash( $_POST['kmae_fixed_price'] ) ) : 0;
		$minimum     = isset( $_POST['kmae_minimum_cash'] ) ? floatval( wp_unslash( $_POST['kmae_minimum_cash'] ) ) : 0;
		$defects     = isset( $_POST['kmae_known_defects'] ) ? sanitize_textarea_field( wp_unslash( $_POST['kmae_known_defects'] ) ) : '';
		$extra_other = isset( $_POST['kmae_commit_extra_other'] ) ? sanitize_text_field( wp_unslash( $_POST['kmae_commit_extra_other'] ) ) : '';

		$raw_commits = isset( $_POST['kmae_commitments'] ) ? (array) wp_unslash( $_POST['kmae_commitments'] ) : array();
		$allowed     = array_merge( array_keys( self::commitment_defs() ), array_keys( self::extra_commitment_defs() ) );
		$commits     = array_values( array_intersect( array_map( 'sanitize_key', $raw_commits ), $allowed ) );

		if ( self::PRICE_FIXED === $mode ) {
			if ( $fixed_price < 1 ) {
				return new WP_Error( 'fixed_price_required', __( 'Add meg a fix árat.', 'ki-mit-adna-erte' ) );
			}
		} else {
			if ( $minimum < 1 ) {
				return new WP_Error( 'minimum_required', __( 'Ajánlatoknál add meg a minimum összeget (ez a vevőnek rejtett marad).', 'ki-mit-adna-erte' ) );
			}
		}

		if ( in_array( self::COMMIT_OTHER, $commits, true ) && '' === $extra_other ) {
			return new WP_Error( 'extra_other_required', __( 'Írd le az egyéb extrát.', 'ki-mit-adna-erte' ) );
		}

		update_post_meta( $post_id, self::META_PRICE_MODE, $mode );
		update_post_meta( $post_id, self::META_FIXED_PRICE, self::PRICE_FIXED === $mode ? $fixed_price : 0 );
		update_post_meta( $post_id, self::META_DEFECTS, $defects );
		update_post_meta( $post_id, self::META_COMMITMENTS, $commits );
		update_post_meta( $post_id, self::META_EXTRA_OTHER, in_array( self::COMMIT_OTHER, $commits, true ) ? $extra_other : '' );

		// Fixed price: ensure cash is accepted; store fixed as public price.
		$offer_types = isset( $_POST['kmae_offer_types'] ) ? array_map( 'sanitize_text_field', wp_unslash( (array) $_POST['kmae_offer_types'] ) ) : array();
		if ( self::PRICE_FIXED === $mode && ! in_array( KMAE_OFFER_TYPE_CASH, $offer_types, true ) ) {
			$offer_types[] = KMAE_OFFER_TYPE_CASH;
			update_post_meta( $post_id, '_kmae_offer_types', $offer_types );
		}

		if ( self::PRICE_OFFERS === $mode ) {
			KMAE_Database::save_private_data( $post_id, $minimum );
		} elseif ( self::PRICE_FIXED === $mode ) {
			// Fixed listings: no hidden min filter (exact price).
			KMAE_Database::save_private_data( $post_id, 0 );
		}

		if ( in_array( self::COMMIT_ONSITE_GUARANTEE, $commits, true ) ) {
			self::maybe_grant_guarantee_boost( $post_id );
		}

		unset( $is_new );
		return true;
	}

	/**
	 * Free featured boost once when onsite guarantee is pledged.
	 *
	 * @param int $listing_id Listing ID.
	 */
	public static function maybe_grant_guarantee_boost( $listing_id ) {
		if ( get_post_meta( $listing_id, self::META_GUARANTEE_BOOST, true ) ) {
			return;
		}
		KMAE_Premium::feature_listing( $listing_id, 7 );
		update_post_meta( $listing_id, self::META_GUARANTEE_BOOST, 1 );
		update_post_meta( $listing_id, '_kmae_featured_reason', 'onsite_guarantee' );
	}
}
