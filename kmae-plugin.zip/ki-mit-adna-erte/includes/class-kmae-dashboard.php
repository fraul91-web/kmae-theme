<?php
/**
 * Logged-in seller dashboard data + view tracking.
 *
 * @package KMAE
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class KMAE_Dashboard {

	const META_VIEWS      = '_kmae_view_count';
	const META_VIEWS_WEEK = '_kmae_views_week';
	const COOKIE_PREFIX   = 'kmae_v_';

	public static function init() {
		add_action( 'template_redirect', array( __CLASS__, 'maybe_track_listing_view' ), 20 );
	}

	/**
	 * Count a listing view once per visitor session (skip owner / bots).
	 */
	public static function maybe_track_listing_view() {
		if ( ! is_singular( 'kmae_listing' ) || is_preview() ) {
			return;
		}

		$listing_id = get_queried_object_id();
		if ( ! $listing_id ) {
			return;
		}

		$author_id = (int) get_post_field( 'post_author', $listing_id );
		if ( is_user_logged_in() && get_current_user_id() === $author_id ) {
			return;
		}

		if ( KMAE_Meta::STATUS_AWAITING_PHOTOS === KMAE_Meta::get_status( $listing_id ) ) {
			return;
		}

		$cookie = self::COOKIE_PREFIX . $listing_id;
		if ( ! empty( $_COOKIE[ $cookie ] ) ) {
			return;
		}

		self::increment_views( $listing_id );
		if ( ! headers_sent() ) {
			setcookie( $cookie, '1', time() + DAY_IN_SECONDS, COOKIEPATH ? COOKIEPATH : '/', COOKIE_DOMAIN, is_ssl(), true );
		}
	}

	/**
	 * @param int $listing_id Listing ID.
	 */
	public static function increment_views( $listing_id ) {
		$listing_id = (int) $listing_id;
		$count      = (int) get_post_meta( $listing_id, self::META_VIEWS, true );
		update_post_meta( $listing_id, self::META_VIEWS, $count + 1 );

		$week_key = gmdate( 'oW' );
		$weeks    = get_post_meta( $listing_id, self::META_VIEWS_WEEK, true );
		if ( ! is_array( $weeks ) ) {
			$weeks = array();
		}
		$weeks[ $week_key ] = isset( $weeks[ $week_key ] ) ? (int) $weeks[ $week_key ] + 1 : 1;
		// Keep last ~8 week buckets.
		if ( count( $weeks ) > 8 ) {
			ksort( $weeks );
			$weeks = array_slice( $weeks, -8, null, true );
		}
		update_post_meta( $listing_id, self::META_VIEWS_WEEK, $weeks );
	}

	/**
	 * @param int $listing_id Listing ID.
	 * @return int
	 */
	public static function get_listing_views( $listing_id ) {
		return (int) get_post_meta( $listing_id, self::META_VIEWS, true );
	}

	/**
	 * Sum views for all listings of a user.
	 *
	 * @param int $user_id User ID.
	 * @return array{total:int,this_week:int,last_week:int,delta:int}
	 */
	public static function get_user_view_stats( $user_id ) {
		$ids = get_posts(
			array(
				'post_type'              => 'kmae_listing',
				'post_status'            => 'publish',
				'author'                 => (int) $user_id,
				'posts_per_page'         => 100,
				'fields'                 => 'ids',
				'no_found_rows'          => true,
				'update_post_meta_cache' => true,
				'update_post_term_cache' => false,
			)
		);

		$total      = 0;
		$this_week  = 0;
		$last_week  = 0;
		$week_key   = gmdate( 'oW' );
		$prev_key   = gmdate( 'oW', strtotime( '-7 days' ) );

		foreach ( $ids as $id ) {
			$total += self::get_listing_views( $id );
			$weeks  = get_post_meta( $id, self::META_VIEWS_WEEK, true );
			if ( ! is_array( $weeks ) ) {
				continue;
			}
			$this_week += isset( $weeks[ $week_key ] ) ? (int) $weeks[ $week_key ] : 0;
			$last_week += isset( $weeks[ $prev_key ] ) ? (int) $weeks[ $prev_key ] : 0;
		}

		return array(
			'total'     => $total,
			'this_week' => $this_week,
			'last_week' => $last_week,
			'delta'     => $this_week - $last_week,
		);
	}

	/**
	 * Full dashboard payload for the logged-in home.
	 *
	 * @param int $user_id User ID.
	 * @return array
	 */
	public static function get_data( $user_id ) {
		$user_id = (int) $user_id;
		$user    = get_userdata( $user_id );
		$name    = $user ? ( $user->display_name ?: $user->user_login ) : '';

		$listings = get_posts(
			array(
				'post_type'      => 'kmae_listing',
				'post_status'    => 'publish',
				'author'         => $user_id,
				'posts_per_page' => 50,
				'orderby'        => 'date',
				'order'          => 'DESC',
			)
		);

		$active_count    = 0;
		$awaiting_count  = 0;
		$closed_count    = 0;
		$archived_count  = 0;
		$new_this_week   = 0;
		$week_ago        = strtotime( '-7 days' );
		$listing_rows    = array();

		foreach ( $listings as $listing ) {
			$status = KMAE_Meta::get_status( $listing->ID );
			if ( KMAE_Meta::STATUS_ACTIVE === $status ) {
				++$active_count;
			} elseif ( KMAE_Meta::STATUS_AWAITING_PHOTOS === $status ) {
				++$awaiting_count;
			} elseif ( KMAE_Meta::STATUS_CLOSED === $status ) {
				++$closed_count;
			} elseif ( KMAE_Meta::STATUS_ARCHIVED === $status ) {
				++$archived_count;
			}

			if ( strtotime( $listing->post_date ) >= $week_ago ) {
				++$new_this_week;
			}

			$listing_rows[] = self::format_listing_row( $listing );
		}

		$offers_raw   = KMAE_Database::get_offers_received_by_user( $user_id );
		$offers_total = is_array( $offers_raw ) ? count( $offers_raw ) : 0;
		$unseen       = (int) KMAE_Database::count_unseen_offer_activity( $user_id );

		$offer_rows    = array();
		$message_rows  = array();
		$activity      = array();

		if ( is_array( $offers_raw ) ) {
			foreach ( array_slice( $offers_raw, 0, 8 ) as $offer ) {
				$row = self::format_offer_row( $offer );
				if ( $row ) {
					$offer_rows[] = $row;
				}
			}
			foreach ( array_slice( $offers_raw, 0, 6 ) as $offer ) {
				$msg = self::format_message_row( $offer );
				if ( $msg ) {
					$message_rows[] = $msg;
				}
			}
			foreach ( array_slice( $offers_raw, 0, 10 ) as $offer ) {
				$act = self::activity_from_offer( $offer );
				if ( $act ) {
					$activity[] = $act;
				}
			}
		}

		foreach ( array_slice( $listings, 0, 8 ) as $listing ) {
			$status = KMAE_Meta::get_status( $listing->ID );
			if ( KMAE_Meta::STATUS_ARCHIVED === $status ) {
				$activity[] = array(
					'type' => 'green',
					'text' => sprintf(
						/* translators: %s: listing title */
						__( 'Sikeres ügylet — „%s” lezárva', 'ki-mit-adna-erte' ),
						$listing->post_title
					),
					'time' => self::relative_time( get_post_meta( $listing->ID, '_kmae_archived_at', true ) ?: $listing->post_modified ),
					'ts'   => strtotime( get_post_meta( $listing->ID, '_kmae_archived_at', true ) ?: $listing->post_modified ),
				);
			} elseif ( KMAE_Meta::STATUS_AWAITING_PHOTOS === $status ) {
				$activity[] = array(
					'type' => 'gold',
					'text' => sprintf(
						/* translators: %s: listing title */
						__( '„%s” fotó feltöltésre vár', 'ki-mit-adna-erte' ),
						$listing->post_title
					),
					'time' => self::relative_time( $listing->post_date ),
					'ts'   => strtotime( $listing->post_date ),
				);
			} elseif ( strtotime( $listing->post_date ) >= $week_ago ) {
				$activity[] = array(
					'type' => 'gold',
					'text' => sprintf(
						/* translators: %s: listing title */
						__( 'Hirdetés feladva: „%s”', 'ki-mit-adna-erte' ),
						$listing->post_title
					),
					'time' => self::relative_time( $listing->post_date ),
					'ts'   => strtotime( $listing->post_date ),
				);
			}
		}

		usort(
			$activity,
			static function ( $a, $b ) {
				return ( $b['ts'] ?? 0 ) <=> ( $a['ts'] ?? 0 );
			}
		);
		$activity = array_slice( $activity, 0, 6 );

		$view_stats = self::get_user_view_stats( $user_id );

		$cycle_active = $active_count + $awaiting_count + $closed_count;

		$trust_summary = class_exists( 'KMAE_Trust' )
			? KMAE_Trust::get_summary( $user_id )
			: array(
				'score'    => 0,
				'deals'    => 0,
				'positive' => 0,
				'badges'   => array(),
			);
		$trust_score   = (int) ( $trust_summary['score'] ?? 0 );
		$trust_deals   = (int) ( $trust_summary['deals'] ?? 0 );
		$trust_pos     = (int) ( $trust_summary['positive'] ?? 0 );
		$feedback_pct  = $trust_deals > 0 ? (int) round( min( 100, ( $trust_pos / max( 1, $trust_deals ) ) * 100 ) ) : ( $trust_score > 0 ? min( 100, $trust_score ) : 0 );
		$accuracy_pct  = $trust_score > 0 ? (int) max( 40, min( 100, $trust_score ) ) : 0;
		$response_pct  = $trust_score > 0 ? (int) max( 35, min( 100, $trust_score - 8 ) ) : 0;
		$badge_title   = ! empty( $trust_summary['badges'][0] )
			? $trust_summary['badges'][0]
			: __( 'Új tag', 'ki-mit-adna-erte' );
		$trust_title   = $trust_score > 0
			? sprintf(
				/* translators: 1: badge label */
				__( 'Bizalmi Pontszám · %s', 'ki-mit-adna-erte' ),
				$badge_title
			)
			: __( 'Bizalmi Pontszám', 'ki-mit-adna-erte' );
		$trust_blurb   = $trust_score > 0
			? __( 'Az átlátható kereskedési múltad és a pozitív visszajelzések alapján alakítottuk ki a pontszámodat.', 'ki-mit-adna-erte' )
			: __( 'Még nincs elég lezárt ügyleted a bizalmi pontszámhoz — az első sikeres üzletek után jelenik meg.', 'ki-mit-adna-erte' );

		return array(
			'name'            => $name,
			'initials'        => self::initials( $name ),
			'trust'           => array(
				'score'  => $trust_score,
				'deals'  => $trust_deals,
				'positive' => $trust_pos,
				'badges' => $trust_summary['badges'] ?? array(),
				'title'  => $trust_title,
				'blurb'  => $trust_blurb,
				'bars'   => array(
					array(
						'label' => __( 'Visszajelzések', 'ki-mit-adna-erte' ),
						'pct'   => $feedback_pct,
						'color' => 'var(--c8)',
						'fill'  => 'fill-violet',
					),
					array(
						'label' => __( 'Hirdetés pontosság', 'ki-mit-adna-erte' ),
						'pct'   => $accuracy_pct,
						'color' => 'var(--c4)',
						'fill'  => 'fill-gold',
					),
					array(
						'label' => __( 'Válaszkészség', 'ki-mit-adna-erte' ),
						'pct'   => $response_pct,
						'color' => 'var(--c7)',
						'fill'  => 'fill-green',
					),
				),
			),
			'stats'           => array(
				'listings'         => $cycle_active,
				'listings_sub'     => $new_this_week > 0
					? sprintf(
						/* translators: %d: count */
						__( '↑ %d ezen a héten', 'ki-mit-adna-erte' ),
						$new_this_week
					)
					: __( 'Nincs új ezen a héten', 'ki-mit-adna-erte' ),
				'offers'           => $offers_total,
				'offers_sub'       => $unseen > 0
					? sprintf(
						/* translators: %d: unread count */
						__( '%d olvasatlan', 'ki-mit-adna-erte' ),
						$unseen
					)
					: __( 'Nincs olvasatlan', 'ki-mit-adna-erte' ),
				'closed'           => $archived_count,
				'closed_sub'       => $archived_count > 0
					? __( 'Lezárt ügyletek', 'ki-mit-adna-erte' )
					: __( 'Még nincs lezárt ügylet', 'ki-mit-adna-erte' ),
				'views'            => $view_stats['total'],
				'views_sub'        => self::format_view_delta( $view_stats['delta'] ),
				'active'           => $active_count,
				'awaiting'         => $awaiting_count,
				'unseen_offers'    => $unseen,
			),
			'listings'        => array_slice( $listing_rows, 0, 5 ),
			'offers'          => array_slice( $offer_rows, 0, 5 ),
			'messages'        => array_slice( $message_rows, 0, 5 ),
			'activity'        => $activity,
			'urls'            => array(
				'create'    => class_exists( 'KMAE_Pages' ) ? KMAE_Pages::url( 'hirdetes-feladasa' ) : home_url( '/hirdetes-feladasa/' ),
				'listings'  => class_exists( 'KMAE_Pages' ) ? KMAE_Pages::url( 'sajat-hirdetesek' ) : home_url( '/sajat-hirdetesek/' ),
				'offers'    => class_exists( 'KMAE_Pages' ) ? KMAE_Pages::url( 'ajanlatok' ) : home_url( '/ajanlatok/' ),
				'messages'  => class_exists( 'KMAE_Pages' ) ? KMAE_Pages::url( 'uzenetek' ) : home_url( '/uzenetek/' ),
				'browse'    => class_exists( 'KMAE_Pages' ) ? KMAE_Pages::url( 'hirdetesek' ) : home_url( '/hirdetesek/' ),
				'profile'   => class_exists( 'KMAE_Pages' ) ? KMAE_Pages::url( 'profil' ) : home_url( '/profil/' ),
				'notify'    => class_exists( 'KMAE_Pages' ) ? KMAE_Pages::url( 'ertesitesek' ) : home_url( '/ertesitesek/' ),
				'settings'  => class_exists( 'KMAE_Pages' ) ? KMAE_Pages::url( 'beallitasok' ) : home_url( '/beallitasok/' ),
				'hub_sell'  => class_exists( 'KMAE_Pages' ) ? KMAE_Pages::url( 'eladni' ) : home_url( '/eladni/' ),
				'hub_buy'   => class_exists( 'KMAE_Pages' ) ? KMAE_Pages::url( 'venni' ) : home_url( '/venni/' ),
				'hub_stats' => class_exists( 'KMAE_Pages' ) ? KMAE_Pages::url( 'statisztikak' ) : home_url( '/statisztikak/' ),
				'education' => class_exists( 'KMAE_Pages' ) ? KMAE_Pages::url( 'oktatas' ) : home_url( '/oktatas/' ),
			),
		);
	}

	/**
	 * @param WP_Post $listing Listing.
	 * @return array
	 */
	private static function format_listing_row( $listing ) {
		$status  = KMAE_Meta::get_status( $listing->ID );
		$labels  = KMAE_Meta::status_labels();
		$gallery = KMAE_Query::get_gallery_ids( $listing->ID );
		$thumb   = ! empty( $gallery ) ? KMAE_Images::get_url( (int) $gallery[0], 'thumbnail' ) : '';
		$price   = '';
		if ( KMAE_Seller::is_fixed_price( $listing->ID ) ) {
			$price = KMAE_Offers::format_cash( KMAE_Seller::get_fixed_price( $listing->ID ) );
		} else {
			$price = __( 'Ajánlatokat vár', 'ki-mit-adna-erte' );
		}

		$edit_url = add_query_arg( 'kmae_edit', $listing->ID, home_url( '/hirdetes-feladasa/' ) );
		if ( KMAE_Meta::STATUS_AWAITING_PHOTOS === $status ) {
			$edit_url = add_query_arg( 'kmae_photos', '1', $edit_url );
		}

		return array(
			'id'       => (int) $listing->ID,
			'title'    => $listing->post_title,
			'meta'     => KMAE_Vehicle::get_swipe_subtitle( $listing->ID ) ?: '',
			'price'    => $price,
			'status'   => $status,
			'label'    => $labels[ $status ] ?? $status,
			'thumb'    => $thumb,
			'url'      => KMAE_Meta::STATUS_AWAITING_PHOTOS === $status ? $edit_url : get_permalink( $listing->ID ),
			'views'    => self::get_listing_views( $listing->ID ),
		);
	}

	/**
	 * @param object $offer Offer row.
	 * @return array|null
	 */
	private static function format_offer_row( $offer ) {
		$listing = get_post( (int) $offer->listing_id );
		if ( ! $listing ) {
			return null;
		}
		$buyer = get_userdata( (int) $offer->offerer_id );
		$bname = $buyer ? ( $buyer->display_name ?: $buyer->user_login ) : __( 'Felhasználó', 'ki-mit-adna-erte' );

		return array(
			'id'       => (int) $offer->id,
			'car'      => $listing->post_title,
			'by'       => $bname,
			'initials' => self::initials( $bname ),
			'amount'   => KMAE_Offers::get_offer_summary( $offer ),
			'time'     => self::relative_time( $offer->created_at ),
			'url'      => KMAE_Pages::offer_thread_url( (int) $offer->id ),
			'unseen'   => 'good' === KMAE_Database::get_offer_alert_state( get_current_user_id(), $offer ),
		);
	}

	/**
	 * @param object $offer Offer row.
	 * @return array|null
	 */
	private static function format_message_row( $offer ) {
		$buyer = get_userdata( (int) $offer->offerer_id );
		$bname = $buyer ? ( $buyer->display_name ?: $buyer->user_login ) : __( 'Felhasználó', 'ki-mit-adna-erte' );
		$latest = KMAE_Database::get_latest_counter_offer( (int) $offer->id );
		$preview = '';
		$when    = $offer->created_at;

		if ( $latest ) {
			$preview = wp_strip_all_tags( KMAE_Counter_Offers::format_counter_message( $latest ) );
			$when    = $latest->created_at;
		} else {
			$preview = self::offer_amount_label( $offer );
		}

		if ( mb_strlen( $preview ) > 72 ) {
			$preview = mb_substr( $preview, 0, 69 ) . '…';
		}

		return array(
			'name'     => $bname,
			'initials' => self::initials( $bname ),
			'preview'  => $preview,
			'time'     => self::relative_time( $when ),
			'url'      => KMAE_Pages::offer_thread_url( (int) $offer->id ),
			'unseen'   => 'good' === KMAE_Database::get_offer_alert_state( get_current_user_id(), $offer ),
		);
	}

	/**
	 * @param object $offer Offer row.
	 * @return array|null
	 */
	private static function activity_from_offer( $offer ) {
		$listing = get_post( (int) $offer->listing_id );
		if ( ! $listing ) {
			return null;
		}
		$amount = KMAE_Offers::get_offer_summary( $offer );
		$type   = 'blue';
		$text   = sprintf(
			/* translators: 1: listing title, 2: amount */
			__( 'Új ajánlat érkezett a(z) „%1$s” hirdetésre — %2$s', 'ki-mit-adna-erte' ),
			$listing->post_title,
			$amount
		);

		if ( KMAE_Offers::STATUS_ACCEPTED === $offer->status ) {
			$type = 'green';
			$text = sprintf(
				/* translators: %s: listing title */
				__( 'Áll az alku: „%s”', 'ki-mit-adna-erte' ),
				$listing->post_title
			);
		} elseif ( KMAE_Offers::STATUS_REJECTED === $offer->status || KMAE_Offers::STATUS_WITHDRAWN === $offer->status ) {
			$type = 'red';
			$text = sprintf(
				/* translators: %s: listing title */
				__( 'Ajánlat lezárult: „%s”', 'ki-mit-adna-erte' ),
				$listing->post_title
			);
		}

		return array(
			'type' => $type,
			'text' => $text,
			'time' => self::relative_time( $offer->created_at ),
			'ts'   => strtotime( $offer->created_at ),
		);
	}

	/**
	 * @param object $offer Offer row.
	 * @return string
	 */
	private static function offer_amount_label( $offer ) {
		return KMAE_Offers::get_offer_summary( $offer );
	}

	/**
	 * @param int $delta Week-over-week delta.
	 * @return string
	 */
	private static function format_view_delta( $delta ) {
		if ( $delta > 0 ) {
			return sprintf(
				/* translators: %d: delta */
				__( '↑ %d a múlt héthez', 'ki-mit-adna-erte' ),
				$delta
			);
		}
		if ( $delta < 0 ) {
			return sprintf(
				/* translators: %d: abs delta */
				__( '↓ %d a múlt héthez', 'ki-mit-adna-erte' ),
				abs( $delta )
			);
		}
		return __( 'Nincs változás a múlt héthez', 'ki-mit-adna-erte' );
	}

	/**
	 * @param string $name Display name.
	 * @return string
	 */
	public static function initials( $name ) {
		$name  = trim( (string) $name );
		$parts = preg_split( '/\s+/u', $name ) ?: array();
		$out   = '';
		foreach ( array_slice( $parts, 0, 2 ) as $part ) {
			$out .= mb_strtoupper( mb_substr( $part, 0, 1 ) );
		}
		return $out ?: 'A';
	}

	/**
	 * @param string $datetime MySQL datetime.
	 * @return string
	 */
	public static function relative_time( $datetime ) {
		if ( empty( $datetime ) ) {
			return '';
		}
		$ts = strtotime( $datetime );
		if ( ! $ts ) {
			return '';
		}
		return human_time_diff( $ts, current_time( 'timestamp' ) ) . ' ' . __( 'óta', 'ki-mit-adna-erte' );
	}
}
