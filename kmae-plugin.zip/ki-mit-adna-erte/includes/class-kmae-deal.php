<?php
/**
 * Deal lock — „Áll az alku” viewing phase before sold/archive.
 *
 * @package KMAE
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class KMAE_Deal {

	const META_LOCKED_AT = '_kmae_deal_locked_at';
	const META_PHASE     = '_kmae_deal_phase';
	const PHASE_VIEWING  = 'viewing';

	const USER_CONTINUE_META = 'kmae_post_purchase_offer_id';

	/**
	 * Lock listing after accept — viewing appointment, not sold yet.
	 *
	 * @param int $offer_id Accepted offer.
	 * @param int $user_id  Actor.
	 */
	public static function lock_on_accept( $offer_id, $user_id ) {
		unset( $user_id );
		$offer = KMAE_Database::get_offer( $offer_id );
		if ( ! $offer ) {
			return;
		}

		$listing_id = (int) $offer->listing_id;
		if ( ! $listing_id || KMAE_Meta::STATUS_ARCHIVED === KMAE_Meta::get_status( $listing_id ) ) {
			return;
		}

		update_post_meta( $listing_id, '_kmae_status', KMAE_Meta::STATUS_CLOSED );
		update_post_meta( $listing_id, '_kmae_accepted_offer_id', (int) $offer_id );
		update_post_meta( $listing_id, self::META_LOCKED_AT, current_time( 'mysql' ) );
		update_post_meta( $listing_id, self::META_PHASE, self::PHASE_VIEWING );

		do_action( 'kmae_deal_locked', $offer_id, $listing_id );
	}

	/**
	 * Active „Áll az alku” offer id for a buyer (any listing), or 0.
	 *
	 * @param int $buyer_id Buyer user ID.
	 * @return int
	 */
	public static function get_buyer_active_lock_offer_id( $buyer_id ) {
		global $wpdb;
		$buyer_id = (int) $buyer_id;
		if ( ! $buyer_id ) {
			return 0;
		}

		$offers_t = KMAE_Database::table( 'offers' );
		$accepted = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT o.id, o.listing_id FROM {$offers_t} o
				WHERE o.offerer_id = %d AND o.status = %s
				ORDER BY o.updated_at DESC
				LIMIT 20",
				$buyer_id,
				KMAE_Offers::STATUS_ACCEPTED
			)
		);

		foreach ( (array) $accepted as $offer ) {
			if ( self::is_locked( (int) $offer->listing_id )
				&& self::get_locked_offer_id( (int) $offer->listing_id ) === (int) $offer->id ) {
				return (int) $offer->id;
			}
		}

		return 0;
	}

	/**
	 * Buyer may only have one Áll az alku at a time.
	 *
	 * @param int $buyer_id     Buyer.
	 * @param int $except_offer Offer allowed (current).
	 * @return true|WP_Error
	 */
	public static function assert_buyer_can_lock( $buyer_id, $except_offer = 0 ) {
		$active = self::get_buyer_active_lock_offer_id( $buyer_id );
		if ( $active && (int) $active !== (int) $except_offer ) {
			return new WP_Error(
				'buyer_deal_locked',
				__( 'Egyszerre csak egy autónál lehet „Áll az alku”. Zárd le vagy oldd fel a folyamatban lévő megtekintést.', 'ki-mit-adna-erte' )
			);
		}
		return true;
	}

	/**
	 * @param int $listing_id Listing ID.
	 * @return bool
	 */
	public static function is_locked( $listing_id ) {
		return KMAE_Meta::STATUS_CLOSED === KMAE_Meta::get_status( $listing_id )
			&& self::PHASE_VIEWING === get_post_meta( $listing_id, self::META_PHASE, true );
	}

	/**
	 * @param int $listing_id Listing ID.
	 * @return int
	 */
	public static function get_locked_offer_id( $listing_id ) {
		return (int) get_post_meta( $listing_id, '_kmae_accepted_offer_id', true );
	}

	/**
	 * @param object $offer Offer row.
	 * @return bool
	 */
	public static function is_viewing_deal( $offer ) {
		if ( ! $offer || KMAE_Offers::STATUS_ACCEPTED !== $offer->status ) {
			return false;
		}
		return self::is_locked( (int) $offer->listing_id )
			&& self::get_locked_offer_id( (int) $offer->listing_id ) === (int) $offer->id;
	}

	/**
	 * Seller or buyer on the locked deal can confirm outcome.
	 *
	 * @param object $offer   Offer.
	 * @param int    $user_id User.
	 * @return bool
	 */
	public static function can_confirm( $offer, $user_id ) {
		if ( ! self::is_viewing_deal( $offer ) ) {
			return false;
		}
		return KMAE_Counter_Offers::is_seller( $offer, $user_id )
			|| KMAE_Counter_Offers::is_buyer( $offer, $user_id );
	}

	/**
	 * Meeting succeeded — car sold.
	 *
	 * @param int $offer_id Offer ID.
	 * @param int $user_id  Actor.
	 * @return true|WP_Error
	 */
	public static function confirm_success( $offer_id, $user_id ) {
		$offer = KMAE_Database::get_offer( $offer_id );
		if ( ! $offer ) {
			return new WP_Error( 'invalid_offer', __( 'Érvénytelen ajánlat.', 'ki-mit-adna-erte' ) );
		}
		if ( ! self::can_confirm( $offer, $user_id ) ) {
			return new WP_Error( 'forbidden', __( 'Nincs jogosultságod ehhez.', 'ki-mit-adna-erte' ) );
		}

		$listing_id = (int) $offer->listing_id;
		$buyer_id   = (int) $offer->offerer_id;

		KMAE_Counter_Offers::reject_other_offers( $listing_id, $offer_id, false );

		delete_post_meta( $listing_id, self::META_PHASE );
		delete_post_meta( $listing_id, self::META_LOCKED_AT );

		update_post_meta( $listing_id, '_kmae_status', KMAE_Meta::STATUS_ARCHIVED );
		update_post_meta( $listing_id, '_kmae_archived_at', current_time( 'mysql' ) );
		update_post_meta( $listing_id, '_kmae_accepted_offer_id', (int) $offer_id );

		update_user_meta( $buyer_id, self::USER_CONTINUE_META, (int) $offer_id );

		do_action( 'kmae_deal_success', $offer_id, $listing_id, $user_id );
		KMAE_Company::on_deal_success( $offer_id, $listing_id, $user_id );
		KMAE_Notifications::listing_closed( $listing_id );

		return true;
	}

	/**
	 * Meeting failed — unlock and continue.
	 *
	 * @param int $offer_id Offer ID.
	 * @param int $user_id  Actor.
	 * @return true|WP_Error
	 */
	public static function confirm_failure( $offer_id, $user_id ) {
		global $wpdb;

		$offer = KMAE_Database::get_offer( $offer_id );
		if ( ! $offer ) {
			return new WP_Error( 'invalid_offer', __( 'Érvénytelen ajánlat.', 'ki-mit-adna-erte' ) );
		}
		if ( ! self::can_confirm( $offer, $user_id ) ) {
			return new WP_Error( 'forbidden', __( 'Nincs jogosultságod ehhez.', 'ki-mit-adna-erte' ) );
		}

		$listing_id = (int) $offer->listing_id;

		$wpdb->update(
			KMAE_Database::table( 'offers' ),
			array( 'status' => KMAE_Offers::STATUS_PENDING ),
			array( 'id' => $offer_id ),
			array( '%s' ),
			array( '%d' )
		);

		delete_post_meta( $listing_id, self::META_PHASE );
		delete_post_meta( $listing_id, self::META_LOCKED_AT );
		delete_post_meta( $listing_id, '_kmae_accepted_offer_id' );
		delete_post_meta( $listing_id, '_kmae_archived_at' );
		update_post_meta( $listing_id, '_kmae_status', KMAE_Meta::STATUS_ACTIVE );

		do_action( 'kmae_deal_failed', $offer_id, $listing_id, $user_id );

		return true;
	}

	/**
	 * After purchase: buyer wants to keep negotiating other cars.
	 *
	 * @param int $buyer_id Buyer.
	 * @return true|WP_Error
	 */
	public static function continue_shopping( $buyer_id ) {
		$pending = (int) get_user_meta( $buyer_id, self::USER_CONTINUE_META, true );
		if ( ! $pending ) {
			return new WP_Error( 'nothing_pending', __( 'Nincs függő döntés.', 'ki-mit-adna-erte' ) );
		}
		delete_user_meta( $buyer_id, self::USER_CONTINUE_META );
		return true;
	}

	/**
	 * After purchase: buyer stops — close other pending talks + notify sellers.
	 *
	 * @param int $buyer_id Buyer.
	 * @return true|WP_Error
	 */
	public static function stop_shopping( $buyer_id ) {
		$pending_offer_id = (int) get_user_meta( $buyer_id, self::USER_CONTINUE_META, true );
		if ( ! $pending_offer_id ) {
			return new WP_Error( 'nothing_pending', __( 'Nincs függő döntés.', 'ki-mit-adna-erte' ) );
		}

		$others = self::get_buyer_other_pending_offers( $buyer_id, $pending_offer_id );
		foreach ( $others as $offer ) {
			KMAE_Database::update_offer_status( (int) $offer->id, KMAE_Offers::STATUS_WITHDRAWN );
			KMAE_Notifications::buyer_found_other_car( (int) $offer->id );
		}

		delete_user_meta( $buyer_id, self::USER_CONTINUE_META );
		return true;
	}

	/**
	 * Pending offers by buyer on other listings.
	 *
	 * @param int $buyer_id        Buyer.
	 * @param int $except_offer_id Skip this offer.
	 * @return array<object>
	 */
	public static function get_buyer_other_pending_offers( $buyer_id, $except_offer_id = 0 ) {
		global $wpdb;
		return $wpdb->get_results(
			$wpdb->prepare(
				'SELECT * FROM ' . KMAE_Database::table( 'offers' ) . ' WHERE offerer_id = %d AND status = %s AND id != %d ORDER BY updated_at DESC',
				(int) $buyer_id,
				KMAE_Offers::STATUS_PENDING,
				(int) $except_offer_id
			)
		);
	}

	/**
	 * @param int $buyer_id Buyer.
	 * @return int
	 */
	public static function get_continue_offer_id( $buyer_id ) {
		return (int) get_user_meta( $buyer_id, self::USER_CONTINUE_META, true );
	}
}
