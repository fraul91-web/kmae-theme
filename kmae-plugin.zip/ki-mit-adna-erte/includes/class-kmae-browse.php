<?php
/**
 * Browse personalization: hide offered listings, resurface passes.
 *
 * @package KMAE
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class KMAE_Browse {

	const PASSED_META       = '_kmae_browse_passed';
	const PASSED_INTERVAL   = 20;

	/**
	 * Listing IDs the user already submitted an offer on.
	 *
	 * @return int[]
	 */
	public static function get_offered_listing_ids( $user_id ) {
		global $wpdb;

		$user_id = (int) $user_id;
		if ( $user_id <= 0 ) {
			return array();
		}

		$ids = $wpdb->get_col(
			$wpdb->prepare(
				'SELECT DISTINCT listing_id FROM ' . KMAE_Database::table( 'offers' ) . ' WHERE offerer_id = %d AND status IN (%s, %s, %s)',
				$user_id,
				KMAE_Offers::STATUS_PENDING,
				KMAE_Offers::STATUS_ACCEPTED,
				KMAE_Offers::STATUS_WITHDRAWN
			)
		);

		return array_map( 'intval', $ids );
	}

	/**
	 * @return int[]
	 */
	public static function get_passed_listing_ids( $user_id ) {
		$passed = get_user_meta( (int) $user_id, self::PASSED_META, true );
		if ( ! is_array( $passed ) ) {
			return array();
		}

		return array_values( array_unique( array_map( 'intval', $passed ) ) );
	}

	public static function record_pass( $user_id, $listing_id ) {
		$user_id    = (int) $user_id;
		$listing_id = (int) $listing_id;
		if ( $user_id <= 0 || $listing_id <= 0 ) {
			return false;
		}

		$passed   = self::get_passed_listing_ids( $user_id );
		$passed[] = $listing_id;
		$passed   = array_values( array_unique( $passed ) );

		update_user_meta( $user_id, self::PASSED_META, $passed );
		return true;
	}

	/**
	 * Fresh listings first; previously passed ones every Nth slot.
	 *
	 * @param WP_Post[] $listings
	 * @return WP_Post[]
	 */
	public static function personalize_listings( $listings, $user_id ) {
		$user_id = (int) $user_id;
		if ( $user_id <= 0 || empty( $listings ) ) {
			return $listings;
		}

		$offered_ids = array_flip( self::get_offered_listing_ids( $user_id ) );
		$passed_ids  = array_flip( self::get_passed_listing_ids( $user_id ) );
		$fresh       = array();
		$passed      = array();

		foreach ( $listings as $listing ) {
			$id = (int) $listing->ID;
			if ( isset( $offered_ids[ $id ] ) ) {
				continue;
			}
			if ( isset( $passed_ids[ $id ] ) ) {
				$passed[] = $listing;
			} else {
				$fresh[] = $listing;
			}
		}

		if ( empty( $fresh ) ) {
			return $passed;
		}

		if ( empty( $passed ) ) {
			return $fresh;
		}

		return self::merge_with_passed_interval( $fresh, $passed, self::PASSED_INTERVAL );
	}

	/**
	 * @param WP_Post[] $fresh
	 * @param WP_Post[] $passed
	 * @return WP_Post[]
	 */
	public static function merge_with_passed_interval( array $fresh, array $passed, $interval = 20 ) {
		$interval      = max( 1, (int) $interval );
		$result        = array();
		$passed_index  = 0;
		$passed_count  = count( $passed );

		foreach ( $fresh as $i => $listing ) {
			$result[] = $listing;
			if ( 0 === ( ( $i + 1 ) % $interval ) ) {
				$result[] = $passed[ $passed_index % $passed_count ];
				++$passed_index;
			}
		}

		return $result;
	}

	/**
	 * Parse browse wizard params from request.
	 *
	 * @return array{county:string,bodies:string[],mod:string,ertek:int,max_kp:int,kp_min:int,kp_max:int}
	 */
	public static function parse_wizard_params( $source = null ) {
		$get = null === $source ? $_GET : $source;

		return array(
			'county'  => isset( $get['megye'] ) ? sanitize_text_field( wp_unslash( $get['megye'] ) ) : '',
			'bodies'  => self::parse_bodies_param( $get['kivitel'] ?? '' ),
			'mod'     => isset( $get['mod'] ) ? sanitize_key( wp_unslash( $get['mod'] ) ) : '',
			'ertek'   => isset( $get['ertek'] ) ? absint( $get['ertek'] ) : 0,
			'max_kp'  => isset( $get['max_kp'] ) ? absint( $get['max_kp'] ) : 0,
			'kp_min'  => isset( $get['kp_min'] ) ? absint( $get['kp_min'] ) : 0,
			'kp_max'  => isset( $get['kp_max'] ) ? absint( $get['kp_max'] ) : 0,
		);
	}

	/**
	 * @param mixed $raw kivitel query value (string or array).
	 * @return string[]
	 */
	public static function parse_bodies_param( $raw ) {
		if ( is_array( $raw ) ) {
			$parts = $raw;
		} elseif ( is_string( $raw ) && '' !== $raw ) {
			$parts = explode( ',', $raw );
		} else {
			return array();
		}

		$valid  = array_keys( KMAE_Vehicle::body_types() );
		$bodies = array();

		foreach ( $parts as $part ) {
			$slug = sanitize_key( is_string( $part ) ? trim( $part ) : '' );
			if ( '' === $slug ) {
				continue;
			}
			if ( 'mind' === $slug ) {
				return array( 'mind' );
			}
			if ( in_array( $slug, $valid, true ) ) {
				$bodies[] = $slug;
			}
		}

		return array_values( array_unique( $bodies ) );
	}

	/**
	 * @param string[] $bodies
	 */
	public static function bodies_to_query_value( array $bodies ) {
		if ( empty( $bodies ) ) {
			return '';
		}
		if ( in_array( 'mind', $bodies, true ) ) {
			return 'mind';
		}
		return implode( ',', $bodies );
	}

	/**
	 * @param string[] $bodies
	 */
	public static function bodies_label( array $bodies ) {
		if ( empty( $bodies ) ) {
			return '';
		}
		if ( in_array( 'mind', $bodies, true ) ) {
			return __( 'Minden kivitel', 'ki-mit-adna-erte' );
		}

		$types  = KMAE_Vehicle::body_types();
		$labels = array();
		foreach ( $bodies as $slug ) {
			if ( isset( $types[ $slug ] ) ) {
				$labels[] = $types[ $slug ]['label'];
			}
		}

		return implode( ', ', $labels );
	}

	public static function is_wizard_complete( $wizard ) {
		if ( empty( $wizard['county'] ) || ! KMAE_Counties::is_valid( $wizard['county'] ) ) {
			return false;
		}
		if ( empty( $wizard['bodies'] ) ) {
			return false;
		}
		if ( empty( $wizard['mod'] ) ) {
			return false;
		}

		switch ( $wizard['mod'] ) {
			case KMAE_Vehicle::BROWSE_CSERE:
				return $wizard['ertek'] > 0;
			case KMAE_Vehicle::BROWSE_CSERE_KP:
				return $wizard['ertek'] > 0;
			case KMAE_Vehicle::BROWSE_KP:
				return $wizard['kp_min'] > 0 && $wizard['kp_max'] >= $wizard['kp_min'];
		}

		return false;
	}

	/**
	 * Filter listings by vehicle browse wizard rules.
	 *
	 * @param WP_Post[] $listings
	 * @param array     $wizard
	 * @return WP_Post[]
	 */
	public static function filter_by_wizard( array $listings, array $wizard ) {
		if ( ! KMAE_Vehicle::is_vehicle_launch() || empty( $wizard['mod'] ) ) {
			return $listings;
		}

		$filtered = array();

		foreach ( $listings as $listing ) {
			if ( ! self::listing_matches_wizard( $listing->ID, $wizard ) ) {
				continue;
			}
			$filtered[] = $listing;
		}

		return $filtered;
	}

	public static function listing_matches_wizard( $listing_id, array $wizard ) {
		$bodies = $wizard['bodies'] ?? array();

		if ( ! empty( $bodies ) && ! in_array( 'mind', $bodies, true ) ) {
			$body = get_post_meta( $listing_id, KMAE_Vehicle::META_BODY, true );
			if ( ! in_array( $body, $bodies, true ) ) {
				return false;
			}
		}

		$offer_types = KMAE_Meta::get_offer_types( $listing_id );
		$value       = KMAE_Vehicle::get_vehicle_value( $listing_id );

		if ( $value <= 0 ) {
			return false;
		}

		switch ( $wizard['mod'] ) {
			case KMAE_Vehicle::BROWSE_CSERE:
				if ( ! in_array( KMAE_OFFER_TYPE_TRADE, $offer_types, true ) ) {
					return false;
				}
				$user_val = (int) $wizard['ertek'];
				$diff     = abs( $value - $user_val );
				return $diff <= KMAE_Vehicle::TRADE_TOLERANCE;

			case KMAE_Vehicle::BROWSE_CSERE_KP:
				if ( ! in_array( KMAE_OFFER_TYPE_TRADE_PLUS_CASH, $offer_types, true ) ) {
					return false;
				}
				$user_val = (int) $wizard['ertek'];
				$max_kp   = (int) $wizard['max_kp'];
				return $value >= $user_val && $value <= ( $user_val + $max_kp );

			case KMAE_Vehicle::BROWSE_KP:
				if ( ! in_array( KMAE_OFFER_TYPE_CASH, $offer_types, true ) ) {
					return false;
				}
				$min = (int) $wizard['kp_min'];
				$max = (int) $wizard['kp_max'];
				return $value >= $min && $value <= $max;
		}

		return true;
	}

	public static function wizard_summary_label( array $wizard ) {
		$parts = array();

		if ( ! empty( $wizard['county'] ) ) {
			$parts[] = KMAE_Counties::get_label( $wizard['county'] );
		}

		if ( ! empty( $wizard['bodies'] ) ) {
			$parts[] = self::bodies_label( $wizard['bodies'] );
		}

		$modes = KMAE_Vehicle::browse_mode_labels();
		if ( ! empty( $wizard['mod'] ) ) {
			$parts[] = $modes[ $wizard['mod'] ] ?? $wizard['mod'];
		}

		return implode( ' · ', array_filter( $parts ) );
	}
}
