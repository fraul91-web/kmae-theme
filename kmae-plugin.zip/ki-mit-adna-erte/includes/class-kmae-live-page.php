<?php
/**
 * Live page fingerprint for auto-refresh polling.
 *
 * @package KMAE
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class KMAE_Live_Page {

	/**
	 * @param array<string,mixed> $args
	 */
	public static function get_fingerprint( $context, $args = array() ) {
		if ( ! is_user_logged_in() ) {
			return '';
		}

		$user_id = get_current_user_id();
		$parts   = array( $context, (string) $user_id );

		switch ( $context ) {
			case 'offer_thread':
				$offer_id = isset( $args['offer_id'] ) ? absint( $args['offer_id'] ) : 0;
				$offer    = $offer_id ? KMAE_Database::get_offer( $offer_id ) : null;
				if ( ! $offer ) {
					break;
				}
				$parts[] = $offer->status;
				$parts[] = $offer->updated_at ?? '';
				foreach ( KMAE_Database::get_counter_offers( $offer_id ) as $counter ) {
					$parts[] = $counter->id . ':' . $counter->created_at;
				}
				break;

			case 'offers_hub':
				$parts[] = (string) KMAE_Database::count_unseen_offer_activity( $user_id );
				foreach ( array_merge( KMAE_Database::get_offers_by_user( $user_id ), KMAE_Database::get_offers_received_by_user( $user_id ) ) as $offer ) {
					$parts[] = $offer->id . ':' . $offer->status . ':' . ( $offer->updated_at ?? '' );
				}
				break;

			case 'single_listing':
				$listing_id = isset( $args['listing_id'] ) ? absint( $args['listing_id'] ) : 0;
				if ( ! $listing_id ) {
					break;
				}
				$listing = get_post( $listing_id );
				if ( $listing && (int) $listing->post_author === $user_id ) {
					$parts[] = (string) KMAE_Database::count_offers_for_listing( $listing_id );
					foreach ( KMAE_Database::get_offers_for_listing( $listing_id ) as $offer ) {
						$parts[] = $offer->id . ':' . $offer->status . ':' . ( $offer->updated_at ?? '' );
					}
				} else {
					$user_offer = KMAE_Database::get_active_user_offer_for_listing( $listing_id, $user_id );
					if ( $user_offer ) {
						$parts[] = $user_offer->status . ':' . ( $user_offer->updated_at ?? '' );
					}
					$withdrawn = KMAE_Database::get_withdrawn_user_offer_for_listing( $listing_id, $user_id );
					if ( $withdrawn ) {
						$parts[] = 'withdrawn:' . $withdrawn->updated_at;
					}
				}
				$parts[] = KMAE_Meta::get_status( $listing_id );
				break;

			default:
				break;
		}

		return md5( implode( '|', $parts ) );
	}
}
