<?php
/**
 * Ratings + trust score (bizalmi szám).
 *
 * @package KMAE
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class KMAE_Trust {

	const META_SCORE    = 'kmae_trust_score';
	const META_DEALS    = 'kmae_trust_deals';
	const META_POSITIVE = 'kmae_trust_positive';

	/**
	 * Criteria when buyer rates seller.
	 *
	 * @return array<string, string>
	 */
	public static function seller_criteria() {
		return array(
			'description_ok'  => __( 'Megfelelt a leírás?', 'ki-mit-adna-erte' ),
			'photos_ok'       => __( 'Megfeleltek a képek?', 'ki-mit-adna-erte' ),
			'honest'          => __( 'Őszinte volt?', 'ki-mit-adna-erte' ),
			'kept_promise'    => __( 'Betartotta a vállalását?', 'ki-mit-adna-erte' ),
			'meeting_ok'      => __( 'Korrekt volt a találkozón?', 'ki-mit-adna-erte' ),
		);
	}

	/**
	 * Criteria when seller rates buyer.
	 *
	 * @return array<string, string>
	 */
	public static function buyer_criteria() {
		return array(
			'serious'       => __( 'Komoly vásárló volt?', 'ki-mit-adna-erte' ),
			'showed_up'     => __( 'Eljött a találkozóra?', 'ki-mit-adna-erte' ),
			'kept_word'     => __( 'Betartotta, amit vállalt?', 'ki-mit-adna-erte' ),
			'meeting_ok'    => __( 'Korrekt volt a találkozón?', 'ki-mit-adna-erte' ),
			'would_again'   => __( 'Újra üzletelnél vele?', 'ki-mit-adna-erte' ),
		);
	}

	/**
	 * @param string $role seller|buyer — who is being rated.
	 * @return array<string, string>
	 */
	public static function criteria_for_rated_role( $role ) {
		return 'seller' === $role ? self::seller_criteria() : self::buyer_criteria();
	}

	/**
	 * Pending ratings for a user after successful deals.
	 *
	 * @param int $user_id User ID.
	 * @return array<int, object> offer rows needing rating.
	 */
	public static function get_pending_for_user( $user_id ) {
		global $wpdb;
		$user_id = (int) $user_id;
		$offers_t  = KMAE_Database::table( 'offers' );
		$ratings_t = KMAE_Database::table( 'ratings' );
		$posts     = $wpdb->posts;

		// Accepted offers on archived listings where user is seller or buyer and has not rated yet.
		$sql = $wpdb->prepare(
			"SELECT o.* FROM {$offers_t} o
			INNER JOIN {$posts} p ON p.ID = o.listing_id AND p.post_type = 'kmae_listing'
			INNER JOIN {$wpdb->postmeta} pm ON pm.post_id = o.listing_id AND pm.meta_key = '_kmae_status' AND pm.meta_value = %s
			WHERE o.status = %s
			AND (o.offerer_id = %d OR p.post_author = %d)
			AND NOT EXISTS (
				SELECT 1 FROM {$ratings_t} r WHERE r.offer_id = o.id AND r.rater_id = %d
			)
			ORDER BY o.updated_at DESC
			LIMIT 20",
			KMAE_Meta::STATUS_ARCHIVED,
			KMAE_Offers::STATUS_ACCEPTED,
			$user_id,
			$user_id,
			$user_id
		);

		return $wpdb->get_results( $sql ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
	}

	/**
	 * @param int $offer_id Offer.
	 * @param int $rater_id Rater.
	 * @return bool
	 */
	public static function has_rated( $offer_id, $rater_id ) {
		global $wpdb;
		$n = (int) $wpdb->get_var(
			$wpdb->prepare(
				'SELECT COUNT(*) FROM ' . KMAE_Database::table( 'ratings' ) . ' WHERE offer_id = %d AND rater_id = %d',
				$offer_id,
				$rater_id
			)
		);
		return $n > 0;
	}

	/**
	 * Who the rater should rate on this offer.
	 *
	 * @param object $offer Offer.
	 * @param int    $rater_id Rater.
	 * @return array{rated_id:int,rated_role:string}|WP_Error
	 */
	public static function resolve_rated_party( $offer, $rater_id ) {
		$listing = get_post( $offer->listing_id );
		if ( ! $listing || KMAE_Offers::STATUS_ACCEPTED !== $offer->status ) {
			return new WP_Error( 'invalid_offer', __( 'Ez az üzlet nem értékelhető.', 'ki-mit-adna-erte' ) );
		}
		if ( KMAE_Meta::STATUS_ARCHIVED !== KMAE_Meta::get_status( $offer->listing_id ) ) {
			return new WP_Error( 'not_sold', __( 'Csak lezárt üzlet után lehet értékelni.', 'ki-mit-adna-erte' ) );
		}

		$seller_id = (int) $listing->post_author;
		$buyer_id  = (int) $offer->offerer_id;

		if ( (int) $rater_id === $seller_id ) {
			return array( 'rated_id' => $buyer_id, 'rated_role' => 'buyer' );
		}
		if ( (int) $rater_id === $buyer_id ) {
			return array( 'rated_id' => $seller_id, 'rated_role' => 'seller' );
		}
		return new WP_Error( 'forbidden', __( 'Nincs jogosultságod értékelni.', 'ki-mit-adna-erte' ) );
	}

	/**
	 * Submit a rating.
	 *
	 * @param int   $offer_id Offer.
	 * @param int   $rater_id Rater.
	 * @param array $data     overall (1-5), criteria (keys => 0|1), comment.
	 * @return int|WP_Error rating id
	 */
	public static function submit( $offer_id, $rater_id, $data ) {
		global $wpdb;

		$offer = KMAE_Database::get_offer( $offer_id );
		if ( ! $offer ) {
			return new WP_Error( 'invalid_offer', __( 'Érvénytelen ajánlat.', 'ki-mit-adna-erte' ) );
		}

		$party = self::resolve_rated_party( $offer, $rater_id );
		if ( is_wp_error( $party ) ) {
			return $party;
		}

		if ( self::has_rated( $offer_id, $rater_id ) ) {
			return new WP_Error( 'already_rated', __( 'Ezt az üzletet már értékelted.', 'ki-mit-adna-erte' ) );
		}

		if ( empty( $data['deal_ok'] ) ) {
			return new WP_Error( 'deal_ok_required', __( 'Erősítsd meg, hogy sikerült az üzlet.', 'ki-mit-adna-erte' ) );
		}

		$overall = isset( $data['overall'] ) ? absint( $data['overall'] ) : 0;
		if ( $overall < 1 || $overall > 5 ) {
			return new WP_Error( 'overall_required', __( 'Válassz 1–5 csillagos értékelést.', 'ki-mit-adna-erte' ) );
		}

		$defs      = self::criteria_for_rated_role( $party['rated_role'] );
		$criteria  = array();
		$raw       = isset( $data['criteria'] ) && is_array( $data['criteria'] ) ? $data['criteria'] : array();
		foreach ( array_keys( $defs ) as $key ) {
			$criteria[ $key ] = ! empty( $raw[ $key ] ) ? 1 : 0;
		}

		$comment = isset( $data['comment'] ) ? sanitize_textarea_field( $data['comment'] ) : '';

		$inserted = $wpdb->insert(
			KMAE_Database::table( 'ratings' ),
			array(
				'offer_id'    => (int) $offer_id,
				'listing_id'  => (int) $offer->listing_id,
				'rater_id'    => (int) $rater_id,
				'rated_id'    => (int) $party['rated_id'],
				'rated_role'  => $party['rated_role'],
				'overall'     => $overall,
				'criteria'    => wp_json_encode( $criteria ),
				'comment'     => $comment,
			),
			array( '%d', '%d', '%d', '%d', '%s', '%d', '%s', '%s' )
		);

		if ( false === $inserted ) {
			return new WP_Error( 'db_error', __( 'Az értékelés mentése sikertelen.', 'ki-mit-adna-erte' ) );
		}

		self::recalculate( (int) $party['rated_id'] );
		do_action( 'kmae_rating_submitted', $wpdb->insert_id, $offer_id, $rater_id, $party['rated_id'] );

		return (int) $wpdb->insert_id;
	}

	/**
	 * Recalculate cached trust stats for a user.
	 *
	 * @param int $user_id User.
	 */
	public static function recalculate( $user_id ) {
		global $wpdb;
		$user_id = (int) $user_id;

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT overall, criteria FROM ' . KMAE_Database::table( 'ratings' ) . ' WHERE rated_id = %d',
				$user_id
			)
		);

		$deals = self::count_successful_deals( $user_id );

		if ( empty( $rows ) ) {
			update_user_meta( $user_id, self::META_SCORE, 0 );
			update_user_meta( $user_id, self::META_DEALS, $deals );
			update_user_meta( $user_id, self::META_POSITIVE, 0 );
			return;
		}

		$sum_score = 0;
		$positive  = 0;
		$n         = 0;

		foreach ( $rows as $row ) {
			$overall = (int) $row->overall;
			$crit    = json_decode( (string) $row->criteria, true );
			if ( ! is_array( $crit ) ) {
				$crit = array();
			}
			$crit_vals = array_map( 'intval', array_values( $crit ) );
			$crit_avg  = $crit_vals ? ( array_sum( $crit_vals ) / count( $crit_vals ) ) : 0;
			$pct       = ( 0.6 * ( $overall / 5 ) + 0.4 * $crit_avg ) * 100;
			$sum_score += $pct;
			$n++;
			if ( $overall >= 4 ) {
				$positive++;
			}
		}

		$score = (int) round( $sum_score / max( 1, $n ) );
		update_user_meta( $user_id, self::META_SCORE, max( 0, min( 100, $score ) ) );
		update_user_meta( $user_id, self::META_DEALS, $deals );
		update_user_meta( $user_id, self::META_POSITIVE, $positive );
	}

	/**
	 * Successful closed deals as seller or buyer.
	 *
	 * @param int $user_id User.
	 * @return int
	 */
	public static function count_successful_deals( $user_id ) {
		global $wpdb;
		$user_id = (int) $user_id;
		$offers_t = KMAE_Database::table( 'offers' );
		$posts    = $wpdb->posts;

		$as_buyer = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$offers_t} o
				INNER JOIN {$wpdb->postmeta} pm ON pm.post_id = o.listing_id AND pm.meta_key = '_kmae_status' AND pm.meta_value = %s
				WHERE o.status = %s AND o.offerer_id = %d",
				KMAE_Meta::STATUS_ARCHIVED,
				KMAE_Offers::STATUS_ACCEPTED,
				$user_id
			)
		);

		$as_seller = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$offers_t} o
				INNER JOIN {$posts} p ON p.ID = o.listing_id AND p.post_author = %d
				INNER JOIN {$wpdb->postmeta} pm ON pm.post_id = o.listing_id AND pm.meta_key = '_kmae_status' AND pm.meta_value = %s
				WHERE o.status = %s",
				$user_id,
				KMAE_Meta::STATUS_ARCHIVED,
				KMAE_Offers::STATUS_ACCEPTED
			)
		);

		return $as_buyer + $as_seller;
	}

	/**
	 * @param int $user_id User.
	 * @return array{score:int,deals:int,positive:int,badges:array<int,string>}
	 */
	public static function get_summary( $user_id ) {
		$score    = (int) get_user_meta( $user_id, self::META_SCORE, true );
		$deals    = (int) get_user_meta( $user_id, self::META_DEALS, true );
		$positive = (int) get_user_meta( $user_id, self::META_POSITIVE, true );

		if ( $deals <= 0 ) {
			$deals = self::count_successful_deals( $user_id );
		}

		return array(
			'score'    => $score,
			'deals'    => $deals,
			'positive' => $positive,
			'badges'   => self::get_badges( $user_id, $score, $deals ),
		);
	}

	/**
	 * @param int $user_id User.
	 * @param int $score   Trust score.
	 * @param int $deals   Deal count.
	 * @return array<int, string>
	 */
	public static function get_badges( $user_id, $score = null, $deals = null ) {
		$summary_score = null === $score ? (int) get_user_meta( $user_id, self::META_SCORE, true ) : (int) $score;
		$summary_deals = null === $deals ? (int) get_user_meta( $user_id, self::META_DEALS, true ) : (int) $deals;
		$badges        = array();

		if ( self::user_used_onsite_guarantee( $user_id ) ) {
			$badges[] = __( 'Helyszíni garanciát vállalt', 'ki-mit-adna-erte' );
		}
		if ( $summary_deals >= 1 && $summary_score >= 80 ) {
			$badges[] = __( 'Megbízható eladó / vevő', 'ki-mit-adna-erte' );
		}
		if ( $summary_deals >= 5 && $summary_score >= 90 ) {
			$badges[] = __( 'Megbízhatósági kitüntetés', 'ki-mit-adna-erte' );
		}

		return $badges;
	}

	/**
	 * @param int $user_id User.
	 * @return bool
	 */
	public static function user_used_onsite_guarantee( $user_id ) {
		$query = new WP_Query(
			array(
				'post_type'              => 'kmae_listing',
				'post_status'            => 'any',
				'author'                 => (int) $user_id,
				'posts_per_page'         => 1,
				'fields'                 => 'ids',
				'no_found_rows'          => true,
				'update_post_meta_cache' => false,
				'meta_query'             => array(
					array(
						'key'     => KMAE_Seller::META_COMMITMENTS,
						'value'   => KMAE_Seller::COMMIT_ONSITE_GUARANTEE,
						'compare' => 'LIKE',
					),
				),
			)
		);
		return ! empty( $query->posts );
	}

	/**
	 * Rating URL for an offer.
	 *
	 * @param int $offer_id Offer.
	 * @return string
	 */
	public static function rate_url( $offer_id ) {
		$base = class_exists( 'KMAE_Pages' ) ? KMAE_Pages::url( 'profil' ) : home_url( '/profil/' );
		return add_query_arg( 'kmae_rate', (int) $offer_id, $base );
	}

	/**
	 * Ask both parties to rate after deal success.
	 *
	 * @param int $offer_id   Offer.
	 * @param int $listing_id Listing.
	 * @param int $user_id    Actor who confirmed.
	 */
	public static function on_deal_success( $offer_id, $listing_id, $user_id ) {
		unset( $user_id );
		$offer   = KMAE_Database::get_offer( $offer_id );
		$listing = get_post( $listing_id );
		if ( ! $offer || ! $listing ) {
			return;
		}

		$seller_id = (int) $listing->post_author;
		$buyer_id  = (int) $offer->offerer_id;

		self::recalculate( $seller_id );
		self::recalculate( $buyer_id );

		KMAE_Notifications::request_rating( $seller_id, $offer_id, $listing );
		KMAE_Notifications::request_rating( $buyer_id, $offer_id, $listing );
	}
}
