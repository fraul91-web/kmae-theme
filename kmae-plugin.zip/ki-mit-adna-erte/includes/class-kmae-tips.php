<?php
/**
 * Tips (borravaló) — after successful deal, tip goes to the buyer.
 *
 * @package KMAE
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class KMAE_Tips {

	const STATUS_SENT = 'sent';

	/**
	 * Preset tip amounts (HUF).
	 *
	 * @return array<int, int>
	 */
	public static function preset_amounts() {
		return array( 2000, 5000, 10000 );
	}

	/**
	 * Buyer of a sold offer.
	 *
	 * @param object $offer Offer.
	 * @return int
	 */
	public static function tip_recipient_id( $offer ) {
		return $offer ? (int) $offer->offerer_id : 0;
	}

	/**
	 * Seller may tip the buyer after successful sale.
	 *
	 * @param object $offer   Offer.
	 * @param int    $user_id Actor.
	 * @return bool
	 */
	public static function can_tip( $offer, $user_id ) {
		if ( ! $offer || KMAE_Offers::STATUS_ACCEPTED !== $offer->status ) {
			return false;
		}
		$listing = get_post( $offer->listing_id );
		if ( ! $listing || KMAE_Meta::STATUS_ARCHIVED !== KMAE_Meta::get_status( $listing->ID ) ) {
			return false;
		}
		if ( (int) $listing->post_author !== (int) $user_id ) {
			return false;
		}
		return ! self::has_tipped( (int) $offer->id );
	}

	/**
	 * @param int $offer_id Offer.
	 * @return bool
	 */
	public static function has_tipped( $offer_id ) {
		global $wpdb;
		$n = (int) $wpdb->get_var(
			$wpdb->prepare(
				'SELECT COUNT(*) FROM ' . KMAE_Database::table( 'tips' ) . ' WHERE offer_id = %d',
				(int) $offer_id
			)
		);
		return $n > 0;
	}

	/**
	 * Deals where current user (seller) can still send a tip.
	 *
	 * @param int $seller_id Seller.
	 * @return array<object>
	 */
	public static function get_pending_for_seller( $seller_id ) {
		global $wpdb;
		$seller_id = (int) $seller_id;
		$offers_t  = KMAE_Database::table( 'offers' );
		$tips_t    = KMAE_Database::table( 'tips' );
		$posts     = $wpdb->posts;

		$sql = $wpdb->prepare(
			"SELECT o.* FROM {$offers_t} o
			INNER JOIN {$posts} p ON p.ID = o.listing_id AND p.post_type = 'kmae_listing' AND p.post_author = %d
			INNER JOIN {$wpdb->postmeta} pm ON pm.post_id = o.listing_id AND pm.meta_key = '_kmae_status' AND pm.meta_value = %s
			WHERE o.status = %s
			AND NOT EXISTS (SELECT 1 FROM {$tips_t} t WHERE t.offer_id = o.id)
			ORDER BY o.updated_at DESC
			LIMIT 20",
			$seller_id,
			KMAE_Meta::STATUS_ARCHIVED,
			KMAE_Offers::STATUS_ACCEPTED
		);

		return $wpdb->get_results( $sql ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
	}

	/**
	 * Send tip to buyer (email notification; payment demo).
	 *
	 * @param int   $offer_id Offer.
	 * @param int   $from_id  Sender (seller).
	 * @param float $amount   Amount HUF.
	 * @param string $message Optional note.
	 * @return true|WP_Error
	 */
	public static function send( $offer_id, $from_id, $amount, $message = '' ) {
		$offer = KMAE_Database::get_offer( $offer_id );
		if ( ! $offer ) {
			return new WP_Error( 'invalid_offer', __( 'Érvénytelen ajánlat.', 'ki-mit-adna-erte' ) );
		}
		if ( ! self::can_tip( $offer, $from_id ) ) {
			return new WP_Error( 'cannot_tip', __( 'Ehhez az üzlethez most nem küldhető borravaló.', 'ki-mit-adna-erte' ) );
		}

		$amount = (float) $amount;
		if ( $amount < 500 ) {
			return new WP_Error( 'tip_too_small', __( 'A borravaló legalább 500 Ft legyen.', 'ki-mit-adna-erte' ) );
		}

		if ( ! KMAE_Settings::demo_payments_enabled() && ! current_user_can( 'manage_options' ) ) {
			return new WP_Error( 'payment_required', __( 'A borravaló-küldés hamarosan elérhető.', 'ki-mit-adna-erte' ) );
		}

		$buyer_id = self::tip_recipient_id( $offer );
		$message  = sanitize_textarea_field( $message );

		global $wpdb;
		$inserted = $wpdb->insert(
			KMAE_Database::table( 'tips' ),
			array(
				'offer_id'     => (int) $offer_id,
				'from_user_id' => (int) $from_id,
				'to_user_id'   => $buyer_id,
				'amount'       => $amount,
				'message'      => $message,
				'status'       => self::STATUS_SENT,
			),
			array( '%d', '%d', '%d', '%f', '%s', '%s' )
		);

		if ( false === $inserted ) {
			return new WP_Error( 'db_error', __( 'A borravaló mentése sikertelen.', 'ki-mit-adna-erte' ) );
		}

		KMAE_Notifications::tip_received( $offer_id, $amount, $message );
		do_action( 'kmae_tip_sent', (int) $wpdb->insert_id, $offer_id, $buyer_id );

		return true;
	}
}
