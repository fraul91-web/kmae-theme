<?php
/**
 * Plugin activation: database tables, default categories, rewrite rules.
 *
 * @package KMAE
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class KMAE_Activator {

	public static function activate() {
		self::create_tables();

		// CPT + taxonomy must be registered BEFORE seeding categories.
		KMAE_Post_Types::register_post_type();
		KMAE_Taxonomies::register_taxonomy();
		KMAE_Taxonomies::seed_categories();

		flush_rewrite_rules();
		KMAE_Pages::ensure_pages();
		KMAE_Auth::ensure_subscriber_caps();
		self::schedule_cron();
	}

	public static function schedule_cron() {
		if ( ! wp_next_scheduled( 'kmae_purge_archived_listings' ) ) {
			wp_schedule_event( time(), 'daily', 'kmae_purge_archived_listings' );
		}
	}

	private static function create_tables() {
		global $wpdb;
		$charset = $wpdb->get_charset_collate();
		$prefix  = $wpdb->prefix;

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$sql_offers = "CREATE TABLE {$prefix}kmae_offers (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			listing_id bigint(20) unsigned NOT NULL,
			offerer_id bigint(20) unsigned NOT NULL,
			offer_type varchar(32) NOT NULL DEFAULT 'cash',
			cash_amount decimal(12,2) DEFAULT NULL,
			currency varchar(3) NOT NULL DEFAULT 'HUF',
			status varchar(20) NOT NULL DEFAULT 'pending',
			counter_rounds int(11) NOT NULL DEFAULT 0,
			filtered_out tinyint(1) NOT NULL DEFAULT 0,
			created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			PRIMARY KEY (id),
			KEY listing_id (listing_id),
			KEY offerer_id (offerer_id),
			KEY status (status)
		) $charset;";

		$sql_offer_images = "CREATE TABLE {$prefix}kmae_offer_images (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			offer_id bigint(20) unsigned NOT NULL,
			attachment_id bigint(20) unsigned NOT NULL,
			sort_order int(11) NOT NULL DEFAULT 0,
			created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY (id),
			KEY offer_id (offer_id)
		) $charset;";

		$sql_counter_offers = "CREATE TABLE {$prefix}kmae_counter_offers (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			offer_id bigint(20) unsigned NOT NULL,
			user_id bigint(20) unsigned NOT NULL,
			template_code varchar(64) NOT NULL,
			cash_amount decimal(12,2) DEFAULT NULL,
			message text DEFAULT NULL,
			status varchar(20) NOT NULL DEFAULT 'pending',
			round_number int(11) NOT NULL DEFAULT 1,
			created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			PRIMARY KEY (id),
			KEY offer_id (offer_id),
			KEY user_id (user_id)
		) $charset;";

		$sql_private_data = "CREATE TABLE {$prefix}kmae_private_data (
			listing_id bigint(20) unsigned NOT NULL,
			minimum_cash decimal(12,2) NOT NULL,
			currency varchar(3) NOT NULL DEFAULT 'HUF',
			created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			PRIMARY KEY (listing_id)
		) $charset;";

		dbDelta( $sql_offers );
		dbDelta( $sql_offer_images );
		dbDelta( $sql_counter_offers );
		dbDelta( $sql_private_data );

		$sql_contact = "CREATE TABLE {$prefix}kmae_contact_unlocks (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			offer_id bigint(20) unsigned NOT NULL,
			user_id bigint(20) unsigned NOT NULL,
			created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY (id),
			UNIQUE KEY offer_user (offer_id, user_id),
			KEY offer_id (offer_id)
		) $charset;";

		$sql_premium = "CREATE TABLE {$prefix}kmae_premium (
			user_id bigint(20) unsigned NOT NULL,
			status varchar(20) NOT NULL DEFAULT 'active',
			expires_at datetime DEFAULT NULL,
			created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			PRIMARY KEY (user_id)
		) $charset;";

		dbDelta( $sql_contact );
		dbDelta( $sql_premium );

		$sql_ratings = "CREATE TABLE {$prefix}kmae_ratings (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			offer_id bigint(20) unsigned NOT NULL,
			listing_id bigint(20) unsigned NOT NULL,
			rater_id bigint(20) unsigned NOT NULL,
			rated_id bigint(20) unsigned NOT NULL,
			rated_role varchar(20) NOT NULL DEFAULT 'seller',
			overall tinyint(3) unsigned NOT NULL DEFAULT 5,
			criteria longtext NOT NULL,
			comment text DEFAULT NULL,
			created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY (id),
			UNIQUE KEY offer_rater (offer_id, rater_id),
			KEY rated_id (rated_id),
			KEY listing_id (listing_id)
		) $charset;";

		dbDelta( $sql_ratings );

		$sql_fees = "CREATE TABLE {$prefix}kmae_seller_fees (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			offer_id bigint(20) unsigned NOT NULL,
			listing_id bigint(20) unsigned NOT NULL,
			seller_id bigint(20) unsigned NOT NULL,
			sale_amount decimal(12,2) NOT NULL DEFAULT 0,
			fee_amount decimal(12,2) NOT NULL DEFAULT 0,
			fee_rate decimal(5,4) NOT NULL DEFAULT 0.0100,
			status varchar(20) NOT NULL DEFAULT 'pending',
			paid_at datetime DEFAULT NULL,
			created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			PRIMARY KEY (id),
			UNIQUE KEY offer_id (offer_id),
			KEY seller_id (seller_id),
			KEY status (status)
		) $charset;";

		dbDelta( $sql_fees );

		$sql_tips = "CREATE TABLE {$prefix}kmae_tips (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			offer_id bigint(20) unsigned NOT NULL,
			from_user_id bigint(20) unsigned NOT NULL,
			to_user_id bigint(20) unsigned NOT NULL,
			amount decimal(12,2) NOT NULL DEFAULT 0,
			message text DEFAULT NULL,
			status varchar(20) NOT NULL DEFAULT 'sent',
			created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY (id),
			UNIQUE KEY offer_id (offer_id),
			KEY to_user_id (to_user_id),
			KEY from_user_id (from_user_id)
		) $charset;";

		dbDelta( $sql_tips );

		$sql_profiles = "CREATE TABLE {$prefix}kmae_user_profiles (
			user_id bigint(20) unsigned NOT NULL,
			phone varchar(32) NOT NULL DEFAULT '',
			account_type varchar(20) NOT NULL DEFAULT 'private',
			email_verified tinyint(1) NOT NULL DEFAULT 0,
			phone_verified tinyint(1) NOT NULL DEFAULT 0,
			email_news tinyint(1) NOT NULL DEFAULT 0,
			email_offers tinyint(1) NOT NULL DEFAULT 0,
			created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			PRIMARY KEY (user_id),
			KEY account_type (account_type)
		) $charset;";

		dbDelta( $sql_profiles );

		// Existing installs: add account_type if missing.
		$profiles_table = $prefix . 'kmae_user_profiles';
		$account_col    = $wpdb->get_results( "SHOW COLUMNS FROM {$profiles_table} LIKE 'account_type'" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		if ( empty( $account_col ) ) {
			$wpdb->query( "ALTER TABLE {$profiles_table} ADD COLUMN account_type varchar(20) NOT NULL DEFAULT 'private' AFTER phone, ADD KEY account_type (account_type)" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		}

		// Existing users before email prefs: keep receiving offer emails.
		$column = $wpdb->get_results( "SHOW COLUMNS FROM {$profiles_table} LIKE 'email_offers'" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		if ( ! empty( $column ) ) {
			$wpdb->query( "UPDATE {$profiles_table} SET email_offers = 1 WHERE email_offers = 0 AND email_news = 0" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		}

		KMAE_Settings::init_defaults();
		update_option( 'kmae_db_version', KMAE_VERSION );
	}

	public static function maybe_upgrade() {
		if ( version_compare( get_option( 'kmae_db_version', '0' ), KMAE_VERSION, '<' ) ) {
			self::create_tables();
			KMAE_Pages::ensure_pages();
			KMAE_Auth::ensure_subscriber_caps();
			self::schedule_cron();
		}
	}
}
