<?php
/**
 * Listing query helpers with filters.
 *
 * @package KMAE
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class KMAE_Query {

	public static function get_listings( $args = array() ) {
		$defaults = array(
			'per_page' => 24,
			'category' => '',
			'type'     => '',
			'county'   => '',
			'body'     => '',
			'bodies'   => array(),
			'mode'     => 'grid',
		);
		$args = wp_parse_args( $args, $defaults );

		if ( KMAE_Launch::is_single_category() && empty( $args['category'] ) ) {
			$args['category'] = KMAE_Launch::category_slug();
		}

		$query_args = array(
			'post_type'      => 'kmae_listing',
			'posts_per_page' => absint( $args['per_page'] ),
			'post_status'    => 'publish',
			'meta_query'     => array(
				array(
					'key'   => '_kmae_status',
					'value' => KMAE_Meta::STATUS_ACTIVE,
				),
			),
		);

		if ( ! empty( $args['category'] ) ) {
			$query_args['tax_query'] = array(
				array(
					'taxonomy' => 'kmae_category',
					'field'    => 'slug',
					'terms'    => sanitize_text_field( $args['category'] ),
				),
			);
		}

		if ( ! empty( $args['type'] ) ) {
			$query_args['meta_query'][] = array(
				'key'     => '_kmae_offer_types',
				'value'   => sanitize_text_field( $args['type'] ),
				'compare' => 'LIKE',
			);
		}

		if ( ! empty( $args['county'] ) ) {
			$query_args['meta_query'][] = array(
				'key'     => '_kmae_county',
				'value'   => sanitize_text_field( $args['county'] ),
				'compare' => '=',
			);
		}

		$bodies = ! empty( $args['bodies'] ) && is_array( $args['bodies'] )
			? array_values( array_filter( $args['bodies'], static function ( $slug ) {
				return 'mind' !== $slug;
			} ) )
			: array();

		if ( empty( $bodies ) && ! empty( $args['body'] ) && 'mind' !== $args['body'] ) {
			$bodies = array( sanitize_key( $args['body'] ) );
		}

		if ( ! empty( $bodies ) ) {
			$query_args['meta_query'][] = array(
				'key'     => KMAE_Vehicle::META_BODY,
				'value'   => $bodies,
				'compare' => 'IN',
			);
		}

		if ( is_user_logged_in() ) {
			$query_args['author__not_in'] = array( get_current_user_id() );
			$offered_ids                  = KMAE_Browse::get_offered_listing_ids( get_current_user_id() );
			if ( ! empty( $offered_ids ) ) {
				$query_args['post__not_in'] = $offered_ids;
			}
		}

		$listings = get_posts( $query_args );

		usort(
			$listings,
			function ( $a, $b ) {
				$af = KMAE_Premium::is_featured( $a->ID ) ? 1 : 0;
				$bf = KMAE_Premium::is_featured( $b->ID ) ? 1 : 0;
				if ( $af !== $bf ) {
					return $bf - $af;
				}
				return strtotime( $b->post_date ) - strtotime( $a->post_date );
			}
		);

		if ( is_user_logged_in() ) {
			$listings = KMAE_Browse::personalize_listings( $listings, get_current_user_id() );
		}

		if ( 'swipe' === $args['mode'] ) {
			$listings = KMAE_Premium::weight_featured_listings( $listings );
		}

		return $listings;
	}

	/**
	 * Popular listings for landing page (featured first, then newest).
	 *
	 * @param int $limit Max items.
	 * @return array<int, WP_Post>
	 */
	public static function get_popular_listings( $limit = 4 ) {
		return self::get_listings(
			array(
				'per_page' => absint( $limit ),
				'mode'     => 'grid',
			)
		);
	}

	/**
	 * Featured image URL, or first gallery image as fallback.
	 */
	public static function get_listing_thumbnail_url( $listing_id, $size = 'medium' ) {
		$thumb_id = get_post_thumbnail_id( $listing_id );
		if ( $thumb_id ) {
			$url = KMAE_Images::get_url( $thumb_id, $size );
			if ( $url ) {
				return $url;
			}
		}

		$gallery_ids = self::get_gallery_ids( $listing_id );
		if ( ! empty( $gallery_ids ) ) {
			$url = KMAE_Images::get_url( $gallery_ids[0], $size );
			if ( $url ) {
				return $url;
			}
		}

		return '';
	}

	/**
	 * Full-size URL for lightbox.
	 */
	public static function get_listing_full_image_url( $listing_id ) {
		return self::get_listing_thumbnail_url( $listing_id, 'full' );
	}

	public static function get_gallery_ids( $listing_id ) {
		$gallery = get_post_meta( $listing_id, '_kmae_gallery', true );
		if ( is_array( $gallery ) && ! empty( $gallery ) ) {
			return array_map( 'absint', $gallery );
		}
		$thumb = get_post_thumbnail_id( $listing_id );
		return $thumb ? array( $thumb ) : array();
	}
}
