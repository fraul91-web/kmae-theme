<?php
/**
 * Vehicle-specific listing fields (car launch).
 *
 * @package KMAE
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class KMAE_Vehicle {

	const META_BRAND         = '_kmae_vehicle_brand';
	const META_MODEL         = '_kmae_vehicle_model';
	const META_YEAR          = '_kmae_vehicle_year';
	const META_MILEAGE       = '_kmae_vehicle_mileage';
	const META_FUEL          = '_kmae_vehicle_fuel';
	const META_TRANSMISSION  = '_kmae_vehicle_transmission';
	const META_BODY          = '_kmae_vehicle_body';
	const META_COLOR         = '_kmae_vehicle_color';
	const META_OWNERS        = '_kmae_vehicle_owners';
	const META_POWER_KW      = '_kmae_vehicle_power_kw';
	const META_ENGINE_CC     = '_kmae_vehicle_engine_cc';
	const META_VALUE         = '_kmae_vehicle_value';

	const TRADE_TOLERANCE    = 100000;

	const BROWSE_CSERE       = 'csere';
	const BROWSE_CSERE_KP    = 'csere_kp';
	const BROWSE_KP          = 'kp';

	public static function is_vehicle_launch() {
		return KMAE_Launch::is_single_category() && 'jarmu' === KMAE_Launch::category_slug();
	}

	public static function fuel_labels() {
		return array(
			'benzin'    => __( 'Benzin', 'ki-mit-adna-erte' ),
			'diesel'    => __( 'Dízel', 'ki-mit-adna-erte' ),
			'hybrid'    => __( 'Hibrid', 'ki-mit-adna-erte' ),
			'electric'  => __( 'Elektromos', 'ki-mit-adna-erte' ),
			'lpg'       => __( 'LPG / Gáz', 'ki-mit-adna-erte' ),
			'other'     => __( 'Egyéb', 'ki-mit-adna-erte' ),
		);
	}

	public static function transmission_labels() {
		return array(
			'manual'    => __( 'Manuális', 'ki-mit-adna-erte' ),
			'automatic' => __( 'Automata', 'ki-mit-adna-erte' ),
		);
	}

	public static function body_labels() {
		$labels = array();
		foreach ( self::body_types() as $slug => $info ) {
			$labels[ $slug ] = $info['label'];
		}
		return $labels;
	}

	/**
	 * All body types for browse wizard and forms.
	 *
	 * @return array<string, array{label:string}>
	 */
	public static function body_types() {
		return array(
			'sedan'      => array( 'label' => __( 'Szedán', 'ki-mit-adna-erte' ) ),
			'hatchback'  => array( 'label' => __( 'Ferdehátú', 'ki-mit-adna-erte' ) ),
			'estate'     => array( 'label' => __( 'Kombi', 'ki-mit-adna-erte' ) ),
			'suv'        => array( 'label' => __( 'SUV', 'ki-mit-adna-erte' ) ),
			'crossover'  => array( 'label' => __( 'Crossover', 'ki-mit-adna-erte' ) ),
			'coupe'      => array( 'label' => __( 'Coupé', 'ki-mit-adna-erte' ) ),
			'cabrio'     => array( 'label' => __( 'Kabrió / Cabrio', 'ki-mit-adna-erte' ) ),
			'roadster'   => array( 'label' => __( 'Roadster', 'ki-mit-adna-erte' ) ),
			'mpv'        => array( 'label' => __( 'Egyterű', 'ki-mit-adna-erte' ) ),
			'pickup'     => array( 'label' => __( 'Pick-up', 'ki-mit-adna-erte' ) ),
			'van'        => array( 'label' => __( 'Furgon / Kisbusz', 'ki-mit-adna-erte' ) ),
			'limousine'  => array( 'label' => __( 'Limuzin', 'ki-mit-adna-erte' ) ),
			'sport'      => array( 'label' => __( 'Sport', 'ki-mit-adna-erte' ) ),
			'offroad'    => array( 'label' => __( 'Terepjáró', 'ki-mit-adna-erte' ) ),
			'classic'    => array( 'label' => __( 'Klasszikus / Retro', 'ki-mit-adna-erte' ) ),
			'caravan'    => array( 'label' => __( 'Lakókocsi', 'ki-mit-adna-erte' ) ),
			'micro'      => array( 'label' => __( 'Micro / Mini', 'ki-mit-adna-erte' ) ),
			'other'      => array( 'label' => __( 'Egyéb', 'ki-mit-adna-erte' ) ),
		);
	}

	public static function browse_mode_labels() {
		return array(
			self::BROWSE_CSERE    => __( 'Csere', 'ki-mit-adna-erte' ),
			self::BROWSE_CSERE_KP => __( 'Csere + készpénz', 'ki-mit-adna-erte' ),
			self::BROWSE_KP       => __( 'Készpénz', 'ki-mit-adna-erte' ),
		);
	}

	public static function get_vehicle_value( $listing_id ) {
		return (int) get_post_meta( $listing_id, self::META_VALUE, true );
	}

	public static function format_value( $amount ) {
		if ( $amount <= 0 ) {
			return '';
		}
		return number_format( $amount, 0, ',', ' ' ) . ' Ft';
	}

	public static function condition_labels() {
		return array(
			'excellent' => __( 'Kitűnő', 'ki-mit-adna-erte' ),
			'good'      => __( 'Jó', 'ki-mit-adna-erte' ),
			'fair'      => __( 'Közepes', 'ki-mit-adna-erte' ),
			'project'   => __( 'Javítandó / projekt', 'ki-mit-adna-erte' ),
		);
	}

	public static function brand_suggestions() {
		return array(
			'Audi', 'BMW', 'Citroën', 'Fiat', 'Ford', 'Honda', 'Hyundai', 'Kia', 'Mazda',
			'Mercedes-Benz', 'Nissan', 'Opel', 'Peugeot', 'Renault', 'Seat', 'Skoda',
			'Suzuki', 'Toyota', 'Volkswagen', 'Volvo',
		);
	}

	public static function get_specs( $listing_id ) {
		return array(
			'brand'        => get_post_meta( $listing_id, self::META_BRAND, true ),
			'model'        => get_post_meta( $listing_id, self::META_MODEL, true ),
			'year'         => (int) get_post_meta( $listing_id, self::META_YEAR, true ),
			'mileage'      => (int) get_post_meta( $listing_id, self::META_MILEAGE, true ),
			'fuel'         => get_post_meta( $listing_id, self::META_FUEL, true ),
			'transmission' => get_post_meta( $listing_id, self::META_TRANSMISSION, true ),
			'body'         => get_post_meta( $listing_id, self::META_BODY, true ),
			'color'        => get_post_meta( $listing_id, self::META_COLOR, true ),
			'owners'       => (int) get_post_meta( $listing_id, self::META_OWNERS, true ),
			'power_kw'     => (int) get_post_meta( $listing_id, self::META_POWER_KW, true ),
			'engine_cc'    => (int) get_post_meta( $listing_id, self::META_ENGINE_CC, true ),
			'condition'    => get_post_meta( $listing_id, '_kmae_condition', true ),
			'value'        => self::get_vehicle_value( $listing_id ),
		);
	}

	public static function save_from_post( $post_id ) {
		if ( ! self::is_vehicle_launch() ) {
			return;
		}

		$brand = isset( $_POST['kmae_vehicle_brand'] ) ? sanitize_text_field( wp_unslash( $_POST['kmae_vehicle_brand'] ) ) : '';
		$model = isset( $_POST['kmae_vehicle_model'] ) ? sanitize_text_field( wp_unslash( $_POST['kmae_vehicle_model'] ) ) : '';
		$year  = isset( $_POST['kmae_vehicle_year'] ) ? absint( $_POST['kmae_vehicle_year'] ) : 0;
		$km    = isset( $_POST['kmae_vehicle_mileage'] ) ? absint( $_POST['kmae_vehicle_mileage'] ) : 0;
		$fuel  = isset( $_POST['kmae_vehicle_fuel'] ) ? sanitize_key( wp_unslash( $_POST['kmae_vehicle_fuel'] ) ) : '';
		$trans = isset( $_POST['kmae_vehicle_transmission'] ) ? sanitize_key( wp_unslash( $_POST['kmae_vehicle_transmission'] ) ) : '';
		$body  = isset( $_POST['kmae_vehicle_body'] ) ? sanitize_key( wp_unslash( $_POST['kmae_vehicle_body'] ) ) : '';
		$color = isset( $_POST['kmae_vehicle_color'] ) ? sanitize_text_field( wp_unslash( $_POST['kmae_vehicle_color'] ) ) : '';
		$owners = isset( $_POST['kmae_vehicle_owners'] ) ? absint( $_POST['kmae_vehicle_owners'] ) : 0;
		$power  = isset( $_POST['kmae_vehicle_power_kw'] ) ? absint( $_POST['kmae_vehicle_power_kw'] ) : 0;
		$cc     = isset( $_POST['kmae_vehicle_engine_cc'] ) ? absint( $_POST['kmae_vehicle_engine_cc'] ) : 0;
		$value  = isset( $_POST['kmae_vehicle_value'] ) ? absint( $_POST['kmae_vehicle_value'] ) : 0;
		$cond   = isset( $_POST['kmae_condition'] ) ? sanitize_key( wp_unslash( $_POST['kmae_condition'] ) ) : '';

		update_post_meta( $post_id, self::META_BRAND, $brand );
		update_post_meta( $post_id, self::META_MODEL, $model );
		update_post_meta( $post_id, self::META_YEAR, $year );
		update_post_meta( $post_id, self::META_MILEAGE, $km );
		update_post_meta( $post_id, self::META_FUEL, array_key_exists( $fuel, self::fuel_labels() ) ? $fuel : '' );
		update_post_meta( $post_id, self::META_TRANSMISSION, array_key_exists( $trans, self::transmission_labels() ) ? $trans : '' );
		update_post_meta( $post_id, self::META_BODY, array_key_exists( $body, self::body_types() ) ? $body : '' );
		update_post_meta( $post_id, self::META_COLOR, $color );
		update_post_meta( $post_id, self::META_OWNERS, $owners );
		update_post_meta( $post_id, self::META_POWER_KW, $power );
		update_post_meta( $post_id, self::META_ENGINE_CC, $cc );
		update_post_meta( $post_id, self::META_VALUE, $value );

		if ( array_key_exists( $cond, self::condition_labels() ) ) {
			update_post_meta( $post_id, '_kmae_condition', $cond );
		}

		$launch_cat = KMAE_Launch::get_launch_category_id();
		if ( $launch_cat ) {
			wp_set_object_terms( $post_id, array( $launch_cat ), 'kmae_category' );
		}
	}

	/**
	 * @return array<int, array{field:string,label:string}>
	 */
	public static function get_missing_required( $data ) {
		$missing = array();

		$required = array(
			'brand'        => __( 'Márka', 'ki-mit-adna-erte' ),
			'model'        => __( 'Modell', 'ki-mit-adna-erte' ),
			'year'         => __( 'Évjárat', 'ki-mit-adna-erte' ),
			'mileage'      => __( 'Kilométeróra állás', 'ki-mit-adna-erte' ),
			'fuel'         => __( 'Üzemanyag', 'ki-mit-adna-erte' ),
			'transmission' => __( 'Váltó', 'ki-mit-adna-erte' ),
			'body'         => __( 'Kivitel', 'ki-mit-adna-erte' ),
			'owners'       => __( 'Tulajdonosok száma', 'ki-mit-adna-erte' ),
			'condition'    => __( 'Állapot', 'ki-mit-adna-erte' ),
			'value'        => __( 'Autó becsült értéke', 'ki-mit-adna-erte' ),
		);

		foreach ( $required as $key => $label ) {
			if ( empty( $data[ $key ] ) ) {
				$missing[] = array(
					'field' => $key,
					'label' => $label,
				);
			}
		}

		$year = (int) ( $data['year'] ?? 0 );
		if ( $year && ( $year < 1950 || $year > (int) gmdate( 'Y' ) + 1 ) ) {
			$missing[] = array(
				'field' => 'year',
				'label' => __( 'Érvényes évjárat', 'ki-mit-adna-erte' ),
			);
		}

		return $missing;
	}

	public static function build_title_from_specs( $data ) {
		$parts = array_filter(
			array(
				$data['brand'] ?? '',
				$data['model'] ?? '',
				! empty( $data['year'] ) ? (string) $data['year'] : '',
			)
		);
		return implode( ' ', $parts );
	}

	public static function format_mileage( $km ) {
		if ( $km <= 0 ) {
			return '';
		}
		return number_format( $km, 0, ',', ' ' ) . ' km';
	}

	/**
	 * Display rows for templates.
	 *
	 * @return array<int, array{label:string,value:string}>
	 */
	public static function get_display_rows( $listing_id ) {
		if ( ! self::is_vehicle_launch() ) {
			return array();
		}

		$s = self::get_specs( $listing_id );
		$rows = array();

		$map = array(
			'year'         => array( __( 'Évjárat', 'ki-mit-adna-erte' ), $s['year'] ? (string) $s['year'] : '' ),
			'mileage'      => array( __( 'Km óra', 'ki-mit-adna-erte' ), self::format_mileage( $s['mileage'] ) ),
			'fuel'         => array( __( 'Üzemanyag', 'ki-mit-adna-erte' ), self::fuel_labels()[ $s['fuel'] ] ?? '' ),
			'transmission' => array( __( 'Váltó', 'ki-mit-adna-erte' ), self::transmission_labels()[ $s['transmission'] ] ?? '' ),
			'body'         => array( __( 'Kivitel', 'ki-mit-adna-erte' ), self::body_labels()[ $s['body'] ] ?? '' ),
			'color'        => array( __( 'Szín', 'ki-mit-adna-erte' ), $s['color'] ),
			'owners'       => array( __( 'Tulajdonos', 'ki-mit-adna-erte' ), $s['owners'] ? (string) $s['owners'] : '' ),
			'power_kw'     => array( __( 'Teljesítmény', 'ki-mit-adna-erte' ), $s['power_kw'] ? $s['power_kw'] . ' kW' : '' ),
			'engine_cc'    => array( __( 'Hengerűrtartalom', 'ki-mit-adna-erte' ), $s['engine_cc'] ? number_format( $s['engine_cc'], 0, ',', ' ' ) . ' cm³' : '' ),
			'value'        => array( __( 'Becsült érték', 'ki-mit-adna-erte' ), self::format_value( $s['value'] ) ),
			'condition'    => array( __( 'Állapot', 'ki-mit-adna-erte' ), self::condition_labels()[ $s['condition'] ] ?? '' ),
		);

		foreach ( $map as $row ) {
			if ( ! empty( $row[1] ) ) {
				$rows[] = array(
					'label' => $row[0],
					'value' => $row[1],
				);
			}
		}

		return $rows;
	}

	public static function get_display_title( $listing_id ) {
		$s = self::get_specs( $listing_id );
		if ( ! empty( $s['brand'] ) && ! empty( $s['model'] ) ) {
			return trim( $s['brand'] . ' ' . $s['model'] );
		}
		if ( ! empty( $s['brand'] ) ) {
			return $s['brand'];
		}
		return get_the_title( $listing_id );
	}

	public static function get_swipe_subtitle( $listing_id ) {
		$s = self::get_specs( $listing_id );
		$parts = array_filter(
			array(
				$s['year'] ? (string) $s['year'] : '',
				self::format_mileage( $s['mileage'] ),
				self::fuel_labels()[ $s['fuel'] ] ?? '',
			)
		);
		return implode( ' · ', $parts );
	}

	public static function parse_post_data() {
		return array(
			'brand'        => isset( $_POST['kmae_vehicle_brand'] ) ? sanitize_text_field( wp_unslash( $_POST['kmae_vehicle_brand'] ) ) : '',
			'model'        => isset( $_POST['kmae_vehicle_model'] ) ? sanitize_text_field( wp_unslash( $_POST['kmae_vehicle_model'] ) ) : '',
			'year'         => isset( $_POST['kmae_vehicle_year'] ) ? absint( $_POST['kmae_vehicle_year'] ) : 0,
			'mileage'      => isset( $_POST['kmae_vehicle_mileage'] ) ? absint( $_POST['kmae_vehicle_mileage'] ) : 0,
			'fuel'         => isset( $_POST['kmae_vehicle_fuel'] ) ? sanitize_key( wp_unslash( $_POST['kmae_vehicle_fuel'] ) ) : '',
			'transmission' => isset( $_POST['kmae_vehicle_transmission'] ) ? sanitize_key( wp_unslash( $_POST['kmae_vehicle_transmission'] ) ) : '',
			'body'         => isset( $_POST['kmae_vehicle_body'] ) ? sanitize_key( wp_unslash( $_POST['kmae_vehicle_body'] ) ) : '',
			'color'        => isset( $_POST['kmae_vehicle_color'] ) ? sanitize_text_field( wp_unslash( $_POST['kmae_vehicle_color'] ) ) : '',
			'owners'       => isset( $_POST['kmae_vehicle_owners'] ) ? absint( $_POST['kmae_vehicle_owners'] ) : 0,
			'power_kw'     => isset( $_POST['kmae_vehicle_power_kw'] ) ? absint( $_POST['kmae_vehicle_power_kw'] ) : 0,
			'engine_cc'    => isset( $_POST['kmae_vehicle_engine_cc'] ) ? absint( $_POST['kmae_vehicle_engine_cc'] ) : 0,
			'condition'    => isset( $_POST['kmae_condition'] ) ? sanitize_key( wp_unslash( $_POST['kmae_condition'] ) ) : '',
			'value'        => isset( $_POST['kmae_vehicle_value'] ) ? absint( $_POST['kmae_vehicle_value'] ) : 0,
			'title'        => isset( $_POST['kmae_title'] ) ? sanitize_text_field( wp_unslash( $_POST['kmae_title'] ) ) : '',
			'description'  => isset( $_POST['kmae_description'] ) ? wp_strip_all_tags( wp_unslash( $_POST['kmae_description'] ) ) : '',
		);
	}
}
