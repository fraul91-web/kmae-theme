<?php
/**
 * Offer submission and filtering logic.
 *
 * Core USP: hidden minimum — low offers are silently filtered, buyer never knows.
 *
 * @package KMAE
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class KMAE_Offers {

	const STATUS_PENDING   = 'pending';
	const STATUS_ACCEPTED  = 'accepted';
	const STATUS_REJECTED  = 'rejected';
	const STATUS_WITHDRAWN = 'withdrawn';

	/**
	 * Guard before submitting a new offer on a listing.
	 *
	 * @return true|WP_Error
	 */
	public static function guard_new_offer( $listing_id, $offerer_id ) {
		if ( KMAE_Database::get_withdrawn_user_offer_for_listing( $listing_id, $offerer_id ) ) {
			return new WP_Error(
				'withdrawn_blocked',
				__( 'Erre a hirdetésre már visszavontad az ajánlatod — nem adhatsz újat.', 'ki-mit-adna-erte' )
			);
		}

		if ( KMAE_Database::get_active_user_offer_for_listing( $listing_id, $offerer_id ) ) {
			return new WP_Error(
				'already_offered',
				__( 'Erre a hirdetésre már adtál ajánlatot.', 'ki-mit-adna-erte' )
			);
		}

		return true;
	}

	/**
	 * Private buyers must accept the fair-buyer pledge when offering.
	 *
	 * @param int $offerer_id Buyer.
	 * @return true|WP_Error
	 */
	public static function require_fair_buyer_pledge( $offerer_id ) {
		if ( ! KMAE_Auth::is_private_person( $offerer_id ) ) {
			return true;
		}
		if ( empty( $_POST['kmae_fair_buyer'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
			return new WP_Error(
				'fair_buyer_required',
				__( 'A tisztességes vevő vállalás elfogadása kötelező az ajánlathoz.', 'ki-mit-adna-erte' )
			);
		}
		update_user_meta( $offerer_id, 'kmae_fair_buyer_pledge', 1 );
		return true;
	}

	public static function submit_cash_offer( $listing_id, $offerer_id, $amount ) {
		global $wpdb;

		$guard = self::guard_new_offer( $listing_id, $offerer_id );
		if ( is_wp_error( $guard ) ) {
			return $guard;
		}

		$pledge = self::require_fair_buyer_pledge( $offerer_id );
		if ( is_wp_error( $pledge ) ) {
			return $pledge;
		}

		$listing = get_post( $listing_id );
		if ( ! $listing || 'kmae_listing' !== $listing->post_type ) {
			return new WP_Error( 'invalid_listing', __( 'Érvénytelen hirdetés.', 'ki-mit-adna-erte' ) );
		}

		if ( (int) $listing->post_author === (int) $offerer_id ) {
			return new WP_Error( 'own_listing', __( 'Saját hirdetésedre nem adhatsz ajánlatot.', 'ki-mit-adna-erte' ) );
		}

		if ( KMAE_Meta::STATUS_ACTIVE !== KMAE_Meta::get_status( $listing_id ) ) {
			return new WP_Error( 'closed', __( 'Ez a hirdetés már nem fogad ajánlatokat.', 'ki-mit-adna-erte' ) );
		}

		if ( ! KMAE_Meta::accepts_offer_type( $listing_id, KMAE_OFFER_TYPE_CASH ) ) {
			return new WP_Error( 'type_not_accepted', __( 'Ez a hirdetés nem fogad készpénzes ajánlatot.', 'ki-mit-adna-erte' ) );
		}

		$filtered_out = 0;
		$private      = KMAE_Database::get_private_data( $listing_id );
		if ( $private && $amount < (float) $private->minimum_cash ) {
			$filtered_out = 1;
		}

		if ( KMAE_Seller::is_fixed_price( $listing_id ) ) {
			$fixed = KMAE_Seller::get_fixed_price( $listing_id );
			if ( $fixed > 0 && abs( $amount - $fixed ) > 0.5 ) {
				return new WP_Error(
					'fixed_price_only',
					sprintf(
						/* translators: %s: formatted price */
						__( 'Ez fix áras hirdetés. Készpénzben csak ennyit lehet megajánlani: %s', 'ki-mit-adna-erte' ),
						number_format( $fixed, 0, ',', ' ' ) . ' Ft'
					)
				);
			}
			$filtered_out = 0;
		}

		$inserted = $wpdb->insert(
			KMAE_Database::table( 'offers' ),
			array(
				'listing_id'   => $listing_id,
				'offerer_id'   => $offerer_id,
				'offer_type'   => KMAE_OFFER_TYPE_CASH,
				'cash_amount'  => $amount,
				'currency'     => 'HUF',
				'status'       => self::STATUS_PENDING,
				'filtered_out' => $filtered_out,
			),
			array( '%d', '%d', '%s', '%f', '%s', '%s', '%d' )
		);

		if ( false === $inserted ) {
			return new WP_Error( 'db_error', __( 'Az ajánlat mentése sikertelen.', 'ki-mit-adna-erte' ) );
		}

		$offer_id = $wpdb->insert_id;

		if ( ! $filtered_out ) {
			do_action( 'kmae_new_offer', $offer_id, $listing_id, $offerer_id );
		}

		// Buyer always sees success — even if filtered out.
		return $offer_id;
	}

	public static function submit_trade_offer( $listing_id, $offerer_id, $attachment_ids, $mode = 'trade', $extra_cash = 0 ) {
		global $wpdb;

		$guard = self::guard_new_offer( $listing_id, $offerer_id );
		if ( is_wp_error( $guard ) ) {
			return $guard;
		}

		$pledge = self::require_fair_buyer_pledge( $offerer_id );
		if ( is_wp_error( $pledge ) ) {
			return $pledge;
		}

		$listing = get_post( $listing_id );
		if ( ! $listing || 'kmae_listing' !== $listing->post_type ) {
			return new WP_Error( 'invalid_listing', __( 'Érvénytelen hirdetés.', 'ki-mit-adna-erte' ) );
		}

		if ( (int) $listing->post_author === (int) $offerer_id ) {
			return new WP_Error( 'own_listing', __( 'Saját hirdetésedre nem adhatsz ajánlatot.', 'ki-mit-adna-erte' ) );
		}

		if ( KMAE_Meta::STATUS_ACTIVE !== KMAE_Meta::get_status( $listing_id ) ) {
			return new WP_Error( 'closed', __( 'Ez a hirdetés már nem fogad ajánlatokat.', 'ki-mit-adna-erte' ) );
		}

		if ( empty( $attachment_ids ) ) {
			return new WP_Error( 'no_images', __( 'Csere ajánlathoz legalább egy kép szükséges.', 'ki-mit-adna-erte' ) );
		}

		$mode_map = array(
			'trade'            => KMAE_OFFER_TYPE_TRADE,
			'trade_plus_cash'  => KMAE_OFFER_TYPE_TRADE_PLUS_CASH,
			'trade_in'         => KMAE_OFFER_TYPE_TRADE_IN,
		);
		$offer_type = $mode_map[ $mode ] ?? KMAE_OFFER_TYPE_TRADE;

		if ( ! KMAE_Meta::accepts_offer_type( $listing_id, $offer_type ) ) {
			return new WP_Error( 'type_not_accepted', __( 'Ez a hirdetés nem fogad ilyen típusú ajánlatot.', 'ki-mit-adna-erte' ) );
		}

		$cash_amount = $extra_cash > 0 ? $extra_cash : null;
		if ( KMAE_OFFER_TYPE_TRADE === $offer_type ) {
			$cash_amount = null;
		}

		$wpdb->insert(
			KMAE_Database::table( 'offers' ),
			array(
				'listing_id'  => $listing_id,
				'offerer_id'  => $offerer_id,
				'offer_type'  => $offer_type,
				'cash_amount' => $cash_amount,
				'currency'    => 'HUF',
				'status'      => self::STATUS_PENDING,
			),
			array( '%d', '%d', '%s', '%f', '%s', '%s' )
		);

		$offer_id = $wpdb->insert_id;

		foreach ( $attachment_ids as $i => $attachment_id ) {
			$wpdb->insert(
				KMAE_Database::table( 'offer_images' ),
				array(
					'offer_id'      => $offer_id,
					'attachment_id' => absint( $attachment_id ),
					'sort_order'    => $i,
				),
				array( '%d', '%d', '%d' )
			);
		}

		do_action( 'kmae_new_offer', $offer_id, $listing_id, $offerer_id );

		return $offer_id;
	}

	public static function get_offerer_display_name( $user_id ) {
		$user = get_userdata( $user_id );
		if ( ! $user ) {
			return __( 'Ismeretlen', 'ki-mit-adna-erte' );
		}
		if ( class_exists( 'KMAE_Company' ) && KMAE_Auth::is_company( $user_id ) ) {
			$name = KMAE_Company::get_company_name( $user_id );
			if ( $name ) {
				return $name;
			}
		}
		return $user->display_name ?: $user->user_login;
	}

	public static function format_cash( $amount ) {
		return number_format( (float) $amount, 0, ',', ' ' ) . ' Ft';
	}

	/**
	 * Parse user-entered amount (supports spaced thousands, e.g. "10 000").
	 */
	public static function parse_amount_input( $raw ) {
		if ( is_numeric( $raw ) ) {
			return (float) $raw;
		}
		$digits = preg_replace( '/[^\d]/', '', (string) wp_unslash( $raw ) );
		return '' !== $digits ? (float) $digits : 0.0;
	}

	public static function can_withdraw( $offer, $user_id ) {
		return $offer
			&& (int) $offer->offerer_id === (int) $user_id
			&& self::STATUS_PENDING === $offer->status;
	}

	public static function withdraw_offer( $offer_id, $user_id ) {
		$offer = KMAE_Database::get_offer( $offer_id );
		if ( ! $offer ) {
			return new WP_Error( 'invalid_offer', __( 'Érvénytelen ajánlat.', 'ki-mit-adna-erte' ) );
		}

		if ( ! self::can_withdraw( $offer, $user_id ) ) {
			return new WP_Error( 'not_allowed', __( 'Ezt az ajánlatot nem vonhatod vissza.', 'ki-mit-adna-erte' ) );
		}

		KMAE_Database::update_offer_status( $offer_id, self::STATUS_WITHDRAWN );
		do_action( 'kmae_offer_withdrawn', $offer_id, $user_id );

		return true;
	}

	public static function is_active_for_listing( $offer ) {
		return $offer && in_array(
			$offer->status,
			array( self::STATUS_PENDING, self::STATUS_ACCEPTED ),
			true
		);
	}

	public static function get_offer_summary( $offer ) {
		if ( KMAE_OFFER_TYPE_CASH === $offer->offer_type && $offer->cash_amount ) {
			return self::format_cash( $offer->cash_amount );
		}
		if ( in_array( $offer->offer_type, array( KMAE_OFFER_TYPE_TRADE, KMAE_OFFER_TYPE_TRADE_IN ), true ) ) {
			$sum = __( 'Csere ajánlat (kép)', 'ki-mit-adna-erte' );
			if ( KMAE_OFFER_TYPE_TRADE_IN === $offer->offer_type && $offer->cash_amount ) {
				$sum .= ' + ' . self::format_cash( $offer->cash_amount );
			}
			return $sum;
		}
		if ( KMAE_OFFER_TYPE_TRADE_PLUS_CASH === $offer->offer_type ) {
			$images = KMAE_Database::get_offer_images( $offer->id );
			$sum    = __( 'Csere + ráfizetés', 'ki-mit-adna-erte' );
			if ( $offer->cash_amount ) {
				$sum .= ' (' . self::format_cash( $offer->cash_amount ) . ')';
			}
			return $sum;
		}
		return __( 'Ajánlat', 'ki-mit-adna-erte' );
	}

	public static function render_offer_images( $offer_id ) {
		$images = KMAE_Database::get_offer_images( $offer_id );
		if ( empty( $images ) ) {
			return '';
		}
		ob_start();
		echo '<div class="kmae-offer-images">';
		foreach ( $images as $img ) {
			$url = wp_get_attachment_image_url( $img->attachment_id, 'medium' );
			if ( $url ) {
				echo '<img src="' . esc_url( $url ) . '" alt="" class="kmae-offer-thumb" />';
			}
		}
		echo '</div>';
		return ob_get_clean();
	}
}
