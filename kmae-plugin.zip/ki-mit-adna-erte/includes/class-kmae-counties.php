<?php
/**
 * Hungarian counties (megyék) for location and map browse.
 *
 * @package KMAE
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class KMAE_Counties {

	const ORSZAG = 'orszag';

	/**
	 * @return array<string, string> slug => label
	 */
	public static function get_all() {
		return array(
			'bacs-kiskun'           => 'Bács-Kiskun',
			'baranya'               => 'Baranya',
			'bekes'                 => 'Békés',
			'borsod-abauj-zemplen'  => 'Borsod-Abaúj-Zemplén',
			'budapest'              => 'Budapest',
			'csongrad-csanad'       => 'Csongrád-Csanád',
			'fejer'                 => 'Fejér',
			'gyor-moson-sopron'     => 'Győr-Moson-Sopron',
			'hajdu-bihar'           => 'Hajdú-Bihar',
			'heves'                 => 'Heves',
			'jasz-nagykun-szolnok'  => 'Jász-Nagykun-Szolnok',
			'komarom-esztergom'     => 'Komárom-Esztergom',
			'nograd'                => 'Nógrád',
			'pest'                  => 'Pest',
			'somogy'                => 'Somogy',
			'szabolcs-szatmar-bereg' => 'Szabolcs-Szatmár-Bereg',
			'tolna'                 => 'Tolna',
			'vas'                   => 'Vas',
			'veszprem'              => 'Veszprém',
			'zala'                  => 'Zala',
		);
	}

	public static function is_valid( $slug ) {
		return self::ORSZAG === $slug || isset( self::get_all()[ $slug ] );
	}

	public static function is_listing_county( $slug ) {
		return isset( self::get_all()[ $slug ] );
	}

	public static function get_label( $slug ) {
		if ( self::ORSZAG === $slug ) {
			return __( 'Egész ország', 'ki-mit-adna-erte' );
		}
		return self::get_all()[ $slug ] ?? $slug;
	}

	/**
	 * Real county paths from Wikipedia HU_counties_blank.svg (public domain).
	 *
	 * @return array{viewBox: string, counties: array<string, array{d: string, cx: float, cy: float}>}
	 */
	public static function get_map_data() {
		static $data = null;
		if ( null !== $data ) {
			return $data;
		}

		$file = KMAE_PLUGIN_DIR . 'assets/data/counties-paths.json';
		if ( ! is_readable( $file ) ) {
			return array(
				'viewBox'  => '0 0 841.89 595.28',
				'counties' => array(),
			);
		}

		$json = file_get_contents( $file ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		$data = json_decode( $json, true );
		if ( ! is_array( $data ) ) {
			$data = array(
				'viewBox'  => '0 0 841.89 595.28',
				'counties' => array(),
			);
		}

		return $data;
	}

	/**
	 * @return array<string, string> slug => SVG path d
	 */
	public static function get_map_paths() {
		$data   = self::get_map_data();
		$paths  = array();
		foreach ( $data['counties'] ?? array() as $slug => $info ) {
			$paths[ $slug ] = $info['d'] ?? '';
		}
		return $paths;
	}

	/** @deprecated Use get_map_data() centroids */
	public static function get_map_label_xy( $slug ) {
		$data = self::get_map_data();
		$info = $data['counties'][ $slug ] ?? null;
		if ( $info ) {
			return $info['cx'] . ',' . $info['cy'];
		}
		return '0,0';
	}

	public static function format_listing_location( $post_id ) {
		$county = get_post_meta( $post_id, '_kmae_county', true );
		$city   = get_post_meta( $post_id, '_kmae_city', true );

		if ( $county && $city ) {
			return self::get_label( $county ) . ', ' . $city;
		}

		return (string) get_post_meta( $post_id, '_kmae_location', true );
	}

	public static function validate_listing_location( $county, $city ) {
		if ( ! self::is_listing_county( $county ) ) {
			return false;
		}
		return '' !== trim( (string) $city );
	}

	public static function save_listing_location( $post_id, $county, $city ) {
		$county = sanitize_text_field( $county );
		$city   = sanitize_text_field( $city );

		update_post_meta( $post_id, '_kmae_county', $county );
		update_post_meta( $post_id, '_kmae_city', $city );
		update_post_meta( $post_id, '_kmae_location', self::get_label( $county ) . ', ' . $city );
	}

	public static function get_map_label_short( $slug ) {
		$short = array(
			'budapest'               => 'Bp.',
			'bacs-kiskun'            => 'B-K',
			'borsod-abauj-zemplen'   => 'BAZ',
			'csongrad-csanad'        => 'Cs.',
			'gyor-moson-sopron'      => 'Gy-M-S',
			'hajdu-bihar'            => 'HB',
			'jasz-nagykun-szolnok'   => 'J-N-Sz',
			'komarom-esztergom'      => 'K-E',
			'szabolcs-szatmar-bereg' => 'Sz-Sz-B',
		);
		if ( isset( $short[ $slug ] ) ) {
			return $short[ $slug ];
		}
		$label = self::get_all()[ $slug ] ?? '';
		return mb_strlen( $label ) > 10 ? mb_substr( $label, 0, 8 ) . '.' : $label;
	}

}
