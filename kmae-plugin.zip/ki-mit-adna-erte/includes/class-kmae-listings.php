<?php
/**
 * Delete listing and related data.
 *
 * @package KMAE
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class KMAE_Listings {

	public static function init() {
		add_action( 'kmae_offer_accepted', array( 'KMAE_Deal', 'lock_on_accept' ), 5, 2 );
		add_action( 'kmae_purge_archived_listings', array( __CLASS__, 'purge_expired_archived' ) );
		add_action( 'kmae_listing_published', array( 'KMAE_Premium', 'maybe_auto_feature_listing' ), 10, 1 );
		KMAE_Activator::schedule_cron();
	}

	/**
	 * @deprecated Archive now happens via KMAE_Deal::confirm_success.
	 */
	public static function archive_on_deal( $offer_id, $user_id ) {
		KMAE_Deal::lock_on_accept( $offer_id, $user_id );
	}

	/**
	 * Lifecycle info for archived listings (null if not archived).
	 *
	 * @return array{phase:string,days_until_reactivate?:int,days_until_delete:int}|null
	 */
	public static function get_archive_lifecycle( $listing_id ) {
		if ( KMAE_Meta::STATUS_ARCHIVED !== KMAE_Meta::get_status( $listing_id ) ) {
			return null;
		}

		$archived_at = get_post_meta( $listing_id, '_kmae_archived_at', true );
		if ( ! $archived_at ) {
			return array(
				'phase'               => 'locked',
				'days_until_reactivate' => KMAE_ARCHIVE_LOCK_DAYS,
				'days_until_delete'   => KMAE_ARCHIVE_TOTAL_DAYS,
			);
		}

		$archived_ts  = strtotime( $archived_at );
		$now          = current_time( 'timestamp' );
		$elapsed      = max( 0, (int) floor( ( $now - $archived_ts ) / DAY_IN_SECONDS ) );
		$until_delete = max( 0, KMAE_ARCHIVE_TOTAL_DAYS - $elapsed );

		if ( $elapsed < KMAE_ARCHIVE_LOCK_DAYS ) {
			return array(
				'phase'                 => 'locked',
				'days_until_reactivate' => KMAE_ARCHIVE_LOCK_DAYS - $elapsed,
				'days_until_delete'     => $until_delete,
			);
		}

		if ( $elapsed < KMAE_ARCHIVE_TOTAL_DAYS ) {
			return array(
				'phase'             => 'reactivate',
				'days_until_delete' => $until_delete,
			);
		}

		return array(
			'phase'             => 'expired',
			'days_until_delete' => 0,
		);
	}

	public static function is_archive_locked( $listing_id ) {
		$lifecycle = self::get_archive_lifecycle( $listing_id );
		return $lifecycle && 'locked' === $lifecycle['phase'];
	}

	public static function can_reactivate_listing( $listing_id ) {
		$lifecycle = self::get_archive_lifecycle( $listing_id );
		return $lifecycle && 'reactivate' === $lifecycle['phase'];
	}

	public static function can_edit_listing( $listing_id ) {
		return ! self::is_archive_locked( $listing_id ) && ! self::can_reactivate_listing( $listing_id )
			&& KMAE_Meta::STATUS_ARCHIVED !== KMAE_Meta::get_status( $listing_id );
	}

	public static function can_delete_listing( $listing_id ) {
		if ( KMAE_Meta::STATUS_ARCHIVED !== KMAE_Meta::get_status( $listing_id ) ) {
			return true;
		}
		return self::can_reactivate_listing( $listing_id );
	}

	public static function reactivate_listing( $listing_id, $user_id ) {
		if ( ! self::user_owns_listing( $listing_id, $user_id ) ) {
			return new WP_Error( 'forbidden', __( 'Nincs jogosultságod ehhez.', 'ki-mit-adna-erte' ) );
		}

		if ( ! self::can_reactivate_listing( $listing_id ) ) {
			return new WP_Error( 'not_allowed', __( 'Ez a hirdetés még nem aktiválható újra, vagy már lejárt az idő.', 'ki-mit-adna-erte' ) );
		}

		update_post_meta( $listing_id, '_kmae_status', KMAE_Meta::STATUS_ACTIVE );
		delete_post_meta( $listing_id, '_kmae_archived_at' );
		delete_post_meta( $listing_id, '_kmae_accepted_offer_id' );
		update_post_meta( $listing_id, '_kmae_reactivated_at', current_time( 'mysql' ) );

		do_action( 'kmae_listing_published', $listing_id );

		return true;
	}

	/**
	 * Daily cron: delete archived listings past the reactivation window.
	 */
	public static function purge_expired_archived() {
		$cutoff = gmdate( 'Y-m-d H:i:s', current_time( 'timestamp' ) - ( KMAE_ARCHIVE_TOTAL_DAYS * DAY_IN_SECONDS ) );

		$query = new WP_Query(
			array(
				'post_type'      => 'kmae_listing',
				'post_status'    => 'publish',
				'posts_per_page' => 50,
				'fields'         => 'ids',
				'meta_query'     => array(
					'relation' => 'AND',
					array(
						'key'   => '_kmae_status',
						'value' => KMAE_Meta::STATUS_ARCHIVED,
					),
					array(
						'key'     => '_kmae_archived_at',
						'value'   => $cutoff,
						'compare' => '<=',
						'type'    => 'DATETIME',
					),
				),
			)
		);

		foreach ( $query->posts as $listing_id ) {
			$post = get_post( $listing_id );
			if ( ! $post ) {
				continue;
			}
			self::delete_listing( (int) $listing_id, (int) $post->post_author );
		}
	}

	public static function user_owns_listing( $listing_id, $user_id ) {
		$listing = get_post( $listing_id );
		return $listing && 'kmae_listing' === $listing->post_type && (int) $listing->post_author === (int) $user_id;
	}

	/**
	 * Activate listing when required vehicle photos are complete.
	 *
	 * @param int $listing_id Listing ID.
	 * @return bool True if activated (or already active with photos).
	 */
	public static function activate_if_photos_ready( $listing_id ) {
		if ( ! KMAE_Photo_Motor::is_enabled() ) {
			return false;
		}
		if ( KMAE_Photo_Motor::count_required_filled( $listing_id ) < KMAE_Photo_Motor::required_count() ) {
			return false;
		}

		$was = KMAE_Meta::get_status( $listing_id );
		update_post_meta( $listing_id, '_kmae_status', KMAE_Meta::STATUS_ACTIVE );
		if ( ! get_post_meta( $listing_id, '_kmae_published_at', true ) ) {
			update_post_meta( $listing_id, '_kmae_published_at', current_time( 'mysql' ) );
		}

		if ( KMAE_Meta::STATUS_AWAITING_PHOTOS === $was ) {
			do_action( 'kmae_listing_published', $listing_id );
		}

		return true;
	}

	public static function save_meta_from_post( $post_id, $is_new = false, $initial_status = null ) {
		$county    = isset( $_POST['kmae_county'] ) ? sanitize_text_field( wp_unslash( $_POST['kmae_county'] ) ) : '';
		$city      = isset( $_POST['kmae_city'] ) ? sanitize_text_field( wp_unslash( $_POST['kmae_city'] ) ) : '';
		$condition = isset( $_POST['kmae_condition'] ) ? sanitize_text_field( wp_unslash( $_POST['kmae_condition'] ) ) : '';

		if ( KMAE_Counties::validate_listing_location( $county, $city ) ) {
			KMAE_Counties::save_listing_location( $post_id, $county, $city );
		}

		update_post_meta( $post_id, '_kmae_condition', $condition );

		if ( $is_new ) {
			$status = in_array( $initial_status, array( KMAE_Meta::STATUS_ACTIVE, KMAE_Meta::STATUS_AWAITING_PHOTOS ), true )
				? $initial_status
				: KMAE_Meta::STATUS_ACTIVE;
			update_post_meta( $post_id, '_kmae_status', $status );
			if ( KMAE_Meta::STATUS_ACTIVE === $status ) {
				update_post_meta( $post_id, '_kmae_published_at', current_time( 'mysql' ) );
			}
		}

		KMAE_Vehicle::save_from_post( $post_id );

		$offer_types = isset( $_POST['kmae_offer_types'] ) ? array_map( 'sanitize_text_field', wp_unslash( (array) $_POST['kmae_offer_types'] ) ) : array();
		update_post_meta( $post_id, '_kmae_offer_types', $offer_types );

		$trade_in = isset( $_POST['kmae_trade_in_categories'] ) ? array_map( 'absint', wp_unslash( (array) $_POST['kmae_trade_in_categories'] ) ) : array();
		update_post_meta( $post_id, '_kmae_trade_in_categories', $trade_in );

		$seller_save = KMAE_Seller::save_from_post( $post_id, $is_new );
		if ( is_wp_error( $seller_save ) ) {
			return $seller_save;
		}

		$category_id = isset( $_POST['kmae_category'] ) ? absint( $_POST['kmae_category'] ) : 0;
		if ( $category_id ) {
			wp_set_object_terms( $post_id, array( $category_id ), 'kmae_category' );
		}

		return true;
	}

	public static function handle_image_uploads( $post_id, $existing_gallery = array() ) {
		if ( KMAE_Photo_Motor::is_enabled() ) {
			return KMAE_Photo_Motor::handle_slot_uploads( $post_id, $existing_gallery );
		}

		if ( empty( $_FILES['kmae_images']['name'] ) ) {
			return $existing_gallery;
		}

		// Single or multiple file field.
		if ( ! is_array( $_FILES['kmae_images']['name'] ) ) {
			$_FILES['kmae_images'] = array(
				'name'     => array( $_FILES['kmae_images']['name'] ),
				'type'     => array( $_FILES['kmae_images']['type'] ),
				'tmp_name' => array( $_FILES['kmae_images']['tmp_name'] ),
				'error'    => array( $_FILES['kmae_images']['error'] ),
				'size'     => array( $_FILES['kmae_images']['size'] ),
			);
		}

		if ( empty( $_FILES['kmae_images']['name'][0] ) ) {
			return $existing_gallery;
		}

		require_once ABSPATH . 'wp-admin/includes/image.php';
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';

		$gallery_ids = $existing_gallery;
		$files       = $_FILES['kmae_images'];
		$count       = count( $files['name'] );
		$has_thumb   = has_post_thumbnail( $post_id );

		for ( $i = 0; $i < $count && count( $gallery_ids ) < 12; $i++ ) {
			if ( empty( $files['name'][ $i ] ) ) {
				continue;
			}
			if ( ! empty( $files['error'][ $i ] ) && UPLOAD_ERR_OK !== (int) $files['error'][ $i ] ) {
				continue;
			}

			$_FILES['kmae_single_image'] = array(
				'name'     => $files['name'][ $i ],
				'type'     => $files['type'][ $i ],
				'tmp_name' => $files['tmp_name'][ $i ],
				'error'    => $files['error'][ $i ],
				'size'     => $files['size'][ $i ],
			);

			$attachment_id = media_handle_upload( 'kmae_single_image', $post_id );
			if ( is_wp_error( $attachment_id ) ) {
				continue;
			}

			KMAE_Images::process_attachment( $attachment_id );

			$gallery_ids[] = $attachment_id;
			if ( ! $has_thumb ) {
				set_post_thumbnail( $post_id, $attachment_id );
				$has_thumb = true;
			}
		}

		if ( ! empty( $gallery_ids ) ) {
			update_post_meta( $post_id, '_kmae_gallery', $gallery_ids );
			set_post_thumbnail( $post_id, $gallery_ids[0] );
		}

		return $gallery_ids;
	}

	/**
	 * Apply reorder / delete from edit form before new uploads.
	 */
	public static function apply_gallery_edits( $post_id, $existing_gallery ) {
		$existing_gallery = array_map( 'absint', (array) $existing_gallery );
		$allowed          = array_flip( $existing_gallery );

		$order  = isset( $_POST['kmae_gallery_order'] ) ? array_map( 'absint', wp_unslash( (array) $_POST['kmae_gallery_order'] ) ) : $existing_gallery;
		$remove = isset( $_POST['kmae_remove_images'] ) ? array_map( 'absint', wp_unslash( (array) $_POST['kmae_remove_images'] ) ) : array();

		foreach ( $remove as $attachment_id ) {
			if ( ! $attachment_id || ! isset( $allowed[ $attachment_id ] ) ) {
				continue;
			}
			if ( ! self::attachment_belongs_to_listing( $attachment_id, $post_id ) ) {
				continue;
			}
			wp_delete_attachment( $attachment_id, true );
			unset( $allowed[ $attachment_id ] );
		}

		$gallery_ids = array();
		foreach ( $order as $attachment_id ) {
			if ( ! $attachment_id || ! isset( $allowed[ $attachment_id ] ) ) {
				continue;
			}
			if ( in_array( $attachment_id, $remove, true ) ) {
				continue;
			}
			if ( ! self::attachment_belongs_to_listing( $attachment_id, $post_id ) ) {
				continue;
			}
			$gallery_ids[] = $attachment_id;
		}

		if ( ! empty( $gallery_ids ) ) {
			update_post_meta( $post_id, '_kmae_gallery', $gallery_ids );
			set_post_thumbnail( $post_id, $gallery_ids[0] );
		} else {
			delete_post_meta( $post_id, '_kmae_gallery' );
			delete_post_thumbnail( $post_id );
		}

		return $gallery_ids;
	}

	private static function attachment_belongs_to_listing( $attachment_id, $post_id ) {
		$attachment = get_post( $attachment_id );
		return $attachment
			&& 'attachment' === $attachment->post_type
			&& (int) $attachment->post_parent === (int) $post_id;
	}

	public static function delete_listing( $listing_id, $user_id ) {
		if ( ! self::user_owns_listing( $listing_id, $user_id ) && ! current_user_can( 'manage_options' ) ) {
			return new WP_Error( 'forbidden', __( 'Nincs jogosultságod ehhez.', 'ki-mit-adna-erte' ) );
		}

		return self::force_delete_listing( $listing_id );
	}

	/**
	 * Delete listing and related data (admin or owner after permission check).
	 */
	public static function force_delete_listing( $listing_id ) {
		global $wpdb;

		$listing = get_post( $listing_id );
		if ( ! $listing || 'kmae_listing' !== $listing->post_type ) {
			return new WP_Error( 'invalid', __( 'Érvénytelen hirdetés.', 'ki-mit-adna-erte' ) );
		}

		$offers = KMAE_Database::get_offers_for_listing( $listing_id, true );
		KMAE_Notifications::on_listing_deleted( $listing_id, $listing, $offers );

		foreach ( $offers as $offer ) {
			$wpdb->delete( KMAE_Database::table( 'counter_offers' ), array( 'offer_id' => $offer->id ), array( '%d' ) );
			$wpdb->delete( KMAE_Database::table( 'offer_images' ), array( 'offer_id' => $offer->id ), array( '%d' ) );
			$wpdb->delete( KMAE_Database::table( 'contact_unlocks' ), array( 'offer_id' => $offer->id ), array( '%d' ) );
		}

		$wpdb->delete( KMAE_Database::table( 'offers' ), array( 'listing_id' => $listing_id ), array( '%d' ) );
		$wpdb->delete( KMAE_Database::table( 'private_data' ), array( 'listing_id' => $listing_id ), array( '%d' ) );

		$deleted = wp_delete_post( $listing_id, true );
		if ( ! $deleted ) {
			return new WP_Error( 'delete_failed', __( 'A hirdetés törlése sikertelen.', 'ki-mit-adna-erte' ) );
		}

		return true;
	}
}
