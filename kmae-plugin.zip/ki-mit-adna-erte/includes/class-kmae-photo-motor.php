<?php
/**
 * Listing photo trust motor — required/recommended slots + basic quality gates.
 *
 * @package KMAE
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class KMAE_Photo_Motor {

	const META_SLOTS = '_kmae_photo_slots';
	const ATTACH_SLOT_META = '_kmae_photo_slot';
	const ATTACH_HASH_META = '_kmae_photo_hash';

	/**
	 * 7 kötelező nézet (diagram pontokkal).
	 *
	 * @return array<string, array{label:string,hint:string,required:bool,x:float,y:float}>
	 */
	public static function required_slots() {
		return array(
			'front_left'  => array(
				'label'    => __( 'Bal első', 'ki-mit-adna-erte' ),
				'hint'     => __( 'Fotózd le az autót bal elölről.', 'ki-mit-adna-erte' ),
				'required' => true,
				'x'        => 22,
				'y'        => 18,
			),
			'front_right' => array(
				'label'    => __( 'Jobb első', 'ki-mit-adna-erte' ),
				'hint'     => __( 'Fotózd le az autót jobb elölről.', 'ki-mit-adna-erte' ),
				'required' => true,
				'x'        => 78,
				'y'        => 18,
			),
			'rear_left'   => array(
				'label'    => __( 'Bal hátul', 'ki-mit-adna-erte' ),
				'hint'     => __( 'Fotózd le az autót bal hátulról.', 'ki-mit-adna-erte' ),
				'required' => true,
				'x'        => 22,
				'y'        => 82,
			),
			'rear_right'  => array(
				'label'    => __( 'Jobb hátul', 'ki-mit-adna-erte' ),
				'hint'     => __( 'Fotózd le az autót jobb hátulról.', 'ki-mit-adna-erte' ),
				'required' => true,
				'x'        => 78,
				'y'        => 82,
			),
			'side'        => array(
				'label'    => __( 'Oldalnézet', 'ki-mit-adna-erte' ),
				'hint'     => __( 'Teljes oldalnézet — az autó egésze látszódjon.', 'ki-mit-adna-erte' ),
				'required' => true,
				'x'        => 12,
				'y'        => 50,
			),
			'interior'    => array(
				'label'    => __( 'Belső tér', 'ki-mit-adna-erte' ),
				'hint'     => __( 'Fotózd le a belső teret (ülések, műszerfal felől).', 'ki-mit-adna-erte' ),
				'required' => true,
				'x'        => 50,
				'y'        => 48,
			),
			'odometer'    => array(
				'label'    => __( 'Műszerfal / kilométeróra', 'ki-mit-adna-erte' ),
				'hint'     => __( 'A kilométeróra állása legyen jól olvasható.', 'ki-mit-adna-erte' ),
				'required' => true,
				'x'        => 50,
				'y'        => 32,
			),
		);
	}

	/**
	 * 6 ajánlott — összesen 13 fotópont.
	 *
	 * @return array<string, array{label:string,hint:string,required:bool,x:float,y:float}>
	 */
	public static function recommended_slots() {
		return array(
			'engine_bay'  => array(
				'label'    => __( 'Motorháztető alatt', 'ki-mit-adna-erte' ),
				'hint'     => __( 'Motortér — tiszta rálátással.', 'ki-mit-adna-erte' ),
				'required' => false,
				'x'        => 50,
				'y'        => 12,
			),
			'trunk'       => array(
				'label'    => __( 'Csomagtartó', 'ki-mit-adna-erte' ),
				'hint'     => __( 'Nyitott csomagtartó.', 'ki-mit-adna-erte' ),
				'required' => false,
				'x'        => 50,
				'y'        => 88,
			),
			'front_seats' => array(
				'label'    => __( 'Ülések', 'ki-mit-adna-erte' ),
				'hint'     => __( 'Első / hátsó ülések állapota.', 'ki-mit-adna-erte' ),
				'required' => false,
				'x'        => 58,
				'y'        => 55,
			),
			'wheels'      => array(
				'label'    => __( 'Felnik / gumik', 'ki-mit-adna-erte' ),
				'hint'     => __( 'Kerék / felni és profil közelről.', 'ki-mit-adna-erte' ),
				'required' => false,
				'x'        => 88,
				'y'        => 50,
			),
			'windshield'  => array(
				'label'    => __( 'Szélvédő', 'ki-mit-adna-erte' ),
				'hint'     => __( 'Szélvédő állapota.', 'ki-mit-adna-erte' ),
				'required' => false,
				'x'        => 50,
				'y'        => 24,
			),
			'damage'      => array(
				'label'    => __( 'Sérülések / hibák', 'ki-mit-adna-erte' ),
				'hint'     => __( 'Karc, horpadás, rozsda, fényezési hiba — ha van, mutasd meg.', 'ki-mit-adna-erte' ),
				'required' => false,
				'x'        => 30,
				'y'        => 65,
			),
		);
	}

	/**
	 * @return int
	 */
	public static function recommended_total_count() {
		return count( self::all_slots() );
	}

	/**
	 * @return array<string, array{label:string,hint:string,required:bool}>
	 */
	public static function all_slots() {
		return array_merge( self::required_slots(), self::recommended_slots() );
	}

	public static function required_count() {
		return count( self::required_slots() );
	}

	public static function is_enabled() {
		return KMAE_Vehicle::is_vehicle_launch();
	}

	/**
	 * @param int $listing_id Listing ID.
	 * @return array<string, int> slot => attachment_id
	 */
	public static function get_slots( $listing_id ) {
		$raw = get_post_meta( $listing_id, self::META_SLOTS, true );
		if ( ! is_array( $raw ) ) {
			return array();
		}
		$out     = array();
		$allowed = array_keys( self::all_slots() );
		foreach ( $raw as $slot => $id ) {
			$slot = sanitize_key( $slot );
			$id   = absint( $id );
			if ( $id && in_array( $slot, $allowed, true ) ) {
				$out[ $slot ] = $id;
			}
		}
		return $out;
	}

	/**
	 * @param int $listing_id Listing ID.
	 * @return int
	 */
	public static function count_required_filled( $listing_id ) {
		$slots = self::get_slots( $listing_id );
		$n     = 0;
		foreach ( array_keys( self::required_slots() ) as $key ) {
			if ( ! empty( $slots[ $key ] ) ) {
				$n++;
			}
		}
		return $n;
	}

	/**
	 * Count required slot files in current request.
	 *
	 * @return int
	 */
	public static function count_required_uploads() {
		$n = 0;
		foreach ( array_keys( self::required_slots() ) as $slot ) {
			if ( self::has_upload_for_slot( $slot ) ) {
				$n++;
			}
		}
		return $n;
	}

	/**
	 * @param string $slot Slot key.
	 * @return bool
	 */
	public static function has_upload_for_slot( $slot ) {
		if ( empty( $_FILES['kmae_slot_photo']['name'][ $slot ] ) ) {
			return false;
		}
		$error = isset( $_FILES['kmae_slot_photo']['error'][ $slot ] ) ? (int) $_FILES['kmae_slot_photo']['error'][ $slot ] : UPLOAD_ERR_NO_FILE;
		return UPLOAD_ERR_OK === $error && ! empty( $_FILES['kmae_slot_photo']['tmp_name'][ $slot ] );
	}

	/**
	 * Whether the current request includes any slot photo upload.
	 *
	 * @return bool
	 */
	public static function has_any_upload() {
		foreach ( array_keys( self::all_slots() ) as $slot ) {
			if ( self::has_upload_for_slot( $slot ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Validate create/update photo requirements.
	 *
	 * @param int  $listing_id 0 on create.
	 * @param bool $is_new     New listing.
	 * @return true|WP_Error
	 */
	public static function validate_request( $listing_id = 0, $is_new = true ) {
		if ( ! self::is_enabled() ) {
			return true;
		}

		$existing = $listing_id ? self::get_slots( $listing_id ) : array();
		$missing  = array();

		foreach ( self::required_slots() as $key => $info ) {
			$has_new = self::has_upload_for_slot( $key );
			$has_old = ! empty( $existing[ $key ] );
			if ( ! $has_new && ! $has_old ) {
				$missing[] = $info['label'];
			}
		}

		if ( ! empty( $missing ) ) {
			return new WP_Error(
				'photo_slots_required',
				sprintf(
					/* translators: %s: comma-separated slot labels */
					__( 'A kötelező fotók hiányoznak: %s', 'ki-mit-adna-erte' ),
					implode( ', ', $missing )
				),
				array( 'reasons' => $missing )
			);
		}

		unset( $is_new );
		return true;
	}

	/**
	 * Process slot uploads, rebuild gallery order.
	 *
	 * @param int   $post_id Listing ID.
	 * @param array $existing_gallery Unused when photo motor owns gallery.
	 * @return array<int>|WP_Error gallery attachment IDs
	 */
	public static function handle_slot_uploads( $post_id, $existing_gallery = array() ) {
		unset( $existing_gallery );

		require_once ABSPATH . 'wp-admin/includes/image.php';
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';

		$slots   = self::get_slots( $post_id );
		$allowed = array_keys( self::all_slots() );
		$hashes  = array();
		$errors  = array();

		foreach ( $slots as $slot => $aid ) {
			$hash = get_post_meta( $aid, self::ATTACH_HASH_META, true );
			if ( $hash ) {
				$hashes[ $hash ] = $aid;
			}
		}

		foreach ( $allowed as $slot ) {
			if ( ! self::has_upload_for_slot( $slot ) ) {
				continue;
			}

			$slot_label = self::all_slots()[ $slot ]['label'] ?? $slot;
			$tmp        = $_FILES['kmae_slot_photo']['tmp_name'][ $slot ]; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
			$quality    = self::analyze_file( $tmp );
			if ( is_wp_error( $quality ) ) {
				$errors[] = $slot_label . ': ' . $quality->get_error_message();
				continue;
			}

			$hash = $quality['hash'] ?? '';
			if ( $hash && isset( $hashes[ $hash ] ) && ( empty( $slots[ $slot ] ) || (int) $hashes[ $hash ] !== (int) ( $slots[ $slot ] ?? 0 ) ) ) {
				$errors[] = $slot_label . ': ' . __( 'Ez a kép már szerepel egy másik nézetnél.', 'ki-mit-adna-erte' );
				continue;
			}

			$_FILES['kmae_single_slot'] = array(
				'name'     => $_FILES['kmae_slot_photo']['name'][ $slot ], // phpcs:ignore
				'type'     => $_FILES['kmae_slot_photo']['type'][ $slot ], // phpcs:ignore
				'tmp_name' => $tmp,
				'error'    => $_FILES['kmae_slot_photo']['error'][ $slot ], // phpcs:ignore
				'size'     => $_FILES['kmae_slot_photo']['size'][ $slot ], // phpcs:ignore
			);

			$attachment_id = media_handle_upload( 'kmae_single_slot', $post_id );
			if ( is_wp_error( $attachment_id ) ) {
				$errors[] = $slot_label . ': ' . __( 'A feltöltés nem sikerült.', 'ki-mit-adna-erte' );
				continue;
			}

			KMAE_Images::process_attachment( $attachment_id );
			update_post_meta( $attachment_id, self::ATTACH_SLOT_META, $slot );
			if ( $hash ) {
				update_post_meta( $attachment_id, self::ATTACH_HASH_META, $hash );
				$hashes[ $hash ] = $attachment_id;
			}

			if ( ! empty( $slots[ $slot ] ) && (int) $slots[ $slot ] !== (int) $attachment_id ) {
				$old = (int) $slots[ $slot ];
				if ( self::attachment_belongs_to_listing( $old, $post_id ) ) {
					wp_delete_attachment( $old, true );
				}
			}

			$slots[ $slot ] = (int) $attachment_id;
		}

		update_post_meta( $post_id, self::META_SLOTS, $slots );

		$gallery = self::slots_to_gallery( $slots );
		if ( ! empty( $gallery ) ) {
			update_post_meta( $post_id, '_kmae_gallery', $gallery );
			set_post_thumbnail( $post_id, $gallery[0] );
		}

		if ( ! empty( $errors ) ) {
			return new WP_Error( 'photo_quality_failed', implode( ' ', $errors ), array( 'reasons' => $errors ) );
		}

		return $gallery;
	}

	/**
	 * @param array<string,int> $slots Slots map.
	 * @return array<int>
	 */
	public static function slots_to_gallery( $slots ) {
		$gallery = array();
		foreach ( array_keys( self::all_slots() ) as $key ) {
			if ( ! empty( $slots[ $key ] ) ) {
				$gallery[] = (int) $slots[ $key ];
			}
		}
		return array_values( array_unique( $gallery ) );
	}

	/**
	 * Basic quality analysis (brightness + blur proxy + perceptual hash).
	 *
	 * @param string $path File path.
	 * @return array{hash:string,brightness:float,variance:float}|WP_Error
	 */
	public static function analyze_file( $path ) {
		if ( ! $path || ! file_exists( $path ) || ! function_exists( 'imagecreatefromstring' ) ) {
			return array( 'hash' => '', 'brightness' => 128, 'variance' => 100 );
		}

		$raw = file_get_contents( $path ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		if ( false === $raw ) {
			return new WP_Error( 'photo_unreadable', __( 'A kép nem olvasható.', 'ki-mit-adna-erte' ) );
		}

		$img = @imagecreatefromstring( $raw );
		if ( ! $img ) {
			return new WP_Error( 'photo_invalid', __( 'Érvénytelen képfájl.', 'ki-mit-adna-erte' ) );
		}

		$w = imagesx( $img );
		$h = imagesy( $img );
		if ( $w < 400 || $h < 300 ) {
			imagedestroy( $img );
			return new WP_Error( 'photo_too_small', __( 'A kép túl kicsi. Készíts nagyobb felbontású fotót.', 'ki-mit-adna-erte' ) );
		}

		$sample = imagecreatetruecolor( 64, 64 );
		imagecopyresampled( $sample, $img, 0, 0, 0, 0, 64, 64, $w, $h );
		imagedestroy( $img );

		$sum    = 0;
		$sum_sq = 0;
		$n      = 64 * 64;
		$gray   = array();

		for ( $y = 0; $y < 64; $y++ ) {
			for ( $x = 0; $x < 64; $x++ ) {
				$rgb = imagecolorat( $sample, $x, $y );
				$r   = ( $rgb >> 16 ) & 0xFF;
				$g   = ( $rgb >> 8 ) & 0xFF;
				$b   = $rgb & 0xFF;
				$luma = ( 0.299 * $r ) + ( 0.587 * $g ) + ( 0.114 * $b );
				$gray[] = $luma;
				$sum   += $luma;
				$sum_sq += $luma * $luma;
			}
		}

		$mean     = $sum / $n;
		$variance = ( $sum_sq / $n ) - ( $mean * $mean );

		// Edge variance proxy (simple Laplacian-ish).
		$edge = 0;
		$ec   = 0;
		for ( $y = 1; $y < 63; $y++ ) {
			for ( $x = 1; $x < 63; $x++ ) {
				$i = ( $y * 64 ) + $x;
				$lap = abs(
					( 4 * $gray[ $i ] )
					- $gray[ $i - 1 ]
					- $gray[ $i + 1 ]
					- $gray[ $i - 64 ]
					- $gray[ $i + 64 ]
				);
				$edge += $lap;
				$ec++;
			}
		}
		$edge_mean = $ec ? ( $edge / $ec ) : 0;

		imagedestroy( $sample );

		if ( $mean < 35 ) {
			return new WP_Error( 'photo_too_dark', __( 'A kép túl sötét. Készíts új fotót jobb fényviszonyok között.', 'ki-mit-adna-erte' ) );
		}
		if ( $mean > 235 ) {
			return new WP_Error( 'photo_too_bright', __( 'A kép túl világos / kiégett. Készíts új fotót.', 'ki-mit-adna-erte' ) );
		}
		if ( $edge_mean < 4.5 && $variance < 180 ) {
			return new WP_Error( 'photo_blurry', __( 'A kép túl homályos. Készíts élesebb fotót.', 'ki-mit-adna-erte' ) );
		}

		// Average hash 8x8 from gray mean blocks.
		$hash = '';
		for ( $by = 0; $by < 8; $by++ ) {
			for ( $bx = 0; $bx < 8; $bx++ ) {
				$block = 0;
				for ( $yy = 0; $yy < 8; $yy++ ) {
					for ( $xx = 0; $xx < 8; $xx++ ) {
						$block += $gray[ ( ( $by * 8 + $yy ) * 64 ) + ( $bx * 8 + $xx ) ];
					}
				}
				$hash .= ( $block / 64 ) > $mean ? '1' : '0';
			}
		}

		return array(
			'hash'       => $hash,
			'brightness' => $mean,
			'variance'   => $variance,
			'edge'       => $edge_mean,
		);
	}

	private static function attachment_belongs_to_listing( $attachment_id, $post_id ) {
		$attachment = get_post( $attachment_id );
		return $attachment
			&& 'attachment' === $attachment->post_type
			&& (int) $attachment->post_parent === (int) $post_id;
	}
}
