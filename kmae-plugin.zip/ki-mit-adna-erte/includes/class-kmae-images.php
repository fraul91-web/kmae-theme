<?php
/**
 * Upload processing: WebP conversion, resize, orientation meta.
 *
 * @package KMAE
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class KMAE_Images {

	const MAX_EDGE = 1920;
	const WEBP_QUALITY = 82;

	public static function supports_webp() {
		if ( function_exists( 'imagewebp' ) ) {
			return true;
		}
		if ( extension_loaded( 'imagick' ) && class_exists( 'Imagick' ) ) {
			$formats = Imagick::queryFormats( 'WEBP' );
			return is_array( $formats ) && in_array( 'WEBP', $formats, true );
		}
		return false;
	}

	public static function orientation_from_dimensions( $width, $height ) {
		$width  = (int) $width;
		$height = (int) $height;
		if ( $width <= 0 || $height <= 0 ) {
			return 'portrait';
		}
		$ratio = $width / $height;
		if ( $ratio > 1.15 ) {
			return 'landscape';
		}
		if ( $ratio < 0.87 ) {
			return 'portrait';
		}
		return 'square';
	}

	/**
	 * Attachment URL with fallbacks when intermediate sizes are missing.
	 */
	public static function get_url( $attachment_id, $size = 'medium' ) {
		$attachment_id = absint( $attachment_id );
		if ( ! $attachment_id ) {
			return '';
		}

		$sizes = array_unique( array( $size, 'large', 'medium', 'full' ) );
		foreach ( $sizes as $try_size ) {
			$url = wp_get_attachment_image_url( $attachment_id, $try_size );
			if ( ! $url || ! self::attachment_url_is_valid( $url ) ) {
				continue;
			}

			if ( 'full' === $try_size ) {
				return $url;
			}

			$meta = wp_get_attachment_metadata( $attachment_id );
			if ( ! empty( $meta['sizes'][ $try_size ]['file'] ) ) {
				return $url;
			}
		}

		$file = get_attached_file( $attachment_id );
		if ( $file && file_exists( $file ) ) {
			$url = wp_get_attachment_image_url( $attachment_id, 'full' );
			return ( $url && self::attachment_url_is_valid( $url ) ) ? $url : '';
		}

		return '';
	}

	private static function attachment_url_is_valid( $url ) {
		if ( ! self::attachment_url_exists( $url ) ) {
			return false;
		}

		$upload = wp_upload_dir();
		if ( empty( $upload['baseurl'] ) || empty( $upload['basedir'] ) ) {
			return true;
		}
		if ( 0 !== strpos( $url, $upload['baseurl'] ) ) {
			return true;
		}

		$path = $upload['basedir'] . substr( $url, strlen( $upload['baseurl'] ) );
		$size = @filesize( $path );
		return false !== $size && $size > 256;
	}

	private static function attachment_url_exists( $url ) {
		$upload = wp_upload_dir();
		if ( empty( $upload['baseurl'] ) || empty( $upload['basedir'] ) ) {
			return true;
		}
		if ( 0 !== strpos( $url, $upload['baseurl'] ) ) {
			return true;
		}
		$path = $upload['basedir'] . substr( $url, strlen( $upload['baseurl'] ) );
		return file_exists( $path );
	}

	public static function get_orientation( $attachment_id ) {
		$stored = get_post_meta( $attachment_id, '_kmae_orientation', true );
		if ( $stored && in_array( $stored, array( 'portrait', 'landscape', 'square' ), true ) ) {
			return $stored;
		}

		$meta = wp_get_attachment_metadata( $attachment_id );
		if ( ! empty( $meta['width'] ) && ! empty( $meta['height'] ) ) {
			return self::orientation_from_dimensions( $meta['width'], $meta['height'] );
		}

		return 'portrait';
	}

	/**
	 * Optimize uploaded image: resize, WebP, orientation meta.
	 */
	public static function process_attachment( $attachment_id ) {
		$file = get_attached_file( $attachment_id );
		if ( ! $file || ! file_exists( $file ) ) {
			return;
		}

		require_once ABSPATH . 'wp-admin/includes/image.php';

		$mime = get_post_mime_type( $attachment_id );
		if ( ! in_array( $mime, array( 'image/jpeg', 'image/jpg', 'image/png', 'image/webp', 'image/gif' ), true ) ) {
			return;
		}

		// Skip animated GIF.
		if ( 'image/gif' === $mime ) {
			$meta = wp_get_attachment_metadata( $attachment_id );
			if ( ! empty( $meta['width'] ) && ! empty( $meta['height'] ) ) {
				update_post_meta(
					$attachment_id,
					'_kmae_orientation',
					self::orientation_from_dimensions( $meta['width'], $meta['height'] )
				);
			}
			return;
		}

		$editor = wp_get_image_editor( $file );
		if ( is_wp_error( $editor ) ) {
			return;
		}

		$size = $editor->get_size();
		if ( is_wp_error( $size ) || empty( $size['width'] ) || empty( $size['height'] ) ) {
			return;
		}

		update_post_meta(
			$attachment_id,
			'_kmae_orientation',
			self::orientation_from_dimensions( $size['width'], $size['height'] )
		);

		if ( $size['width'] > self::MAX_EDGE || $size['height'] > self::MAX_EDGE ) {
			$editor->resize( self::MAX_EDGE, self::MAX_EDGE, false );
		}

		$editor->set_quality( self::WEBP_QUALITY );

		$original_file = $file;
		$convert_webp  = self::supports_webp() && 'image/webp' !== $mime;

		if ( $convert_webp ) {
			$webp_file = preg_replace( '/\.[^.]+$/', '.webp', $file );
			$saved     = $editor->save( $webp_file, 'image/webp' );
		} else {
			$saved = $editor->save( $file );
		}

		if ( is_wp_error( $saved ) || empty( $saved['path'] ) ) {
			return;
		}

		$new_file = $saved['path'];

		if ( $convert_webp && $new_file !== $original_file && file_exists( $original_file ) ) {
			$old_meta = wp_get_attachment_metadata( $attachment_id );
			if ( ! empty( $old_meta['sizes'] ) ) {
				$base_dir = dirname( $original_file );
				foreach ( $old_meta['sizes'] as $size_data ) {
					if ( ! empty( $size_data['file'] ) ) {
						wp_delete_file( $base_dir . '/' . $size_data['file'] );
					}
				}
			}
			wp_delete_file( $original_file );
		}

		update_attached_file( $attachment_id, $new_file );

		if ( $convert_webp ) {
			wp_update_post(
				array(
					'ID'             => $attachment_id,
					'post_mime_type' => 'image/webp',
				)
			);
		}

		$metadata = wp_generate_attachment_metadata( $attachment_id, $new_file );
		if ( ! is_wp_error( $metadata ) && $metadata ) {
			wp_update_attachment_metadata( $attachment_id, $metadata );
		}
	}
}
