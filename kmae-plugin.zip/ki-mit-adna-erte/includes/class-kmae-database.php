<?php
/**
 * Database table names and helper queries.
 *
 * @package KMAE
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class KMAE_Database {

	public static function table( $name ) {
		global $wpdb;
		return $wpdb->prefix . 'kmae_' . $name;
	}

	public static function get_private_data( $listing_id ) {
		global $wpdb;
		return $wpdb->get_row(
			$wpdb->prepare(
				'SELECT * FROM ' . self::table( 'private_data' ) . ' WHERE listing_id = %d',
				$listing_id
			)
		);
	}

	public static function save_private_data( $listing_id, $minimum_cash, $currency = 'HUF' ) {
		global $wpdb;

		if ( $minimum_cash <= 0 ) {
			$wpdb->delete( self::table( 'private_data' ), array( 'listing_id' => $listing_id ), array( '%d' ) );
			return;
		}

		$existing = self::get_private_data( $listing_id );
		if ( $existing ) {
			$wpdb->update(
				self::table( 'private_data' ),
				array(
					'minimum_cash' => $minimum_cash,
					'currency'     => $currency,
				),
				array( 'listing_id' => $listing_id ),
				array( '%f', '%s' ),
				array( '%d' )
			);
		} else {
			$wpdb->insert(
				self::table( 'private_data' ),
				array(
					'listing_id'   => $listing_id,
					'minimum_cash' => $minimum_cash,
					'currency'     => $currency,
				),
				array( '%d', '%f', '%s' )
			);
		}
	}

	public static function get_offers_for_listing( $listing_id, $include_filtered = false ) {
		global $wpdb;
		$sql = 'SELECT * FROM ' . self::table( 'offers' ) . ' WHERE listing_id = %d';
		if ( ! $include_filtered ) {
			$sql .= ' AND filtered_out = 0';
		}
		$sql .= ' ORDER BY created_at DESC';
		return $wpdb->get_results( $wpdb->prepare( $sql, $listing_id ) );
	}

	public static function count_offers_for_listing( $listing_id, $include_filtered = false ) {
		global $wpdb;
		$sql = 'SELECT COUNT(*) FROM ' . self::table( 'offers' ) . ' WHERE listing_id = %d';
		if ( ! $include_filtered ) {
			$sql .= ' AND filtered_out = 0';
		}
		return (int) $wpdb->get_var( $wpdb->prepare( $sql, $listing_id ) );
	}

	public static function get_offer( $offer_id ) {
		global $wpdb;
		return $wpdb->get_row(
			$wpdb->prepare(
				'SELECT * FROM ' . self::table( 'offers' ) . ' WHERE id = %d',
				$offer_id
			)
		);
	}

	public static function get_offers_by_user( $user_id ) {
		global $wpdb;
		return $wpdb->get_results(
			$wpdb->prepare(
				'SELECT * FROM ' . self::table( 'offers' ) . ' WHERE offerer_id = %d ORDER BY created_at DESC',
				$user_id
			)
		);
	}

	/**
	 * Offers received on listings owned by the user.
	 */
	public static function get_offers_received_by_user( $user_id ) {
		global $wpdb;
		return $wpdb->get_results(
			$wpdb->prepare(
				'SELECT o.* FROM ' . self::table( 'offers' ) . ' o
				INNER JOIN ' . $wpdb->posts . ' p ON p.ID = o.listing_id
				WHERE p.post_author = %d AND o.filtered_out = 0
				ORDER BY o.created_at DESC',
				$user_id
			)
		);
	}

	/**
	 * All offers for admin management.
	 */
	public static function get_all_offers( $args = array() ) {
		global $wpdb;

		$defaults = array(
			'per_page' => 50,
			'offset'   => 0,
			'status'   => '',
		);
		$args = wp_parse_args( $args, $defaults );

		$sql    = 'SELECT o.*, p.post_title AS listing_title FROM ' . self::table( 'offers' ) . ' o
			INNER JOIN ' . $wpdb->posts . ' p ON p.ID = o.listing_id
			WHERE 1=1';
		$params = array();

		if ( ! empty( $args['status'] ) ) {
			$sql     .= ' AND o.status = %s';
			$params[] = $args['status'];
		}

		$sql     .= ' ORDER BY o.created_at DESC LIMIT %d OFFSET %d';
		$params[] = absint( $args['per_page'] );
		$params[] = absint( $args['offset'] );

		if ( empty( $params ) ) {
			return array();
		}

		return $wpdb->get_results( $wpdb->prepare( $sql, $params ) );
	}

	public static function count_all_offers( $status = '' ) {
		global $wpdb;
		$sql = 'SELECT COUNT(*) FROM ' . self::table( 'offers' ) . ' WHERE 1=1';
		if ( $status ) {
			return (int) $wpdb->get_var( $wpdb->prepare( $sql . ' AND status = %s', $status ) );
		}
		return (int) $wpdb->get_var( $sql );
	}

	public static function admin_delete_offer( $offer_id ) {
		global $wpdb;
		$offer = self::get_offer( $offer_id );
		if ( ! $offer ) {
			return new WP_Error( 'invalid', __( 'Érvénytelen ajánlat.', 'ki-mit-adna-erte' ) );
		}

		$wpdb->delete( KMAE_Database::table( 'counter_offers' ), array( 'offer_id' => $offer_id ), array( '%d' ) );
		$wpdb->delete( KMAE_Database::table( 'offer_images' ), array( 'offer_id' => $offer_id ), array( '%d' ) );
		$wpdb->delete( KMAE_Database::table( 'contact_unlocks' ), array( 'offer_id' => $offer_id ), array( '%d' ) );
		$wpdb->delete( KMAE_Database::table( 'offers' ), array( 'id' => $offer_id ), array( '%d' ) );

		return true;
	}

	const OFFERS_SEEN_AT_META     = '_kmae_offers_last_seen_at';
	const OFFERS_SEEN_LEGACY_META = '_kmae_offers_last_seen_offer_id';
	const OFFERS_SEEN_MAP_META    = '_kmae_offers_seen_map';

	/**
	 * Per-offer read timestamps.
	 *
	 * @return array<string, string>
	 */
	private static function get_offers_seen_map( $user_id ) {
		$map = get_user_meta( $user_id, self::OFFERS_SEEN_MAP_META, true );
		return is_array( $map ) ? $map : array();
	}

	public static function get_offer_seen_at( $user_id, $offer_id ) {
		$map      = self::get_offers_seen_map( $user_id );
		$offer_id = (string) $offer_id;
		if ( isset( $map[ $offer_id ] ) && is_string( $map[ $offer_id ] ) ) {
			return $map[ $offer_id ];
		}

		return self::get_offers_last_seen_at( $user_id );
	}

	public static function mark_offer_seen( $user_id, $offer_id ) {
		$map                 = self::get_offers_seen_map( $user_id );
		$map[ (string) $offer_id ] = current_time( 'mysql' );
		update_user_meta( $user_id, self::OFFERS_SEEN_MAP_META, $map );
	}

	/**
	 * Latest activity on this offer from the other party.
	 */
	public static function get_last_activity_from_other( $user_id, $offer ) {
		$user_id = (int) $user_id;
		$listing = get_post( $offer->listing_id );
		if ( ! $listing ) {
			return null;
		}

		$seller_id = (int) $listing->post_author;
		$buyer_id  = (int) $offer->offerer_id;
		if ( ! in_array( $user_id, array( $seller_id, $buyer_id ), true ) ) {
			return null;
		}

		$timestamps = array();

		if ( $user_id === $seller_id && $buyer_id !== $user_id ) {
			$timestamps[] = $offer->created_at;
		}

		foreach ( self::get_counter_offers( $offer->id ) as $counter ) {
			if ( (int) $counter->user_id !== $user_id ) {
				$timestamps[] = $counter->created_at;
			}
		}

		if ( in_array( $offer->status, array( KMAE_Offers::STATUS_ACCEPTED, KMAE_Offers::STATUS_REJECTED, KMAE_Offers::STATUS_WITHDRAWN ), true )
			&& ! empty( $offer->updated_at )
			&& $offer->updated_at > $offer->created_at
		) {
			$timestamps[] = $offer->updated_at;
		}

		if ( empty( $timestamps ) ) {
			return null;
		}

		return max( $timestamps );
	}

	/**
	 * Hub card highlight: good = unread fresh/good news (pulse), bad = rejected (solid red).
	 *
	 * @return string ''|'good'|'bad'
	 */
	public static function get_offer_alert_state( $user_id, $offer ) {
		if ( KMAE_Offers::STATUS_REJECTED === $offer->status ) {
			return 'bad';
		}

		$seen_at = self::get_offer_seen_at( $user_id, $offer->id );
		$last    = self::get_last_activity_from_other( $user_id, $offer );
		if ( ! $last || $last <= $seen_at ) {
			return '';
		}

		return 'good';
	}

	/**
	 * Last time the user opened the offers hub (legacy offer-id meta is migrated on read).
	 */
	public static function get_offers_last_seen_at( $user_id ) {
		$seen_at = get_user_meta( $user_id, self::OFFERS_SEEN_AT_META, true );
		if ( is_string( $seen_at ) && '' !== $seen_at ) {
			return $seen_at;
		}

		$legacy_id = (int) get_user_meta( $user_id, self::OFFERS_SEEN_LEGACY_META, true );
		if ( $legacy_id > 0 ) {
			$offer = self::get_offer( $legacy_id );
			if ( $offer && ! empty( $offer->created_at ) ) {
				return $offer->created_at;
			}
		}

		return '1970-01-01 00:00:00';
	}

	/**
	 * Count offers with unread good news (nav alert).
	 */
	public static function count_unseen_offer_activity( $user_id ) {
		$user_id = (int) $user_id;
		$count   = 0;
		$seen    = array();

		foreach ( self::get_offers_by_user( $user_id ) as $offer ) {
			$seen[ (int) $offer->id ] = true;
			if ( 'good' === self::get_offer_alert_state( $user_id, $offer ) ) {
				++$count;
			}
		}

		foreach ( self::get_offers_received_by_user( $user_id ) as $offer ) {
			if ( isset( $seen[ (int) $offer->id ] ) ) {
				continue;
			}
			if ( 'good' === self::get_offer_alert_state( $user_id, $offer ) ) {
				++$count;
			}
		}

		return $count;
	}

	/** @deprecated Use count_unseen_offer_activity(). */
	public static function count_unseen_received_offers( $user_id ) {
		return self::count_unseen_offer_activity( $user_id );
	}

	public static function mark_offer_activity_seen( $user_id ) {
		update_user_meta( $user_id, self::OFFERS_SEEN_AT_META, current_time( 'mysql' ) );
		delete_user_meta( $user_id, self::OFFERS_SEEN_LEGACY_META );
	}

	/** @deprecated Use mark_offer_activity_seen(). */
	public static function mark_received_offers_seen( $user_id ) {
		self::mark_offer_activity_seen( $user_id );
	}

	public static function get_offers_page_url() {
		return class_exists( 'KMAE_Pages' ) ? KMAE_Pages::offers_page_url() : home_url( '/ajanlatok/' );
	}

	public static function get_user_offer_for_listing( $listing_id, $user_id ) {
		global $wpdb;
		return $wpdb->get_row(
			$wpdb->prepare(
				'SELECT * FROM ' . self::table( 'offers' ) . ' WHERE listing_id = %d AND offerer_id = %d ORDER BY created_at DESC LIMIT 1',
				$listing_id,
				$user_id
			)
		);
	}

	/**
	 * Latest offer that still blocks re-submitting (pending or accepted).
	 */
	public static function get_active_user_offer_for_listing( $listing_id, $user_id ) {
		$offer = self::get_user_offer_for_listing( $listing_id, $user_id );
		if ( ! $offer || ! KMAE_Offers::is_active_for_listing( $offer ) ) {
			return null;
		}
		return $offer;
	}

	/**
	 * Withdrawn offer on this listing — permanent block on re-offering.
	 */
	public static function get_withdrawn_user_offer_for_listing( $listing_id, $user_id ) {
		global $wpdb;
		return $wpdb->get_row(
			$wpdb->prepare(
				'SELECT * FROM ' . self::table( 'offers' ) . ' WHERE listing_id = %d AND offerer_id = %d AND status = %s ORDER BY created_at DESC LIMIT 1',
				$listing_id,
				$user_id,
				KMAE_Offers::STATUS_WITHDRAWN
			)
		);
	}

	public static function get_offer_images( $offer_id ) {
		global $wpdb;
		return $wpdb->get_results(
			$wpdb->prepare(
				'SELECT * FROM ' . self::table( 'offer_images' ) . ' WHERE offer_id = %d ORDER BY sort_order ASC',
				$offer_id
			)
		);
	}

	public static function get_counter_offers( $offer_id ) {
		global $wpdb;
		return $wpdb->get_results(
			$wpdb->prepare(
				'SELECT * FROM ' . self::table( 'counter_offers' ) . ' WHERE offer_id = %d ORDER BY created_at ASC',
				$offer_id
			)
		);
	}

	public static function get_latest_counter_offer( $offer_id ) {
		global $wpdb;
		return $wpdb->get_row(
			$wpdb->prepare(
				'SELECT * FROM ' . self::table( 'counter_offers' ) . ' WHERE offer_id = %d ORDER BY created_at DESC LIMIT 1',
				$offer_id
			)
		);
	}

	public static function count_counter_offers_by_user( $offer_id, $user_id ) {
		global $wpdb;
		return (int) $wpdb->get_var(
			$wpdb->prepare(
				'SELECT COUNT(*) FROM ' . self::table( 'counter_offers' ) . ' WHERE offer_id = %d AND user_id = %d',
				$offer_id,
				$user_id
			)
		);
	}

	public static function update_offer_status( $offer_id, $status ) {
		global $wpdb;
		return $wpdb->update(
			self::table( 'offers' ),
			array( 'status' => $status ),
			array( 'id' => $offer_id ),
			array( '%s' ),
			array( '%d' )
		);
	}

	public static function get_counter_offer( $counter_id ) {
		global $wpdb;
		return $wpdb->get_row(
			$wpdb->prepare(
				'SELECT * FROM ' . self::table( 'counter_offers' ) . ' WHERE id = %d',
				$counter_id
			)
		);
	}

	public static function has_contact_unlock( $offer_id, $user_id ) {
		global $wpdb;
		return (bool) $wpdb->get_var(
			$wpdb->prepare(
				'SELECT id FROM ' . self::table( 'contact_unlocks' ) . ' WHERE offer_id = %d AND user_id = %d',
				$offer_id,
				$user_id
			)
		);
	}

	public static function create_contact_unlock( $offer_id, $user_id ) {
		global $wpdb;
		return $wpdb->replace(
			self::table( 'contact_unlocks' ),
			array(
				'offer_id' => $offer_id,
				'user_id'  => $user_id,
			),
			array( '%d', '%d' )
		);
	}

	public static function get_premium( $user_id ) {
		global $wpdb;
		return $wpdb->get_row(
			$wpdb->prepare(
				'SELECT * FROM ' . self::table( 'premium' ) . ' WHERE user_id = %d',
				$user_id
			)
		);
	}

	public static function set_premium( $user_id, $status, $expires_at ) {
		global $wpdb;
		$existing = self::get_premium( $user_id );
		if ( $existing ) {
			return $wpdb->update(
				self::table( 'premium' ),
				array( 'status' => $status, 'expires_at' => $expires_at ),
				array( 'user_id' => $user_id ),
				array( '%s', '%s' ),
				array( '%d' )
			);
		}
		return $wpdb->insert(
			self::table( 'premium' ),
			array(
				'user_id'    => $user_id,
				'status'     => $status,
				'expires_at' => $expires_at,
			),
			array( '%d', '%s', '%s' )
		);
	}
}
