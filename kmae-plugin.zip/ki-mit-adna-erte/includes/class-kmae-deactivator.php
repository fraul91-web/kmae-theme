<?php
/**
 * Plugin deactivation.
 *
 * @package KMAE
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class KMAE_Deactivator {

	public static function deactivate() {
		wp_clear_scheduled_hook( 'kmae_purge_archived_listings' );
		flush_rewrite_rules();
	}
}
