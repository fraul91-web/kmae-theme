(function () {
  'use strict';

  function parseCurrency(value) {
    var digits = String(value || '').replace(/\D/g, '');
    if (!digits) {
      return 0;
    }
    return parseInt(digits, 10) || 0;
  }

  function formatCurrency(num) {
    if (!num || num <= 0) {
      return '';
    }
    return String(num).replace(/\B(?=(\d{3})+(?!\d))/g, '.');
  }

  function getCurrencyValue(el) {
    return el ? parseCurrency(el.value) : 0;
  }

  function bindCurrencyInput(el, onChange) {
    if (!el) {
      return;
    }

    el.addEventListener('input', function () {
      var raw = parseCurrency(el.value);
      el.value = formatCurrency(raw);
      if (typeof onChange === 'function') {
        onChange();
      }
    });

    el.addEventListener('blur', function () {
      var raw = parseCurrency(el.value);
      el.value = formatCurrency(raw);
    });
  }

  function initBodyPicker() {
    var picker = document.getElementById('kmae-wizard-body-picker');
    var nextBtn = document.getElementById('kmae-wizard-body-next');
    if (!picker || !nextBtn) {
      return;
    }

    var baseUrl = picker.getAttribute('data-base-url') || window.location.pathname;
    var cards = picker.querySelectorAll('[data-kmae-body]');
    var selected = new Set();

    cards.forEach(function (card) {
      if (card.classList.contains('is-selected')) {
        selected.add(card.getAttribute('data-kmae-body'));
      }
    });

    function syncCards() {
      cards.forEach(function (card) {
        var slug = card.getAttribute('data-kmae-body');
        var isSelected = selected.has(slug);
        card.classList.toggle('is-selected', isSelected);
        card.setAttribute('aria-pressed', isSelected ? 'true' : 'false');
      });
      nextBtn.disabled = selected.size === 0;
    }

    cards.forEach(function (card) {
      card.addEventListener('click', function () {
        var slug = card.getAttribute('data-kmae-body');
        if (slug === 'mind') {
          if (selected.has('mind')) {
            selected.delete('mind');
          } else {
            selected.clear();
            selected.add('mind');
          }
        } else {
          selected.delete('mind');
          if (selected.has(slug)) {
            selected.delete(slug);
          } else {
            selected.add(slug);
          }
        }
        syncCards();
      });
    });

    nextBtn.addEventListener('click', function () {
      if (selected.size === 0) {
        return;
      }

      var value = selected.has('mind') ? 'mind' : Array.from(selected).join(',');
      var url = new URL(baseUrl, window.location.origin);
      url.searchParams.set('kivitel', value);
      url.searchParams.delete('step');
      window.location.href = url.toString();
    });

    syncCards();
  }

  function initOfferForm() {
    var form = document.getElementById('kmae-wizard-offer-form');
    if (!form) {
      return;
    }

    var modInput = document.getElementById('kmae-wizard-mod');
    var searchBtn = document.getElementById('kmae-wizard-search-btn');
    var ertekVal = document.getElementById('kmae-wizard-ertek-val');
    var maxKpVal = document.getElementById('kmae-wizard-max-kp-val');
    var panels = {
      csere: document.getElementById('kmae-panel-csere'),
      csere_kp: document.getElementById('kmae-panel-csere_kp'),
      kp: document.getElementById('kmae-panel-kp')
    };

    var ertekCsere = document.getElementById('kmae-wizard-ertek-csere');
    var ertekCsereKp = document.getElementById('kmae-wizard-ertek-csere-kp');
    var maxKpInput = document.getElementById('kmae-wizard-max-kp');
    var kpMinInput = document.getElementById('kmae-wizard-kp-min');
    var kpMaxInput = document.getElementById('kmae-wizard-kp-max');
    var kpMinVal = document.getElementById('kmae-wizard-kp-min-val');
    var kpMaxVal = document.getElementById('kmae-wizard-kp-max-val');

    var modeCards = form.querySelectorAll('[data-kmae-mode]');
    var activeMode = '';
    var errorBox = document.getElementById('kmae-wizard-errors');

    function hidePanels() {
      Object.keys(panels).forEach(function (key) {
        if (panels[key]) {
          panels[key].hidden = true;
        }
      });
    }

    function msg(key) {
      if (!errorBox) {
        return '';
      }
      return errorBox.getAttribute('data-msg-' + key) || '';
    }

    function clearFeedback() {
      if (!errorBox) {
        return;
      }
      while (errorBox.firstChild) {
        errorBox.removeChild(errorBox.firstChild);
      }
      errorBox.hidden = true;
      errorBox.classList.remove('is-error', 'is-guide');
    }

    function showFeedback(items) {
      if (!errorBox) {
        return;
      }
      clearFeedback();
      var list = (items || []).filter(function (item) {
        return item && item.text;
      });
      if (!list.length) {
        return;
      }

      var hasError = list.some(function (item) {
        return item.kind === 'error';
      });
      errorBox.hidden = false;
      errorBox.classList.add(hasError ? 'is-error' : 'is-guide');
      errorBox.setAttribute('role', hasError ? 'alert' : 'status');

      list.forEach(function (item) {
        var p = document.createElement('p');
        p.className =
          item.kind === 'error' ? 'kmae-wizard-form-error' : 'kmae-wizard-form-guide';
        p.textContent = item.text;
        errorBox.appendChild(p);
      });
    }

    function collectIssues() {
      var items = [];

      if (!activeMode) {
        items.push({ kind: 'guide', text: msg('mode') });
        return items;
      }

      if (activeMode === 'csere') {
        if (getCurrencyValue(ertekCsere) < 1) {
          items.push({ kind: 'guide', text: msg('ertek') });
        }
      } else if (activeMode === 'csere_kp') {
        if (getCurrencyValue(ertekCsereKp) < 1) {
          items.push({ kind: 'guide', text: msg('ertek') });
        }
        if (getCurrencyValue(maxKpInput) < 1) {
          items.push({ kind: 'guide', text: msg('max-kp') });
        }
      } else if (activeMode === 'kp') {
        var min = getCurrencyValue(kpMinInput);
        var max = getCurrencyValue(kpMaxInput);
        if (min < 1) {
          items.push({ kind: 'guide', text: msg('kp-min') });
        }
        if (max < 1) {
          items.push({ kind: 'guide', text: msg('kp-max') });
        }
        if (min >= 1 && max >= 1 && max < min) {
          items.push({ kind: 'error', text: msg('kp-range') });
        }
      }

      return items;
    }

    function syncSearchBtn() {
      if (searchBtn) {
        searchBtn.disabled = !activeMode;
      }
    }

    [ertekCsere, ertekCsereKp, maxKpInput, kpMinInput, kpMaxInput].forEach(function (el) {
      bindCurrencyInput(el, function () {
        // Hide previous submit feedback; do not re-validate live.
        clearFeedback();
      });
    });

    modeCards.forEach(function (card) {
      card.addEventListener('click', function () {
        activeMode = card.getAttribute('data-kmae-mode');
        modInput.value = activeMode;
        modeCards.forEach(function (c) {
          c.classList.toggle('is-active', c === card);
        });
        hidePanels();
        if (panels[activeMode]) {
          panels[activeMode].hidden = false;
        }
        clearFeedback();
        syncSearchBtn();
      });
    });

    form.addEventListener('submit', function (e) {
      var issues = collectIssues();
      if (issues.length) {
        e.preventDefault();
        showFeedback(issues);
        return;
      }

      clearFeedback();

      if (activeMode === 'csere') {
        ertekVal.value = String(getCurrencyValue(ertekCsere));
        maxKpVal.value = '';
      } else if (activeMode === 'csere_kp') {
        ertekVal.value = String(getCurrencyValue(ertekCsereKp));
        maxKpVal.value = String(getCurrencyValue(maxKpInput));
      } else if (activeMode === 'kp') {
        kpMinVal.value = String(getCurrencyValue(kpMinInput));
        kpMaxVal.value = String(getCurrencyValue(kpMaxInput));
        ertekVal.value = '';
        maxKpVal.value = '';
      }
    });

    syncSearchBtn();
  }

  document.addEventListener('DOMContentLoaded', function () {
    initBodyPicker();
    initOfferForm();
  });
})();
