(function () {
  'use strict';

  document.addEventListener('DOMContentLoaded', function () {
    var stack = document.getElementById('kmae-swipe-stack');
    if (!stack) return;

    var cards = Array.prototype.slice.call(stack.querySelectorAll('.kmae-swipe-card'));
    var current = 0;

    function topCard() {
      return cards[current] || null;
    }

    function recordPass(listingId) {
      if (!listingId || typeof kmaeSwipe === 'undefined') return;
      var body = new FormData();
      body.append('action', 'kmae_browse_pass');
      body.append('nonce', kmaeSwipe.nonce);
      body.append('listing_id', listingId);
      fetch(kmaeSwipe.ajaxUrl, { method: 'POST', body: body, credentials: 'same-origin' });
    }

    function swipeAway(direction) {
      var card = topCard();
      if (!card) return;

      if (direction === 'like') {
        var link = card.querySelector('.kmae-swipe-cta');
        if (link) {
          window.location.href = link.href;
          return;
        }
      }

      if (direction === 'pass') {
        var listingId = card.getAttribute('data-listing-id');
        recordPass(listingId);
      }

      card.style.transform = direction === 'like' ? 'translateX(120%) rotate(12deg)' : 'translateX(-120%) rotate(-12deg)';
      card.style.opacity = '0';
      setTimeout(function () {
        card.style.display = 'none';
        current++;
        var next = topCard();
        if (next) {
          next.style.zIndex = cards.length;
        }
      }, 280);
    }

    var passBtn = document.getElementById('kmae-swipe-pass');
    var likeBtn = document.getElementById('kmae-swipe-like');
    if (passBtn) passBtn.addEventListener('click', function () { swipeAway('pass'); });
    if (likeBtn) likeBtn.addEventListener('click', function () { swipeAway('like'); });

    cards.forEach(function (card, i) {
      card.style.zIndex = cards.length - i;
    });
  });
})();
