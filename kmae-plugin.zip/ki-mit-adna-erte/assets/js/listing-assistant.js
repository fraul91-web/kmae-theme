(function () {
  'use strict';

  var MIN_DESC = 80;
  var MIN_IMAGES = 7;

  var requiredFields = [
    { id: 'kmae_vehicle_brand', label: 'Márka' },
    { id: 'kmae_vehicle_model', label: 'Modell' },
    { id: 'kmae_vehicle_year', label: 'Évjárat' },
    { id: 'kmae_vehicle_mileage', label: 'Km óra' },
    { id: 'kmae_vehicle_fuel', label: 'Üzemanyag' },
    { id: 'kmae_vehicle_transmission', label: 'Váltó' },
    { id: 'kmae_vehicle_body', label: 'Kivitel' },
    { id: 'kmae_vehicle_owners', label: 'Tulajdonosok száma' },
    { id: 'kmae_condition', label: 'Állapot' },
    { id: 'kmae_vehicle_value', label: 'Autó becsült értéke' }
  ];

  function updateTitleSuggestion() {
    var brand = document.getElementById('kmae_vehicle_brand');
    var model = document.getElementById('kmae_vehicle_model');
    var year = document.getElementById('kmae_vehicle_year');
    var title = document.getElementById('kmae_title');
    if (!brand || !model || !year || !title || title.dataset.userEdited === '1') {
      return;
    }
    var parts = [brand.value.trim(), model.value.trim(), year.value.trim()].filter(Boolean);
    if (parts.length >= 2) {
      title.value = parts.join(' ');
    }
  }

  function runAssistant() {
    var panel = document.getElementById('kmae-listing-assistant');
    var list = document.getElementById('kmae-assistant-list');
    if (!panel || !list) {
      return;
    }

    var issues = [];

    requiredFields.forEach(function (field) {
      var el = document.getElementById(field.id);
      if (!el || !el.value || !String(el.value).trim()) {
        issues.push('Hiányzik: ' + field.label);
      }
    });

    var desc = document.getElementById('kmae_description');
    if (desc && desc.value.trim().length < MIN_DESC) {
      issues.push('Leírás túl rövid (min. ' + MIN_DESC + ' karakter)');
    }

    var images = document.getElementById('kmae_images');
    var photoMotor = document.getElementById('kmae-photo-motor');
    var deviceInput = document.getElementById('kmae_create_device');
    var deferPhotos = deviceInput && deviceInput.value === 'computer';
    var awaiting = document.getElementById('kmae-listing-form');
    awaiting = awaiting && awaiting.getAttribute('data-awaiting') === '1';

    if (photoMotor && !deferPhotos && !awaiting) {
      var filled = 0;
      photoMotor.querySelectorAll('.kmae-photo-slot[data-required="1"]').forEach(function (slot) {
        var input = slot.querySelector('input[type="file"]');
        var hasPreview = !!slot.querySelector('.kmae-photo-slot__preview img');
        var hasFile = input && input.files && input.files.length > 0;
        if (hasPreview || hasFile) filled++;
      });
      if (filled < MIN_IMAGES) {
        issues.push('Kötelező fotók: ' + filled + ' / ' + MIN_IMAGES);
      }
    } else if (!deferPhotos && !awaiting && images && images.files && images.files.length < MIN_IMAGES) {
      issues.push('Legalább ' + MIN_IMAGES + ' kép szükséges');
    }

    list.innerHTML = '';
    if (!issues.length) {
      panel.hidden = true;
      return;
    }

    issues.forEach(function (msg) {
      var li = document.createElement('li');
      li.textContent = msg;
      list.appendChild(li);
    });
    panel.hidden = false;
  }

  document.addEventListener('DOMContentLoaded', function () {
    var form = document.querySelector('.kmae-form');
    if (!form || !document.getElementById('kmae_vehicle_brand')) {
      return;
    }

    ['kmae_vehicle_brand', 'kmae_vehicle_model', 'kmae_vehicle_year'].forEach(function (id) {
      var el = document.getElementById(id);
      if (el) {
        el.addEventListener('input', updateTitleSuggestion);
      }
    });

    var title = document.getElementById('kmae_title');
    if (title) {
      title.addEventListener('input', function () {
        title.dataset.userEdited = '1';
      });
    }

    form.querySelectorAll('input, select, textarea').forEach(function (el) {
      el.addEventListener('input', runAssistant);
      el.addEventListener('change', runAssistant);
    });

    runAssistant();
    updateTitleSuggestion();
  });
})();
