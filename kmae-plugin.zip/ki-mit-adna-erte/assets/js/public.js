(function () {
  'use strict';

  function roundsMessage(roundsLeft) {
    if (typeof kmaePublic === 'undefined') {
      return '';
    }
    var left = parseInt(roundsLeft, 10);
    if (left <= 1) {
      return kmaePublic.roundsWarningLast;
    }
    return kmaePublic.roundsWarningMulti.replace(/%d/, String(left));
  }

  function roundsCountLabel(roundsLeft, max) {
    var left = parseInt(roundsLeft, 10);
    var used = max - left;
    if (left <= 0) {
      return 'Nincs több alkudozási köröd';
    }
    if (left <= 1) {
      return used + ' / ' + max + ' kör felhasználva · utolsó maradt';
    }
    return left + ' / ' + max + ' kör maradt (' + used + ' felhasználva)';
  }

  function renderModalCountdown(countEl, labelEl, roundsLeft) {
    if (!countEl) {
      return;
    }
    var max = typeof kmaePublic !== 'undefined' && kmaePublic.maxCounterRounds ? kmaePublic.maxCounterRounds : 2;
    var left = parseInt(roundsLeft, 10);
    var used = Math.max(0, max - left);
    countEl.innerHTML = '';

    for (var i = 0; i < max; i++) {
      var dot = document.createElement('span');
      dot.className = 'kmae-rounds-modal-dot';
      if (i < used) {
        dot.classList.add('is-used');
      } else if (i === used && left > 0) {
        dot.classList.add('is-current');
      }
      countEl.appendChild(dot);
    }

    if (labelEl) {
      labelEl.textContent = roundsCountLabel(roundsLeft, max);
    }

    countEl.classList.toggle('kmae-rounds-modal-count--last', left <= 1 && left > 0);
    countEl.classList.toggle('kmae-rounds-modal-count--empty', left <= 0);
  }

  function showRoundsModal(roundsLeft, onDismiss) {
    var modal = document.getElementById('kmae-rounds-modal');
    var textEl = modal ? modal.querySelector('[data-kmae-rounds-text]') : null;
    var countEl = modal ? modal.querySelector('[data-kmae-rounds-count]') : null;
    var labelEl = modal ? modal.querySelector('[data-kmae-rounds-count-label]') : null;
    if (!modal || !textEl) {
      if (onDismiss) onDismiss();
      return;
    }

    textEl.textContent = roundsMessage(roundsLeft);
    renderModalCountdown(countEl, labelEl, roundsLeft);
    modal.removeAttribute('hidden');

    function closeModal() {
      modal.setAttribute('hidden', '');
      modal.removeEventListener('click', closeModal);
      if (onDismiss) onDismiss();
    }

    modal.addEventListener('click', closeModal);
  }

  document.addEventListener('DOMContentLoaded', function () {
    /* Offer type tabs */
    document.querySelectorAll('.kmae-offer-tabs').forEach(function (wrap) {
      var buttons = wrap.querySelectorAll('.kmae-tab-btn');
      var panels = wrap.querySelectorAll('.kmae-tab-panel');
      buttons.forEach(function (btn) {
        btn.addEventListener('click', function () {
          var tab = btn.getAttribute('data-tab');
          buttons.forEach(function (b) { b.classList.remove('active'); });
          panels.forEach(function (p) { p.classList.remove('active'); });
          btn.classList.add('active');
          var panel = wrap.querySelector('[data-panel="' + tab + '"]');
          if (panel) panel.classList.add('active');
        });
      });
    });

    /* Create listing: price mode + trade-in + other extra */
    var tradeInCheckbox = document.querySelector('input[data-offer-type="trade_in"]');
    var minimumField = document.querySelector('.kmae-minimum-field');
    var fixedPriceField = document.querySelector('.kmae-fixed-price-field');
    var tradeInField = document.querySelector('.kmae-trade-in-field');
    var extraOtherField = document.querySelector('.kmae-extra-other-field');
    var otherCommit = document.querySelector('input[data-kmae-commit="other"]');
    var priceModeRadios = document.querySelectorAll('input[name="kmae_price_mode"]');

    function togglePriceModeFields() {
      var mode = '';
      priceModeRadios.forEach(function (el) {
        if (el.checked) mode = el.value;
      });
      if (fixedPriceField) {
        fixedPriceField.style.display = mode === 'fixed' ? 'block' : 'none';
        var fixedInput = fixedPriceField.querySelector('input');
        if (fixedInput) fixedInput.required = mode === 'fixed';
      }
      if (minimumField) {
        minimumField.style.display = mode === 'offers' ? 'block' : 'none';
        var minInput = minimumField.querySelector('input');
        if (minInput) minInput.required = mode === 'offers';
      }
      // Fixed price implies cash accepted.
      var cashCheckbox = document.querySelector('input[data-offer-type="cash"]');
      if (cashCheckbox && mode === 'fixed') {
        cashCheckbox.checked = true;
      }
    }

    function toggleCreateFields() {
      if (tradeInField && tradeInCheckbox) {
        tradeInField.style.display = tradeInCheckbox.checked ? 'block' : 'none';
      }
      if (extraOtherField && otherCommit) {
        extraOtherField.style.display = otherCommit.checked ? 'block' : 'none';
      }
    }

    priceModeRadios.forEach(function (el) {
      el.addEventListener('change', togglePriceModeFields);
    });
    document.querySelectorAll('input[data-offer-type]').forEach(function (el) {
      el.addEventListener('change', toggleCreateFields);
    });
    if (otherCommit) {
      otherCommit.addEventListener('change', toggleCreateFields);
    }
    togglePriceModeFields();
    toggleCreateFields();

    function parseGalleryUrls(gallery) {
      if (!gallery) return [];
      try {
        var raw = gallery.getAttribute('data-full-urls');
        var urls = raw ? JSON.parse(raw) : [];
        return Array.isArray(urls) ? urls.filter(Boolean) : [];
      } catch (e) {
        return [];
      }
    }

    function getGalleryLightbox(gallery) {
      if (!gallery) return document.querySelector('.kmae-lightbox');
      var next = gallery.nextElementSibling;
      if (next && next.classList.contains('kmae-lightbox')) return next;
      return gallery.parentElement ? gallery.parentElement.querySelector('.kmae-lightbox') : null;
    }

    function getGalleryIndex(gallery) {
      var active = gallery.querySelector('.kmae-gallery-slide.active');
      if (!active) return 0;
      return parseInt(active.getAttribute('data-index'), 10) || 0;
    }

    function setGalleryIndex(gallery, idx) {
      var slides = gallery.querySelectorAll('.kmae-gallery-slide');
      var dots = gallery.querySelectorAll('.kmae-gallery-dot');
      var counter = gallery.querySelector('.kmae-gallery-counter');
      if (!slides.length) return;

      if (idx < 0) idx = slides.length - 1;
      if (idx >= slides.length) idx = 0;

      slides.forEach(function (slide, i) {
        slide.classList.toggle('active', i === idx);
      });
      dots.forEach(function (dot, i) {
        dot.classList.toggle('active', i === idx);
      });
      if (counter) {
        counter.textContent = (idx + 1) + ' / ' + slides.length;
      }
    }

    function navigateGallery(gallery, delta) {
      var slides = gallery.querySelectorAll('.kmae-gallery-slide');
      if (slides.length <= 1) return;
      setGalleryIndex(gallery, getGalleryIndex(gallery) + delta);
    }

    var activeLightboxGallery = null;
    var activeLightboxUrls = [];
    var activeLightboxIndex = 0;

    function updateLightboxImage(box) {
      if (!box || !activeLightboxUrls.length) return;
      var img = box.querySelector('.kmae-lightbox-img');
      if (!img) return;
      img.src = activeLightboxUrls[activeLightboxIndex] || '';
      box.setAttribute('data-index', String(activeLightboxIndex));

      var prev = box.querySelector('.kmae-lightbox-prev');
      var next = box.querySelector('.kmae-lightbox-next');
      var multi = activeLightboxUrls.length > 1;
      if (prev) prev.hidden = !multi;
      if (next) next.hidden = !multi;
    }

    function openLightbox(src, gallery, index) {
      var box = getGalleryLightbox(gallery);
      if (!box) return;

      activeLightboxGallery = gallery || null;
      activeLightboxUrls = gallery ? parseGalleryUrls(gallery) : (src ? [src] : []);
      if (!activeLightboxUrls.length && src) activeLightboxUrls = [src];

      activeLightboxIndex = typeof index === 'number' ? index : (gallery ? getGalleryIndex(gallery) : 0);
      if (activeLightboxIndex >= activeLightboxUrls.length) activeLightboxIndex = 0;

      updateLightboxImage(box);
      box.hidden = false;
      box.setAttribute('aria-hidden', 'false');
      document.body.classList.add('kmae-lightbox-open');
    }

    function closeLightbox() {
      document.querySelectorAll('.kmae-lightbox').forEach(function (box) {
        box.hidden = true;
        box.setAttribute('aria-hidden', 'true');
        var img = box.querySelector('.kmae-lightbox-img');
        if (img) img.src = '';
      });
      document.body.classList.remove('kmae-lightbox-open');
      activeLightboxGallery = null;
      activeLightboxUrls = [];
      activeLightboxIndex = 0;
    }

    function navigateLightbox(delta) {
      if (!activeLightboxUrls.length) return;
      var box = activeLightboxGallery ? getGalleryLightbox(activeLightboxGallery) : document.querySelector('.kmae-lightbox:not([hidden])');
      if (!box) return;
      activeLightboxIndex = (activeLightboxIndex + delta + activeLightboxUrls.length) % activeLightboxUrls.length;
      updateLightboxImage(box);
      if (activeLightboxGallery) {
        setGalleryIndex(activeLightboxGallery, activeLightboxIndex);
      }
    }

    document.querySelectorAll('.kmae-lightbox-close, .kmae-lightbox-backdrop').forEach(function (el) {
      el.addEventListener('click', closeLightbox);
    });

    document.querySelectorAll('.kmae-lightbox-prev').forEach(function (btn) {
      btn.addEventListener('click', function (e) {
        e.stopPropagation();
        navigateLightbox(-1);
      });
    });

    document.querySelectorAll('.kmae-lightbox-next').forEach(function (btn) {
      btn.addEventListener('click', function (e) {
        e.stopPropagation();
        navigateLightbox(1);
      });
    });

    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') {
        closeLightbox();
        return;
      }
      var openBox = document.querySelector('.kmae-lightbox:not([hidden])');
      if (!openBox) return;
      if (e.key === 'ArrowLeft') navigateLightbox(-1);
      if (e.key === 'ArrowRight') navigateLightbox(1);
    });

    /* Gallery slides + dots + arrows + lightbox */
    document.querySelectorAll('.kmae-gallery').forEach(function (gallery) {
      var dots = gallery.querySelectorAll('.kmae-gallery-dot');
      dots.forEach(function (dot) {
        dot.addEventListener('click', function (e) {
          e.stopPropagation();
          var idx = parseInt(dot.getAttribute('data-index'), 10);
          setGalleryIndex(gallery, idx);
        });
      });

      var prev = gallery.querySelector('.kmae-gallery-prev');
      var next = gallery.querySelector('.kmae-gallery-next');
      if (prev) {
        prev.addEventListener('click', function (e) {
          e.stopPropagation();
          navigateGallery(gallery, -1);
        });
      }
      if (next) {
        next.addEventListener('click', function (e) {
          e.stopPropagation();
          navigateGallery(gallery, 1);
        });
      }

      gallery.querySelectorAll('.kmae-gallery-slide').forEach(function (slide) {
        slide.addEventListener('click', function () {
          var full = slide.getAttribute('data-full');
          var idx = parseInt(slide.getAttribute('data-index'), 10) || 0;
          if (full) openLightbox(full, gallery, idx);
        });
      });
    });

    /* Card / thumb / form preview lightbox */
    document.querySelectorAll('.kmae-zoomable').forEach(function (el) {
      el.addEventListener('click', function (e) {
        var full = el.getAttribute('data-full') || el.getAttribute('src');
        if (full) {
          e.preventDefault();
          e.stopPropagation();
          openLightbox(full, null, 0);
        }
      });
    });

    /* Edit form — gallery manager */
    (function initGalleryManager() {
      var list = document.getElementById('kmae-gallery-manager');
      if (!list) return;

      var removedWrap = document.getElementById('kmae-gallery-removed-inputs');
      var dragItem = null;

      function visibleItems() {
        return Array.prototype.slice.call(list.querySelectorAll('.kmae-gallery-manager-item:not(.is-removed)'));
      }

      function updateBadges() {
        list.querySelectorAll('.kmae-gallery-manager-badge').forEach(function (badge) {
          badge.remove();
        });
        var first = visibleItems()[0];
        if (!first) return;
        var badge = document.createElement('span');
        badge.className = 'kmae-gallery-manager-badge';
        badge.textContent = 'Főkép';
        first.appendChild(badge);
      }

      function moveItem(item, delta) {
        var items = visibleItems();
        var idx = items.indexOf(item);
        if (idx < 0) return;
        var target = idx + delta;
        if (target < 0 || target >= items.length) return;
        if (delta < 0) {
          list.insertBefore(item, items[target]);
        } else {
          list.insertBefore(items[target], item);
        }
        updateBadges();
      }

      list.querySelectorAll('.kmae-gallery-manager-item').forEach(function (item) {
        var up = item.querySelector('.kmae-gallery-manager-up');
        var down = item.querySelector('.kmae-gallery-manager-down');
        var remove = item.querySelector('.kmae-gallery-manager-remove');

        if (up) {
          up.addEventListener('click', function (e) {
            e.preventDefault();
            e.stopPropagation();
            moveItem(item, -1);
          });
        }

        if (down) {
          down.addEventListener('click', function (e) {
            e.preventDefault();
            e.stopPropagation();
            moveItem(item, 1);
          });
        }

        if (remove) {
          remove.addEventListener('click', function (e) {
            e.preventDefault();
            e.stopPropagation();
            if (!window.confirm('Biztosan törlöd ezt a képet?')) return;
            var id = item.getAttribute('data-id');
            var orderInput = item.querySelector('input[name="kmae_gallery_order[]"]');
            if (orderInput) orderInput.disabled = true;
            if (removedWrap && id) {
              var input = document.createElement('input');
              input.type = 'hidden';
              input.name = 'kmae_remove_images[]';
              input.value = id;
              removedWrap.appendChild(input);
            }
            item.classList.add('is-removed');
            item.hidden = true;
            updateBadges();
          });
        }

        item.addEventListener('dragstart', function () {
          dragItem = item;
          item.classList.add('is-dragging');
        });

        item.addEventListener('dragend', function () {
          item.classList.remove('is-dragging');
          dragItem = null;
          updateBadges();
        });

        item.addEventListener('dragover', function (e) {
          e.preventDefault();
        });

        item.addEventListener('drop', function (e) {
          e.preventDefault();
          if (!dragItem || dragItem === item || item.classList.contains('is-removed')) return;
          var rect = item.getBoundingClientRect();
          var after = e.clientX > rect.left + rect.width / 2;
          if (after) {
            list.insertBefore(dragItem, item.nextSibling);
          } else {
            list.insertBefore(dragItem, item);
          }
        });
      });
    })();

    /* Offer chat: scroll to latest message */
    var chatThread = document.getElementById('kmae-chat-thread');
    if (chatThread) {
      chatThread.scrollTop = chatThread.scrollHeight;
    }

    /* Offer chat: inline counter / revise panels */
    document.querySelectorAll('[data-kmae-chat-msg]').forEach(function (msg) {
      var counterOpen = msg.querySelector('[data-kmae-counter-open]');
      var counterPanel = msg.querySelector('[data-kmae-counter-panel]');
      var counterCancel = msg.querySelector('[data-kmae-counter-cancel]');
      var reviseOpen = msg.querySelector('[data-kmae-revise-open]');
      var revisePanel = msg.querySelector('[data-kmae-revise-panel]');
      var reviseCancel = msg.querySelector('[data-kmae-revise-cancel]');

      if (counterOpen && counterPanel) {
        counterOpen.addEventListener('click', function () {
          var roundsLeft = counterOpen.getAttribute('data-kmae-rounds-left') || kmaePublic.maxCounterRounds;
          showRoundsModal(roundsLeft, function () {
            counterPanel.removeAttribute('hidden');
            counterOpen.setAttribute('hidden', '');
            counterOpen.setAttribute('aria-expanded', 'true');
          });
        });
      }

      if (counterCancel && counterPanel) {
        counterCancel.addEventListener('click', function () {
          counterPanel.setAttribute('hidden', '');
          if (counterOpen) {
            counterOpen.removeAttribute('hidden');
            counterOpen.setAttribute('aria-expanded', 'false');
          }
        });
      }

      if (reviseOpen && revisePanel) {
        reviseOpen.addEventListener('click', function () {
          var roundsLeft = reviseOpen.getAttribute('data-kmae-rounds-left') || kmaePublic.maxCounterRounds;
          showRoundsModal(roundsLeft, function () {
            revisePanel.removeAttribute('hidden');
            reviseOpen.setAttribute('hidden', '');
            reviseOpen.setAttribute('aria-expanded', 'true');
          });
        });
      }

      if (reviseCancel && revisePanel) {
        reviseCancel.addEventListener('click', function () {
          revisePanel.setAttribute('hidden', '');
          if (reviseOpen) {
            reviseOpen.removeAttribute('hidden');
            reviseOpen.setAttribute('aria-expanded', 'false');
          }
        });
      }
    });

    /* Offer zone: warn before typing or sending — never after redirect */
    document.querySelectorAll('[data-kmae-offer-zone]').forEach(function (zone) {
      var roundsLeft = zone.getAttribute('data-kmae-rounds-left') || (typeof kmaePublic !== 'undefined' ? kmaePublic.maxCounterRounds : 2);
      var warned = false;

      function warnOnce(onDone) {
        if (warned) {
          if (onDone) {
            onDone();
          }
          return;
        }
        warned = true;
        showRoundsModal(roundsLeft, onDone);
      }

      zone.addEventListener('focusin', function (e) {
        if (e.target.matches('input, textarea, select')) {
          warnOnce();
        }
      });

      zone.querySelectorAll('.kmae-tab-btn').forEach(function (btn) {
        btn.addEventListener('click', function () {
          warnOnce();
        });
      });

      zone.querySelectorAll('form').forEach(function (form) {
        form.addEventListener('submit', function (e) {
          if (form.dataset.kmaeRoundsSkip === '1') {
            form.dataset.kmaeRoundsSkip = '';
            return;
          }
          if (warned) {
            return;
          }
          e.preventDefault();
          warnOnce(function () {
            form.dataset.kmaeRoundsSkip = '1';
            if (typeof form.requestSubmit === 'function') {
              form.requestSubmit();
            } else {
              form.submit();
            }
          });
        });
      });
    });

    /* Cash amounts: live thousands formatting + strip on submit */
    function stripCashDigits(value) {
      return (value || '').replace(/\D/g, '');
    }

    function formatCashDigits(digits) {
      if (!digits) {
        return '';
      }
      return digits.replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
    }

    document.querySelectorAll('[data-kmae-cash-input]').forEach(function (input) {
      input.addEventListener('input', function () {
        var digits = stripCashDigits(input.value);
        input.value = formatCashDigits(digits);
      });
    });

    document.addEventListener('submit', function (e) {
      var form = e.target;
      if (!form || !form.querySelectorAll) {
        return;
      }
      form.querySelectorAll('[data-kmae-cash-input]').forEach(function (input) {
        input.value = stripCashDigits(input.value);
      });
    }, true);

    /* Auto-refresh when offer activity changes on the current page */
    (function () {
      var root = document.querySelector('[data-kmae-live-page]');
      if (!root || typeof kmaePublic === 'undefined' || !kmaePublic.livePoll) {
        return;
      }

      var context = root.getAttribute('data-kmae-live-page');
      var initialFingerprint = root.getAttribute('data-kmae-live-fingerprint') || '';
      var interval = kmaePublic.livePoll.interval || 30000;

      function pollPageState() {
        if (document.hidden) {
          return;
        }

        var body = new FormData();
        body.append('action', 'kmae_poll_page');
        body.append('nonce', kmaePublic.livePoll.nonce);
        body.append('context', context);

        if (context === 'offer_thread') {
          body.append('offer_id', root.getAttribute('data-kmae-offer-id') || '');
        } else if (context === 'single_listing') {
          body.append('listing_id', root.getAttribute('data-kmae-listing-id') || '');
        }

        fetch(kmaePublic.livePoll.ajaxUrl, {
          method: 'POST',
          body: body,
          credentials: 'same-origin',
        })
          .then(function (response) {
            return response.json();
          })
          .then(function (data) {
            if (
              data &&
              data.success &&
              data.data &&
              data.data.fingerprint &&
              data.data.fingerprint !== initialFingerprint
            ) {
              window.location.reload();
            }
          })
          .catch(function () {});
      }

      setInterval(pollPageState, interval);
    })();

    (function initAccountTypeToggle() {
      var radios = document.querySelectorAll('input[name="kmae_account_type"]');
      if (!radios.length) {
        return;
      }
      var companyBlocks = document.querySelectorAll('[data-kmae-company-fields]');
      var privateName = document.querySelector('[data-kmae-private-name]');
      var companyName = document.getElementById('kmae_reg_company_name');
      var displayName = document.getElementById('kmae_reg_display_name');

      function sync() {
        var checked = document.querySelector('input[name="kmae_account_type"]:checked');
        var isCompany = checked && checked.value === 'company';
        companyBlocks.forEach(function (el) {
          el.hidden = !isCompany;
        });
        if (privateName) {
          privateName.hidden = !!isCompany;
        }
        if (companyName) {
          companyName.required = !!isCompany;
        }
        if (displayName) {
          displayName.required = !isCompany;
        }
      }

      radios.forEach(function (radio) {
        radio.addEventListener('change', sync);
      });
      sync();
    })();
  });
})();
