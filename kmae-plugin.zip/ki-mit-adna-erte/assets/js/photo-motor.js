(function () {
  'use strict';

  var msgs = {
    tooDark: 'A kép túl sötét. Készíts új fotót jobb fényviszonyok között.',
    tooBright: 'A kép túl világos / kiégett. Készíts új fotót.',
    blurry: 'A kép túl homályos. Készíts élesebb fotót.',
    duplicate: 'Ez a kép már szerepel egy másik nézetnél. Készíts új fotót.',
    tooSmall: 'A kép túl kicsi. Készíts nagyobb felbontású fotót.',
    invalid: 'Érvénytelen kép. Próbáld újra a kamerával.'
  };

  function applyCapturePrefs(root) {
    // Vehicle photos must go through the device camera — never a silent gallery pick.
    root.querySelectorAll('input[data-prefer-camera]').forEach(function (input) {
      input.setAttribute('capture', 'environment');
      input.setAttribute('accept', 'image/*');
    });
  }

  function getCreateDevice() {
    var input = document.getElementById('kmae_create_device');
    return input ? String(input.value || '') : '';
  }

  function isComputerCreate() {
    return getCreateDevice() === 'computer';
  }

  function isAwaitingEdit() {
    var form = document.getElementById('kmae-listing-form');
    return form && form.getAttribute('data-awaiting') === '1';
  }

  function applyDeviceMode(device) {
    var deviceInput = document.getElementById('kmae_create_device');
    var deviceStep = document.getElementById('kmae-device-step');
    var fields = document.getElementById('kmae-listing-fields');
    var photoGate = document.getElementById('kmae-photo-gate');
    var computerHint = document.getElementById('kmae-photo-gate-computer-hint');
    var gateHint = document.getElementById('kmae-photo-gate-hint');
    var openBtn = document.getElementById('kmae-open-photo-step');
    var submit = document.getElementById('kmae-listing-submit');
    var submitHint = document.getElementById('kmae-listing-submit-hint');
    var root = document.getElementById('kmae-photo-motor');

    if (deviceInput) deviceInput.value = device;
    if (deviceStep) deviceStep.hidden = true;
    if (fields) fields.hidden = false;

    var computer = device === 'computer';
    if (photoGate) {
      photoGate.hidden = false;
      photoGate.classList.toggle('is-deferred', computer);
    }
    if (computerHint) computerHint.hidden = !computer;
    if (gateHint) gateHint.hidden = computer;
    if (openBtn) openBtn.hidden = computer;

    if (submit) {
      if (computer) {
        submit.disabled = false;
      } else if (root) {
        updateProgress(root);
      }
    }
    if (submitHint) {
      if (computer) {
        submitHint.textContent = 'Mentés után a hirdetés „Fotó feltöltésre vár” státuszban lesz — később telefonról fotózd le az autót.';
        submitHint.hidden = false;
      } else {
        submitHint.textContent = 'Először készítsd el a 7 kötelező fotót a „Fotók készítése” gombbal.';
        submitHint.hidden = false;
      }
    }

    document.querySelectorAll('.kmae-device-choice').forEach(function (btn) {
      btn.classList.toggle('is-selected', btn.getAttribute('data-kmae-device') === device);
    });
  }

  function loadImage(file) {
    return new Promise(function (resolve, reject) {
      var url = URL.createObjectURL(file);
      var img = new Image();
      img.onload = function () {
        URL.revokeObjectURL(url);
        resolve(img);
      };
      img.onerror = function () {
        URL.revokeObjectURL(url);
        reject(new Error('invalid'));
      };
      img.src = url;
    });
  }

  function analyze(img) {
    var canvas = document.createElement('canvas');
    canvas.width = 64;
    canvas.height = 64;
    var ctx = canvas.getContext('2d', { willReadFrequently: true });
    if (!ctx) {
      return { ok: true, hash: '' };
    }
    ctx.drawImage(img, 0, 0, 64, 64);
    var data = ctx.getImageData(0, 0, 64, 64).data;
    var gray = [];
    var sum = 0;
    var sumSq = 0;
    var n = 64 * 64;
    for (var i = 0; i < data.length; i += 4) {
      var luma = 0.299 * data[i] + 0.587 * data[i + 1] + 0.114 * data[i + 2];
      gray.push(luma);
      sum += luma;
      sumSq += luma * luma;
    }
    var mean = sum / n;
    var variance = sumSq / n - mean * mean;

    var edge = 0;
    var ec = 0;
    for (var y = 1; y < 63; y++) {
      for (var x = 1; x < 63; x++) {
        var idx = y * 64 + x;
        var lap = Math.abs(
          4 * gray[idx] - gray[idx - 1] - gray[idx + 1] - gray[idx - 64] - gray[idx + 64]
        );
        edge += lap;
        ec++;
      }
    }
    var edgeMean = ec ? edge / ec : 0;

    if (img.naturalWidth < 400 || img.naturalHeight < 300) {
      return { ok: false, reason: 'tooSmall' };
    }
    if (mean < 35) {
      return { ok: false, reason: 'tooDark' };
    }
    if (mean > 235) {
      return { ok: false, reason: 'tooBright' };
    }
    if (edgeMean < 4.5 && variance < 180) {
      return { ok: false, reason: 'blurry' };
    }

    var hash = '';
    for (var by = 0; by < 8; by++) {
      for (var bx = 0; bx < 8; bx++) {
        var block = 0;
        for (var yy = 0; yy < 8; yy++) {
          for (var xx = 0; xx < 8; xx++) {
            block += gray[(by * 8 + yy) * 64 + (bx * 8 + xx)];
          }
        }
        hash += block > mean * 64 ? '1' : '0';
      }
    }
    return { ok: true, hash: hash };
  }

  function hamming(a, b) {
    if (!a || !b || a.length !== b.length) return 99;
    var d = 0;
    for (var i = 0; i < a.length; i++) {
      if (a[i] !== b[i]) d++;
    }
    return d;
  }

  function setError(slot, text) {
    var err = slot.querySelector('.kmae-photo-slot__error');
    if (!err) return;
    if (text) {
      err.textContent = text;
      err.hidden = false;
    } else {
      err.textContent = '';
      err.hidden = true;
    }
  }

  function setPreview(slot, file) {
    var preview = slot.querySelector('.kmae-photo-slot__preview');
    if (!preview) return;
    var url = URL.createObjectURL(file);
    preview.innerHTML = '<img src="' + url + '" alt="" />';
    slot.classList.add('is-filled');
    var label = slot.querySelector('.kmae-photo-slot__capture-label');
    if (label) label.textContent = 'Újrafotózás';
    var key = slot.getAttribute('data-slot');
    var dot = document.querySelector('.kmae-car-dot[data-kmae-goto-slot="' + key + '"]');
    if (dot) dot.classList.add('is-filled');
  }

  function countFilled(root, requiredOnly) {
    var filled = 0;
    var sel = requiredOnly ? '.kmae-photo-slot[data-required="1"]' : '.kmae-photo-slot';
    root.querySelectorAll(sel).forEach(function (slot) {
      var input = slot.querySelector('input[type="file"]');
      var hasPreview = !!slot.querySelector('.kmae-photo-slot__preview img');
      var hasFile = input && input.files && input.files.length > 0;
      if (hasPreview || hasFile) filled++;
    });
    return filled;
  }

  function updateProgress(root) {
    var total = parseInt(root.getAttribute('data-required-total') || '7', 10);
    var allTotal = parseInt(root.getAttribute('data-all-total') || '13', 10);
    var filled = countFilled(root, true);
    var allFilled = countFilled(root, false);
    var ready = filled >= total;

    var progress = document.getElementById('kmae-photo-progress');
    if (progress) {
      progress.textContent = 'Kötelező: ' + filled + ' / ' + total;
    }

    var done = document.getElementById('kmae-photo-required-done');
    if (done) done.hidden = !ready;

    var doneBtn = document.getElementById('kmae-photo-done-btn');
    var doneHint = document.getElementById('kmae-photo-done-hint');
    if (doneBtn) doneBtn.disabled = !ready;
    if (doneHint) doneHint.hidden = ready;

    var gate = document.getElementById('kmae-photo-gate');
    var gateStatus = document.getElementById('kmae-photo-gate-status');
    var openBtn = document.getElementById('kmae-open-photo-step');
    if (gate) gate.setAttribute('data-ready', ready ? '1' : '0');
    if (gateStatus) {
      gateStatus.textContent =
        'Kötelező: ' + filled + ' / ' + total + ' · Összes (ajánlott): ' + allFilled + ' / ' + allTotal;
    }
    if (openBtn) {
      openBtn.textContent = ready ? 'Fotók szerkesztése' : 'Fotó feltöltés';
    }

    var submit = document.getElementById('kmae-listing-submit');
    var submitHint = document.getElementById('kmae-listing-submit-hint');
    if (submit && !isComputerCreate()) {
      if (isAwaitingEdit()) {
        // Allow saving listing details anytime; activation happens when photos are complete.
        submit.disabled = false;
        if (ready) {
          submit.textContent = 'Fotók mentése és aktiválás';
        } else {
          submit.textContent = 'Mentés';
        }
        if (submitHint) {
          submitHint.textContent = ready
            ? 'A kötelező fotók megvannak — mentés után a hirdetés aktív lesz.'
            : 'Fotók nélkül is mentheted az adatokat. Aktiváláshoz készítsd el a 7 kötelező kamera-fotót.';
          submitHint.hidden = false;
        }
      } else if (submitHint) {
        submit.disabled = !ready;
        submitHint.hidden = ready;
      }
    }
  }

  function collectHashes(root, exceptSlot) {
    var hashes = [];
    root.querySelectorAll('.kmae-photo-slot').forEach(function (slot) {
      if (exceptSlot && slot === exceptSlot) return;
      if (slot.dataset.photoHash) hashes.push(slot.dataset.photoHash);
    });
    return hashes;
  }

  function openPhotoStep() {
    var fields = document.getElementById('kmae-listing-fields');
    var step = document.getElementById('kmae-photo-step');
    if (fields) fields.hidden = true;
    if (step) {
      step.hidden = false;
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }

  function closePhotoStep() {
    var fields = document.getElementById('kmae-listing-fields');
    var step = document.getElementById('kmae-photo-step');
    if (step) step.hidden = true;
    if (fields) {
      fields.hidden = false;
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }

  document.addEventListener('DOMContentLoaded', function () {
    var root = document.getElementById('kmae-photo-motor');
    var form = document.getElementById('kmae-listing-form');
    var deviceStep = document.getElementById('kmae-device-step');

    document.querySelectorAll('[data-kmae-device]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        applyDeviceMode(btn.getAttribute('data-kmae-device') || '');
      });
    });

    if (!root) {
      if (deviceStep) {
        // Device step present but no photo motor root yet — still allow computer path after choice.
        return;
      }
      return;
    }

    applyCapturePrefs(root);

    var openBtn = document.getElementById('kmae-open-photo-step');
    var closeBtn = document.getElementById('kmae-close-photo-step');
    var doneBtn = document.getElementById('kmae-photo-done-btn');
    if (openBtn) openBtn.addEventListener('click', openPhotoStep);
    if (closeBtn) closeBtn.addEventListener('click', closePhotoStep);
    if (doneBtn) {
      doneBtn.addEventListener('click', function () {
        if (!doneBtn.disabled) closePhotoStep();
      });
    }

    if (form && form.getAttribute('data-open-photos') === '1') {
      openPhotoStep();
    }

    // Edit of awaiting listing: require photos before activate submit.
    if (isAwaitingEdit()) {
      updateProgress(root);
    }

    // Create without device yet: keep submit disabled until device chosen.
    if (deviceStep && !deviceStep.hidden && !getCreateDevice()) {
      var submit = document.getElementById('kmae-listing-submit');
      if (submit) submit.disabled = true;
    }

    document.querySelectorAll('[data-kmae-goto-slot]').forEach(function (dot) {
      dot.addEventListener('click', function () {
        var key = dot.getAttribute('data-kmae-goto-slot');
        var slot = document.getElementById('kmae-slot-' + key);
        if (slot) {
          slot.scrollIntoView({ behavior: 'smooth', block: 'center' });
          var input = slot.querySelector('input[type="file"]');
          if (input) input.focus({ preventScroll: true });
        }
      });
    });

    root.querySelectorAll('.kmae-photo-slot input[type="file"]').forEach(function (input) {
      input.addEventListener('change', function () {
        var slot = input.closest('.kmae-photo-slot');
        if (!slot || !input.files || !input.files[0]) return;
        var file = input.files[0];
        setError(slot, '');
        loadImage(file)
          .then(function (img) {
            var result = analyze(img);
            if (!result.ok) {
              setError(slot, msgs[result.reason] || msgs.invalid);
              input.value = '';
              return;
            }
            var others = collectHashes(root, slot);
            for (var i = 0; i < others.length; i++) {
              if (hamming(result.hash, others[i]) <= 8) {
                setError(slot, msgs.duplicate);
                input.value = '';
                return;
              }
            }
            slot.dataset.photoHash = result.hash;
            setPreview(slot, file);
            updateProgress(root);
          })
          .catch(function () {
            setError(slot, msgs.invalid);
            input.value = '';
          });
      });
    });

    if (form) {
      form.addEventListener('submit', function (e) {
        if (isComputerCreate()) {
          return;
        }
        // Awaiting edit may save details without photos; only block phone/tablet create.
        if (isAwaitingEdit()) {
          return;
        }
        var total = parseInt(root.getAttribute('data-required-total') || '7', 10);
        var filled = countFilled(root, true);
        if (filled < total) {
          e.preventDefault();
          openPhotoStep();
          var first = root.querySelector('.kmae-photo-slot[data-required="1"]:not(.is-filled)');
          if (first) {
            first.scrollIntoView({ behavior: 'smooth', block: 'center' });
            setError(first, 'Ez a nézet kötelező.');
          }
        }
      });
    }

    updateProgress(root);
  });
})();
