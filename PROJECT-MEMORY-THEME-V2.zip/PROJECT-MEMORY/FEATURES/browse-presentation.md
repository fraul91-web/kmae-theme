# FEATURE — BROWSE / SEARCH PRESENTATION

## PURPOSE
Identify browse/archive surfaces and apply the browse visual layer.

## READ FIRST
- `functions.php::kmae_is_browse_page()`
- `functions.php::kmae_enqueue_browse()`
- `assets/css/browse.css`

## THEN IF NEEDED
- header active-state logic;
- plugin map for archive template / `kmae_browse` shortcode.

## DO NOT LOAD UNLESS RELEVANT
- listing-create CSS.

## ENTRY POINTS
`kmae_listing` archive, slug `hirdetesek`, or `kmae_browse` shortcode.

## DATA USED
Theme only uses query/slug/content/auth state.

## FLOW
Route detection → `kmae-browse-page` → browse.css → external/plugin markup.

## DEPENDENCIES
Plugin owns actual filtering/search/result generation.

## SIDE EFFECTS
None in theme.

## CHANGE RISKS
Archive and page share one detector; a change intended for one can affect both.

## V2 DIAGNOSTIC ROUTING

**FEATURE:** BROWSE PRESENTATION  
**PURPOSE:** Keep diagnosis inside the smallest theme-owned path before crossing any plugin boundary.

**COMMON SYMPTOMS:** browse CSS missing; guest/logged-in browse visual mismatch; search results markup does not match theme selectors.

**READ FIRST:** `functions.php::kmae_is_browse_page()` (`82–102`) → `kmae_body_classes()` → `kmae_enqueue_browse()` (`478–489`) → `assets/css/browse.css`.

**EXPECTED FLOW:** archive/page/shortcode detector → body class → CSS handle → plugin/archive DOM → visual rules.

**CHECKPOINTS:** detector true? body class present? style loaded? DOM matches selector? data itself correct?.

**IF X → GO TO:** DOM/data wrong → plugin/archive boundary; DOM correct but visual wrong → browse CSS only.

**SEARCH TERMS:** `kmae_listing`, `hirdetesek`, `kmae_browse`, `kmae-browse-page`, `kmae-browse`.

**DO NOT LOAD UNLESS:** listing-create CSS, offers/chat, full plugin until DOM/data boundary fails.

**PLUGIN BOUNDARY:** browse/search markup and behavior are plugin/archive-owned; implementation UNVERIFIED.

**CHANGE RISKS:** page is supported for guest and logged-in with different CSS dependency parent.

**REGRESSION CHECKS:** archive + page/shortcode detection; guest + logged-in browse; one mobile/desktop breakpoint.

**VERIFICATION STATUS:** VERIFIED theme routing/presentation.
