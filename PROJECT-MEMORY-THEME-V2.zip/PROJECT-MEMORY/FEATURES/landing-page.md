# FEATURE — GUEST LANDING PAGE

## PURPOSE
Render the complete public front-page marketing content and route CTAs to browse/listing-create.

## READ FIRST
- `template-parts/simple-mode/landing.php`
- `assets/css/simple-mode/landing.css`

## THEN IF NEEDED
- `functions.php::kmae_media_url()`
- `functions.php::kmae_page_url()`
- `front-page.php`

## DO NOT LOAD UNLESS RELEVANT
- plugin listing-create/browse implementation;
- logged-in dashboard files.

## ENTRY POINT
`front-page.php` when logged out.

## PRIMARY SECTIONS
Hero; seller/buyer role explanation; two selling paths; value/offer graphic; 4-step process; trust section; final CTA.

## DATA USED
Remote image URLs from `kmae_media_url()` and logical route URLs from `kmae_page_url()`.

## FLOW
Front-page guest branch → landing variables → static translated markup → CTA links.

## DEPENDENCIES
Remote production uploads; plugin URL provider optional through `KMAE_Pages`.

## SIDE EFFECTS
None.

## CHANGE RISKS
Image keys are centralized in PHP while an additional landing background is hardcoded in CSS, so visual asset migration spans at least two files.

## V2 DIAGNOSTIC ROUTING

**FEATURE:** LANDING PAGE  
**PURPOSE:** Keep diagnosis inside the smallest theme-owned path before crossing any plugin boundary.

**COMMON SYMPTOMS:** guest hero/CTA/link/media wrong; landing section visually wrong.

**READ FIRST:** `front-page.php:8–16` → `template-parts/simple-mode/landing.php` affected section → `landing.css`.

**EXPECTED FLOW:** guest front page → landing template variables/helpers → section markup → guest CSS.

**CHECKPOINTS:** correct branch? href/src correct in HTML? selector matches? responsive rule?.

**IF X → GO TO:** URL/logo helper wrong → branding/boundary; markup correct visual wrong → landing CSS.

**SEARCH TERMS:** visible section text, `kmae_page_url`, `kmae_media_url`, section class, media key.

**DO NOT LOAD UNLESS:** logged-in app/dashboard.

**PLUGIN BOUNDARY:** URL/logo helpers can delegate to plugin; landing composition itself is theme-owned.

**CHANGE RISKS:** landing.css also affects guest inner pages via broad guest layer.

**REGRESSION CHECKS:** front-page guest section + shared guest header/footer + relevant breakpoint.

**VERIFICATION STATUS:** VERIFIED.
