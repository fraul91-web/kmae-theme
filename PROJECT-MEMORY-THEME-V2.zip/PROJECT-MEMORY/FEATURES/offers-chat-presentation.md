# FEATURE — OFFERS / CHAT PRESENTATION

## PURPOSE
Detect and style offers plus chat/thread UI and expose offer activity badges in navigation.

## READ FIRST
- `functions.php::kmae_is_my_offers_page()`
- `functions.php::kmae_enqueue_app_shell()` offers branch
- `assets/css/my-offers.css`
- `header.php` unseen badge

## THEN IF NEEDED
- `kmae_app_menu_groups()`
- plugin map for offers/counter-offers/chat/notifications/database.

## DO NOT LOAD UNLESS RELEVANT
- profile/settings/wizard CSS.

## ENTRY POINT
Slug `ajanlatok` or shortcode `kmae_my_offers`; `?kmae_offer` additionally affects active nav.

## DATA USED
Theme directly uses only route state and plugin unseen activity count.

## FLOW
Route → body class/CSS → plugin offer/chat DOM. Separately header/menu call unseen-count plugin API for badges.

## DEPENDENCIES
Strong plugin DOM and data dependency.

## SIDE EFFECTS
No theme message send/counter-offer/AJAX logic.

## CHANGE RISKS
Do not treat `.kmae-chat-*` CSS as proof of behavior. For any send/accept/reject/counter logic issue, transition immediately to plugin map.

## V2 DIAGNOSTIC ROUTING

**FEATURE:** OFFERS CHAT PRESENTATION  
**PURPOSE:** Keep diagnosis inside the smallest theme-owned path before crossing any plugin boundary.

**COMMON SYMPTOMS:** offers page styling wrong; badge wrong; chat/offer action/update fails.

**READ FIRST:** route/style: `kmae_is_my_offers_page()` + app-shell enqueue `425–432`; badge: header/menu groups; CSS: `my-offers.css`.

**EXPECTED FLOW:** route → body/style → plugin offers/chat DOM/data; unseen count separately flows through plugin count → theme badge.

**CHECKPOINTS:** visual vs value vs action? route/class/style? count return? DOM/data?.

**IF X → GO TO:** badge → R10; action/data/poll/update → plugin boundary; visual → my-offers.css.

**SEARCH TERMS:** `ajanlatok`, `kmae_my_offers`, `kmae-my-offers-page`, `my-offers.css`, `kmae_offer`, `data-kmae-unseen`.

**DO NOT LOAD UNLESS:** full theme JS for offer business action; no theme AJAX/REST/fetch exists.

**PLUGIN BOUNDARY:** offers/chat business logic and producer data UNVERIFIED PLUGIN TARGET.

**CHANGE RISKS:** unseen count is reused in header and drawer; active state also reacts to `kmae_offer` query.

**REGRESSION CHECKS:** offers route/style; zero/positive badge; desktop+drawer; plugin actions require separate plugin regression.

**VERIFICATION STATUS:** VERIFIED theme boundary.
