# CSS MAP — CASCADE + DOM OWNERSHIP

## Load matrix

| CSS | Guest | Logged-in | Condition | Main responsibility |
|---|:---:|:---:|---|---|
| `theme.css` | ✓ | ✓ | always | shared base, shell primitives, generic/legacy components |
| `simple-mode/landing.css` | ✓ | – | all logged-out | guest marketing/auth visual system |
| `simple-mode/app.css` | – | ✓ | all logged-in | application/dashboard/hub base |
| `simple-mode/pc-dashboard.css` | – | ✓ | all logged-in | PC dashboard/sidebar/info layout |
| `simple-mode/app-shell-dark.css` | – | ✓ | all logged-in, late | dark app shell overrides |
| `simple-mode/header.css` | – | ✓ | all logged-in, late | logged-in header/topbar |
| `home-cards.css` | – | ✓ | all logged-in | dashboard/home-card visuals |
| `listing-create.css` | ✓ | ✓ | create page | wizard/listing-create presentation |
| `browse.css` | ✓ | ✓ | browse/archive | browse/search presentation |
| `how-it-works.css` | ✓ | ✓ | how-it-works page | feature page + lightbox styling |
| `faq.css` | ✓ | ✓ | FAQ page | FAQ page |
| `contact.css` | ✓ | ✓ | contact page | contact page |
| `single-listing.css` | –* | ✓* | singular listing inside logged-in shell enqueue | listing body presentation |
| `my-listings.css` | – | ✓ | my-listings | owner listing cards/actions |
| `my-offers.css` | – | ✓ | offers | offer/chat UI |
| `profile.css` | – | ✓ | profile | profile UI |
| `settings.css` | – | ✓ | settings | settings UI |
| `google-complete.css` | – | ✓ | Google completion | completion/auth override |

`*` In this snapshot `single-listing.css` is enqueued from the logged-in-only app-shell callback, so a logged-out singular listing does not receive that enqueue from the theme.

## Major selector families and markup ownership

### `theme.css`
- Theme-owned: `.kmae-header*`, `.kmae-drawer*`, `.kmae-footer*`, `.kmae-bottom-nav*`, `.kmae-page*`, common button/container classes.
- Mixed/external: `.kmae-auth*`, `.kmae-wizard*`, `.kmae-swipe-*`, notices and several plugin-facing primitives.
- Use as first cascade layer, not feature truth.

### `landing.css`
- Theme-owned landing markup: `.kmae-landing-*` families.
- Plugin-facing auth markup: `.kmae-auth*`, `.kmae-form*`, `.kmae-account-type*`, `.kmae-phone-input*`, `.kmae-google-btn*`.
- Remote page background is encoded in CSS.

### `app.css`
- Core logged-in structure: `.kmae-app*`, `.kmae-app-layout`, `.kmae-app-content`.
- Many `.kmae-dash*`, `.kmae-hub*` selectors style plugin dashboard/hub markup.
- Contains responsive dashboard/hub behavior and reduced-motion adjustments.

### `pc-dashboard.css`
- Strongly plugin-markup coupled: `.kmae-pc*`, `.kmae-app-sidebar*`, `.kmae-app-info*`, `.kmae-tip*`.
- If dashboard markup changes, inspect plugin dashboard partial before editing CSS.

### `app-shell-dark.css`
- Late shell overrides anchored on `body.kmae-app.kmae-theme-dark` and `.kmae-hub*`.
- Remote app background landscape + portrait.

### `header.css`
- Strongly coupled to `header.php` classes.
- Desktop threshold 1025px; mobile/tablet <=1024.
- Remote `header.webp` background in logged-in desktop section.

### `home-cards.css`
- `.kmae-home-card*` and `.kmae-home-greeting*`.
- Most markup not emitted by theme itself; expected in plugin dashboard partial.
- Two remote background images via custom property `--hc-bg`.

### `listing-create.css`
- Very large selector contract for plugin wizard/listing form markup.
- Dominant roots include `.kmae-create-page`, `.kmae-wizard-choice`, `.kmae-wizard-stage`, `.kmae-wizard-preview`, `.kmae-wizard-main`, `.kmae-wizard-assist`, `.kmae-create-section`, `.kmae-listing-guest`, `.kmae-year`, `.kmae-commitment-option`, `.kmae-price-mode`, `.kmae-uploader`, `.kmae-shot`, `.kmae-catalog-*`, `.kmae-mileage`.
- Responsive breakpoints found: 1280, 1024, 1000, 860, 720, 640, 560, 520 and desktop min 1025.
- Contains multiple animation keyframes and reduced-motion handling.
- Theme provides styling only; wizard JS/PHP/data flow are outside this snapshot.

### `browse.css`
- Scoped heavily by `.kmae-browse-page`.
- Main external DOM families: wizard/map/county/mode cards, `.kmae-swipe-*`, result cards.
- Desktop-only feature rules begin at min 1025.

### `single-listing.css`
- Main external DOM: `.kmae-single-listing*`, `.kmae-listing-hero*`, `.kmae-gallery-*`, `.kmae-vehicle-*`, `.kmae-offer-*`, `.kmae-verify-gate*`, `.kmae-trust-card*`, `.kmae-pledge-*`.
- Markup not emitted by this theme snapshot.

### `my-listings.css`
- `.kmae-my-listings*`, `.kmae-my-listing-card*`, `.kmae-draft-radial*`, `.kmae-delete-confirm*`.
- Comment explicitly names `my-listings.js`; JS is absent from theme.

### `my-offers.css`
- `.kmae-my-offers*`, `.kmae-offer-thread*`, `.kmae-offer-tile*`, `.kmae-chat-*`, `.kmae-counter-*`, `.kmae-rounds-modal-*`.
- Strong plugin DOM/behavior coupling.

### `profile.css`
- `.kmae-profile-*` families; desktop rules under min 1025.
- Page body class from theme; content markup plugin-owned.

### `settings.css`
- `.kmae-settings-*` families; desktop rules under min 1025.
- Content markup plugin-owned.

### `google-complete.css`
- Scoped with `.kmae-app.kmae-complete-page` and auth/form selectors.
- Explicitly suppresses common shell distractions at desktop.
- Content markup is register/auth shortcode output: plugin-owned.

### `how-it-works.css`
- `.kmae-how-*` plus `.kmae-video-lightbox*`.
- Theme JS knows lightbox hooks, but PHP markup is not in theme.

### `faq.css`
- `.kmae-faq*` families; content markup outside theme.

### `contact.css`
- `.kmae-contact-*` families; content markup outside theme.

## Responsive breakpoints by file

- `theme.css`: extensive 380/420/520/820/900/960/1024/1100/1600 plus orientation/height cases.
- `landing.css`: desktop min 1025; mobile/tablet default rules.
- `app.css`: 480/720/1025/1366 + reduced motion.
- `header.css`: <=1024, >=1025, 1025–1399.
- `listing-create.css`: 520/560/640/720/860/1000/1024/1280 + >=1025 + reduced motion.
- `home-cards.css`: <=1024, <=480.
- `my-listings.css`: <=1100.
- `my-offers.css`: >=1025 and <=640.
- `single-listing.css`: <=1100 and <=640.
- profile/settings/browse/FAQ/contact/how-it-works/google-complete: major desktop block at >=1025.

## CSS change-risk rule

Before modifying a feature stylesheet, determine whether its target DOM is:
1. emitted by theme PHP (safe to inspect locally), or
2. emitted by plugin shortcode/template (load plugin feature map first).

The second case applies to most application feature CSS files.

## V2 CSS DIAGNOSTIC PROTOCOL

Use this order; stop as soon as the first failed checkpoint is found:

1. **ROUTE:** is the request the route the feature detector recognizes?
2. **BODY:** is the expected `kmae-*-page` / auth body class present?
3. **HANDLE:** is the expected stylesheet actually enqueued with the correct dependency/auth gate?
4. **DOM:** does the exact selector match current markup?
5. **MEDIA:** is the current viewport inside the intended `@media` branch?
6. **CASCADE:** does a later/more-specific rule override it?
7. **LAYOUT:** only after computed declaration is correct, inspect parent/grid/flex/overflow/position interactions.

### Negative routing

- Correct DOM class + correct computed data/text → **do not inspect backend** for a visual-only problem.
- Failure only at one breakpoint + same DOM → **do not load all CSS**; search the affected selector and its media variants.
- Missing selector match → **stop cascade debugging**; identify DOM producer.
- `landing.css` is not landing-only: it loads on every guest request through `kmae_assets()`.
- `single-listing.css` is currently enqueued only from logged-in `kmae_enqueue_app_shell()`; guest-only missing single-listing style can be explained before selector analysis.
