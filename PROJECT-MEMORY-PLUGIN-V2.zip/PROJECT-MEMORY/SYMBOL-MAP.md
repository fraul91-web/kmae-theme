# SYMBOL MAP

This is the broad symbol index. For feature work, open the matching `FEATURES/*.md` first and only use this file to locate exact symbols.

Format per symbol: FILE / SYMBOL / PURPOSE / CALLED BY / CALLS / READS / WRITES / RELATED FEATURE.

## `KMAE_Admin::__construct`
- FILE: `admin/class-kmae-admin.php:14-26`
- SYMBOL: `KMAE_Admin::__construct`
- PURPOSE: WordPress admin integration.
- CALLED BY: —
- CALLS: `KMAE_Settings::init`
- READS: —
- WRITES: —
- RELATED FEATURE: `ADMIN`

## `KMAE_Admin::add_menu`
- FILE: `admin/class-kmae-admin.php:29-65`
- SYMBOL: `KMAE_Admin::add_menu`
- PURPOSE: WordPress admin integration.
- CALLED BY: `WP action `admin_menu``
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `ADMIN`

## `KMAE_Admin::admin_notices`
- FILE: `admin/class-kmae-admin.php:68-83`
- SYMBOL: `KMAE_Admin::admin_notices`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `WP action `admin_notices``
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `ADMIN`
- GET KEYS: `kmae_notice`

## `KMAE_Admin::render_settings`
- FILE: `admin/class-kmae-admin.php:86-87`
- SYMBOL: `KMAE_Admin::render_settings`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: —
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `ADMIN`

## `KMAE_Admin::render_offers`
- FILE: `admin/class-kmae-admin.php:90-105`
- SYMBOL: `KMAE_Admin::render_offers`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: —
- CALLS: `KMAE_Database::get_all_offers`, `KMAE_Database::count_all_offers`, `KMAE_Counter_Offers::status_labels`
- READS: —
- WRITES: —
- RELATED FEATURE: `ADMIN`
- GET KEYS: `kmae_notice`, `paged`, `status`

## `KMAE_Admin::render_dashboard`
- FILE: `admin/class-kmae-admin.php:108-113`
- SYMBOL: `KMAE_Admin::render_dashboard`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: —
- CALLS: —
- READS: `wpdb:get_var`
- WRITES: —
- RELATED FEATURE: `ADMIN`

## `KMAE_Admin::handle_delete_listing`
- FILE: `admin/class-kmae-admin.php:133-147`
- SYMBOL: `KMAE_Admin::handle_delete_listing`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `WP action `admin_post_kmae_admin_delete_listing``
- CALLS: `KMAE_Listings::force_delete_listing`
- READS: —
- WRITES: —
- RELATED FEATURE: `ADMIN`
- GET KEYS: `listing_id`, `redirect`

## `KMAE_Admin::handle_delete_offer`
- FILE: `admin/class-kmae-admin.php:150-162`
- SYMBOL: `KMAE_Admin::handle_delete_offer`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `WP action `admin_post_kmae_admin_delete_offer``
- CALLS: `KMAE_Database::admin_delete_offer`
- READS: —
- WRITES: —
- RELATED FEATURE: `ADMIN`
- GET KEYS: `offer_id`

## `KMAE_Admin::handle_set_status`
- FILE: `admin/class-kmae-admin.php:165-193`
- SYMBOL: `KMAE_Admin::handle_set_status`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `WP action `admin_post_kmae_admin_set_status``
- CALLS: —
- READS: —
- WRITES: `postmeta:_kmae_status`, `postmeta:_kmae_published_at`
- RELATED FEATURE: `ADMIN`
- GET KEYS: `listing_id`, `redirect`, `status`

## `KMAE_Admin::listing_columns`
- FILE: `admin/class-kmae-admin.php:196-213`
- SYMBOL: `KMAE_Admin::listing_columns`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `WP filter `manage_kmae_listing_posts_columns``
- CALLS: `KMAE_Vehicle::is_vehicle_launch`
- READS: —
- WRITES: —
- RELATED FEATURE: `ADMIN`

## `KMAE_Admin::listing_column_content`
- FILE: `admin/class-kmae-admin.php:216-246`
- SYMBOL: `KMAE_Admin::listing_column_content`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `WP action `manage_kmae_listing_posts_custom_column``
- CALLS: `KMAE_Vehicle::get_swipe_subtitle`, `KMAE_Meta::get_status`, `KMAE_Meta::get_offer_types`, `KMAE_Taxonomies::offer_type_labels`, `KMAE_Database::count_offers_for_listing`, `KMAE_Admin::status_badge`
- READS: —
- WRITES: —
- RELATED FEATURE: `ADMIN`

## `KMAE_Admin::listing_row_actions`
- FILE: `admin/class-kmae-admin.php:249-318`
- SYMBOL: `KMAE_Admin::listing_row_actions`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `WP filter `post_row_actions``
- CALLS: `KMAE_Meta::get_status`
- READS: —
- WRITES: —
- RELATED FEATURE: `ADMIN`

## `KMAE_Admin::listing_bulk_actions`
- FILE: `admin/class-kmae-admin.php:321-325`
- SYMBOL: `KMAE_Admin::listing_bulk_actions`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `WP filter `bulk_actions-edit-kmae_listing``
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `ADMIN`

## `KMAE_Admin::handle_listing_bulk_actions`
- FILE: `admin/class-kmae-admin.php:328-352`
- SYMBOL: `KMAE_Admin::handle_listing_bulk_actions`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `WP filter `handle_bulk_actions-edit-kmae_listing``
- CALLS: `KMAE_Listings::force_delete_listing`
- READS: —
- WRITES: `postmeta:_kmae_status`
- RELATED FEATURE: `ADMIN`

## `KMAE_Admin::status_badge`
- FILE: `admin/class-kmae-admin.php:355-363`
- SYMBOL: `KMAE_Admin::status_badge`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Admin::listing_column_content`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `ADMIN`

## `KMAE_Admin::admin_action_url`
- FILE: `admin/class-kmae-admin.php:366-373`
- SYMBOL: `KMAE_Admin::admin_action_url`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: —
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `ADMIN`

## `KMAE_Admin::enqueue`
- FILE: `admin/class-kmae-admin.php:376-379`
- SYMBOL: `KMAE_Admin::enqueue`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `WP action `admin_enqueue_scripts``
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `ADMIN`

## `KMAE_Activator::activate`
- FILE: `includes/class-kmae-activator.php:14-26`
- SYMBOL: `KMAE_Activator::activate`
- PURPOSE: Plugin activation: database tables, default categories, rewrite rules.
- CALLED BY: —
- CALLS: `KMAE_Post_Types::register_post_type`, `KMAE_Taxonomies::register_taxonomy`, `KMAE_Taxonomies::seed_categories`, `KMAE_Pages::ensure_pages`, `KMAE_Auth::ensure_subscriber_caps`, `KMAE_Activator::create_tables`, `KMAE_Activator::migrate_price_modes`, `KMAE_Activator::schedule_cron`
- READS: —
- WRITES: —
- RELATED FEATURE: `BOOT-ARCHITECTURE`, `CRON-ARCHIVE`

## `KMAE_Activator::schedule_cron`
- FILE: `includes/class-kmae-activator.php:29-32`
- SYMBOL: `KMAE_Activator::schedule_cron`
- PURPOSE: Plugin activation: database tables, default categories, rewrite rules.
- CALLED BY: `KMAE_Listings::init`, `KMAE_Activator::activate`, `KMAE_Activator::maybe_upgrade`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `BOOT-ARCHITECTURE`, `CRON-ARCHIVE`

## `KMAE_Activator::create_tables`
- FILE: `includes/class-kmae-activator.php:35-42`
- SYMBOL: `KMAE_Activator::create_tables`
- PURPOSE: Plugin activation: database tables, default categories, rewrite rules.
- CALLED BY: `KMAE_Activator::activate`, `KMAE_Activator::maybe_upgrade`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `BOOT-ARCHITECTURE`, `CRON-ARCHIVE`

## `KMAE_Activator::migrate_price_modes`
- FILE: `includes/class-kmae-activator.php:168-185`
- SYMBOL: `KMAE_Activator::migrate_price_modes`
- PURPOSE: Pre-3.18 listings stored a single "offers" mode. It now means "Ki mit adna érte" (open).
- CALLED BY: `KMAE_Activator::activate`, `KMAE_Activator::maybe_upgrade`
- CALLS: —
- READS: `option:kmae_price_modes_migrated`
- WRITES: `option:kmae_price_modes_migrated`, `wpdb:update`
- RELATED FEATURE: `BOOT-ARCHITECTURE`, `CRON-ARCHIVE`

## `KMAE_Activator::maybe_upgrade`
- FILE: `includes/class-kmae-activator.php:188-195`
- SYMBOL: `KMAE_Activator::maybe_upgrade`
- PURPOSE: Pre-3.18 listings stored a single "offers" mode. It now means "Ki mit adna érte" (open).
- CALLED BY: `KMAE_Plugin::run`
- CALLS: `KMAE_Pages::ensure_pages`, `KMAE_Auth::ensure_subscriber_caps`, `KMAE_Activator::create_tables`, `KMAE_Activator::migrate_price_modes`, `KMAE_Activator::schedule_cron`
- READS: `option:kmae_db_version`
- WRITES: —
- RELATED FEATURE: `BOOT-ARCHITECTURE`, `CRON-ARCHIVE`

## `KMAE_Auth::login_url`
- FILE: `includes/class-kmae-auth.php:17-22`
- SYMBOL: `KMAE_Auth::login_url`
- PURPOSE: User registration, login, and profile storage.
- CALLED BY: `KMAE_Auth::lost_password_url`, `KMAE_Auth::reset_password_url`, `KMAE_Auth::maybe_handle_email_verify_link`, `KMAE_Auth::handle_resend_verification`, `KMAE_Public::admin_login`, `KMAE_Public::admin_register`, `KMAE_Public::admin_lost_password`, `KMAE_Public::admin_reset_password`, `KMAE_Shortcodes::require_login`
- CALLS: `KMAE_Pages::url`
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `NOTIFICATIONS`

## `KMAE_Auth::register_url`
- FILE: `includes/class-kmae-auth.php:25-26`
- SYMBOL: `KMAE_Auth::register_url`
- PURPOSE: User registration, login, and profile storage.
- CALLED BY: `KMAE_Public::admin_register`, `KMAE_Shortcodes::require_login`
- CALLS: `KMAE_Pages::url`
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `NOTIFICATIONS`

## `KMAE_Auth::lost_password_url`
- FILE: `includes/class-kmae-auth.php:34-35`
- SYMBOL: `KMAE_Auth::lost_password_url`
- PURPOSE: Branded lost-password URL.
- CALLED BY: `KMAE_Auth::filter_lostpassword_url`, `KMAE_Auth::redirect_wp_password_screens`, `KMAE_Public::admin_lost_password`, `KMAE_Public::admin_reset_password`
- CALLS: `KMAE_Auth::login_url`
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `NOTIFICATIONS`

## `KMAE_Auth::reset_password_url`
- FILE: `includes/class-kmae-auth.php:45-53`
- SYMBOL: `KMAE_Auth::reset_password_url`
- PURPOSE: Branded password-reset URL (from email link).
- CALLED BY: `KMAE_Auth::filter_reset_message`, `KMAE_Auth::redirect_wp_password_screens`, `KMAE_Auth::request_password_reset`, `KMAE_Public::admin_reset_password`
- CALLS: `KMAE_Auth::login_url`
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `NOTIFICATIONS`

## `KMAE_Auth::init`
- FILE: `includes/class-kmae-auth.php:56-62`
- SYMBOL: `KMAE_Auth::init`
- PURPOSE: Branded password-reset URL (from email link).
- CALLED BY: `KMAE_Plugin::run`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `NOTIFICATIONS`

## `KMAE_Auth::filter_lostpassword_url`
- FILE: `includes/class-kmae-auth.php:71-72`
- SYMBOL: `KMAE_Auth::filter_lostpassword_url`
- PURPOSE: Point WP lost-password links to the branded login page.
- CALLED BY: `WP filter `lostpassword_url``
- CALLS: `KMAE_Auth::lost_password_url`
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `NOTIFICATIONS`

## `KMAE_Auth::filter_reset_message`
- FILE: `includes/class-kmae-auth.php:84-86`
- SYMBOL: `KMAE_Auth::filter_reset_message`
- PURPOSE: Replace default wp-login reset link in the email.
- CALLED BY: `WP filter `retrieve_password_message``
- CALLS: `KMAE_Auth::password_reset_email_html`, `KMAE_Auth::reset_password_url`
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `NOTIFICATIONS`

## `KMAE_Auth::password_reset_email_html`
- FILE: `includes/class-kmae-auth.php:98-123`
- SYMBOL: `KMAE_Auth::password_reset_email_html`
- PURPOSE: A jelszó-visszaállító levél egyetlen forrása — ugyanez fut le akkor is, ha a WordPress saját folyamata küldi (fenti szűrő), és akkor is, ha a mi „Elfelejtett jelszó" űrlapunk (lásd lent).
- CALLED BY: `KMAE_Auth::filter_reset_message`, `KMAE_Auth::request_password_reset`
- CALLS: `KMAE_Brand::wrap_email`
- READS: `option:blogname`
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `NOTIFICATIONS`

## `KMAE_Auth::redirect_wp_password_screens`
- FILE: `includes/class-kmae-auth.php:129-150`
- SYMBOL: `KMAE_Auth::redirect_wp_password_screens`
- PURPOSE: Keep users on branded screens instead of wp-login.php password flows.
- CALLED BY: `WP action `login_init``
- CALLS: `KMAE_Auth::lost_password_url`, `KMAE_Auth::reset_password_url`
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `NOTIFICATIONS`
- GET KEYS: `key`, `login`

## `KMAE_Auth::request_password_reset`
- FILE: `includes/class-kmae-auth.php:159-185`
- SYMBOL: `KMAE_Auth::request_password_reset`
- PURPOSE: Send password reset email for an address.
- CALLED BY: `KMAE_Public::admin_lost_password`
- CALLS: `KMAE_Auth::password_reset_email_html`, `KMAE_Auth::reset_password_url`
- READS: `option:blogname`
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `NOTIFICATIONS`

## `KMAE_Auth::reset_password_with_key`
- FILE: `includes/class-kmae-auth.php:197-219`
- SYMBOL: `KMAE_Auth::reset_password_with_key`
- PURPOSE: Set a new password using WP reset key.
- CALLED BY: `KMAE_Public::admin_reset_password`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `NOTIFICATIONS`

## `KMAE_Auth::account_types`
- FILE: `includes/class-kmae-auth.php:227-231`
- SYMBOL: `KMAE_Auth::account_types`
- PURPOSE: Allowed account types (magánszemély / cég).
- CALLED BY: `KMAE_Google_Auth::handle_complete`, `KMAE_Auth::sanitize_account_type`, `KMAE_Auth::account_type_label`, `KMAE_Auth::register`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `NOTIFICATIONS`

## `KMAE_Auth::sanitize_account_type`
- FILE: `includes/class-kmae-auth.php:238-241`
- SYMBOL: `KMAE_Auth::sanitize_account_type`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Auth::get_account_type`, `KMAE_Auth::mark_email_verified`, `KMAE_Auth::get_profile`, `KMAE_Auth::save_email_prefs`, `KMAE_Auth::sync_phone`
- CALLS: `KMAE_Auth::account_types`
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `NOTIFICATIONS`

## `KMAE_Auth::get_account_type`
- FILE: `includes/class-kmae-auth.php:248-254`
- SYMBOL: `KMAE_Auth::get_account_type`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Auth::is_company`, `KMAE_Auth::is_private_person`, `KMAE_Auth::account_type_label`
- CALLS: `KMAE_Auth::get_profile`, `KMAE_Auth::sanitize_account_type`
- READS: `usermeta:kmae_account_type`
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `NOTIFICATIONS`

## `KMAE_Auth::is_company`
- FILE: `includes/class-kmae-auth.php:257-258`
- SYMBOL: `KMAE_Auth::is_company`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Listings::save_meta_from_post`, `KMAE_Company::seller_display_name`, `KMAE_Company::save_profile_fields`, `KMAE_Offers::get_offerer_display_name`, `KMAE_Notifications::on_deal_locked`, `KMAE_Notifications::on_deal_failed`, `KMAE_Counter_Offers::get_other_party_name`, `KMAE_Public::admin_save_profile`, `KMAE_Public::admin_update_listing`, `KMAE_Public::process_create_listing`
- CALLS: `KMAE_Auth::get_account_type`
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `NOTIFICATIONS`

## `KMAE_Auth::is_private_person`
- FILE: `includes/class-kmae-auth.php:261-262`
- SYMBOL: `KMAE_Auth::is_private_person`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Offers::require_fair_buyer_pledge`
- CALLS: `KMAE_Auth::get_account_type`
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `NOTIFICATIONS`

## `KMAE_Auth::account_type_label`
- FILE: `includes/class-kmae-auth.php:271-274`
- SYMBOL: `KMAE_Auth::account_type_label`
- PURPOSE: Human-readable account type label.
- CALLED BY: —
- CALLS: `KMAE_Auth::get_account_type`, `KMAE_Auth::account_types`
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `NOTIFICATIONS`

## `KMAE_Auth::ensure_subscriber_caps`
- FILE: `includes/class-kmae-auth.php:280-284`
- SYMBOL: `KMAE_Auth::ensure_subscriber_caps`
- PURPOSE: Subscribers need upload_files for listing photos.
- CALLED BY: `KMAE_Google_Auth::resolve_user`, `KMAE_Activator::activate`, `KMAE_Activator::maybe_upgrade`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `NOTIFICATIONS`

## `KMAE_Auth::map_listing_caps`
- FILE: `includes/class-kmae-auth.php:293-308`
- SYMBOL: `KMAE_Auth::map_listing_caps`
- PURPOSE: Authors may edit/delete their own listings without edit_posts cap.
- CALLED BY: `WP filter `map_meta_cap``
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `NOTIFICATIONS`

## `KMAE_Auth::register`
- FILE: `includes/class-kmae-auth.php:311-422`
- SYMBOL: `KMAE_Auth::register`
- PURPOSE: Authors may edit/delete their own listings without edit_posts cap.
- CALLED BY: `KMAE_Public::admin_register`
- CALLS: `KMAE_Counties::validate_listing_location`, `KMAE_Company::save_profile_fields`, `KMAE_Database::table`, `KMAE_Auth::normalize_phone`, `KMAE_Auth::account_types`, `KMAE_Auth::generate_username`, `KMAE_Auth::generate_email_verify_token`, `KMAE_Auth::send_verification_email`
- READS: `table:user_profiles`
- WRITES: `usermeta:kmae_phone`, `usermeta:kmae_account_type`, `wpdb:replace`
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `NOTIFICATIONS`

## `KMAE_Auth::mark_email_verified`
- FILE: `includes/class-kmae-auth.php:436-452`
- SYMBOL: `KMAE_Auth::mark_email_verified`
- PURPOSE: A profil sorát „megerősítve" állapotba teszi, a többi mezőt érintetlenül hagyva. Ugyanezt hívja a Google-belépés is, hiszen ott a Google már igazolta a címet.
- CALLED BY: `KMAE_Google_Auth::handle_callback`, `KMAE_Google_Auth::handle_complete`, `KMAE_Auth::verify_email_link`
- CALLS: `KMAE_Database::table`, `KMAE_Auth::get_profile`, `KMAE_Auth::sanitize_account_type`
- READS: `table:user_profiles`
- WRITES: `wpdb:replace`
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `NOTIFICATIONS`

## `KMAE_Auth::generate_email_verify_token`
- FILE: `includes/class-kmae-auth.php:462-466`
- SYMBOL: `KMAE_Auth::generate_email_verify_token`
- PURPOSE: Új megerősítő kulcs. A nyers érték megy a linkbe, az adatbázisba csak a lenyomata kerül — ahogy a jelszó-visszaállításnál is.
- CALLED BY: `KMAE_Auth::register`, `KMAE_Auth::handle_resend_verification`
- CALLS: —
- READS: —
- WRITES: `usermeta:kmae_email_verify_token`, `usermeta:kmae_email_verify_sent`
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `NOTIFICATIONS`

## `KMAE_Auth::send_verification_email`
- FILE: `includes/class-kmae-auth.php:474-512`
- SYMBOL: `KMAE_Auth::send_verification_email`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Auth::register`, `KMAE_Auth::handle_resend_verification`
- CALLS: `KMAE_Brand::wrap_email`, `KMAE_Brand::email_mascot_url`, `KMAE_Auth::first_name`
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `NOTIFICATIONS`

## `KMAE_Auth::verify_email_link`
- FILE: `includes/class-kmae-auth.php:520-535`
- SYMBOL: `KMAE_Auth::verify_email_link`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Auth::maybe_handle_email_verify_link`
- CALLS: `KMAE_Auth::mark_email_verified`
- READS: `usermeta:kmae_email_verify_token`, `usermeta:kmae_email_verify_sent`
- WRITES: `usermeta:kmae_email_verify_token`, `usermeta:kmae_email_verify_sent`
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `NOTIFICATIONS`

## `KMAE_Auth::maybe_handle_email_verify_link`
- FILE: `includes/class-kmae-auth.php:541-559`
- SYMBOL: `KMAE_Auth::maybe_handle_email_verify_link`
- PURPOSE: A levélben kapott linkre kattintva ide fut be a látogató, bárhol jár.
- CALLED BY: `WP action `init``
- CALLS: `KMAE_Pages::url`, `KMAE_Auth::verify_email_link`, `KMAE_Auth::login_url`
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `NOTIFICATIONS`
- GET KEYS: `kmae_email_token`, `kmae_email_verify`

## `KMAE_Auth::handle_resend_verification`
- FILE: `includes/class-kmae-auth.php:565-591`
- SYMBOL: `KMAE_Auth::handle_resend_verification`
- PURPOSE: „Küldd újra" gomb a profilon és a letiltó képernyőkön.
- CALLED BY: `WP action `admin_post_kmae_resend_verification``
- CALLS: `KMAE_Auth::login_url`, `KMAE_Auth::is_email_verified`, `KMAE_Auth::generate_email_verify_token`, `KMAE_Auth::send_verification_email`
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `NOTIFICATIONS`
- POST KEYS: `kmae_redirect`, `kmae_resend_nonce`

## `KMAE_Auth::login`
- FILE: `includes/class-kmae-auth.php:594-619`
- SYMBOL: `KMAE_Auth::login`
- PURPOSE: „Küldd újra" gomb a profilon és a letiltó képernyőkön.
- CALLED BY: `KMAE_Public::admin_login`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `NOTIFICATIONS`

## `KMAE_Auth::get_profile`
- FILE: `includes/class-kmae-auth.php:622-649`
- SYMBOL: `KMAE_Auth::get_profile`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Auth::get_account_type`, `KMAE_Auth::mark_email_verified`, `KMAE_Auth::wants_offer_emails`, `KMAE_Auth::wants_news_emails`, `KMAE_Auth::save_email_prefs`, `KMAE_Auth::is_email_verified`, `KMAE_Auth::is_phone_verified`, `KMAE_Auth::sync_phone`
- CALLS: `KMAE_Database::table`, `KMAE_Auth::sanitize_account_type`
- READS: `usermeta:kmae_phone`, `usermeta:kmae_account_type`, `table:user_profiles`, `wpdb:get_row`
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `NOTIFICATIONS`

## `KMAE_Auth::wants_offer_emails`
- FILE: `includes/class-kmae-auth.php:652-654`
- SYMBOL: `KMAE_Auth::wants_offer_emails`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Notifications::send_offer_email`
- CALLS: `KMAE_Auth::get_profile`
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `NOTIFICATIONS`

## `KMAE_Auth::wants_news_emails`
- FILE: `includes/class-kmae-auth.php:657-659`
- SYMBOL: `KMAE_Auth::wants_news_emails`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: —
- CALLS: `KMAE_Auth::get_profile`
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `NOTIFICATIONS`

## `KMAE_Auth::save_email_prefs`
- FILE: `includes/class-kmae-auth.php:670-686`
- SYMBOL: `KMAE_Auth::save_email_prefs`
- PURPOSE: Értesítési preferenciák mentése a beállítások oldalról. A profil sorának többi mezőjét érintetlenül hagyja.
- CALLED BY: `KMAE_Google_Auth::handle_complete`, `KMAE_Public::admin_save_settings`
- CALLS: `KMAE_Database::table`, `KMAE_Auth::get_profile`, `KMAE_Auth::sanitize_account_type`
- READS: `table:user_profiles`
- WRITES: `wpdb:replace`
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `NOTIFICATIONS`

## `KMAE_Auth::is_email_verified`
- FILE: `includes/class-kmae-auth.php:689-691`
- SYMBOL: `KMAE_Auth::is_email_verified`
- PURPOSE: Értesítési preferenciák mentése a beállítások oldalról. A profil sorának többi mezőjét érintetlenül hagyja.
- CALLED BY: `KMAE_Auth::handle_resend_verification`, `KMAE_Auth::should_gate_for_verification`, `KMAE_Auth::is_fully_verified`
- CALLS: `KMAE_Auth::get_profile`
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `NOTIFICATIONS`

## `KMAE_Auth::should_gate_for_verification`
- FILE: `includes/class-kmae-auth.php:701-705`
- SYMBOL: `KMAE_Auth::should_gate_for_verification`
- PURPOSE: Hirdetésfeladás és ajánlattétel csak megerősített e-mail címmel megy — a rendszergazda tesztelés közben nem akad el ezen.
- CALLED BY: `KMAE_Public::handle_forms`, `KMAE_Shortcodes::create_listing`
- CALLS: `KMAE_Auth::is_email_verified`
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `NOTIFICATIONS`

## `KMAE_Auth::is_phone_verified`
- FILE: `includes/class-kmae-auth.php:708-710`
- SYMBOL: `KMAE_Auth::is_phone_verified`
- PURPOSE: Hirdetésfeladás és ajánlattétel csak megerősített e-mail címmel megy — a rendszergazda tesztelés közben nem akad el ezen.
- CALLED BY: `KMAE_Auth::is_fully_verified`
- CALLS: `KMAE_Auth::get_profile`
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `NOTIFICATIONS`

## `KMAE_Auth::is_fully_verified`
- FILE: `includes/class-kmae-auth.php:713-714`
- SYMBOL: `KMAE_Auth::is_fully_verified`
- PURPOSE: Hirdetésfeladás és ajánlattétel csak megerősített e-mail címmel megy — a rendszergazda tesztelés közben nem akad el ezen.
- CALLED BY: —
- CALLS: `KMAE_Auth::is_email_verified`, `KMAE_Auth::is_phone_verified`
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `NOTIFICATIONS`

## `KMAE_Auth::first_name`
- FILE: `includes/class-kmae-auth.php:727-739`
- SYMBOL: `KMAE_Auth::first_name`
- PURPOSE: A köszönéshez való keresztnév. Google-belépésnél a keresztnevet külön megkapjuk és eltároljuk; minden más esetben a megjelenített név első szava. Üres, ha nincs használható nevünk (például e-mail cím áll a név helyén).
- CALLED BY: `KMAE_Dashboard::get_data`, `KMAE_Auth::send_verification_email`, `KMAE_Notifications::send_offer_email`
- CALLS: —
- READS: `usermeta:kmae_given_name`
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `NOTIFICATIONS`

## `KMAE_Auth::normalize_phone`
- FILE: `includes/class-kmae-auth.php:749-768`
- SYMBOL: `KMAE_Auth::normalize_phone`
- PURPOSE: Magyar telefonszám egységes alakra hozása. A böngészőben is szűrünk, de az megkerülhető — itt dől el, mi kerül az adatbázisba.
- CALLED BY: `KMAE_Google_Auth::handle_complete`, `KMAE_Auth::register`, `KMAE_Public::admin_save_profile`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `NOTIFICATIONS`

## `KMAE_Auth::sync_phone`
- FILE: `includes/class-kmae-auth.php:771-789`
- SYMBOL: `KMAE_Auth::sync_phone`
- PURPOSE: Magyar telefonszám egységes alakra hozása. A böngészőben is szűrünk, de az megkerülhető — itt dől el, mi kerül az adatbázisba.
- CALLED BY: `KMAE_Google_Auth::handle_complete`, `KMAE_Public::admin_save_profile`
- CALLS: `KMAE_Database::table`, `KMAE_Auth::get_profile`, `KMAE_Auth::sanitize_account_type`
- READS: `table:user_profiles`
- WRITES: `usermeta:kmae_phone`, `usermeta:kmae_account_type`, `wpdb:replace`
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `NOTIFICATIONS`

## `KMAE_Auth::generate_username`
- FILE: `includes/class-kmae-auth.php:792-803`
- SYMBOL: `KMAE_Auth::generate_username`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Auth::register`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `NOTIFICATIONS`

## `KMAE_Back::browse_url`
- FILE: `includes/class-kmae-back.php:14-15`
- SYMBOL: `KMAE_Back::browse_url`
- PURPOSE: Back URL helpers for inline page navigation.
- CALLED BY: —
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `BOOT-ARCHITECTURE`

## `KMAE_Back::home_url`
- FILE: `includes/class-kmae-back.php:21-22`
- SYMBOL: `KMAE_Back::home_url`
- PURPOSE: Back to logged-in home / guest landing.
- CALLED BY: `KMAE_Back::listing_back_url`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `BOOT-ARCHITECTURE`

## `KMAE_Back::home_label`
- FILE: `includes/class-kmae-back.php:25-26`
- SYMBOL: `KMAE_Back::home_label`
- PURPOSE: Back to logged-in home / guest landing.
- CALLED BY: —
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `BOOT-ARCHITECTURE`

## `KMAE_Back::listing_back_url`
- FILE: `includes/class-kmae-back.php:29-35`
- SYMBOL: `KMAE_Back::listing_back_url`
- PURPOSE: Back to logged-in home / guest landing.
- CALLED BY: —
- CALLS: `KMAE_Back::home_url`
- READS: —
- WRITES: —
- RELATED FEATURE: `BOOT-ARCHITECTURE`

## `KMAE_Brand::init`
- FILE: `includes/class-kmae-brand.php:21-22`
- SYMBOL: `KMAE_Brand::init`
- PURPOSE: Official Albira brand assets and HTML mail wrapper.
- CALLED BY: `KMAE_Plugin::run`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `NOTIFICATIONS`, `CONTACT-FORM`

## `KMAE_Brand::logo_guest`
- FILE: `includes/class-kmae-brand.php:25-26`
- SYMBOL: `KMAE_Brand::logo_guest`
- PURPOSE: Official Albira brand assets and HTML mail wrapper.
- CALLED BY: —
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `NOTIFICATIONS`, `CONTACT-FORM`

## `KMAE_Brand::logo_app`
- FILE: `includes/class-kmae-brand.php:29-30`
- SYMBOL: `KMAE_Brand::logo_app`
- PURPOSE: Official Albira brand assets and HTML mail wrapper.
- CALLED BY: —
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `NOTIFICATIONS`, `CONTACT-FORM`

## `KMAE_Brand::email_logo_url`
- FILE: `includes/class-kmae-brand.php:41-42`
- SYMBOL: `KMAE_Brand::email_logo_url`
- PURPOSE: E-mailben a logó eredeti fájlja átlátszó — több levelezőkliens (pl. a Gmail képproxyja) nem kompozitálja helyesen a webp-alfacsatornát, és fekete dobozként rajzolja ki. Ezért a levelekhez egy fehér alapra
- CALLED BY: `KMAE_Brand::wrap_email`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `NOTIFICATIONS`, `CONTACT-FORM`

## `KMAE_Brand::email_mascot_url`
- FILE: `includes/class-kmae-brand.php:51-52`
- SYMBOL: `KMAE_Brand::email_mascot_url`
- PURPOSE: Ugyanaz az ok, mint a logónál — a mackó levélben használt, fehér alapra égetett változata.
- CALLED BY: `KMAE_Auth::send_verification_email`, `KMAE_Notifications::on_new_offer`, `KMAE_Notifications::on_counter_offer`, `KMAE_Notifications::on_buyer_revision`, `KMAE_Notifications::on_offer_accepted`, `KMAE_Notifications::on_deal_locked`, `KMAE_Notifications::notify_buyer_other_sellers_hold`, `KMAE_Notifications::on_deal_failed`, `KMAE_Notifications::notify_buyer_other_sellers_resume`, `KMAE_Notifications::on_offer_rejected`, `KMAE_Notifications::on_offer_withdrawn`, `KMAE_Notifications::on_listing_deleted`, `KMAE_Notifications::listing_closed`, `KMAE_Notifications::request_rating`, `KMAE_Notifications::buyer_found_other_car`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `NOTIFICATIONS`, `CONTACT-FORM`

## `KMAE_Brand::logo_url`
- FILE: `includes/class-kmae-brand.php:61-63`
- SYMBOL: `KMAE_Brand::logo_url`
- PURPOSE: A logó mindenhol ugyanaz; a paraméter csak a régi hívások miatt maradt.
- CALLED BY: —
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `NOTIFICATIONS`, `CONTACT-FORM`

## `KMAE_Brand::html_content_type`
- FILE: `includes/class-kmae-brand.php:66-67`
- SYMBOL: `KMAE_Brand::html_content_type`
- PURPOSE: A logó mindenhol ugyanaz; a paraméter csak a régi hívások miatt maradt.
- CALLED BY: —
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `NOTIFICATIONS`, `CONTACT-FORM`

## `KMAE_Brand::send_mail`
- FILE: `includes/class-kmae-brand.php:79-92`
- SYMBOL: `KMAE_Brand::send_mail`
- PURPOSE: Send a branded HTML email with the official (logged-in) logo.
- CALLED BY: `KMAE_Notifications::send_offer_email`, `KMAE_Public::admin_contact_form`
- CALLS: `KMAE_Brand::wrap_email`
- READS: —
- WRITES: —
- RELATED FEATURE: `NOTIFICATIONS`, `CONTACT-FORM`

## `KMAE_Brand::wrap_email`
- FILE: `includes/class-kmae-brand.php:112-189`
- SYMBOL: `KMAE_Brand::wrap_email`
- PURPOSE: Az összes kimenő levél egyetlen közös héja — az oldal világos, üveges arculatában: kék-narancs csík a tetején, kerek kártya, és egy igazi gomb a linknek, nem egy nyers URL beillesztve.
- CALLED BY: `KMAE_Brand::send_mail`, `KMAE_Auth::password_reset_email_html`, `KMAE_Auth::send_verification_email`
- CALLS: `KMAE_Brand::email_logo_url`, `KMAE_Brand::format_email_body`
- READS: —
- WRITES: —
- RELATED FEATURE: `NOTIFICATIONS`, `CONTACT-FORM`

## `KMAE_Brand::ensure_html_headers`
- FILE: `includes/class-kmae-brand.php:198-230`
- SYMBOL: `KMAE_Brand::ensure_html_headers`
- PURPOSE: If the body already contains the official logo, force HTML content-type.
- CALLED BY: `WP filter `wp_mail``
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `NOTIFICATIONS`, `CONTACT-FORM`

## `KMAE_Brand::format_email_body`
- FILE: `includes/class-kmae-brand.php:237-245`
- SYMBOL: `KMAE_Brand::format_email_body`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Brand::wrap_email`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `NOTIFICATIONS`, `CONTACT-FORM`

## `KMAE_Browse::get_offered_listing_ids`
- FILE: `includes/class-kmae-browse.php:22-40`
- SYMBOL: `KMAE_Browse::get_offered_listing_ids`
- PURPOSE: Listing IDs the user already submitted an offer on.
- CALLED BY: `KMAE_Browse::personalize_listings`, `KMAE_Query::get_listings`
- CALLS: `KMAE_Database::table`
- READS: `table:offers`, `wpdb:get_col`
- WRITES: —
- RELATED FEATURE: `BROWSE-SEARCH`

## `KMAE_Browse::get_passed_listing_ids`
- FILE: `includes/class-kmae-browse.php:46-52`
- SYMBOL: `KMAE_Browse::get_passed_listing_ids`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Browse::record_pass`, `KMAE_Browse::personalize_listings`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `BROWSE-SEARCH`

## `KMAE_Browse::record_pass`
- FILE: `includes/class-kmae-browse.php:55-67`
- SYMBOL: `KMAE_Browse::record_pass`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Public::ajax_browse_pass`
- CALLS: `KMAE_Browse::get_passed_listing_ids`
- READS: —
- WRITES: —
- RELATED FEATURE: `BROWSE-SEARCH`

## `KMAE_Browse::personalize_listings`
- FILE: `includes/class-kmae-browse.php:76-107`
- SYMBOL: `KMAE_Browse::personalize_listings`
- PURPOSE: Fresh listings first; previously passed ones every Nth slot.
- CALLED BY: `KMAE_Query::get_listings`
- CALLS: `KMAE_Browse::get_offered_listing_ids`, `KMAE_Browse::get_passed_listing_ids`, `KMAE_Browse::merge_with_passed_interval`
- READS: —
- WRITES: —
- RELATED FEATURE: `BROWSE-SEARCH`

## `KMAE_Browse::merge_with_passed_interval`
- FILE: `includes/class-kmae-browse.php:115-129`
- SYMBOL: `KMAE_Browse::merge_with_passed_interval`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Browse::personalize_listings`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `BROWSE-SEARCH`

## `KMAE_Browse::parse_wizard_params`
- FILE: `includes/class-kmae-browse.php:137-146`
- SYMBOL: `KMAE_Browse::parse_wizard_params`
- PURPOSE: Parse browse wizard params from request.
- CALLED BY: `KMAE_Shortcodes::browse_vehicle_wizard`
- CALLS: `KMAE_Browse::parse_bodies_param`
- READS: —
- WRITES: —
- RELATED FEATURE: `BROWSE-SEARCH`

## `KMAE_Browse::parse_bodies_param`
- FILE: `includes/class-kmae-browse.php:153-178`
- SYMBOL: `KMAE_Browse::parse_bodies_param`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Browse::parse_wizard_params`
- CALLS: `KMAE_Vehicle::body_types`
- READS: —
- WRITES: —
- RELATED FEATURE: `BROWSE-SEARCH`

## `KMAE_Browse::bodies_to_query_value`
- FILE: `includes/class-kmae-browse.php:184-191`
- SYMBOL: `KMAE_Browse::bodies_to_query_value`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Shortcodes::browse_vehicle_wizard`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `BROWSE-SEARCH`

## `KMAE_Browse::bodies_label`
- FILE: `includes/class-kmae-browse.php:197-213`
- SYMBOL: `KMAE_Browse::bodies_label`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Browse::wizard_summary_label`
- CALLS: `KMAE_Vehicle::body_types`
- READS: —
- WRITES: —
- RELATED FEATURE: `BROWSE-SEARCH`

## `KMAE_Browse::is_wizard_complete`
- FILE: `includes/class-kmae-browse.php:216-234`
- SYMBOL: `KMAE_Browse::is_wizard_complete`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Shortcodes::browse_vehicle_wizard`
- CALLS: `KMAE_Counties::is_valid`
- READS: —
- WRITES: —
- RELATED FEATURE: `BROWSE-SEARCH`

## `KMAE_Browse::filter_by_wizard`
- FILE: `includes/class-kmae-browse.php:244-258`
- SYMBOL: `KMAE_Browse::filter_by_wizard`
- PURPOSE: Filter listings by vehicle browse wizard rules.
- CALLED BY: `KMAE_Shortcodes::browse_vehicle_wizard`
- CALLS: `KMAE_Vehicle::is_vehicle_launch`, `KMAE_Browse::listing_matches_wizard`
- READS: —
- WRITES: —
- RELATED FEATURE: `BROWSE-SEARCH`

## `KMAE_Browse::listing_matches_wizard`
- FILE: `includes/class-kmae-browse.php:261-289`
- SYMBOL: `KMAE_Browse::listing_matches_wizard`
- PURPOSE: Filter listings by vehicle browse wizard rules.
- CALLED BY: `KMAE_Browse::filter_by_wizard`
- CALLS: `KMAE_Seller::is_open_price`, `KMAE_Meta::get_offer_types`, `KMAE_Vehicle::get_vehicle_value`
- READS: —
- WRITES: —
- RELATED FEATURE: `BROWSE-SEARCH`

## `KMAE_Browse::wizard_summary_label`
- FILE: `includes/class-kmae-browse.php:292-308`
- SYMBOL: `KMAE_Browse::wizard_summary_label`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: —
- CALLS: `KMAE_Counties::get_label`, `KMAE_Vehicle::browse_mode_labels`, `KMAE_Browse::bodies_label`
- READS: —
- WRITES: —
- RELATED FEATURE: `BROWSE-SEARCH`

## `KMAE_Company::get_company_name`
- FILE: `includes/class-kmae-company.php:24-30`
- SYMBOL: `KMAE_Company::get_company_name`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Company::seller_display_name`, `KMAE_Offers::get_offerer_display_name`, `KMAE_Counter_Offers::get_other_party_name`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `PROFILE-COMPANY-SETTINGS`

## `KMAE_Company::get_tax_id`
- FILE: `includes/class-kmae-company.php:37-38`
- SYMBOL: `KMAE_Company::get_tax_id`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: —
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `PROFILE-COMPANY-SETTINGS`

## `KMAE_Company::get_address`
- FILE: `includes/class-kmae-company.php:45-46`
- SYMBOL: `KMAE_Company::get_address`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: —
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `PROFILE-COMPANY-SETTINGS`

## `KMAE_Company::get_county`
- FILE: `includes/class-kmae-company.php:49-50`
- SYMBOL: `KMAE_Company::get_county`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Company::has_listing_location`, `KMAE_Company::apply_listing_location`, `KMAE_Public::admin_update_listing`, `KMAE_Public::process_create_listing`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `PROFILE-COMPANY-SETTINGS`

## `KMAE_Company::get_city`
- FILE: `includes/class-kmae-company.php:53-54`
- SYMBOL: `KMAE_Company::get_city`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Company::has_listing_location`, `KMAE_Company::apply_listing_location`, `KMAE_Public::admin_update_listing`, `KMAE_Public::process_create_listing`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `PROFILE-COMPANY-SETTINGS`

## `KMAE_Company::has_listing_location`
- FILE: `includes/class-kmae-company.php:57-58`
- SYMBOL: `KMAE_Company::has_listing_location`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Company::apply_listing_location`
- CALLS: `KMAE_Counties::validate_listing_location`, `KMAE_Company::get_county`, `KMAE_Company::get_city`
- READS: —
- WRITES: —
- RELATED FEATURE: `PROFILE-COMPANY-SETTINGS`

## `KMAE_Company::apply_listing_location`
- FILE: `includes/class-kmae-company.php:61-67`
- SYMBOL: `KMAE_Company::apply_listing_location`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Listings::save_meta_from_post`
- CALLS: `KMAE_Counties::save_listing_location`, `KMAE_Company::has_listing_location`, `KMAE_Company::get_county`, `KMAE_Company::get_city`
- READS: —
- WRITES: —
- RELATED FEATURE: `PROFILE-COMPANY-SETTINGS`

## `KMAE_Company::seller_display_name`
- FILE: `includes/class-kmae-company.php:76-81`
- SYMBOL: `KMAE_Company::seller_display_name`
- PURPOSE: Public seller label (company name or personal display name).
- CALLED BY: —
- CALLS: `KMAE_Auth::is_company`, `KMAE_Company::get_company_name`
- READS: —
- WRITES: —
- RELATED FEATURE: `PROFILE-COMPANY-SETTINGS`

## `KMAE_Company::save_profile_fields`
- FILE: `includes/class-kmae-company.php:91-122`
- SYMBOL: `KMAE_Company::save_profile_fields`
- PURPOSE: Save company fields from POST (register / profile).
- CALLED BY: `KMAE_Google_Auth::handle_complete`, `KMAE_Auth::register`, `KMAE_Public::admin_save_profile`
- CALLS: `KMAE_Auth::is_company`, `KMAE_Counties::validate_listing_location`
- READS: —
- WRITES: —
- RELATED FEATURE: `PROFILE-COMPANY-SETTINGS`

## `KMAE_Contact::is_unlocked`
- FILE: `includes/class-kmae-contact.php:14-15`
- SYMBOL: `KMAE_Contact::is_unlocked`
- PURPOSE: Contact unlock after accepted offer.
- CALLED BY: `KMAE_Contact::unlock`
- CALLS: `KMAE_Database::has_contact_unlock`
- READS: —
- WRITES: —
- RELATED FEATURE: `CONTACT-UNLOCK`

## `KMAE_Contact::can_view`
- FILE: `includes/class-kmae-contact.php:18-31`
- SYMBOL: `KMAE_Contact::can_view`
- PURPOSE: Contact unlock after accepted offer.
- CALLED BY: —
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `CONTACT-UNLOCK`

## `KMAE_Contact::unlock_accepted_deal`
- FILE: `includes/class-kmae-contact.php:37-39`
- SYMBOL: `KMAE_Contact::unlock_accepted_deal`
- PURPOSE: Record contact unlock for both parties (audit trail).
- CALLED BY: `KMAE_Counter_Offers::accept_offer`
- CALLS: `KMAE_Database::create_contact_unlock`
- READS: —
- WRITES: —
- RELATED FEATURE: `CONTACT-UNLOCK`

## `KMAE_Contact::unlock`
- FILE: `includes/class-kmae-contact.php:42-53`
- SYMBOL: `KMAE_Contact::unlock`
- PURPOSE: Record contact unlock for both parties (audit trail).
- CALLED BY: `KMAE_Public::process_unlock_contact`
- CALLS: `KMAE_Database::get_offer`, `KMAE_Database::create_contact_unlock`, `KMAE_Contact::is_unlocked`
- READS: —
- WRITES: —
- RELATED FEATURE: `CONTACT-UNLOCK`

## `KMAE_Contact::get_contact_details`
- FILE: `includes/class-kmae-contact.php:56-66`
- SYMBOL: `KMAE_Contact::get_contact_details`
- PURPOSE: Record contact unlock for both parties (audit trail).
- CALLED BY: `KMAE_Notifications::on_offer_accepted`
- CALLS: `KMAE_Dashboard::greeting_case`
- READS: `usermeta:kmae_phone`
- WRITES: —
- RELATED FEATURE: `CONTACT-UNLOCK`

## `KMAE_Contact::get_other_party_id`
- FILE: `includes/class-kmae-contact.php:69-73`
- SYMBOL: `KMAE_Contact::get_other_party_id`
- PURPOSE: Record contact unlock for both parties (audit trail).
- CALLED BY: —
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `CONTACT-UNLOCK`

## `KMAE_Counter_Offers::status_labels`
- FILE: `includes/class-kmae-counter-offers.php:16-22`
- SYMBOL: `KMAE_Counter_Offers::status_labels`
- PURPOSE: Counter-offer and negotiation logic.
- CALLED BY: `KMAE_Admin::render_offers`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `NEGOTIATION-CHAT`, `DEAL`, `CONTACT-UNLOCK`, `NOTIFICATIONS`

## `KMAE_Counter_Offers::get_listing_seller_id`
- FILE: `includes/class-kmae-counter-offers.php:25-27`
- SYMBOL: `KMAE_Counter_Offers::get_listing_seller_id`
- PURPOSE: Counter-offer and negotiation logic.
- CALLED BY: `KMAE_Counter_Offers::is_seller`, `KMAE_Counter_Offers::accept_offer`, `KMAE_Counter_Offers::get_negotiation_summary`, `KMAE_Counter_Offers::get_other_party_name`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `NEGOTIATION-CHAT`, `DEAL`, `CONTACT-UNLOCK`, `NOTIFICATIONS`

## `KMAE_Counter_Offers::is_seller`
- FILE: `includes/class-kmae-counter-offers.php:30-31`
- SYMBOL: `KMAE_Counter_Offers::is_seller`
- PURPOSE: Counter-offer and negotiation logic.
- CALLED BY: `KMAE_Deal::can_confirm`, `KMAE_Counter_Offers::can_seller_counter`, `KMAE_Counter_Offers::can_buyer_revise`, `KMAE_Counter_Offers::can_seller_accept`, `KMAE_Counter_Offers::can_buyer_accept`, `KMAE_Counter_Offers::accept_offer`, `KMAE_Counter_Offers::user_can_access`, `KMAE_Counter_Offers::get_chat_action_state`, `KMAE_Counter_Offers::get_other_party_name`, `KMAE_Counter_Offers::get_user_rounds_left`
- CALLS: `KMAE_Counter_Offers::get_listing_seller_id`
- READS: —
- WRITES: —
- RELATED FEATURE: `NEGOTIATION-CHAT`, `DEAL`, `CONTACT-UNLOCK`, `NOTIFICATIONS`

## `KMAE_Counter_Offers::is_buyer`
- FILE: `includes/class-kmae-counter-offers.php:34-35`
- SYMBOL: `KMAE_Counter_Offers::is_buyer`
- PURPOSE: Counter-offer and negotiation logic.
- CALLED BY: `KMAE_Deal::can_confirm`, `KMAE_Counter_Offers::can_buyer_revise`, `KMAE_Counter_Offers::can_buyer_accept`, `KMAE_Counter_Offers::accept_offer`, `KMAE_Counter_Offers::user_can_access`, `KMAE_Counter_Offers::get_user_rounds_left`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `NEGOTIATION-CHAT`, `DEAL`, `CONTACT-UNLOCK`, `NOTIFICATIONS`

## `KMAE_Counter_Offers::count_user_counters`
- FILE: `includes/class-kmae-counter-offers.php:38-39`
- SYMBOL: `KMAE_Counter_Offers::count_user_counters`
- PURPOSE: Counter-offer and negotiation logic.
- CALLED BY: `KMAE_Counter_Offers::can_seller_counter`, `KMAE_Counter_Offers::can_buyer_revise`, `KMAE_Counter_Offers::submit_seller_counter`, `KMAE_Counter_Offers::submit_buyer_revision`, `KMAE_Counter_Offers::get_negotiation_summary`
- CALLS: `KMAE_Database::count_counter_offers_by_user`
- READS: —
- WRITES: —
- RELATED FEATURE: `NEGOTIATION-CHAT`, `DEAL`, `CONTACT-UNLOCK`, `NOTIFICATIONS`

## `KMAE_Counter_Offers::can_seller_counter`
- FILE: `includes/class-kmae-counter-offers.php:42-56`
- SYMBOL: `KMAE_Counter_Offers::can_seller_counter`
- PURPOSE: Counter-offer and negotiation logic.
- CALLED BY: `KMAE_Counter_Offers::submit_seller_counter`, `KMAE_Counter_Offers::get_chat_action_state`
- CALLS: `KMAE_Deal::is_locked`, `KMAE_Database::get_latest_counter_offer`, `KMAE_Counter_Offers::is_seller`, `KMAE_Counter_Offers::count_user_counters`
- READS: —
- WRITES: —
- RELATED FEATURE: `NEGOTIATION-CHAT`, `DEAL`, `CONTACT-UNLOCK`, `NOTIFICATIONS`

## `KMAE_Counter_Offers::can_buyer_revise`
- FILE: `includes/class-kmae-counter-offers.php:59-73`
- SYMBOL: `KMAE_Counter_Offers::can_buyer_revise`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Counter_Offers::submit_buyer_revision`, `KMAE_Counter_Offers::get_chat_action_state`
- CALLS: `KMAE_Deal::is_locked`, `KMAE_Database::get_latest_counter_offer`, `KMAE_Counter_Offers::is_buyer`, `KMAE_Counter_Offers::count_user_counters`, `KMAE_Counter_Offers::is_seller`
- READS: —
- WRITES: —
- RELATED FEATURE: `NEGOTIATION-CHAT`, `DEAL`, `CONTACT-UNLOCK`, `NOTIFICATIONS`

## `KMAE_Counter_Offers::can_seller_accept`
- FILE: `includes/class-kmae-counter-offers.php:76-84`
- SYMBOL: `KMAE_Counter_Offers::can_seller_accept`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Counter_Offers::get_chat_action_state`
- CALLS: `KMAE_Deal::is_locked`, `KMAE_Deal::assert_buyer_can_lock`, `KMAE_Counter_Offers::is_seller`
- READS: —
- WRITES: —
- RELATED FEATURE: `NEGOTIATION-CHAT`, `DEAL`, `CONTACT-UNLOCK`, `NOTIFICATIONS`

## `KMAE_Counter_Offers::can_buyer_accept`
- FILE: `includes/class-kmae-counter-offers.php:87-99`
- SYMBOL: `KMAE_Counter_Offers::can_buyer_accept`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Counter_Offers::accept_offer`, `KMAE_Counter_Offers::get_chat_action_state`
- CALLS: `KMAE_Deal::is_locked`, `KMAE_Deal::assert_buyer_can_lock`, `KMAE_Database::get_latest_counter_offer`, `KMAE_Counter_Offers::is_buyer`, `KMAE_Counter_Offers::is_seller`
- READS: —
- WRITES: —
- RELATED FEATURE: `NEGOTIATION-CHAT`, `DEAL`, `CONTACT-UNLOCK`, `NOTIFICATIONS`

## `KMAE_Counter_Offers::submit_seller_counter`
- FILE: `includes/class-kmae-counter-offers.php:102-148`
- SYMBOL: `KMAE_Counter_Offers::submit_seller_counter`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Public::process_counter_offer`
- CALLS: `KMAE_Database::get_offer`, `KMAE_Taxonomies::counter_templates`, `KMAE_Database::table`, `KMAE_Counter_Offers::can_seller_counter`, `KMAE_Counter_Offers::count_user_counters`
- READS: `table:counter_offers`, `table:offers`
- WRITES: `wpdb:insert`, `wpdb:update`
- RELATED FEATURE: `NEGOTIATION-CHAT`, `DEAL`, `CONTACT-UNLOCK`, `NOTIFICATIONS`
- EMITS: `kmae_new_counter_offer`

## `KMAE_Counter_Offers::submit_buyer_revision`
- FILE: `includes/class-kmae-counter-offers.php:151-199`
- SYMBOL: `KMAE_Counter_Offers::submit_buyer_revision`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Public::process_revise_offer`
- CALLS: `KMAE_Database::get_offer`, `KMAE_Database::table`, `KMAE_Counter_Offers::can_buyer_revise`, `KMAE_Counter_Offers::count_user_counters`
- READS: `table:offers`, `table:counter_offers`
- WRITES: `wpdb:insert`, `wpdb:update`
- RELATED FEATURE: `NEGOTIATION-CHAT`, `DEAL`, `CONTACT-UNLOCK`, `NOTIFICATIONS`
- EMITS: `kmae_buyer_revised_offer`

## `KMAE_Counter_Offers::accept_offer`
- FILE: `includes/class-kmae-counter-offers.php:202-258`
- SYMBOL: `KMAE_Counter_Offers::accept_offer`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Public::process_accept_offer`
- CALLS: `KMAE_Database::get_offer`, `KMAE_Deal::is_locked`, `KMAE_Deal::assert_buyer_can_lock`, `KMAE_Database::get_latest_counter_offer`, `KMAE_Database::table`, `KMAE_Contact::unlock_accepted_deal`, `KMAE_Counter_Offers::is_seller`, `KMAE_Counter_Offers::is_buyer`, `KMAE_Counter_Offers::can_buyer_accept`, `KMAE_Counter_Offers::get_listing_seller_id`
- READS: `table:offers`
- WRITES: `wpdb:update`
- RELATED FEATURE: `NEGOTIATION-CHAT`, `DEAL`, `CONTACT-UNLOCK`, `NOTIFICATIONS`
- EMITS: `kmae_offer_accepted`

## `KMAE_Counter_Offers::reject_other_offers`
- FILE: `includes/class-kmae-counter-offers.php:266-281`
- SYMBOL: `KMAE_Counter_Offers::reject_other_offers`
- PURPOSE: Reject all other pending offers on the same listing.
- CALLED BY: `KMAE_Deal::confirm_success`
- CALLS: `KMAE_Database::get_offers_for_listing`, `KMAE_Database::update_offer_status`
- READS: —
- WRITES: —
- RELATED FEATURE: `NEGOTIATION-CHAT`, `DEAL`, `CONTACT-UNLOCK`, `NOTIFICATIONS`
- EMITS: `kmae_offer_rejected`

## `KMAE_Counter_Offers::format_counter_message`
- FILE: `includes/class-kmae-counter-offers.php:284-306`
- SYMBOL: `KMAE_Counter_Offers::format_counter_message`
- PURPOSE: Reject all other pending offers on the same listing.
- CALLED BY: `KMAE_Dashboard::format_message_row`, `KMAE_Counter_Offers::get_chat_messages`
- CALLS: `KMAE_Offers::format_cash`, `KMAE_Taxonomies::counter_templates`
- READS: —
- WRITES: —
- RELATED FEATURE: `NEGOTIATION-CHAT`, `DEAL`, `CONTACT-UNLOCK`, `NOTIFICATIONS`

## `KMAE_Counter_Offers::get_negotiation_summary`
- FILE: `includes/class-kmae-counter-offers.php:309-320`
- SYMBOL: `KMAE_Counter_Offers::get_negotiation_summary`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Counter_Offers::get_chat_action_state`, `KMAE_Counter_Offers::get_current_amount_summary`, `KMAE_Counter_Offers::get_user_rounds_left`
- CALLS: `KMAE_Database::get_counter_offers`, `KMAE_Counter_Offers::count_user_counters`, `KMAE_Counter_Offers::get_listing_seller_id`
- READS: —
- WRITES: —
- RELATED FEATURE: `NEGOTIATION-CHAT`, `DEAL`, `CONTACT-UNLOCK`, `NOTIFICATIONS`

## `KMAE_Counter_Offers::user_can_access`
- FILE: `includes/class-kmae-counter-offers.php:323-327`
- SYMBOL: `KMAE_Counter_Offers::user_can_access`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Pages::mark_offers_seen_on_visit`, `KMAE_Shortcodes::my_offers`
- CALLS: `KMAE_Counter_Offers::is_seller`, `KMAE_Counter_Offers::is_buyer`
- READS: —
- WRITES: —
- RELATED FEATURE: `NEGOTIATION-CHAT`, `DEAL`, `CONTACT-UNLOCK`, `NOTIFICATIONS`

## `KMAE_Counter_Offers::get_chat_messages`
- FILE: `includes/class-kmae-counter-offers.php:335-362`
- SYMBOL: `KMAE_Counter_Offers::get_chat_messages`
- PURPOSE: Chat timeline: initial offer + counter messages.
- CALLED BY: `KMAE_Counter_Offers::get_chat_action_state`, `KMAE_Counter_Offers::get_last_chat_preview`
- CALLS: `KMAE_Offers::get_offer_summary`, `KMAE_Database::get_counter_offers`, `KMAE_Counter_Offers::format_counter_message`
- READS: —
- WRITES: —
- RELATED FEATURE: `NEGOTIATION-CHAT`, `DEAL`, `CONTACT-UNLOCK`, `NOTIFICATIONS`

## `KMAE_Counter_Offers::get_chat_action_state`
- FILE: `includes/class-kmae-counter-offers.php:377-411`
- SYMBOL: `KMAE_Counter_Offers::get_chat_action_state`
- PURPOSE: Which timeline message can be acted on, and what actions are available.
- CALLED BY: —
- CALLS: `KMAE_Counter_Offers::get_negotiation_summary`, `KMAE_Counter_Offers::get_chat_messages`, `KMAE_Counter_Offers::is_seller`, `KMAE_Counter_Offers::can_seller_accept`, `KMAE_Counter_Offers::can_buyer_accept`, `KMAE_Counter_Offers::can_seller_counter`, `KMAE_Counter_Offers::can_buyer_revise`
- READS: —
- WRITES: —
- RELATED FEATURE: `NEGOTIATION-CHAT`, `DEAL`, `CONTACT-UNLOCK`, `NOTIFICATIONS`

## `KMAE_Counter_Offers::get_current_amount_summary`
- FILE: `includes/class-kmae-counter-offers.php:414-420`
- SYMBOL: `KMAE_Counter_Offers::get_current_amount_summary`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: —
- CALLS: `KMAE_Offers::format_cash`, `KMAE_Offers::get_offer_summary`, `KMAE_Counter_Offers::get_negotiation_summary`
- READS: —
- WRITES: —
- RELATED FEATURE: `NEGOTIATION-CHAT`, `DEAL`, `CONTACT-UNLOCK`, `NOTIFICATIONS`

## `KMAE_Counter_Offers::get_last_chat_preview`
- FILE: `includes/class-kmae-counter-offers.php:423-428`
- SYMBOL: `KMAE_Counter_Offers::get_last_chat_preview`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: —
- CALLS: `KMAE_Counter_Offers::get_chat_messages`
- READS: —
- WRITES: —
- RELATED FEATURE: `NEGOTIATION-CHAT`, `DEAL`, `CONTACT-UNLOCK`, `NOTIFICATIONS`

## `KMAE_Counter_Offers::get_chat_kind_label`
- FILE: `includes/class-kmae-counter-offers.php:431-437`
- SYMBOL: `KMAE_Counter_Offers::get_chat_kind_label`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: —
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `NEGOTIATION-CHAT`, `DEAL`, `CONTACT-UNLOCK`, `NOTIFICATIONS`

## `KMAE_Counter_Offers::get_other_party_name`
- FILE: `includes/class-kmae-counter-offers.php:440-449`
- SYMBOL: `KMAE_Counter_Offers::get_other_party_name`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: —
- CALLS: `KMAE_Offers::get_offerer_display_name`, `KMAE_Auth::is_company`, `KMAE_Company::get_company_name`, `KMAE_Dashboard::greeting_case`, `KMAE_Counter_Offers::is_seller`, `KMAE_Counter_Offers::get_listing_seller_id`
- READS: —
- WRITES: —
- RELATED FEATURE: `NEGOTIATION-CHAT`, `DEAL`, `CONTACT-UNLOCK`, `NOTIFICATIONS`

## `KMAE_Counter_Offers::get_rounds_warning_message`
- FILE: `includes/class-kmae-counter-offers.php:455-465`
- SYMBOL: `KMAE_Counter_Offers::get_rounds_warning_message`
- PURPOSE: Popup copy for remaining negotiation rounds.
- CALLED BY: `KMAE_Public::enqueue`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `NEGOTIATION-CHAT`, `DEAL`, `CONTACT-UNLOCK`, `NOTIFICATIONS`

## `KMAE_Counter_Offers::get_rounds_meter`
- FILE: `includes/class-kmae-counter-offers.php:473-482`
- SYMBOL: `KMAE_Counter_Offers::get_rounds_meter`
- PURPOSE: Used / remaining round counts for the progress meter.
- CALLED BY: —
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `NEGOTIATION-CHAT`, `DEAL`, `CONTACT-UNLOCK`, `NOTIFICATIONS`

## `KMAE_Counter_Offers::get_user_rounds_left`
- FILE: `includes/class-kmae-counter-offers.php:485-493`
- SYMBOL: `KMAE_Counter_Offers::get_user_rounds_left`
- PURPOSE: Used / remaining round counts for the progress meter.
- CALLED BY: —
- CALLS: `KMAE_Counter_Offers::get_negotiation_summary`, `KMAE_Counter_Offers::is_seller`, `KMAE_Counter_Offers::is_buyer`
- READS: —
- WRITES: —
- RELATED FEATURE: `NEGOTIATION-CHAT`, `DEAL`, `CONTACT-UNLOCK`, `NOTIFICATIONS`

## `KMAE_Counties::get_all`
- FILE: `includes/class-kmae-counties.php:19-41`
- SYMBOL: `KMAE_Counties::get_all`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Counties::is_valid`, `KMAE_Counties::is_listing_county`, `KMAE_Counties::get_label`, `KMAE_Counties::get_map_label_short`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `PROFILE-COMPANY-SETTINGS`, `BROWSE-SEARCH`

## `KMAE_Counties::is_valid`
- FILE: `includes/class-kmae-counties.php:44-45`
- SYMBOL: `KMAE_Counties::is_valid`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Browse::is_wizard_complete`, `KMAE_Shortcodes::browse`, `KMAE_Shortcodes::browse_vehicle_wizard`
- CALLS: `KMAE_Counties::get_all`
- READS: —
- WRITES: —
- RELATED FEATURE: `PROFILE-COMPANY-SETTINGS`, `BROWSE-SEARCH`

## `KMAE_Counties::is_listing_county`
- FILE: `includes/class-kmae-counties.php:48-49`
- SYMBOL: `KMAE_Counties::is_listing_county`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Counties::validate_listing_location`
- CALLS: `KMAE_Counties::get_all`
- READS: —
- WRITES: —
- RELATED FEATURE: `PROFILE-COMPANY-SETTINGS`, `BROWSE-SEARCH`

## `KMAE_Counties::get_label`
- FILE: `includes/class-kmae-counties.php:52-56`
- SYMBOL: `KMAE_Counties::get_label`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Counties::format_listing_location`, `KMAE_Counties::save_listing_location`, `KMAE_Browse::wizard_summary_label`
- CALLS: `KMAE_Counties::get_all`
- READS: —
- WRITES: —
- RELATED FEATURE: `PROFILE-COMPANY-SETTINGS`, `BROWSE-SEARCH`

## `KMAE_Counties::get_map_data`
- FILE: `includes/class-kmae-counties.php:64-87`
- SYMBOL: `KMAE_Counties::get_map_data`
- PURPOSE: Real county paths from Wikipedia HU_counties_blank.svg (public domain).
- CALLED BY: `KMAE_Counties::get_map_paths`, `KMAE_Counties::get_map_label_xy`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `PROFILE-COMPANY-SETTINGS`, `BROWSE-SEARCH`

## `KMAE_Counties::get_map_paths`
- FILE: `includes/class-kmae-counties.php:93-99`
- SYMBOL: `KMAE_Counties::get_map_paths`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: —
- CALLS: `KMAE_Counties::get_map_data`
- READS: —
- WRITES: —
- RELATED FEATURE: `PROFILE-COMPANY-SETTINGS`, `BROWSE-SEARCH`

## `KMAE_Counties::get_map_label_xy`
- FILE: `includes/class-kmae-counties.php:103-109`
- SYMBOL: `KMAE_Counties::get_map_label_xy`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: —
- CALLS: `KMAE_Counties::get_map_data`
- READS: —
- WRITES: —
- RELATED FEATURE: `PROFILE-COMPANY-SETTINGS`, `BROWSE-SEARCH`

## `KMAE_Counties::format_listing_location`
- FILE: `includes/class-kmae-counties.php:112-120`
- SYMBOL: `KMAE_Counties::format_listing_location`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: —
- CALLS: `KMAE_Counties::get_label`
- READS: `postmeta:_kmae_county`, `postmeta:_kmae_city`, `postmeta:_kmae_location`
- WRITES: —
- RELATED FEATURE: `PROFILE-COMPANY-SETTINGS`, `BROWSE-SEARCH`

## `KMAE_Counties::validate_listing_location`
- FILE: `includes/class-kmae-counties.php:123-127`
- SYMBOL: `KMAE_Counties::validate_listing_location`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Google_Auth::handle_complete`, `KMAE_Listings::save_meta_from_post`, `KMAE_Auth::register`, `KMAE_Company::has_listing_location`, `KMAE_Company::save_profile_fields`, `KMAE_Meta::save_listing_meta`, `KMAE_Public::admin_update_listing`, `KMAE_Public::process_create_listing`
- CALLS: `KMAE_Counties::is_listing_county`
- READS: —
- WRITES: —
- RELATED FEATURE: `PROFILE-COMPANY-SETTINGS`, `BROWSE-SEARCH`

## `KMAE_Counties::save_listing_location`
- FILE: `includes/class-kmae-counties.php:130-136`
- SYMBOL: `KMAE_Counties::save_listing_location`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Listings::save_meta_from_post`, `KMAE_Company::apply_listing_location`, `KMAE_Meta::save_listing_meta`
- CALLS: `KMAE_Counties::get_label`
- READS: —
- WRITES: `postmeta:_kmae_county`, `postmeta:_kmae_city`, `postmeta:_kmae_location`
- RELATED FEATURE: `PROFILE-COMPANY-SETTINGS`, `BROWSE-SEARCH`

## `KMAE_Counties::get_map_label_short`
- FILE: `includes/class-kmae-counties.php:139-155`
- SYMBOL: `KMAE_Counties::get_map_label_short`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: —
- CALLS: `KMAE_Counties::get_all`
- READS: —
- WRITES: —
- RELATED FEATURE: `PROFILE-COMPANY-SETTINGS`, `BROWSE-SEARCH`

## `KMAE_Dashboard::greeting_case`
- FILE: `includes/class-kmae-dashboard.php:26-47`
- SYMBOL: `KMAE_Dashboard::greeting_case`
- PURPOSE: Megszólításra szánt név: az első betű mindig nagy, akkor is, ha a felhasználó csupa kisbetűvel regisztrált. Ékezetes kezdőbetűvel is helyesen működik (á → Á), a név többi része érintetlen marad.
- CALLED BY: `KMAE_Listing_Wizard::greeting_name`, `KMAE_Contact::get_contact_details`, `KMAE_Dashboard::get_data`, `KMAE_Dashboard::format_offer_row`, `KMAE_Dashboard::format_message_row`, `KMAE_Offers::get_offerer_display_name`, `KMAE_Counter_Offers::get_other_party_name`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `DASHBOARD-HUBS`

## `KMAE_Dashboard::take_home_greeting`
- FILE: `includes/class-kmae-dashboard.php:51-66`
- SYMBOL: `KMAE_Dashboard::take_home_greeting`
- PURPOSE: Show the personal home greeting once per authenticated WordPress session.
- CALLED BY: —
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `DASHBOARD-HUBS`

## `KMAE_Dashboard::init`
- FILE: `includes/class-kmae-dashboard.php:69-70`
- SYMBOL: `KMAE_Dashboard::init`
- PURPOSE: Show the personal home greeting once per authenticated WordPress session.
- CALLED BY: `KMAE_Plugin::run`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `DASHBOARD-HUBS`

## `KMAE_Dashboard::maybe_track_listing_view`
- FILE: `includes/class-kmae-dashboard.php:76-103`
- SYMBOL: `KMAE_Dashboard::maybe_track_listing_view`
- PURPOSE: Count a listing view once per visitor session (skip owner / bots).
- CALLED BY: `WP action `template_redirect``
- CALLS: `KMAE_Meta::get_status`, `KMAE_Dashboard::increment_views`
- READS: —
- WRITES: —
- RELATED FEATURE: `DASHBOARD-HUBS`

## `KMAE_Dashboard::increment_views`
- FILE: `includes/class-kmae-dashboard.php:109-125`
- SYMBOL: `KMAE_Dashboard::increment_views`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Dashboard::maybe_track_listing_view`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `DASHBOARD-HUBS`

## `KMAE_Dashboard::get_listing_views`
- FILE: `includes/class-kmae-dashboard.php:132-133`
- SYMBOL: `KMAE_Dashboard::get_listing_views`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Dashboard::get_user_view_stats`, `KMAE_Dashboard::format_listing_row`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `DASHBOARD-HUBS`

## `KMAE_Dashboard::get_user_view_stats`
- FILE: `includes/class-kmae-dashboard.php:142-177`
- SYMBOL: `KMAE_Dashboard::get_user_view_stats`
- PURPOSE: Sum views for all listings of a user.
- CALLED BY: `KMAE_Dashboard::get_data`
- CALLS: `KMAE_Dashboard::get_listing_views`
- READS: —
- WRITES: —
- RELATED FEATURE: `DASHBOARD-HUBS`

## `KMAE_Dashboard::get_data`
- FILE: `includes/class-kmae-dashboard.php:186-414`
- SYMBOL: `KMAE_Dashboard::get_data`
- PURPOSE: Full dashboard payload for the logged-in home.
- CALLED BY: `KMAE_Shortcodes::render_hub_section`
- CALLS: `KMAE_Meta::get_status`, `KMAE_Database::get_offers_received_by_user`, `KMAE_Database::count_unseen_offer_activity`, `KMAE_Trust::get_summary`, `KMAE_Auth::first_name`, `KMAE_Pages::url`, `KMAE_Dashboard::greeting_case`, `KMAE_Dashboard::format_listing_row`, `KMAE_Dashboard::format_offer_row`, `KMAE_Dashboard::format_message_row`, `KMAE_Dashboard::activity_from_offer`, `KMAE_Dashboard::relative_time`, `KMAE_Dashboard::get_user_view_stats`, `KMAE_Dashboard::initials`, `KMAE_Dashboard::format_view_delta`
- READS: `postmeta:_kmae_archived_at`
- WRITES: —
- RELATED FEATURE: `DASHBOARD-HUBS`

## `KMAE_Dashboard::format_listing_row`
- FILE: `includes/class-kmae-dashboard.php:421-450`
- SYMBOL: `KMAE_Dashboard::format_listing_row`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Dashboard::get_data`
- CALLS: `KMAE_Meta::get_status`, `KMAE_Meta::status_labels`, `KMAE_Query::get_gallery_ids`, `KMAE_Images::get_url`, `KMAE_Seller::get_public_price_row`, `KMAE_Vehicle::get_swipe_subtitle`, `KMAE_Dashboard::get_listing_views`
- READS: —
- WRITES: —
- RELATED FEATURE: `DASHBOARD-HUBS`

## `KMAE_Dashboard::format_offer_row`
- FILE: `includes/class-kmae-dashboard.php:457-474`
- SYMBOL: `KMAE_Dashboard::format_offer_row`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Dashboard::get_data`
- CALLS: `KMAE_Offers::get_offer_summary`, `KMAE_Pages::offer_thread_url`, `KMAE_Database::get_offer_alert_state`, `KMAE_Dashboard::greeting_case`, `KMAE_Dashboard::initials`, `KMAE_Dashboard::relative_time`
- READS: —
- WRITES: —
- RELATED FEATURE: `DASHBOARD-HUBS`

## `KMAE_Dashboard::format_message_row`
- FILE: `includes/class-kmae-dashboard.php:481-506`
- SYMBOL: `KMAE_Dashboard::format_message_row`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Dashboard::get_data`
- CALLS: `KMAE_Database::get_latest_counter_offer`, `KMAE_Counter_Offers::format_counter_message`, `KMAE_Pages::offer_thread_url`, `KMAE_Database::get_offer_alert_state`, `KMAE_Dashboard::greeting_case`, `KMAE_Dashboard::offer_amount_label`, `KMAE_Dashboard::initials`, `KMAE_Dashboard::relative_time`
- READS: —
- WRITES: —
- RELATED FEATURE: `DASHBOARD-HUBS`

## `KMAE_Dashboard::activity_from_offer`
- FILE: `includes/class-kmae-dashboard.php:513-548`
- SYMBOL: `KMAE_Dashboard::activity_from_offer`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Dashboard::get_data`
- CALLS: `KMAE_Offers::get_offer_summary`, `KMAE_Dashboard::relative_time`
- READS: —
- WRITES: —
- RELATED FEATURE: `DASHBOARD-HUBS`

## `KMAE_Dashboard::offer_amount_label`
- FILE: `includes/class-kmae-dashboard.php:555-556`
- SYMBOL: `KMAE_Dashboard::offer_amount_label`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Dashboard::format_message_row`
- CALLS: `KMAE_Offers::get_offer_summary`
- READS: —
- WRITES: —
- RELATED FEATURE: `DASHBOARD-HUBS`

## `KMAE_Dashboard::format_view_delta`
- FILE: `includes/class-kmae-dashboard.php:563-578`
- SYMBOL: `KMAE_Dashboard::format_view_delta`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Dashboard::get_data`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `DASHBOARD-HUBS`

## `KMAE_Dashboard::initials`
- FILE: `includes/class-kmae-dashboard.php:585-592`
- SYMBOL: `KMAE_Dashboard::initials`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Dashboard::get_data`, `KMAE_Dashboard::format_offer_row`, `KMAE_Dashboard::format_message_row`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `DASHBOARD-HUBS`

## `KMAE_Dashboard::relative_time`
- FILE: `includes/class-kmae-dashboard.php:599-607`
- SYMBOL: `KMAE_Dashboard::relative_time`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Dashboard::get_data`, `KMAE_Dashboard::format_offer_row`, `KMAE_Dashboard::format_message_row`, `KMAE_Dashboard::activity_from_offer`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `DASHBOARD-HUBS`

## `KMAE_Database::table`
- FILE: `includes/class-kmae-database.php:14-16`
- SYMBOL: `KMAE_Database::table`
- PURPOSE: Database table names and helper queries.
- CALLED BY: `KMAE_Listings::collect_listing_attachment_ids`, `KMAE_Listings::force_delete_listing`, `KMAE_Auth::register`, `KMAE_Auth::mark_email_verified`, `KMAE_Auth::get_profile`, `KMAE_Auth::save_email_prefs`, `KMAE_Auth::sync_phone`, `KMAE_Database::get_private_data`, `KMAE_Database::save_private_data`, `KMAE_Database::get_offers_for_listing`, `KMAE_Database::count_offers_for_listing`, `KMAE_Database::get_offer`, `KMAE_Database::get_offers_by_user`, `KMAE_Database::get_offers_received_by_user`, `KMAE_Database::get_all_offers` +25 more
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `OFFERS`, `CONTACT-UNLOCK`, `DASHBOARD-HUBS`, `LIVE-NAV`

## `KMAE_Database::get_private_data`
- FILE: `includes/class-kmae-database.php:19-26`
- SYMBOL: `KMAE_Database::get_private_data`
- PURPOSE: Database table names and helper queries.
- CALLED BY: `KMAE_Database::save_private_data`, `KMAE_Offers::submit_cash_offer`, `KMAE_Meta::render_meta_box`
- CALLS: `KMAE_Database::table`
- READS: `wpdb:get_row`
- WRITES: —
- RELATED FEATURE: `OFFERS`, `CONTACT-UNLOCK`, `DASHBOARD-HUBS`, `LIVE-NAV`

## `KMAE_Database::save_private_data`
- FILE: `includes/class-kmae-database.php:29-59`
- SYMBOL: `KMAE_Database::save_private_data`
- PURPOSE: Database table names and helper queries.
- CALLED BY: `KMAE_Seller::save_from_post`, `KMAE_Meta::save_listing_meta`
- CALLS: `KMAE_Database::table`, `KMAE_Database::get_private_data`
- READS: —
- WRITES: `wpdb:insert`, `wpdb:update`, `wpdb:delete`
- RELATED FEATURE: `OFFERS`, `CONTACT-UNLOCK`, `DASHBOARD-HUBS`, `LIVE-NAV`

## `KMAE_Database::get_offers_for_listing`
- FILE: `includes/class-kmae-database.php:62-69`
- SYMBOL: `KMAE_Database::get_offers_for_listing`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Listings::force_delete_listing`, `KMAE_Notifications::on_deal_locked`, `KMAE_Notifications::on_deal_failed`, `KMAE_Notifications::listing_closed`, `KMAE_Live_Page::get_fingerprint`, `KMAE_Counter_Offers::reject_other_offers`
- CALLS: `KMAE_Database::table`
- READS: `wpdb:get_results`
- WRITES: —
- RELATED FEATURE: `OFFERS`, `CONTACT-UNLOCK`, `DASHBOARD-HUBS`, `LIVE-NAV`

## `KMAE_Database::count_offers_for_listing`
- FILE: `includes/class-kmae-database.php:72-78`
- SYMBOL: `KMAE_Database::count_offers_for_listing`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Admin::listing_column_content`, `KMAE_Live_Page::get_fingerprint`
- CALLS: `KMAE_Database::table`
- READS: `wpdb:get_var`
- WRITES: —
- RELATED FEATURE: `OFFERS`, `CONTACT-UNLOCK`, `DASHBOARD-HUBS`, `LIVE-NAV`

## `KMAE_Database::get_offer`
- FILE: `includes/class-kmae-database.php:81-88`
- SYMBOL: `KMAE_Database::get_offer`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Contact::unlock`, `KMAE_Database::admin_delete_offer`, `KMAE_Database::get_offers_last_seen_at`, `KMAE_Offers::withdraw_offer`, `KMAE_Trust::submit`, `KMAE_Trust::on_deal_success`, `KMAE_Deal::lock_on_accept`, `KMAE_Deal::confirm_success`, `KMAE_Deal::confirm_failure`, `KMAE_Notifications::on_new_offer`, `KMAE_Notifications::on_counter_offer`, `KMAE_Notifications::on_buyer_revision`, `KMAE_Notifications::on_offer_accepted`, `KMAE_Notifications::on_deal_locked`, `KMAE_Notifications::on_deal_failed` +9 more
- CALLS: `KMAE_Database::table`
- READS: `wpdb:get_row`
- WRITES: —
- RELATED FEATURE: `OFFERS`, `CONTACT-UNLOCK`, `DASHBOARD-HUBS`, `LIVE-NAV`

## `KMAE_Database::get_offers_by_user`
- FILE: `includes/class-kmae-database.php:91-98`
- SYMBOL: `KMAE_Database::get_offers_by_user`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Database::count_unseen_offer_activity`, `KMAE_Live_Page::get_fingerprint`, `KMAE_Shortcodes::my_offers`
- CALLS: `KMAE_Database::table`
- READS: `wpdb:get_results`
- WRITES: —
- RELATED FEATURE: `OFFERS`, `CONTACT-UNLOCK`, `DASHBOARD-HUBS`, `LIVE-NAV`

## `KMAE_Database::get_offers_received_by_user`
- FILE: `includes/class-kmae-database.php:104-114`
- SYMBOL: `KMAE_Database::get_offers_received_by_user`
- PURPOSE: Offers received on listings owned by the user.
- CALLED BY: `KMAE_Dashboard::get_data`, `KMAE_Database::count_unseen_offer_activity`, `KMAE_Live_Page::get_fingerprint`, `KMAE_Shortcodes::my_offers`
- CALLS: `KMAE_Database::table`
- READS: `wpdb:get_results`
- WRITES: —
- RELATED FEATURE: `OFFERS`, `CONTACT-UNLOCK`, `DASHBOARD-HUBS`, `LIVE-NAV`

## `KMAE_Database::get_all_offers`
- FILE: `includes/class-kmae-database.php:120-148`
- SYMBOL: `KMAE_Database::get_all_offers`
- PURPOSE: All offers for admin management.
- CALLED BY: `KMAE_Admin::render_offers`
- CALLS: `KMAE_Database::table`
- READS: `wpdb:get_results`
- WRITES: —
- RELATED FEATURE: `OFFERS`, `CONTACT-UNLOCK`, `DASHBOARD-HUBS`, `LIVE-NAV`

## `KMAE_Database::count_all_offers`
- FILE: `includes/class-kmae-database.php:151-157`
- SYMBOL: `KMAE_Database::count_all_offers`
- PURPOSE: All offers for admin management.
- CALLED BY: `KMAE_Admin::render_offers`
- CALLS: `KMAE_Database::table`
- READS: `wpdb:get_var`
- WRITES: —
- RELATED FEATURE: `OFFERS`, `CONTACT-UNLOCK`, `DASHBOARD-HUBS`, `LIVE-NAV`

## `KMAE_Database::admin_delete_offer`
- FILE: `includes/class-kmae-database.php:160-172`
- SYMBOL: `KMAE_Database::admin_delete_offer`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Admin::handle_delete_offer`
- CALLS: `KMAE_Database::table`, `KMAE_Database::get_offer`
- READS: `table:counter_offers`, `table:offer_images`, `table:contact_unlocks`, `table:offers`
- WRITES: `wpdb:delete`
- RELATED FEATURE: `OFFERS`, `CONTACT-UNLOCK`, `DASHBOARD-HUBS`, `LIVE-NAV`

## `KMAE_Database::get_offers_seen_map`
- FILE: `includes/class-kmae-database.php:184-186`
- SYMBOL: `KMAE_Database::get_offers_seen_map`
- PURPOSE: Per-offer read timestamps.
- CALLED BY: `KMAE_Database::get_offer_seen_at`, `KMAE_Database::mark_offer_seen`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `OFFERS`, `CONTACT-UNLOCK`, `DASHBOARD-HUBS`, `LIVE-NAV`

## `KMAE_Database::get_offer_seen_at`
- FILE: `includes/class-kmae-database.php:189-196`
- SYMBOL: `KMAE_Database::get_offer_seen_at`
- PURPOSE: Per-offer read timestamps.
- CALLED BY: `KMAE_Database::get_offer_alert_state`
- CALLS: `KMAE_Database::get_offers_seen_map`, `KMAE_Database::get_offers_last_seen_at`
- READS: —
- WRITES: —
- RELATED FEATURE: `OFFERS`, `CONTACT-UNLOCK`, `DASHBOARD-HUBS`, `LIVE-NAV`

## `KMAE_Database::db_now`
- FILE: `includes/class-kmae-database.php:207-209`
- SYMBOL: `KMAE_Database::db_now`
- PURPOSE: Az „olvasva” időpontokat az adatbázis órája szerint tároljuk: az ajánlat/ellenajánlat időbélyegek is a MySQL CURRENT_TIMESTAMP-jéből jönnek, így a két időskála garantáltan egyezik, akkor is, ha a
- CALLED BY: `KMAE_Database::mark_offer_seen`, `KMAE_Database::mark_offer_activity_seen`
- CALLS: —
- READS: `wpdb:get_var`
- WRITES: —
- RELATED FEATURE: `OFFERS`, `CONTACT-UNLOCK`, `DASHBOARD-HUBS`, `LIVE-NAV`

## `KMAE_Database::mark_offer_seen`
- FILE: `includes/class-kmae-database.php:212-215`
- SYMBOL: `KMAE_Database::mark_offer_seen`
- PURPOSE: Az „olvasva” időpontokat az adatbázis órája szerint tároljuk: az ajánlat/ellenajánlat időbélyegek is a MySQL CURRENT_TIMESTAMP-jéből jönnek, így a két időskála garantáltan egyezik, akkor is, ha a
- CALLED BY: `KMAE_Pages::mark_offers_seen_on_visit`, `KMAE_Shortcodes::my_offers`
- CALLS: `KMAE_Database::get_offers_seen_map`, `KMAE_Database::db_now`
- READS: —
- WRITES: —
- RELATED FEATURE: `OFFERS`, `CONTACT-UNLOCK`, `DASHBOARD-HUBS`, `LIVE-NAV`

## `KMAE_Database::get_last_activity_from_other`
- FILE: `includes/class-kmae-database.php:221-257`
- SYMBOL: `KMAE_Database::get_last_activity_from_other`
- PURPOSE: Latest activity on this offer from the other party.
- CALLED BY: `KMAE_Database::get_offer_alert_state`
- CALLS: `KMAE_Database::get_counter_offers`
- READS: —
- WRITES: —
- RELATED FEATURE: `OFFERS`, `CONTACT-UNLOCK`, `DASHBOARD-HUBS`, `LIVE-NAV`

## `KMAE_Database::get_offer_alert_state`
- FILE: `includes/class-kmae-database.php:265-276`
- SYMBOL: `KMAE_Database::get_offer_alert_state`
- PURPOSE: Hub card highlight: good = unread fresh/good news (pulse), bad = rejected (solid red).
- CALLED BY: `KMAE_Dashboard::format_offer_row`, `KMAE_Dashboard::format_message_row`, `KMAE_Database::count_unseen_offer_activity`
- CALLS: `KMAE_Database::get_offer_seen_at`, `KMAE_Database::get_last_activity_from_other`
- READS: —
- WRITES: —
- RELATED FEATURE: `OFFERS`, `CONTACT-UNLOCK`, `DASHBOARD-HUBS`, `LIVE-NAV`

## `KMAE_Database::get_offers_last_seen_at`
- FILE: `includes/class-kmae-database.php:282-296`
- SYMBOL: `KMAE_Database::get_offers_last_seen_at`
- PURPOSE: Last time the user opened the offers hub (legacy offer-id meta is migrated on read).
- CALLED BY: `KMAE_Database::get_offer_seen_at`
- CALLS: `KMAE_Database::get_offer`
- READS: —
- WRITES: —
- RELATED FEATURE: `OFFERS`, `CONTACT-UNLOCK`, `DASHBOARD-HUBS`, `LIVE-NAV`

## `KMAE_Database::count_unseen_offer_activity`
- FILE: `includes/class-kmae-database.php:302-323`
- SYMBOL: `KMAE_Database::count_unseen_offer_activity`
- PURPOSE: Count offers with unread good news (nav alert).
- CALLED BY: `KMAE_Dashboard::get_data`, `KMAE_Database::count_unseen_received_offers`, `KMAE_Live_Page::get_fingerprint`, `KMAE_Public::ajax_poll_page`
- CALLS: `KMAE_Database::get_offers_by_user`, `KMAE_Database::get_offer_alert_state`, `KMAE_Database::get_offers_received_by_user`
- READS: —
- WRITES: —
- RELATED FEATURE: `OFFERS`, `CONTACT-UNLOCK`, `DASHBOARD-HUBS`, `LIVE-NAV`

## `KMAE_Database::count_unseen_received_offers`
- FILE: `includes/class-kmae-database.php:327-328`
- SYMBOL: `KMAE_Database::count_unseen_received_offers`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: —
- CALLS: `KMAE_Database::count_unseen_offer_activity`
- READS: —
- WRITES: —
- RELATED FEATURE: `OFFERS`, `CONTACT-UNLOCK`, `DASHBOARD-HUBS`, `LIVE-NAV`

## `KMAE_Database::mark_offer_activity_seen`
- FILE: `includes/class-kmae-database.php:331-333`
- SYMBOL: `KMAE_Database::mark_offer_activity_seen`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Database::mark_received_offers_seen`, `KMAE_Shortcodes::my_offers`
- CALLS: `KMAE_Database::db_now`
- READS: —
- WRITES: —
- RELATED FEATURE: `OFFERS`, `CONTACT-UNLOCK`, `DASHBOARD-HUBS`, `LIVE-NAV`

## `KMAE_Database::mark_received_offers_seen`
- FILE: `includes/class-kmae-database.php:337-338`
- SYMBOL: `KMAE_Database::mark_received_offers_seen`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: —
- CALLS: `KMAE_Database::mark_offer_activity_seen`
- READS: —
- WRITES: —
- RELATED FEATURE: `OFFERS`, `CONTACT-UNLOCK`, `DASHBOARD-HUBS`, `LIVE-NAV`

## `KMAE_Database::get_offers_page_url`
- FILE: `includes/class-kmae-database.php:341-342`
- SYMBOL: `KMAE_Database::get_offers_page_url`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: —
- CALLS: `KMAE_Pages::offers_page_url`
- READS: —
- WRITES: —
- RELATED FEATURE: `OFFERS`, `CONTACT-UNLOCK`, `DASHBOARD-HUBS`, `LIVE-NAV`

## `KMAE_Database::get_user_offer_for_listing`
- FILE: `includes/class-kmae-database.php:345-353`
- SYMBOL: `KMAE_Database::get_user_offer_for_listing`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Database::get_active_user_offer_for_listing`
- CALLS: `KMAE_Database::table`
- READS: `wpdb:get_row`
- WRITES: —
- RELATED FEATURE: `OFFERS`, `CONTACT-UNLOCK`, `DASHBOARD-HUBS`, `LIVE-NAV`

## `KMAE_Database::get_active_user_offer_for_listing`
- FILE: `includes/class-kmae-database.php:359-364`
- SYMBOL: `KMAE_Database::get_active_user_offer_for_listing`
- PURPOSE: Latest offer that still blocks re-submitting (pending or accepted).
- CALLED BY: `KMAE_Offers::guard_new_offer`, `KMAE_Live_Page::get_fingerprint`
- CALLS: `KMAE_Offers::is_active_for_listing`, `KMAE_Database::get_user_offer_for_listing`
- READS: —
- WRITES: —
- RELATED FEATURE: `OFFERS`, `CONTACT-UNLOCK`, `DASHBOARD-HUBS`, `LIVE-NAV`

## `KMAE_Database::get_withdrawn_user_offer_for_listing`
- FILE: `includes/class-kmae-database.php:370-379`
- SYMBOL: `KMAE_Database::get_withdrawn_user_offer_for_listing`
- PURPOSE: Withdrawn offer on this listing — permanent block on re-offering.
- CALLED BY: `KMAE_Offers::guard_new_offer`, `KMAE_Live_Page::get_fingerprint`
- CALLS: `KMAE_Database::table`
- READS: `wpdb:get_row`
- WRITES: —
- RELATED FEATURE: `OFFERS`, `CONTACT-UNLOCK`, `DASHBOARD-HUBS`, `LIVE-NAV`

## `KMAE_Database::get_offer_images`
- FILE: `includes/class-kmae-database.php:382-389`
- SYMBOL: `KMAE_Database::get_offer_images`
- PURPOSE: Withdrawn offer on this listing — permanent block on re-offering.
- CALLED BY: `KMAE_Offers::get_offer_summary`, `KMAE_Offers::render_offer_images`
- CALLS: `KMAE_Database::table`
- READS: `wpdb:get_results`
- WRITES: —
- RELATED FEATURE: `OFFERS`, `CONTACT-UNLOCK`, `DASHBOARD-HUBS`, `LIVE-NAV`

## `KMAE_Database::get_counter_offers`
- FILE: `includes/class-kmae-database.php:392-399`
- SYMBOL: `KMAE_Database::get_counter_offers`
- PURPOSE: Withdrawn offer on this listing — permanent block on re-offering.
- CALLED BY: `KMAE_Database::get_last_activity_from_other`, `KMAE_Live_Page::get_fingerprint`, `KMAE_Counter_Offers::get_negotiation_summary`, `KMAE_Counter_Offers::get_chat_messages`
- CALLS: `KMAE_Database::table`
- READS: `wpdb:get_results`
- WRITES: —
- RELATED FEATURE: `OFFERS`, `CONTACT-UNLOCK`, `DASHBOARD-HUBS`, `LIVE-NAV`

## `KMAE_Database::get_latest_counter_offer`
- FILE: `includes/class-kmae-database.php:402-409`
- SYMBOL: `KMAE_Database::get_latest_counter_offer`
- PURPOSE: Withdrawn offer on this listing — permanent block on re-offering.
- CALLED BY: `KMAE_Dashboard::format_message_row`, `KMAE_Counter_Offers::can_seller_counter`, `KMAE_Counter_Offers::can_buyer_revise`, `KMAE_Counter_Offers::can_buyer_accept`, `KMAE_Counter_Offers::accept_offer`
- CALLS: `KMAE_Database::table`
- READS: `wpdb:get_row`
- WRITES: —
- RELATED FEATURE: `OFFERS`, `CONTACT-UNLOCK`, `DASHBOARD-HUBS`, `LIVE-NAV`

## `KMAE_Database::count_counter_offers_by_user`
- FILE: `includes/class-kmae-database.php:412-420`
- SYMBOL: `KMAE_Database::count_counter_offers_by_user`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Counter_Offers::count_user_counters`
- CALLS: `KMAE_Database::table`
- READS: `wpdb:get_var`
- WRITES: —
- RELATED FEATURE: `OFFERS`, `CONTACT-UNLOCK`, `DASHBOARD-HUBS`, `LIVE-NAV`

## `KMAE_Database::update_offer_status`
- FILE: `includes/class-kmae-database.php:423-431`
- SYMBOL: `KMAE_Database::update_offer_status`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Offers::withdraw_offer`, `KMAE_Deal::stop_shopping`, `KMAE_Counter_Offers::reject_other_offers`
- CALLS: `KMAE_Database::table`
- READS: —
- WRITES: `wpdb:update`
- RELATED FEATURE: `OFFERS`, `CONTACT-UNLOCK`, `DASHBOARD-HUBS`, `LIVE-NAV`

## `KMAE_Database::get_counter_offer`
- FILE: `includes/class-kmae-database.php:434-441`
- SYMBOL: `KMAE_Database::get_counter_offer`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Notifications::on_counter_offer`
- CALLS: `KMAE_Database::table`
- READS: `wpdb:get_row`
- WRITES: —
- RELATED FEATURE: `OFFERS`, `CONTACT-UNLOCK`, `DASHBOARD-HUBS`, `LIVE-NAV`

## `KMAE_Database::has_contact_unlock`
- FILE: `includes/class-kmae-database.php:444-452`
- SYMBOL: `KMAE_Database::has_contact_unlock`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Contact::is_unlocked`
- CALLS: `KMAE_Database::table`
- READS: `wpdb:get_var`
- WRITES: —
- RELATED FEATURE: `OFFERS`, `CONTACT-UNLOCK`, `DASHBOARD-HUBS`, `LIVE-NAV`

## `KMAE_Database::create_contact_unlock`
- FILE: `includes/class-kmae-database.php:455-464`
- SYMBOL: `KMAE_Database::create_contact_unlock`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Contact::unlock_accepted_deal`, `KMAE_Contact::unlock`
- CALLS: `KMAE_Database::table`
- READS: —
- WRITES: `wpdb:replace`
- RELATED FEATURE: `OFFERS`, `CONTACT-UNLOCK`, `DASHBOARD-HUBS`, `LIVE-NAV`

## `KMAE_Deactivator::deactivate`
- FILE: `includes/class-kmae-deactivator.php:14-16`
- SYMBOL: `KMAE_Deactivator::deactivate`
- PURPOSE: Plugin deactivation.
- CALLED BY: —
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `BOOT-ARCHITECTURE`, `CRON-ARCHIVE`

## `KMAE_Deal::lock_on_accept`
- FILE: `includes/class-kmae-deal.php:26-43`
- SYMBOL: `KMAE_Deal::lock_on_accept`
- PURPOSE: Lock listing after accept — viewing appointment, not sold yet.
- CALLED BY: `KMAE_Listings::archive_on_deal`, `WP action `kmae_offer_accepted``
- CALLS: `KMAE_Database::get_offer`, `KMAE_Meta::get_status`
- READS: —
- WRITES: `postmeta:_kmae_status`, `postmeta:_kmae_accepted_offer_id`
- RELATED FEATURE: `DEAL`, `NOTIFICATIONS`, `CRON-ARCHIVE`
- EMITS: `kmae_deal_locked`

## `KMAE_Deal::get_buyer_active_lock_offer_id`
- FILE: `includes/class-kmae-deal.php:52-62`
- SYMBOL: `KMAE_Deal::get_buyer_active_lock_offer_id`
- PURPOSE: Active „Áll az alku” offer id for a buyer (any listing), or 0.
- CALLED BY: `KMAE_Deal::assert_buyer_can_lock`
- CALLS: `KMAE_Database::table`
- READS: `table:offers`, `wpdb:get_results`
- WRITES: —
- RELATED FEATURE: `DEAL`, `NOTIFICATIONS`, `CRON-ARCHIVE`

## `KMAE_Deal::assert_buyer_can_lock`
- FILE: `includes/class-kmae-deal.php:88-96`
- SYMBOL: `KMAE_Deal::assert_buyer_can_lock`
- PURPOSE: Buyer may only have one Áll az alku at a time.
- CALLED BY: `KMAE_Counter_Offers::can_seller_accept`, `KMAE_Counter_Offers::can_buyer_accept`, `KMAE_Counter_Offers::accept_offer`
- CALLS: `KMAE_Deal::get_buyer_active_lock_offer_id`
- READS: —
- WRITES: —
- RELATED FEATURE: `DEAL`, `NOTIFICATIONS`, `CRON-ARCHIVE`

## `KMAE_Deal::is_locked`
- FILE: `includes/class-kmae-deal.php:103-105`
- SYMBOL: `KMAE_Deal::is_locked`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Deal::is_viewing_deal`, `KMAE_Counter_Offers::can_seller_counter`, `KMAE_Counter_Offers::can_buyer_revise`, `KMAE_Counter_Offers::can_seller_accept`, `KMAE_Counter_Offers::can_buyer_accept`, `KMAE_Counter_Offers::accept_offer`
- CALLS: `KMAE_Meta::get_status`
- READS: —
- WRITES: —
- RELATED FEATURE: `DEAL`, `NOTIFICATIONS`, `CRON-ARCHIVE`

## `KMAE_Deal::get_locked_offer_id`
- FILE: `includes/class-kmae-deal.php:112-113`
- SYMBOL: `KMAE_Deal::get_locked_offer_id`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Deal::is_viewing_deal`
- CALLS: —
- READS: `postmeta:_kmae_accepted_offer_id`
- WRITES: —
- RELATED FEATURE: `DEAL`, `NOTIFICATIONS`, `CRON-ARCHIVE`

## `KMAE_Deal::is_viewing_deal`
- FILE: `includes/class-kmae-deal.php:120-125`
- SYMBOL: `KMAE_Deal::is_viewing_deal`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Deal::can_confirm`
- CALLS: `KMAE_Deal::is_locked`, `KMAE_Deal::get_locked_offer_id`
- READS: —
- WRITES: —
- RELATED FEATURE: `DEAL`, `NOTIFICATIONS`, `CRON-ARCHIVE`

## `KMAE_Deal::can_confirm`
- FILE: `includes/class-kmae-deal.php:135-140`
- SYMBOL: `KMAE_Deal::can_confirm`
- PURPOSE: Seller or buyer on the locked deal can confirm outcome.
- CALLED BY: `KMAE_Deal::confirm_success`, `KMAE_Deal::confirm_failure`
- CALLS: `KMAE_Counter_Offers::is_seller`, `KMAE_Counter_Offers::is_buyer`, `KMAE_Deal::is_viewing_deal`
- READS: —
- WRITES: —
- RELATED FEATURE: `DEAL`, `NOTIFICATIONS`, `CRON-ARCHIVE`

## `KMAE_Deal::confirm_success`
- FILE: `includes/class-kmae-deal.php:150-176`
- SYMBOL: `KMAE_Deal::confirm_success`
- PURPOSE: Meeting succeeded — car sold.
- CALLED BY: `KMAE_Public::process_deal_success`
- CALLS: `KMAE_Database::get_offer`, `KMAE_Counter_Offers::reject_other_offers`, `KMAE_Notifications::listing_closed`, `KMAE_Deal::can_confirm`
- READS: —
- WRITES: `postmeta:_kmae_status`, `postmeta:_kmae_archived_at`, `postmeta:_kmae_accepted_offer_id`
- RELATED FEATURE: `DEAL`, `NOTIFICATIONS`, `CRON-ARCHIVE`
- EMITS: `kmae_deal_success`

## `KMAE_Deal::confirm_failure`
- FILE: `includes/class-kmae-deal.php:186-215`
- SYMBOL: `KMAE_Deal::confirm_failure`
- PURPOSE: Meeting failed — unlock and continue.
- CALLED BY: `KMAE_Public::process_deal_failure`
- CALLS: `KMAE_Database::get_offer`, `KMAE_Database::table`, `KMAE_Deal::can_confirm`
- READS: `table:offers`
- WRITES: `postmeta:_kmae_accepted_offer_id`, `postmeta:_kmae_archived_at`, `postmeta:_kmae_status`, `wpdb:update`
- RELATED FEATURE: `DEAL`, `NOTIFICATIONS`, `CRON-ARCHIVE`
- EMITS: `kmae_deal_failed`

## `KMAE_Deal::continue_shopping`
- FILE: `includes/class-kmae-deal.php:224-230`
- SYMBOL: `KMAE_Deal::continue_shopping`
- PURPOSE: After purchase: buyer wants to keep negotiating other cars.
- CALLED BY: `KMAE_Public::admin_continue_shopping`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `DEAL`, `NOTIFICATIONS`, `CRON-ARCHIVE`

## `KMAE_Deal::stop_shopping`
- FILE: `includes/class-kmae-deal.php:239-252`
- SYMBOL: `KMAE_Deal::stop_shopping`
- PURPOSE: After purchase: buyer stops — close other pending talks + notify sellers.
- CALLED BY: `KMAE_Public::admin_continue_shopping`
- CALLS: `KMAE_Database::update_offer_status`, `KMAE_Notifications::buyer_found_other_car`, `KMAE_Deal::get_buyer_other_pending_offers`
- READS: —
- WRITES: —
- RELATED FEATURE: `DEAL`, `NOTIFICATIONS`, `CRON-ARCHIVE`

## `KMAE_Deal::get_buyer_other_pending_offers`
- FILE: `includes/class-kmae-deal.php:262-271`
- SYMBOL: `KMAE_Deal::get_buyer_other_pending_offers`
- PURPOSE: Pending offers by buyer on other listings.
- CALLED BY: `KMAE_Deal::stop_shopping`, `KMAE_Notifications::notify_buyer_other_sellers_hold`, `KMAE_Notifications::notify_buyer_other_sellers_resume`
- CALLS: `KMAE_Database::table`
- READS: `table:offers`, `wpdb:get_results`
- WRITES: —
- RELATED FEATURE: `DEAL`, `NOTIFICATIONS`, `CRON-ARCHIVE`

## `KMAE_Deal::get_continue_offer_id`
- FILE: `includes/class-kmae-deal.php:278-279`
- SYMBOL: `KMAE_Deal::get_continue_offer_id`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: —
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `DEAL`, `NOTIFICATIONS`, `CRON-ARCHIVE`

## `KMAE_Google_Auth::init`
- FILE: `includes/class-kmae-google-auth.php:36-41`
- SYMBOL: `KMAE_Google_Auth::init`
- PURPOSE: Igaz, amíg a kötelező adatok hiányoznak az első belépés után.
- CALLED BY: `KMAE_Plugin::run`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `GOOGLE-AUTH`

## `KMAE_Google_Auth::enforce_completion`
- FILE: `includes/class-kmae-google-auth.php:54-74`
- SYMBOL: `KMAE_Google_Auth::enforce_completion`
- PURPOSE: Aki a kiegészítő képernyőt elhagyja, félkész fiókkal maradna: nincs telefonszáma (a kapcsolatfeloldás alapja), nincs fióktípusa, és nem fogadta el a feltételeket. Ilyen fiókkal nem engedjük használni az
- CALLED BY: `WP action `template_redirect``
- CALLS: `KMAE_Pages::url`, `KMAE_Google_Auth::needs_completion`
- READS: —
- WRITES: —
- RELATED FEATURE: `GOOGLE-AUTH`
- GET KEYS: `kmae_complete`

## `KMAE_Google_Auth::admin_user_column`
- FILE: `includes/class-kmae-google-auth.php:83-85`
- SYMBOL: `KMAE_Google_Auth::admin_user_column`
- PURPOSE: A felhasználólistában lássuk, melyik fiók maradt félbe.
- CALLED BY: `WP filter `manage_users_columns``
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `GOOGLE-AUTH`

## `KMAE_Google_Auth::admin_user_column_value`
- FILE: `includes/class-kmae-google-auth.php:94-109`
- SYMBOL: `KMAE_Google_Auth::admin_user_column_value`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `WP filter `manage_users_custom_column``
- CALLS: `KMAE_Google_Auth::needs_completion`
- READS: —
- WRITES: —
- RELATED FEATURE: `GOOGLE-AUTH`

## `KMAE_Google_Auth::client_id`
- FILE: `includes/class-kmae-google-auth.php:116-117`
- SYMBOL: `KMAE_Google_Auth::client_id`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Google_Auth::is_configured`, `KMAE_Google_Auth::redirect_to_google`, `KMAE_Google_Auth::fetch_profile`
- CALLS: —
- READS: `option:kmae_google_client_id`
- WRITES: —
- RELATED FEATURE: `GOOGLE-AUTH`

## `KMAE_Google_Auth::client_secret`
- FILE: `includes/class-kmae-google-auth.php:120-121`
- SYMBOL: `KMAE_Google_Auth::client_secret`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Google_Auth::is_configured`, `KMAE_Google_Auth::fetch_profile`
- CALLS: —
- READS: `option:kmae_google_client_secret`
- WRITES: —
- RELATED FEATURE: `GOOGLE-AUTH`

## `KMAE_Google_Auth::is_configured`
- FILE: `includes/class-kmae-google-auth.php:125-126`
- SYMBOL: `KMAE_Google_Auth::is_configured`
- PURPOSE: Addig nem mutatjuk a gombot, amíg nincsenek meg a kulcsok.
- CALLED BY: `KMAE_Google_Auth::maybe_handle_request`
- CALLS: `KMAE_Google_Auth::client_id`, `KMAE_Google_Auth::client_secret`
- READS: —
- WRITES: —
- RELATED FEATURE: `GOOGLE-AUTH`

## `KMAE_Google_Auth::redirect_uri`
- FILE: `includes/class-kmae-google-auth.php:130-131`
- SYMBOL: `KMAE_Google_Auth::redirect_uri`
- PURPOSE: Ezt a címet kell beírni a Google Console „Redirect URI" mezőjébe.
- CALLED BY: `KMAE_Google_Auth::redirect_to_google`, `KMAE_Google_Auth::fetch_profile`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `GOOGLE-AUTH`

## `KMAE_Google_Auth::start_url`
- FILE: `includes/class-kmae-google-auth.php:144-151`
- SYMBOL: `KMAE_Google_Auth::start_url`
- PURPOSE: A gomb célcíme: innen megy a látogató a Google-höz.
- CALLED BY: —
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `GOOGLE-AUTH`

## `KMAE_Google_Auth::maybe_handle_request`
- FILE: `includes/class-kmae-google-auth.php:154-164`
- SYMBOL: `KMAE_Google_Auth::maybe_handle_request`
- PURPOSE: A gomb célcíme: innen megy a látogató a Google-höz.
- CALLED BY: `WP action `init``
- CALLS: `KMAE_Google_Auth::is_configured`, `KMAE_Google_Auth::redirect_to_google`, `KMAE_Google_Auth::handle_callback`
- READS: —
- WRITES: —
- RELATED FEATURE: `GOOGLE-AUTH`
- GET KEYS: `kmae_google`

## `KMAE_Google_Auth::redirect_to_google`
- FILE: `includes/class-kmae-google-auth.php:167-188`
- SYMBOL: `KMAE_Google_Auth::redirect_to_google`
- PURPOSE: A gomb célcíme: innen megy a látogató a Google-höz.
- CALLED BY: `KMAE_Google_Auth::maybe_handle_request`
- CALLS: `KMAE_Google_Auth::client_id`, `KMAE_Google_Auth::redirect_uri`
- READS: —
- WRITES: `transient:kmae_google_`
- RELATED FEATURE: `GOOGLE-AUTH`
- GET KEYS: `redirect_to`

## `KMAE_Google_Auth::handle_callback`
- FILE: `includes/class-kmae-google-auth.php:195-235`
- SYMBOL: `KMAE_Google_Auth::handle_callback`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Google_Auth::maybe_handle_request`
- CALLS: `KMAE_Auth::mark_email_verified`, `KMAE_Pages::url`, `KMAE_Google_Auth::fail`, `KMAE_Google_Auth::fetch_profile`, `KMAE_Google_Auth::resolve_user`
- READS: `transient:kmae_google_`
- WRITES: `transient:kmae_google_`
- RELATED FEATURE: `GOOGLE-AUTH`
- GET KEYS: `code`, `state`

## `KMAE_Google_Auth::fetch_profile`
- FILE: `includes/class-kmae-google-auth.php:244-285`
- SYMBOL: `KMAE_Google_Auth::fetch_profile`
- PURPOSE: A kódot kicseréljük a Google-nél, és kiolvassuk a fiók adatait.
- CALLED BY: `KMAE_Google_Auth::handle_callback`
- CALLS: `KMAE_Google_Auth::client_id`, `KMAE_Google_Auth::client_secret`, `KMAE_Google_Auth::redirect_uri`, `KMAE_Google_Auth::decode_id_token`
- READS: —
- WRITES: —
- RELATED FEATURE: `GOOGLE-AUTH`

## `KMAE_Google_Auth::decode_id_token`
- FILE: `includes/class-kmae-google-auth.php:296-305`
- SYMBOL: `KMAE_Google_Auth::decode_id_token`
- PURPOSE: Az azonosító jegy középső szelete hordozza az adatokat. Aláírást nem ellenőrzünk: a jegyet közvetlenül a Google-től kaptuk, HTTPS-en, a saját titkunkkal hitelesítve — nem a böngészőn keresztül érkezett.
- CALLED BY: `KMAE_Google_Auth::fetch_profile`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `GOOGLE-AUTH`

## `KMAE_Google_Auth::resolve_user`
- FILE: `includes/class-kmae-google-auth.php:314-362`
- SYMBOL: `KMAE_Google_Auth::resolve_user`
- PURPOSE: Meglévő fiók megkeresése, vagy új létrehozása.
- CALLED BY: `KMAE_Google_Auth::handle_callback`
- CALLS: `KMAE_Auth::ensure_subscriber_caps`, `KMAE_Google_Auth::store_given_name`, `KMAE_Google_Auth::unique_login`
- READS: —
- WRITES: —
- RELATED FEATURE: `GOOGLE-AUTH`

## `KMAE_Google_Auth::store_given_name`
- FILE: `includes/class-kmae-google-auth.php:372-382`
- SYMBOL: `KMAE_Google_Auth::store_given_name`
- PURPOSE: Keresztnév eltárolása. Ha a Google nem adott, a teljes név első szava marad — az még mindig jobb, mint a teljes név vagy az e-mail cím.
- CALLED BY: `KMAE_Google_Auth::resolve_user`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `GOOGLE-AUTH`

## `KMAE_Google_Auth::unique_login`
- FILE: `includes/class-kmae-google-auth.php:385-398`
- SYMBOL: `KMAE_Google_Auth::unique_login`
- PURPOSE: Keresztnév eltárolása. Ha a Google nem adott, a teljes név első szava marad — az még mindig jobb, mint a teljes név vagy az e-mail cím.
- CALLED BY: `KMAE_Google_Auth::resolve_user`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `GOOGLE-AUTH`

## `KMAE_Google_Auth::needs_completion`
- FILE: `includes/class-kmae-google-auth.php:405-406`
- SYMBOL: `KMAE_Google_Auth::needs_completion`
- PURPOSE: Keresztnév eltárolása. Ha a Google nem adott, a teljes név első szava marad — az még mindig jobb, mint a teljes név vagy az e-mail cím.
- CALLED BY: `KMAE_Google_Auth::enforce_completion`, `KMAE_Google_Auth::admin_user_column_value`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `GOOGLE-AUTH`

## `KMAE_Google_Auth::handle_complete`
- FILE: `includes/class-kmae-google-auth.php:409-496`
- SYMBOL: `KMAE_Google_Auth::handle_complete`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `WP action `admin_post_kmae_google_complete``
- CALLS: `KMAE_Pages::url`, `KMAE_Auth::normalize_phone`, `KMAE_Auth::account_types`, `KMAE_Counties::validate_listing_location`, `KMAE_Company::save_profile_fields`, `KMAE_Auth::sync_phone`, `KMAE_Auth::save_email_prefs`, `KMAE_Auth::mark_email_verified`
- READS: —
- WRITES: `usermeta:kmae_account_type`, `usermeta:kmae_phone`
- RELATED FEATURE: `GOOGLE-AUTH`
- POST KEYS: `kmae_account_type`, `kmae_company_address`, `kmae_company_city`, `kmae_company_county`, `kmae_company_name`, `kmae_google_nonce`, `kmae_phone`, `kmae_terms`

## `KMAE_Google_Auth::fail`
- FILE: `includes/class-kmae-google-auth.php:499-501`
- SYMBOL: `KMAE_Google_Auth::fail`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Google_Auth::handle_callback`
- CALLS: `KMAE_Pages::url`
- READS: —
- WRITES: —
- RELATED FEATURE: `GOOGLE-AUTH`

## `KMAE_Icons::render`
- FILE: `includes/class-kmae-icons.php:18-42`
- SYMBOL: `KMAE_Icons::render`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Public::render_rounds_modal`
- CALLS: `KMAE_Icons::paths`
- READS: —
- WRITES: —
- RELATED FEATURE: `BOOT-ARCHITECTURE`

## `KMAE_Icons::paths`
- FILE: `includes/class-kmae-icons.php:48-108`
- SYMBOL: `KMAE_Icons::paths`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Icons::render`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `BOOT-ARCHITECTURE`

## `KMAE_Images::init`
- FILE: `includes/class-kmae-images.php:20-27`
- SYMBOL: `KMAE_Images::init`
- PURPOSE: Feliratkozás a feltöltési folyamatra.
- CALLED BY: `KMAE_Plugin::run`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `PHOTO-MOTOR`

## `KMAE_Images::supports_webp`
- FILE: `includes/class-kmae-images.php:41-49`
- SYMBOL: `KMAE_Images::supports_webp`
- PURPOSE: A WordPress alapból minden nagy feltöltésből készít egy `-scaled` munkapéldányt, és MEGTARTJA mellette az érintetlen eredetit. Ezt a viselkedést kikapcsoljuk: így eredeti példány létre sem jön, nem csak
- CALLED BY: `KMAE_Images::process_attachment`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `PHOTO-MOTOR`

## `KMAE_Images::orientation_from_dimensions`
- FILE: `includes/class-kmae-images.php:52-65`
- SYMBOL: `KMAE_Images::orientation_from_dimensions`
- PURPOSE: A WordPress alapból minden nagy feltöltésből készít egy `-scaled` munkapéldányt, és MEGTARTJA mellette az érintetlen eredetit. Ezt a viselkedést kikapcsoljuk: így eredeti példány létre sem jön, nem csak
- CALLED BY: `KMAE_Images::get_orientation`, `KMAE_Images::process_attachment`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `PHOTO-MOTOR`

## `KMAE_Images::get_url`
- FILE: `includes/class-kmae-images.php:71-100`
- SYMBOL: `KMAE_Images::get_url`
- PURPOSE: Attachment URL with fallbacks when intermediate sizes are missing.
- CALLED BY: `KMAE_Dashboard::format_listing_row`, `KMAE_Query::get_listing_thumbnail_url`
- CALLS: `KMAE_Images::attachment_url_is_valid`
- READS: —
- WRITES: —
- RELATED FEATURE: `PHOTO-MOTOR`

## `KMAE_Images::responsive_attrs`
- FILE: `includes/class-kmae-images.php:117-131`
- SYMBOL: `KMAE_Images::responsive_attrs`
- PURPOSE: A reszponzív `srcset`/`sizes` attribútumok egy képhez.
- CALLED BY: —
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `PHOTO-MOTOR`

## `KMAE_Images::attachment_url_is_valid`
- FILE: `includes/class-kmae-images.php:134-149`
- SYMBOL: `KMAE_Images::attachment_url_is_valid`
- PURPOSE: A reszponzív `srcset`/`sizes` attribútumok egy képhez.
- CALLED BY: `KMAE_Images::get_url`
- CALLS: `KMAE_Images::attachment_url_exists`
- READS: —
- WRITES: —
- RELATED FEATURE: `PHOTO-MOTOR`

## `KMAE_Images::attachment_url_exists`
- FILE: `includes/class-kmae-images.php:152-161`
- SYMBOL: `KMAE_Images::attachment_url_exists`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Images::attachment_url_is_valid`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `PHOTO-MOTOR`

## `KMAE_Images::get_orientation`
- FILE: `includes/class-kmae-images.php:164-175`
- SYMBOL: `KMAE_Images::get_orientation`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: —
- CALLS: `KMAE_Images::orientation_from_dimensions`
- READS: `postmeta:_kmae_orientation`
- WRITES: —
- RELATED FEATURE: `PHOTO-MOTOR`

## `KMAE_Images::process_attachment`
- FILE: `includes/class-kmae-images.php:181-288`
- SYMBOL: `KMAE_Images::process_attachment`
- PURPOSE: Optimize uploaded image: resize, WebP, orientation meta.
- CALLED BY: `KMAE_Listings::handle_image_uploads`, `KMAE_Photo_Motor::handle_slot_uploads`
- CALLS: `KMAE_Images::orientation_from_dimensions`, `KMAE_Images::supports_webp`
- READS: —
- WRITES: `postmeta:_kmae_orientation`
- RELATED FEATURE: `PHOTO-MOTOR`

## `KMAE_Launch::mode`
- FILE: `includes/class-kmae-launch.php:18-19`
- SYMBOL: `KMAE_Launch::mode`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Launch::is_single_category`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `PAGES-ROUTING`, `VEHICLE`, `TAXONOMY-LAUNCH`

## `KMAE_Launch::category_slug`
- FILE: `includes/class-kmae-launch.php:22-23`
- SYMBOL: `KMAE_Launch::category_slug`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Launch::get_launch_category_id`, `KMAE_Launch::get_available_categories`, `KMAE_Launch::site_tagline`, `KMAE_Vehicle::is_vehicle_launch`, `KMAE_Query::get_listings`, `KMAE_Shortcodes::browse`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `PAGES-ROUTING`, `VEHICLE`, `TAXONOMY-LAUNCH`

## `KMAE_Launch::is_single_category`
- FILE: `includes/class-kmae-launch.php:26-27`
- SYMBOL: `KMAE_Launch::is_single_category`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Launch::should_skip_category_wizard`, `KMAE_Launch::get_available_categories`, `KMAE_Launch::site_tagline`, `KMAE_Vehicle::is_vehicle_launch`, `KMAE_Query::get_listings`
- CALLS: `KMAE_Launch::mode`
- READS: —
- WRITES: —
- RELATED FEATURE: `PAGES-ROUTING`, `VEHICLE`, `TAXONOMY-LAUNCH`

## `KMAE_Launch::should_skip_category_wizard`
- FILE: `includes/class-kmae-launch.php:30-31`
- SYMBOL: `KMAE_Launch::should_skip_category_wizard`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Launch::wizard_total_steps`, `KMAE_Shortcodes::browse`
- CALLS: `KMAE_Launch::is_single_category`
- READS: —
- WRITES: —
- RELATED FEATURE: `PAGES-ROUTING`, `VEHICLE`, `TAXONOMY-LAUNCH`

## `KMAE_Launch::get_launch_category_id`
- FILE: `includes/class-kmae-launch.php:34-36`
- SYMBOL: `KMAE_Launch::get_launch_category_id`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Vehicle::save_from_post`
- CALLS: `KMAE_Launch::category_slug`
- READS: —
- WRITES: —
- RELATED FEATURE: `PAGES-ROUTING`, `VEHICLE`, `TAXONOMY-LAUNCH`

## `KMAE_Launch::get_available_categories`
- FILE: `includes/class-kmae-launch.php:44-60`
- SYMBOL: `KMAE_Launch::get_available_categories`
- PURPOSE: Categories visible in forms and browse (filtered in single mode).
- CALLED BY: —
- CALLS: `KMAE_Taxonomies::seed_categories`, `KMAE_Launch::is_single_category`, `KMAE_Launch::category_slug`
- READS: —
- WRITES: —
- RELATED FEATURE: `PAGES-ROUTING`, `VEHICLE`, `TAXONOMY-LAUNCH`

## `KMAE_Launch::wizard_total_steps`
- FILE: `includes/class-kmae-launch.php:63-67`
- SYMBOL: `KMAE_Launch::wizard_total_steps`
- PURPOSE: Categories visible in forms and browse (filtered in single mode).
- CALLED BY: `KMAE_Launch::wizard_step_label`
- CALLS: `KMAE_Vehicle::is_vehicle_launch`, `KMAE_Launch::should_skip_category_wizard`
- READS: —
- WRITES: —
- RELATED FEATURE: `PAGES-ROUTING`, `VEHICLE`, `TAXONOMY-LAUNCH`

## `KMAE_Launch::wizard_step_label`
- FILE: `includes/class-kmae-launch.php:70-76`
- SYMBOL: `KMAE_Launch::wizard_step_label`
- PURPOSE: Categories visible in forms and browse (filtered in single mode).
- CALLED BY: —
- CALLS: `KMAE_Launch::wizard_total_steps`
- READS: —
- WRITES: —
- RELATED FEATURE: `PAGES-ROUTING`, `VEHICLE`, `TAXONOMY-LAUNCH`

## `KMAE_Launch::site_tagline`
- FILE: `includes/class-kmae-launch.php:79-83`
- SYMBOL: `KMAE_Launch::site_tagline`
- PURPOSE: Categories visible in forms and browse (filtered in single mode).
- CALLED BY: —
- CALLS: `KMAE_Launch::is_single_category`, `KMAE_Launch::category_slug`
- READS: —
- WRITES: —
- RELATED FEATURE: `PAGES-ROUTING`, `VEHICLE`, `TAXONOMY-LAUNCH`

## `KMAE_Listing_Drafts::init`
- FILE: `includes/class-kmae-listing-drafts.php:23-24`
- SYMBOL: `KMAE_Listing_Drafts::init`
- PURPOSE: Félbehagyott hirdetések (wizard automatikus mentése).
- CALLED BY: `KMAE_Plugin::run`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `LISTING-WIZARD-DRAFTS`

## `KMAE_Listing_Drafts::get_user_draft`
- FILE: `includes/class-kmae-listing-drafts.php:34-51`
- SYMBOL: `KMAE_Listing_Drafts::get_user_draft`
- PURPOSE: A felhasználó egy saját piszkozata, vagy null.
- CALLED BY: `KMAE_Listing_Drafts::ajax_save`, `KMAE_Listing_Drafts::discard_submitted`, `KMAE_Public::enqueue_listing_wizard`
- CALLS: —
- READS: `postmeta:_kmae_status`
- WRITES: —
- RELATED FEATURE: `LISTING-WIZARD-DRAFTS`

## `KMAE_Listing_Drafts::get_latest_draft`
- FILE: `includes/class-kmae-listing-drafts.php:60-79`
- SYMBOL: `KMAE_Listing_Drafts::get_latest_draft`
- PURPOSE: A legutóbb módosított piszkozat.
- CALLED BY: `KMAE_Public::enqueue_listing_wizard`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `LISTING-WIZARD-DRAFTS`

## `KMAE_Listing_Drafts::to_client`
- FILE: `includes/class-kmae-listing-drafts.php:88-101`
- SYMBOL: `KMAE_Listing_Drafts::to_client`
- PURPOSE: A wizardnak átadott adatcsomag.
- CALLED BY: `KMAE_Public::enqueue_listing_wizard`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `LISTING-WIZARD-DRAFTS`

## `KMAE_Listing_Drafts::ajax_save`
- FILE: `includes/class-kmae-listing-drafts.php:108-159`
- SYMBOL: `KMAE_Listing_Drafts::ajax_save`
- PURPOSE: Mentés AJAX-on (a wizard lépésváltáskor, mezőváltozáskor és az oldal elhagyásakor hívja).
- CALLED BY: `WP action `wp_ajax_kmae_save_listing_draft``
- CALLS: `KMAE_Listing_Drafts::get_user_draft`
- READS: —
- WRITES: `postmeta:_kmae_status`
- RELATED FEATURE: `LISTING-WIZARD-DRAFTS`
- POST KEYS: `draft_id`, `payload`, `title`

## `KMAE_Listing_Drafts::discard_submitted`
- FILE: `includes/class-kmae-listing-drafts.php:167-172`
- SYMBOL: `KMAE_Listing_Drafts::discard_submitted`
- PURPOSE: Sikeres feladás után a piszkozat törlődik, hogy ne legyen dupla hirdetés.
- CALLED BY: `KMAE_Public::process_create_listing`
- CALLS: `KMAE_Listing_Drafts::get_user_draft`
- READS: —
- WRITES: —
- RELATED FEATURE: `LISTING-WIZARD-DRAFTS`
- POST KEYS: `kmae_draft_id`

## `KMAE_Listing_Wizard::description_topics`
- FILE: `includes/class-kmae-listing-wizard.php:54-125`
- SYMBOL: `KMAE_Listing_Wizard::description_topics`
- PURPOSE: Az asszisztens szempontjai a hirdetés szövegéhez.
- CALLED BY: —
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `LISTING-WIZARD-DRAFTS`

## `KMAE_Listing_Wizard::assistant_intro`
- FILE: `includes/class-kmae-listing-wizard.php:137-166`
- SYMBOL: `KMAE_Listing_Wizard::assistant_intro`
- PURPOSE: Az asszisztens bemutatkozása a szövegíró lépésen.
- CALLED BY: `KMAE_Public::enqueue_listing_wizard`
- CALLS: `KMAE_Listing_Wizard::assist_inline_badge`
- READS: —
- WRITES: —
- RELATED FEATURE: `LISTING-WIZARD-DRAFTS`

## `KMAE_Listing_Wizard::assist_inline_badge`
- FILE: `includes/class-kmae-listing-wizard.php:177-187`
- SYMBOL: `KMAE_Listing_Wizard::assist_inline_badge`
- PURPOSE: Az asszisztens szövegébe ágyazott kis jelvény — pontosan úgy fest, mint a lenti hozzáadó/eltávolító gomb, hogy a mondat ne csak leírja, hanem meg is mutassa, melyik gombra gondol.
- CALLED BY: `KMAE_Listing_Wizard::assistant_intro`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `LISTING-WIZARD-DRAFTS`

## `KMAE_Listing_Wizard::assistant_reactions`
- FILE: `includes/class-kmae-listing-wizard.php:197-209`
- SYMBOL: `KMAE_Listing_Wizard::assistant_reactions`
- PURPOSE: Az asszisztens reakciói a hozzáadásokra, sorszám szerint: az első hozzáadásnál az 1-es, a másodiknál a 2-es szólal meg. Amelyik sorszámhoz nincs bejegyzés, ott nem szól bele — nem dicsér minden kattintásnál.
- CALLED BY: `KMAE_Public::enqueue_listing_wizard`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `LISTING-WIZARD-DRAFTS`

## `KMAE_Listing_Wizard::assistant_publish`
- FILE: `includes/class-kmae-listing-wizard.php:225-229`
- SYMBOL: `KMAE_Listing_Wizard::assistant_publish`
- PURPOSE: A feladás pillanatához tartozó dicséret. A fotók lépésén a „Tovább" helyett „Hirdetés feladása" áll — megnyomás után ez jelenik meg, és csak utána megy el a mentés, hogy a visszajelzés ne villanjon el.
- CALLED BY: `KMAE_Public::enqueue_listing_wizard`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `LISTING-WIZARD-DRAFTS`

## `KMAE_Listing_Wizard::assistant_done`
- FILE: `includes/class-kmae-listing-wizard.php:232-241`
- SYMBOL: `KMAE_Listing_Wizard::assistant_done`
- PURPOSE: A feladás pillanatához tartozó dicséret. A fotók lépésén a „Tovább" helyett „Hirdetés feladása" áll — megnyomás után ez jelenik meg, és csak utána megy el a mentés, hogy a visszajelzés ne villanjon el.
- CALLED BY: `KMAE_Public::enqueue_listing_wizard`
- CALLS: `KMAE_Listing_Wizard::greeting_name`
- READS: —
- WRITES: —
- RELATED FEATURE: `LISTING-WIZARD-DRAFTS`

## `KMAE_Listing_Wizard::greeting_name`
- FILE: `includes/class-kmae-listing-wizard.php:251-262`
- SYMBOL: `KMAE_Listing_Wizard::greeting_name`
- PURPOSE: A köszönésben használt név: a regisztrációkor megadott név, ahogy a „Szia, …!" köszönés is használja. Az első betűt mindig nagybetűre alakítjuk — akkor is, ha kisbetűvel regisztrált.
- CALLED BY: `KMAE_Listing_Wizard::assistant_done`
- CALLS: `KMAE_Dashboard::greeting_case`
- READS: —
- WRITES: —
- RELATED FEATURE: `LISTING-WIZARD-DRAFTS`

## `KMAE_Listing_Wizard::description_progress_messages`
- FILE: `includes/class-kmae-listing-wizard.php:271-278`
- SYMBOL: `KMAE_Listing_Wizard::description_progress_messages`
- PURPOSE: Bátorító mondat a kitöltöttség arányához. A cél nem a 100%, hanem hogy az eladó lássa: minden kitöltött szempont növeli az eladás esélyét.
- CALLED BY: `KMAE_Public::enqueue_listing_wizard`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `LISTING-WIZARD-DRAFTS`

## `KMAE_Listing_Wizard::phases`
- FILE: `includes/class-kmae-listing-wizard.php:281-313`
- SYMBOL: `KMAE_Listing_Wizard::phases`
- PURPOSE: Bátorító mondat a kitöltöttség arányához. A cél nem a 100%, hanem hogy az eladó lássa: minden kitöltött szempont növeli az eladás esélyét.
- CALLED BY: `KMAE_Public::enqueue_listing_wizard`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `LISTING-WIZARD-DRAFTS`

## `KMAE_Listings::init`
- FILE: `includes/class-kmae-listings.php:14-17`
- SYMBOL: `KMAE_Listings::init`
- PURPOSE: Delete listing and related data.
- CALLED BY: `KMAE_Plugin::run`
- CALLS: `KMAE_Activator::schedule_cron`
- READS: —
- WRITES: —
- RELATED FEATURE: `LISTINGS`, `PHOTO-MOTOR`, `DEAL`, `CRON-ARCHIVE`

## `KMAE_Listings::archive_on_deal`
- FILE: `includes/class-kmae-listings.php:23-24`
- SYMBOL: `KMAE_Listings::archive_on_deal`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: —
- CALLS: `KMAE_Deal::lock_on_accept`
- READS: —
- WRITES: —
- RELATED FEATURE: `LISTINGS`, `PHOTO-MOTOR`, `DEAL`, `CRON-ARCHIVE`

## `KMAE_Listings::get_archive_lifecycle`
- FILE: `includes/class-kmae-listings.php:32-69`
- SYMBOL: `KMAE_Listings::get_archive_lifecycle`
- PURPOSE: Lifecycle info for archived listings (null if not archived).
- CALLED BY: `KMAE_Listings::is_archive_locked`, `KMAE_Listings::can_reactivate_listing`
- CALLS: `KMAE_Meta::get_status`
- READS: `postmeta:_kmae_archived_at`
- WRITES: —
- RELATED FEATURE: `LISTINGS`, `PHOTO-MOTOR`, `DEAL`, `CRON-ARCHIVE`

## `KMAE_Listings::is_archive_locked`
- FILE: `includes/class-kmae-listings.php:72-74`
- SYMBOL: `KMAE_Listings::is_archive_locked`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Listings::can_edit_listing`
- CALLS: `KMAE_Listings::get_archive_lifecycle`
- READS: —
- WRITES: —
- RELATED FEATURE: `LISTINGS`, `PHOTO-MOTOR`, `DEAL`, `CRON-ARCHIVE`

## `KMAE_Listings::can_reactivate_listing`
- FILE: `includes/class-kmae-listings.php:77-79`
- SYMBOL: `KMAE_Listings::can_reactivate_listing`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Listings::can_edit_listing`, `KMAE_Listings::can_delete_listing`, `KMAE_Listings::reactivate_listing`
- CALLS: `KMAE_Listings::get_archive_lifecycle`
- READS: —
- WRITES: —
- RELATED FEATURE: `LISTINGS`, `PHOTO-MOTOR`, `DEAL`, `CRON-ARCHIVE`

## `KMAE_Listings::can_edit_listing`
- FILE: `includes/class-kmae-listings.php:82-84`
- SYMBOL: `KMAE_Listings::can_edit_listing`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Public::admin_update_listing`, `KMAE_Shortcodes::create_listing`
- CALLS: `KMAE_Meta::get_status`, `KMAE_Listings::is_archive_locked`, `KMAE_Listings::can_reactivate_listing`
- READS: —
- WRITES: —
- RELATED FEATURE: `LISTINGS`, `PHOTO-MOTOR`, `DEAL`, `CRON-ARCHIVE`

## `KMAE_Listings::can_delete_listing`
- FILE: `includes/class-kmae-listings.php:87-91`
- SYMBOL: `KMAE_Listings::can_delete_listing`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Public::admin_delete_listing`
- CALLS: `KMAE_Meta::get_status`, `KMAE_Listings::can_reactivate_listing`
- READS: —
- WRITES: —
- RELATED FEATURE: `LISTINGS`, `PHOTO-MOTOR`, `DEAL`, `CRON-ARCHIVE`

## `KMAE_Listings::reactivate_listing`
- FILE: `includes/class-kmae-listings.php:94-110`
- SYMBOL: `KMAE_Listings::reactivate_listing`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Public::admin_reactivate_listing`
- CALLS: `KMAE_Listings::user_owns_listing`, `KMAE_Listings::can_reactivate_listing`
- READS: —
- WRITES: `postmeta:_kmae_status`, `postmeta:_kmae_archived_at`, `postmeta:_kmae_accepted_offer_id`, `postmeta:_kmae_reactivated_at`
- RELATED FEATURE: `LISTINGS`, `PHOTO-MOTOR`, `DEAL`, `CRON-ARCHIVE`
- EMITS: `kmae_listing_published`

## `KMAE_Listings::purge_expired_archived`
- FILE: `includes/class-kmae-listings.php:116-147`
- SYMBOL: `KMAE_Listings::purge_expired_archived`
- PURPOSE: Daily cron: delete archived listings past the reactivation window.
- CALLED BY: `WP action `kmae_purge_archived_listings``
- CALLS: `KMAE_Listings::delete_listing`
- READS: —
- WRITES: —
- RELATED FEATURE: `LISTINGS`, `PHOTO-MOTOR`, `DEAL`, `CRON-ARCHIVE`

## `KMAE_Listings::user_owns_listing`
- FILE: `includes/class-kmae-listings.php:150-152`
- SYMBOL: `KMAE_Listings::user_owns_listing`
- PURPOSE: Daily cron: delete archived listings past the reactivation window.
- CALLED BY: `KMAE_Listings::reactivate_listing`, `KMAE_Listings::delete_listing`, `KMAE_Public::admin_update_listing`, `KMAE_Shortcodes::create_listing`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `LISTINGS`, `PHOTO-MOTOR`, `DEAL`, `CRON-ARCHIVE`

## `KMAE_Listings::activate_if_photos_ready`
- FILE: `includes/class-kmae-listings.php:161-179`
- SYMBOL: `KMAE_Listings::activate_if_photos_ready`
- PURPOSE: Activate listing when required vehicle photos are complete.
- CALLED BY: `KMAE_Public::admin_update_listing`
- CALLS: `KMAE_Photo_Motor::is_enabled`, `KMAE_Photo_Motor::count_required_filled`, `KMAE_Photo_Motor::required_count`, `KMAE_Meta::get_status`
- READS: `postmeta:_kmae_published_at`
- WRITES: `postmeta:_kmae_status`, `postmeta:_kmae_published_at`
- RELATED FEATURE: `LISTINGS`, `PHOTO-MOTOR`, `DEAL`, `CRON-ARCHIVE`
- EMITS: `kmae_listing_published`

## `KMAE_Listings::save_meta_from_post`
- FILE: `includes/class-kmae-listings.php:182-223`
- SYMBOL: `KMAE_Listings::save_meta_from_post`
- PURPOSE: Activate listing when required vehicle photos are complete.
- CALLED BY: `KMAE_Public::admin_update_listing`, `KMAE_Public::process_create_listing`
- CALLS: `KMAE_Auth::is_company`, `KMAE_Company::apply_listing_location`, `KMAE_Counties::validate_listing_location`, `KMAE_Counties::save_listing_location`, `KMAE_Vehicle::save_from_post`, `KMAE_Taxonomies::default_offer_types`, `KMAE_Seller::save_from_post`
- READS: —
- WRITES: `postmeta:_kmae_condition`, `postmeta:_kmae_status`, `postmeta:_kmae_published_at`, `postmeta:_kmae_offer_types`, `postmeta:_kmae_trade_in_categories`
- RELATED FEATURE: `LISTINGS`, `PHOTO-MOTOR`, `DEAL`, `CRON-ARCHIVE`
- POST KEYS: `kmae_category`, `kmae_city`, `kmae_condition`, `kmae_county`

## `KMAE_Listings::handle_image_uploads`
- FILE: `includes/class-kmae-listings.php:226-327`
- SYMBOL: `KMAE_Listings::handle_image_uploads`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Public::admin_update_listing`, `KMAE_Public::process_create_listing`
- CALLS: `KMAE_Photo_Motor::is_enabled`, `KMAE_Photo_Motor::handle_slot_uploads`, `KMAE_Photo_Motor::analyze_file`, `KMAE_Photo_Motor::autocorrect_file`, `KMAE_Photo_Motor::analysis_record`, `KMAE_Images::process_attachment`
- READS: —
- WRITES: `postmeta:_kmae_gallery`
- RELATED FEATURE: `LISTINGS`, `PHOTO-MOTOR`, `DEAL`, `CRON-ARCHIVE`

## `KMAE_Listings::apply_gallery_edits`
- FILE: `includes/class-kmae-listings.php:333-373`
- SYMBOL: `KMAE_Listings::apply_gallery_edits`
- PURPOSE: Apply reorder / delete from edit form before new uploads.
- CALLED BY: `KMAE_Public::admin_update_listing`
- CALLS: `KMAE_Listings::attachment_belongs_to_listing`
- READS: —
- WRITES: `postmeta:_kmae_gallery`
- RELATED FEATURE: `LISTINGS`, `PHOTO-MOTOR`, `DEAL`, `CRON-ARCHIVE`
- POST KEYS: `kmae_gallery_order`, `kmae_remove_images`

## `KMAE_Listings::attachment_belongs_to_listing`
- FILE: `includes/class-kmae-listings.php:376-380`
- SYMBOL: `KMAE_Listings::attachment_belongs_to_listing`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Listings::apply_gallery_edits`, `KMAE_Listings::delete_listing_attachments`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `LISTINGS`, `PHOTO-MOTOR`, `DEAL`, `CRON-ARCHIVE`

## `KMAE_Listings::collect_listing_attachment_ids`
- FILE: `includes/class-kmae-listings.php:383-430`
- SYMBOL: `KMAE_Listings::collect_listing_attachment_ids`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Listings::delete_listing_attachments`
- CALLS: `KMAE_Database::table`
- READS: `postmeta:_kmae_gallery`, `table:offer_images`, `wpdb:get_col`
- WRITES: —
- RELATED FEATURE: `LISTINGS`, `PHOTO-MOTOR`, `DEAL`, `CRON-ARCHIVE`

## `KMAE_Listings::delete_listing_attachments`
- FILE: `includes/class-kmae-listings.php:433-438`
- SYMBOL: `KMAE_Listings::delete_listing_attachments`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Listings::force_delete_listing`
- CALLS: `KMAE_Listings::collect_listing_attachment_ids`, `KMAE_Listings::attachment_belongs_to_listing`
- READS: —
- WRITES: —
- RELATED FEATURE: `LISTINGS`, `PHOTO-MOTOR`, `DEAL`, `CRON-ARCHIVE`

## `KMAE_Listings::delete_listing`
- FILE: `includes/class-kmae-listings.php:441-446`
- SYMBOL: `KMAE_Listings::delete_listing`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Listings::purge_expired_archived`, `KMAE_Public::admin_delete_listing`
- CALLS: `KMAE_Listings::user_owns_listing`, `KMAE_Listings::force_delete_listing`
- READS: —
- WRITES: —
- RELATED FEATURE: `LISTINGS`, `PHOTO-MOTOR`, `DEAL`, `CRON-ARCHIVE`

## `KMAE_Listings::force_delete_listing`
- FILE: `includes/class-kmae-listings.php:452-478`
- SYMBOL: `KMAE_Listings::force_delete_listing`
- PURPOSE: Delete listing and related data (admin or owner after permission check).
- CALLED BY: `KMAE_Admin::handle_delete_listing`, `KMAE_Admin::handle_listing_bulk_actions`, `KMAE_Listings::delete_listing`
- CALLS: `KMAE_Database::get_offers_for_listing`, `KMAE_Notifications::on_listing_deleted`, `KMAE_Database::table`, `KMAE_Listings::delete_listing_attachments`
- READS: `table:counter_offers`, `table:offer_images`, `table:contact_unlocks`, `table:offers`, `table:private_data`
- WRITES: `wpdb:delete`
- RELATED FEATURE: `LISTINGS`, `PHOTO-MOTOR`, `DEAL`, `CRON-ARCHIVE`

## `KMAE_Live_Page::get_fingerprint`
- FILE: `includes/class-kmae-live-page.php:17-78`
- SYMBOL: `KMAE_Live_Page::get_fingerprint`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Public::ajax_poll_page`
- CALLS: `KMAE_Database::get_offer`, `KMAE_Database::get_counter_offers`, `KMAE_Database::count_unseen_offer_activity`, `KMAE_Database::get_offers_by_user`, `KMAE_Database::get_offers_received_by_user`, `KMAE_Database::count_offers_for_listing`, `KMAE_Database::get_offers_for_listing`, `KMAE_Database::get_active_user_offer_for_listing`, `KMAE_Database::get_withdrawn_user_offer_for_listing`, `KMAE_Meta::get_status`
- READS: —
- WRITES: —
- RELATED FEATURE: `LIVE-NAV`

## `KMAE_Meta::status_labels`
- FILE: `includes/class-kmae-meta.php:25-31`
- SYMBOL: `KMAE_Meta::status_labels`
- PURPOSE: User-facing status labels (seller UI).
- CALLED BY: `KMAE_Dashboard::format_listing_row`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `LISTINGS`, `ADMIN`

## `KMAE_Meta::is_publicly_visible`
- FILE: `includes/class-kmae-meta.php:40-41`
- SYMBOL: `KMAE_Meta::is_publicly_visible`
- PURPOSE: Whether buyers can see the listing in browse / public single.
- CALLED BY: —
- CALLS: `KMAE_Meta::get_status`
- READS: —
- WRITES: —
- RELATED FEATURE: `LISTINGS`, `ADMIN`

## `KMAE_Meta::__construct`
- FILE: `includes/class-kmae-meta.php:44-46`
- SYMBOL: `KMAE_Meta::__construct`
- PURPOSE: Whether buyers can see the listing in browse / public single.
- CALLED BY: —
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `LISTINGS`, `ADMIN`

## `KMAE_Meta::add_meta_boxes`
- FILE: `includes/class-kmae-meta.php:49-57`
- SYMBOL: `KMAE_Meta::add_meta_boxes`
- PURPOSE: Whether buyers can see the listing in browse / public single.
- CALLED BY: `WP action `add_meta_boxes``
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `LISTINGS`, `ADMIN`

## `KMAE_Meta::render_meta_box`
- FILE: `includes/class-kmae-meta.php:60-73`
- SYMBOL: `KMAE_Meta::render_meta_box`
- PURPOSE: Whether buyers can see the listing in browse / public single.
- CALLED BY: —
- CALLS: `KMAE_Database::get_private_data`, `KMAE_Taxonomies::offer_type_labels`, `KMAE_Meta::get_offer_types`
- READS: `postmeta:_kmae_county`, `postmeta:_kmae_city`, `postmeta:_kmae_location`, `postmeta:_kmae_condition`, `postmeta:_kmae_status`
- WRITES: —
- RELATED FEATURE: `LISTINGS`, `ADMIN`

## `KMAE_Meta::save_listing_meta`
- FILE: `includes/class-kmae-meta.php:76-118`
- SYMBOL: `KMAE_Meta::save_listing_meta`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `WP action `save_post_kmae_listing``
- CALLS: `KMAE_Counties::validate_listing_location`, `KMAE_Counties::save_listing_location`, `KMAE_Taxonomies::default_offer_types`, `KMAE_Seller::get_price_mode`, `KMAE_Database::save_private_data`, `KMAE_Vehicle::save_from_post`
- READS: `postmeta:_kmae_published_at`
- WRITES: `postmeta:_kmae_location`, `postmeta:_kmae_condition`, `postmeta:_kmae_status`, `postmeta:_kmae_offer_types`, `postmeta:_kmae_trade_in_categories`, `postmeta:_kmae_published_at`
- RELATED FEATURE: `LISTINGS`, `ADMIN`
- POST KEYS: `kmae_city`, `kmae_condition`, `kmae_county`, `kmae_listing_nonce`, `kmae_location`, `kmae_minimum_cash`, `kmae_status`

## `KMAE_Meta::get_status`
- FILE: `includes/class-kmae-meta.php:121-122`
- SYMBOL: `KMAE_Meta::get_status`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Admin::listing_column_content`, `KMAE_Admin::listing_row_actions`, `KMAE_Listings::get_archive_lifecycle`, `KMAE_Listings::can_edit_listing`, `KMAE_Listings::can_delete_listing`, `KMAE_Listings::activate_if_photos_ready`, `KMAE_Dashboard::maybe_track_listing_view`, `KMAE_Dashboard::get_data`, `KMAE_Dashboard::format_listing_row`, `KMAE_Offers::submit_cash_offer`, `KMAE_Trust::resolve_rated_party`, `KMAE_Deal::lock_on_accept`, `KMAE_Deal::is_locked`, `KMAE_Meta::is_publicly_visible`, `KMAE_Live_Page::get_fingerprint` +3 more
- CALLS: —
- READS: `postmeta:_kmae_status`
- WRITES: —
- RELATED FEATURE: `LISTINGS`, `ADMIN`

## `KMAE_Meta::get_offer_types`
- FILE: `includes/class-kmae-meta.php:125-127`
- SYMBOL: `KMAE_Meta::get_offer_types`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Admin::listing_column_content`, `KMAE_Seller::save_from_post`, `KMAE_Meta::render_meta_box`, `KMAE_Meta::accepts_offer_type`, `KMAE_Browse::listing_matches_wizard`
- CALLS: `KMAE_Taxonomies::default_offer_types`
- READS: —
- WRITES: —
- RELATED FEATURE: `LISTINGS`, `ADMIN`

## `KMAE_Meta::accepts_offer_type`
- FILE: `includes/class-kmae-meta.php:130-131`
- SYMBOL: `KMAE_Meta::accepts_offer_type`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Offers::submit_cash_offer`
- CALLS: `KMAE_Meta::get_offer_types`
- READS: —
- WRITES: —
- RELATED FEATURE: `LISTINGS`, `ADMIN`

## `KMAE_Moderation::is_enabled`
- FILE: `includes/class-kmae-moderation.php:17-21`
- SYMBOL: `KMAE_Moderation::is_enabled`
- PURPOSE: Automated listing moderation (rule-based, no external AI).
- CALLED BY: `KMAE_Moderation::validate`, `KMAE_Public::enqueue_listing_wizard`, `KMAE_Public::admin_update_listing`
- CALLS: —
- READS: `option:kmae_auto_moderation`
- WRITES: —
- RELATED FEATURE: `MODERATION`

## `KMAE_Moderation::validate`
- FILE: `includes/class-kmae-moderation.php:32-81`
- SYMBOL: `KMAE_Moderation::validate`
- PURPOSE: Validate listing before publish. Returns WP_Error on failure.
- CALLED BY: `KMAE_Public::admin_update_listing`, `KMAE_Public::process_create_listing`
- CALLS: `KMAE_Vehicle::is_vehicle_launch`, `KMAE_Vehicle::get_missing_required`, `KMAE_Photo_Motor::is_enabled`, `KMAE_Photo_Motor::required_count`, `KMAE_Moderation::is_enabled`, `KMAE_Moderation::contains_contact_info`
- READS: —
- WRITES: —
- RELATED FEATURE: `MODERATION`

## `KMAE_Moderation::contains_contact_info`
- FILE: `includes/class-kmae-moderation.php:84-95`
- SYMBOL: `KMAE_Moderation::contains_contact_info`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Moderation::validate`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `MODERATION`

## `KMAE_Moderation::count_uploaded_images`
- FILE: `includes/class-kmae-moderation.php:98-115`
- SYMBOL: `KMAE_Moderation::count_uploaded_images`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Public::admin_update_listing`, `KMAE_Public::process_create_listing`
- CALLS: `KMAE_Photo_Motor::is_enabled`, `KMAE_Photo_Motor::count_required_uploads`
- READS: —
- WRITES: —
- RELATED FEATURE: `MODERATION`

## `KMAE_Moderation::stash_errors_for_user`
- FILE: `includes/class-kmae-moderation.php:121-122`
- SYMBOL: `KMAE_Moderation::stash_errors_for_user`
- PURPOSE: Store rejection reasons in transient for display on form.
- CALLED BY: `KMAE_Public::admin_update_listing`, `KMAE_Public::process_create_listing`
- CALLS: —
- READS: —
- WRITES: `transient:kmae_mod_errors_`
- RELATED FEATURE: `MODERATION`

## `KMAE_Moderation::pull_errors_for_user`
- FILE: `includes/class-kmae-moderation.php:125-129`
- SYMBOL: `KMAE_Moderation::pull_errors_for_user`
- PURPOSE: Store rejection reasons in transient for display on form.
- CALLED BY: —
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `MODERATION`

## `KMAE_Nav::__construct`
- FILE: `includes/class-kmae-nav.php:15-20`
- SYMBOL: `KMAE_Nav::__construct`
- PURPOSE: Dynamic nav: login/register when logged out, logout when logged in.
- CALLED BY: —
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `LIVE-NAV`

## `KMAE_Nav::enqueue_assets`
- FILE: `includes/class-kmae-nav.php:23-39`
- SYMBOL: `KMAE_Nav::enqueue_assets`
- PURPOSE: Dynamic nav: login/register when logged out, logout when logged in.
- CALLED BY: `WP action `wp_enqueue_scripts``
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `LIVE-NAV`

## `KMAE_Nav::inline_nav_css`
- FILE: `includes/class-kmae-nav.php:42-88`
- SYMBOL: `KMAE_Nav::inline_nav_css`
- PURPOSE: Dynamic nav: login/register when logged out, logout when logged in.
- CALLED BY: `WP action `wp_head``
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `LIVE-NAV`

## `KMAE_Nav::filter_menu_items`
- FILE: `includes/class-kmae-nav.php:90-124`
- SYMBOL: `KMAE_Nav::filter_menu_items`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `WP filter `wp_nav_menu_objects``, `WP filter `wp_get_nav_menu_items``
- CALLS: `KMAE_Nav::is_login_item`, `KMAE_Nav::is_register_item`, `KMAE_Nav::is_logout_item`
- READS: —
- WRITES: —
- RELATED FEATURE: `LIVE-NAV`

## `KMAE_Nav::filter_navigation_block`
- FILE: `includes/class-kmae-nav.php:127-145`
- SYMBOL: `KMAE_Nav::filter_navigation_block`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `WP filter `render_block``
- CALLS: `KMAE_Nav::url_is_auth`, `KMAE_Nav::label_is_auth`
- READS: —
- WRITES: —
- RELATED FEATURE: `LIVE-NAV`

## `KMAE_Nav::is_login_item`
- FILE: `includes/class-kmae-nav.php:148-151`
- SYMBOL: `KMAE_Nav::is_login_item`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Nav::filter_menu_items`
- CALLS: `KMAE_Nav::url_is_auth`, `KMAE_Nav::label_is_auth`
- READS: —
- WRITES: —
- RELATED FEATURE: `LIVE-NAV`

## `KMAE_Nav::is_register_item`
- FILE: `includes/class-kmae-nav.php:154-157`
- SYMBOL: `KMAE_Nav::is_register_item`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Nav::filter_menu_items`
- CALLS: `KMAE_Nav::url_is_auth`, `KMAE_Nav::label_is_auth`
- READS: —
- WRITES: —
- RELATED FEATURE: `LIVE-NAV`

## `KMAE_Nav::is_logout_item`
- FILE: `includes/class-kmae-nav.php:160-163`
- SYMBOL: `KMAE_Nav::is_logout_item`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Nav::filter_menu_items`
- CALLS: `KMAE_Nav::label_is_auth`
- READS: —
- WRITES: —
- RELATED FEATURE: `LIVE-NAV`

## `KMAE_Nav::url_is_auth`
- FILE: `includes/class-kmae-nav.php:166-174`
- SYMBOL: `KMAE_Nav::url_is_auth`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Nav::filter_navigation_block`, `KMAE_Nav::is_login_item`, `KMAE_Nav::is_register_item`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `LIVE-NAV`

## `KMAE_Nav::label_is_auth`
- FILE: `includes/class-kmae-nav.php:177-189`
- SYMBOL: `KMAE_Nav::label_is_auth`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Nav::filter_navigation_block`, `KMAE_Nav::is_login_item`, `KMAE_Nav::is_register_item`, `KMAE_Nav::is_logout_item`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `LIVE-NAV`

## `KMAE_Nav::create_logout_item`
- FILE: `includes/class-kmae-nav.php:192-215`
- SYMBOL: `KMAE_Nav::create_logout_item`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: —
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `LIVE-NAV`

## `KMAE_Notifications::init`
- FILE: `includes/class-kmae-notifications.php:14-23`
- SYMBOL: `KMAE_Notifications::init`
- PURPOSE: Email notifications.
- CALLED BY: `KMAE_Plugin::run`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `NOTIFICATIONS`, `TRUST-RATINGS`

## `KMAE_Notifications::on_new_offer`
- FILE: `includes/class-kmae-notifications.php:26-60`
- SYMBOL: `KMAE_Notifications::on_new_offer`
- PURPOSE: Email notifications.
- CALLED BY: `WP action `kmae_new_offer``
- CALLS: `KMAE_Database::get_offer`, `KMAE_Brand::email_mascot_url`, `KMAE_Pages::offer_thread_url`, `KMAE_Notifications::send_offer_email`
- READS: —
- WRITES: —
- RELATED FEATURE: `NOTIFICATIONS`, `TRUST-RATINGS`

## `KMAE_Notifications::on_counter_offer`
- FILE: `includes/class-kmae-notifications.php:63-97`
- SYMBOL: `KMAE_Notifications::on_counter_offer`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `WP action `kmae_new_counter_offer``
- CALLS: `KMAE_Database::get_offer`, `KMAE_Database::get_counter_offer`, `KMAE_Brand::email_mascot_url`, `KMAE_Pages::offer_thread_url`, `KMAE_Notifications::send_offer_email`
- READS: —
- WRITES: —
- RELATED FEATURE: `NOTIFICATIONS`, `TRUST-RATINGS`

## `KMAE_Notifications::on_buyer_revision`
- FILE: `includes/class-kmae-notifications.php:100-127`
- SYMBOL: `KMAE_Notifications::on_buyer_revision`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `WP action `kmae_buyer_revised_offer``
- CALLS: `KMAE_Database::get_offer`, `KMAE_Brand::email_mascot_url`, `KMAE_Pages::offer_thread_url`, `KMAE_Notifications::send_offer_email`
- READS: —
- WRITES: —
- RELATED FEATURE: `NOTIFICATIONS`, `TRUST-RATINGS`

## `KMAE_Notifications::on_offer_accepted`
- FILE: `includes/class-kmae-notifications.php:130-153`
- SYMBOL: `KMAE_Notifications::on_offer_accepted`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `WP action `kmae_offer_accepted``
- CALLS: `KMAE_Database::get_offer`, `KMAE_Brand::email_mascot_url`, `KMAE_Pages::offer_thread_url`, `KMAE_Contact::get_contact_details`, `KMAE_Notifications::send_viewing_deal_email`
- READS: —
- WRITES: —
- RELATED FEATURE: `NOTIFICATIONS`, `TRUST-RATINGS`

## `KMAE_Notifications::on_deal_locked`
- FILE: `includes/class-kmae-notifications.php:162-207`
- SYMBOL: `KMAE_Notifications::on_deal_locked`
- PURPOSE: Soft-hold mail to other pending interest after Áll az alku.
- CALLED BY: `WP action `kmae_deal_locked``
- CALLS: `KMAE_Database::get_offer`, `KMAE_Database::get_offers_for_listing`, `KMAE_Brand::email_mascot_url`, `KMAE_Pages::offer_thread_url`, `KMAE_Auth::is_company`, `KMAE_Notifications::send_offer_email`, `KMAE_Notifications::notify_buyer_other_sellers_hold`
- READS: —
- WRITES: —
- RELATED FEATURE: `NOTIFICATIONS`, `TRUST-RATINGS`

## `KMAE_Notifications::notify_buyer_other_sellers_hold`
- FILE: `includes/class-kmae-notifications.php:216-247`
- SYMBOL: `KMAE_Notifications::notify_buyer_other_sellers_hold`
- PURPOSE: Company buyer locked one car — tell other pending sellers they may become moot.
- CALLED BY: `KMAE_Notifications::on_deal_locked`
- CALLS: `KMAE_Deal::get_buyer_other_pending_offers`, `KMAE_Brand::email_mascot_url`, `KMAE_Pages::offer_thread_url`, `KMAE_Notifications::send_offer_email`
- READS: —
- WRITES: —
- RELATED FEATURE: `NOTIFICATIONS`, `TRUST-RATINGS`

## `KMAE_Notifications::on_deal_failed`
- FILE: `includes/class-kmae-notifications.php:257-341`
- SYMBOL: `KMAE_Notifications::on_deal_failed`
- PURPOSE: Viewing failed — notify other pending buyers.
- CALLED BY: `WP action `kmae_deal_failed``
- CALLS: `KMAE_Database::get_offer`, `KMAE_Brand::email_mascot_url`, `KMAE_Pages::offer_thread_url`, `KMAE_Database::get_offers_for_listing`, `KMAE_Auth::is_company`, `KMAE_Notifications::send_offer_email`, `KMAE_Notifications::notify_buyer_other_sellers_resume`
- READS: —
- WRITES: —
- RELATED FEATURE: `NOTIFICATIONS`, `TRUST-RATINGS`

## `KMAE_Notifications::notify_buyer_other_sellers_resume`
- FILE: `includes/class-kmae-notifications.php:350-381`
- SYMBOL: `KMAE_Notifications::notify_buyer_other_sellers_resume`
- PURPOSE: After failed viewing: company buyer's other pending sellers can continue.
- CALLED BY: `KMAE_Notifications::on_deal_failed`
- CALLS: `KMAE_Deal::get_buyer_other_pending_offers`, `KMAE_Brand::email_mascot_url`, `KMAE_Pages::offer_thread_url`, `KMAE_Notifications::send_offer_email`
- READS: —
- WRITES: —
- RELATED FEATURE: `NOTIFICATIONS`, `TRUST-RATINGS`

## `KMAE_Notifications::send_viewing_deal_email`
- FILE: `includes/class-kmae-notifications.php:392-420`
- SYMBOL: `KMAE_Notifications::send_viewing_deal_email`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Notifications::on_offer_accepted`
- CALLS: `KMAE_Notifications::send_offer_email`
- READS: —
- WRITES: —
- RELATED FEATURE: `NOTIFICATIONS`, `TRUST-RATINGS`

## `KMAE_Notifications::on_offer_rejected`
- FILE: `includes/class-kmae-notifications.php:423-454`
- SYMBOL: `KMAE_Notifications::on_offer_rejected`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `WP action `kmae_offer_rejected``
- CALLS: `KMAE_Database::get_offer`, `KMAE_Brand::email_mascot_url`, `KMAE_Notifications::send_offer_email`
- READS: —
- WRITES: —
- RELATED FEATURE: `NOTIFICATIONS`, `TRUST-RATINGS`

## `KMAE_Notifications::on_offer_withdrawn`
- FILE: `includes/class-kmae-notifications.php:457-490`
- SYMBOL: `KMAE_Notifications::on_offer_withdrawn`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `WP action `kmae_offer_withdrawn``
- CALLS: `KMAE_Database::get_offer`, `KMAE_Offers::get_offerer_display_name`, `KMAE_Brand::email_mascot_url`, `KMAE_Notifications::send_offer_email`
- READS: —
- WRITES: —
- RELATED FEATURE: `NOTIFICATIONS`, `TRUST-RATINGS`

## `KMAE_Notifications::on_listing_deleted`
- FILE: `includes/class-kmae-notifications.php:498-536`
- SYMBOL: `KMAE_Notifications::on_listing_deleted`
- PURPOSE: Notify everyone who sent an offer before the listing is removed.
- CALLED BY: `KMAE_Listings::force_delete_listing`
- CALLS: `KMAE_Brand::email_mascot_url`, `KMAE_Notifications::send_offer_email`
- READS: —
- WRITES: —
- RELATED FEATURE: `NOTIFICATIONS`, `TRUST-RATINGS`

## `KMAE_Notifications::send_deal_email`
- FILE: `includes/class-kmae-notifications.php:539-562`
- SYMBOL: `KMAE_Notifications::send_deal_email`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: —
- CALLS: `KMAE_Notifications::send_offer_email`
- READS: —
- WRITES: —
- RELATED FEATURE: `NOTIFICATIONS`, `TRUST-RATINGS`

## `KMAE_Notifications::listing_closed`
- FILE: `includes/class-kmae-notifications.php:565-600`
- SYMBOL: `KMAE_Notifications::listing_closed`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Deal::confirm_success`
- CALLS: `KMAE_Database::get_offers_for_listing`, `KMAE_Brand::email_mascot_url`, `KMAE_Notifications::send_offer_email`
- READS: —
- WRITES: —
- RELATED FEATURE: `NOTIFICATIONS`, `TRUST-RATINGS`

## `KMAE_Notifications::request_rating`
- FILE: `includes/class-kmae-notifications.php:610-634`
- SYMBOL: `KMAE_Notifications::request_rating`
- PURPOSE: Ask user to rate the other party after a successful deal.
- CALLED BY: `KMAE_Trust::on_deal_success`
- CALLS: `KMAE_Trust::rate_url`, `KMAE_Brand::email_mascot_url`, `KMAE_Notifications::send_offer_email`
- READS: —
- WRITES: —
- RELATED FEATURE: `NOTIFICATIONS`, `TRUST-RATINGS`

## `KMAE_Notifications::buyer_found_other_car`
- FILE: `includes/class-kmae-notifications.php:642-671`
- SYMBOL: `KMAE_Notifications::buyer_found_other_car`
- PURPOSE: Buyer bought another car — notify seller on withdrawn talks.
- CALLED BY: `KMAE_Deal::stop_shopping`
- CALLS: `KMAE_Database::get_offer`, `KMAE_Brand::email_mascot_url`, `KMAE_Notifications::send_offer_email`
- READS: —
- WRITES: —
- RELATED FEATURE: `NOTIFICATIONS`, `TRUST-RATINGS`

## `KMAE_Notifications::send_offer_email`
- FILE: `includes/class-kmae-notifications.php:674-691`
- SYMBOL: `KMAE_Notifications::send_offer_email`
- PURPOSE: Buyer bought another car — notify seller on withdrawn talks.
- CALLED BY: `KMAE_Notifications::on_new_offer`, `KMAE_Notifications::on_counter_offer`, `KMAE_Notifications::on_buyer_revision`, `KMAE_Notifications::on_deal_locked`, `KMAE_Notifications::notify_buyer_other_sellers_hold`, `KMAE_Notifications::on_deal_failed`, `KMAE_Notifications::notify_buyer_other_sellers_resume`, `KMAE_Notifications::send_viewing_deal_email`, `KMAE_Notifications::on_offer_rejected`, `KMAE_Notifications::on_offer_withdrawn`, `KMAE_Notifications::on_listing_deleted`, `KMAE_Notifications::send_deal_email`, `KMAE_Notifications::listing_closed`, `KMAE_Notifications::request_rating`, `KMAE_Notifications::buyer_found_other_car`
- CALLS: `KMAE_Auth::wants_offer_emails`, `KMAE_Auth::first_name`, `KMAE_Brand::send_mail`
- READS: —
- WRITES: —
- RELATED FEATURE: `NOTIFICATIONS`, `TRUST-RATINGS`

## `KMAE_Offers::guard_new_offer`
- FILE: `includes/class-kmae-offers.php:26-41`
- SYMBOL: `KMAE_Offers::guard_new_offer`
- PURPOSE: Guard before submitting a new offer on a listing.
- CALLED BY: `KMAE_Offers::submit_cash_offer`
- CALLS: `KMAE_Database::get_withdrawn_user_offer_for_listing`, `KMAE_Database::get_active_user_offer_for_listing`
- READS: —
- WRITES: —
- RELATED FEATURE: `OFFERS`, `NOTIFICATIONS`

## `KMAE_Offers::require_fair_buyer_pledge`
- FILE: `includes/class-kmae-offers.php:50-61`
- SYMBOL: `KMAE_Offers::require_fair_buyer_pledge`
- PURPOSE: Private buyers must accept the fair-buyer pledge when offering.
- CALLED BY: `KMAE_Offers::submit_cash_offer`
- CALLS: `KMAE_Auth::is_private_person`
- READS: —
- WRITES: `usermeta:kmae_fair_buyer_pledge`
- RELATED FEATURE: `OFFERS`, `NOTIFICATIONS`
- POST KEYS: `kmae_fair_buyer`

## `KMAE_Offers::submit_cash_offer`
- FILE: `includes/class-kmae-offers.php:64-139`
- SYMBOL: `KMAE_Offers::submit_cash_offer`
- PURPOSE: Private buyers must accept the fair-buyer pledge when offering.
- CALLED BY: `KMAE_Public::process_cash_offer`
- CALLS: `KMAE_Meta::get_status`, `KMAE_Meta::accepts_offer_type`, `KMAE_Database::get_private_data`, `KMAE_Seller::is_fixed_price`, `KMAE_Seller::get_fixed_price`, `KMAE_Database::table`, `KMAE_Offers::guard_new_offer`, `KMAE_Offers::require_fair_buyer_pledge`
- READS: `table:offers`
- WRITES: `wpdb:insert`
- RELATED FEATURE: `OFFERS`, `NOTIFICATIONS`
- EMITS: `kmae_new_offer`

## `KMAE_Offers::get_offerer_display_name`
- FILE: `includes/class-kmae-offers.php:142-153`
- SYMBOL: `KMAE_Offers::get_offerer_display_name`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Notifications::on_offer_withdrawn`, `KMAE_Counter_Offers::get_other_party_name`
- CALLS: `KMAE_Auth::is_company`, `KMAE_Company::get_company_name`, `KMAE_Dashboard::greeting_case`
- READS: —
- WRITES: —
- RELATED FEATURE: `OFFERS`, `NOTIFICATIONS`

## `KMAE_Offers::format_cash`
- FILE: `includes/class-kmae-offers.php:156-157`
- SYMBOL: `KMAE_Offers::format_cash`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Seller::get_public_price_row`, `KMAE_Offers::get_offer_summary`, `KMAE_Counter_Offers::format_counter_message`, `KMAE_Counter_Offers::get_current_amount_summary`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `OFFERS`, `NOTIFICATIONS`

## `KMAE_Offers::parse_amount_input`
- FILE: `includes/class-kmae-offers.php:163-168`
- SYMBOL: `KMAE_Offers::parse_amount_input`
- PURPOSE: Parse user-entered amount (supports spaced thousands, e.g. "10 000").
- CALLED BY: `KMAE_Public::process_cash_offer`, `KMAE_Public::process_counter_offer`, `KMAE_Public::process_revise_offer`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `OFFERS`, `NOTIFICATIONS`

## `KMAE_Offers::can_withdraw`
- FILE: `includes/class-kmae-offers.php:171-174`
- SYMBOL: `KMAE_Offers::can_withdraw`
- PURPOSE: Parse user-entered amount (supports spaced thousands, e.g. "10 000").
- CALLED BY: `KMAE_Offers::withdraw_offer`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `OFFERS`, `NOTIFICATIONS`

## `KMAE_Offers::withdraw_offer`
- FILE: `includes/class-kmae-offers.php:177-190`
- SYMBOL: `KMAE_Offers::withdraw_offer`
- PURPOSE: Parse user-entered amount (supports spaced thousands, e.g. "10 000").
- CALLED BY: `KMAE_Public::process_withdraw_offer`
- CALLS: `KMAE_Database::get_offer`, `KMAE_Database::update_offer_status`, `KMAE_Offers::can_withdraw`
- READS: —
- WRITES: —
- RELATED FEATURE: `OFFERS`, `NOTIFICATIONS`
- EMITS: `kmae_offer_withdrawn`

## `KMAE_Offers::is_active_for_listing`
- FILE: `includes/class-kmae-offers.php:193-198`
- SYMBOL: `KMAE_Offers::is_active_for_listing`
- PURPOSE: Parse user-entered amount (supports spaced thousands, e.g. "10 000").
- CALLED BY: `KMAE_Database::get_active_user_offer_for_listing`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `OFFERS`, `NOTIFICATIONS`

## `KMAE_Offers::get_offer_summary`
- FILE: `includes/class-kmae-offers.php:201-220`
- SYMBOL: `KMAE_Offers::get_offer_summary`
- PURPOSE: Parse user-entered amount (supports spaced thousands, e.g. "10 000").
- CALLED BY: `KMAE_Dashboard::format_offer_row`, `KMAE_Dashboard::activity_from_offer`, `KMAE_Dashboard::offer_amount_label`, `KMAE_Counter_Offers::get_chat_messages`, `KMAE_Counter_Offers::get_current_amount_summary`
- CALLS: `KMAE_Database::get_offer_images`, `KMAE_Offers::format_cash`
- READS: —
- WRITES: —
- RELATED FEATURE: `OFFERS`, `NOTIFICATIONS`

## `KMAE_Offers::render_offer_images`
- FILE: `includes/class-kmae-offers.php:223-237`
- SYMBOL: `KMAE_Offers::render_offer_images`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: —
- CALLS: `KMAE_Database::get_offer_images`
- READS: —
- WRITES: —
- RELATED FEATURE: `OFFERS`, `NOTIFICATIONS`

## `KMAE_Pages::__construct`
- FILE: `includes/class-kmae-pages.php:105-111`
- SYMBOL: `KMAE_Pages::__construct`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: —
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `PAGES-ROUTING`, `LIVE-NAV`

## `KMAE_Pages::register_query_vars`
- FILE: `includes/class-kmae-pages.php:120-133`
- SYMBOL: `KMAE_Pages::register_query_vars`
- PURPOSE: Keep browse wizard filters on canonical page URLs.
- CALLED BY: `WP filter `query_vars``
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `PAGES-ROUTING`, `LIVE-NAV`

## `KMAE_Pages::maybe_ensure_pages`
- FILE: `includes/class-kmae-pages.php:139-145`
- SYMBOL: `KMAE_Pages::maybe_ensure_pages`
- PURPOSE: Create/update shortcode pages after plugin updates (without re-activation).
- CALLED BY: `WP action `init``
- CALLS: `KMAE_Pages::ensure_pages`
- READS: `option:kmae_pages_version`
- WRITES: `option:kmae_pages_version`
- RELATED FEATURE: `PAGES-ROUTING`, `LIVE-NAV`

## `KMAE_Pages::offer_thread_body_class`
- FILE: `includes/class-kmae-pages.php:151-161`
- SYMBOL: `KMAE_Pages::offer_thread_body_class`
- PURPOSE: Full-page chat room styling when viewing a single offer thread.
- CALLED BY: `WP filter `body_class``
- CALLS: `KMAE_Pages::is_offers_page`
- READS: —
- WRITES: —
- RELATED FEATURE: `PAGES-ROUTING`, `LIVE-NAV`
- GET KEYS: `kmae_offer`

## `KMAE_Pages::mark_offers_seen_on_visit`
- FILE: `includes/class-kmae-pages.php:167-182`
- SYMBOL: `KMAE_Pages::mark_offers_seen_on_visit`
- PURPOSE: Mark a single offer thread as read when opened.
- CALLED BY: `WP action `template_redirect``
- CALLS: `KMAE_Database::get_offer`, `KMAE_Counter_Offers::user_can_access`, `KMAE_Database::mark_offer_seen`, `KMAE_Pages::is_offers_page`
- READS: —
- WRITES: —
- RELATED FEATURE: `PAGES-ROUTING`, `LIVE-NAV`
- GET KEYS: `kmae_offer`

## `KMAE_Pages::is_offers_page`
- FILE: `includes/class-kmae-pages.php:188-201`
- SYMBOL: `KMAE_Pages::is_offers_page`
- PURPOSE: Whether the current request is the offers hub page.
- CALLED BY: `KMAE_Pages::offer_thread_body_class`, `KMAE_Pages::mark_offers_seen_on_visit`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `PAGES-ROUTING`, `LIVE-NAV`

## `KMAE_Pages::browse_page_url`
- FILE: `includes/class-kmae-pages.php:204-205`
- SYMBOL: `KMAE_Pages::browse_page_url`
- PURPOSE: Whether the current request is the offers hub page.
- CALLED BY: `KMAE_Shortcodes::get_browse_base_url`
- CALLS: `KMAE_Pages::url`
- READS: —
- WRITES: —
- RELATED FEATURE: `PAGES-ROUTING`, `LIVE-NAV`

## `KMAE_Pages::offers_page_url`
- FILE: `includes/class-kmae-pages.php:208-209`
- SYMBOL: `KMAE_Pages::offers_page_url`
- PURPOSE: Whether the current request is the offers hub page.
- CALLED BY: `KMAE_Database::get_offers_page_url`, `KMAE_Pages::offer_thread_url`, `KMAE_Pages::redirect_legacy_offers_page`, `KMAE_Shortcodes::my_offers`
- CALLS: `KMAE_Pages::url`
- READS: —
- WRITES: —
- RELATED FEATURE: `PAGES-ROUTING`, `LIVE-NAV`

## `KMAE_Pages::offer_thread_url`
- FILE: `includes/class-kmae-pages.php:212-213`
- SYMBOL: `KMAE_Pages::offer_thread_url`
- PURPOSE: Whether the current request is the offers hub page.
- CALLED BY: `KMAE_Dashboard::format_offer_row`, `KMAE_Dashboard::format_message_row`, `KMAE_Notifications::on_new_offer`, `KMAE_Notifications::on_counter_offer`, `KMAE_Notifications::on_buyer_revision`, `KMAE_Notifications::on_offer_accepted`, `KMAE_Notifications::on_deal_locked`, `KMAE_Notifications::notify_buyer_other_sellers_hold`, `KMAE_Notifications::on_deal_failed`, `KMAE_Notifications::notify_buyer_other_sellers_resume`
- CALLS: `KMAE_Pages::offers_page_url`
- READS: —
- WRITES: —
- RELATED FEATURE: `PAGES-ROUTING`, `LIVE-NAV`

## `KMAE_Pages::url`
- FILE: `includes/class-kmae-pages.php:223-237`
- SYMBOL: `KMAE_Pages::url`
- PURPOSE: Permalink for a registered shortcode page (by slug key in PAGES).
- CALLED BY: `KMAE_Google_Auth::enforce_completion`, `KMAE_Google_Auth::handle_callback`, `KMAE_Google_Auth::handle_complete`, `KMAE_Google_Auth::fail`, `KMAE_Dashboard::get_data`, `KMAE_Auth::login_url`, `KMAE_Auth::register_url`, `KMAE_Auth::maybe_handle_email_verify_link`, `KMAE_Trust::rate_url`, `KMAE_Pages::browse_page_url`, `KMAE_Pages::offers_page_url`, `KMAE_Public::get_settings_redirect_url`, `KMAE_Public::admin_contact_form`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `PAGES-ROUTING`, `LIVE-NAV`

## `KMAE_Pages::shortcode_for`
- FILE: `includes/class-kmae-pages.php:246-247`
- SYMBOL: `KMAE_Pages::shortcode_for`
- PURPOSE: Shortcode tag for a registered page slug, or empty string.
- CALLED BY: —
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `PAGES-ROUTING`, `LIVE-NAV`

## `KMAE_Pages::redirect_legacy_offers_page`
- FILE: `includes/class-kmae-pages.php:253-262`
- SYMBOL: `KMAE_Pages::redirect_legacy_offers_page`
- PURPOSE: 301 from old slug after rename.
- CALLED BY: `WP action `template_redirect``
- CALLS: `KMAE_Pages::offers_page_url`
- READS: —
- WRITES: —
- RELATED FEATURE: `PAGES-ROUTING`, `LIVE-NAV`

## `KMAE_Pages::ensure_pages`
- FILE: `includes/class-kmae-pages.php:265-270`
- SYMBOL: `KMAE_Pages::ensure_pages`
- PURPOSE: 301 from old slug after rename.
- CALLED BY: `KMAE_Pages::maybe_ensure_pages`, `KMAE_Activator::activate`, `KMAE_Activator::maybe_upgrade`
- CALLS: `KMAE_Pages::migrate_offers_page_slug`, `KMAE_Pages::ensure_page`, `KMAE_Pages::ensure_front_page`
- READS: —
- WRITES: —
- RELATED FEATURE: `PAGES-ROUTING`, `LIVE-NAV`

## `KMAE_Pages::migrate_offers_page_slug`
- FILE: `includes/class-kmae-pages.php:276-295`
- SYMBOL: `KMAE_Pages::migrate_offers_page_slug`
- PURPOSE: Rename legacy offers page slug on existing installs.
- CALLED BY: `KMAE_Pages::ensure_pages`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `PAGES-ROUTING`, `LIVE-NAV`

## `KMAE_Pages::ensure_front_page`
- FILE: `includes/class-kmae-pages.php:301-315`
- SYMBOL: `KMAE_Pages::ensure_front_page`
- PURPOSE: Set dedicated landing page as site front page; browse lives at /hirdetesek/.
- CALLED BY: `KMAE_Pages::ensure_pages`
- CALLS: `KMAE_Pages::ensure_page`
- READS: `option:page_on_front`
- WRITES: `option:show_on_front`, `option:page_on_front`
- RELATED FEATURE: `PAGES-ROUTING`, `LIVE-NAV`

## `KMAE_Pages::ensure_page`
- FILE: `includes/class-kmae-pages.php:318-351`
- SYMBOL: `KMAE_Pages::ensure_page`
- PURPOSE: Set dedicated landing page as site front page; browse lives at /hirdetesek/.
- CALLED BY: `KMAE_Pages::ensure_pages`, `KMAE_Pages::ensure_front_page`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `PAGES-ROUTING`, `LIVE-NAV`

## `KMAE_Pages::inject_page_content`
- FILE: `includes/class-kmae-pages.php:354-389`
- SYMBOL: `KMAE_Pages::inject_page_content`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `WP filter `the_content``
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `PAGES-ROUTING`, `LIVE-NAV`

## `KMAE_Photo_Motor::required_slots`
- FILE: `includes/class-kmae-photo-motor.php:124-175`
- SYMBOL: `KMAE_Photo_Motor::required_slots`
- PURPOSE: 7 kötelező nézet (diagram pontokkal).
- CALLED BY: `KMAE_Photo_Motor::all_slots`, `KMAE_Photo_Motor::required_count`, `KMAE_Photo_Motor::count_required_filled`, `KMAE_Photo_Motor::count_required_uploads`, `KMAE_Photo_Motor::validate_request`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `PHOTO-MOTOR`, `MODERATION`

## `KMAE_Photo_Motor::recommended_slots`
- FILE: `includes/class-kmae-photo-motor.php:183-227`
- SYMBOL: `KMAE_Photo_Motor::recommended_slots`
- PURPOSE: 6 ajánlott — összesen 13 fotópont.
- CALLED BY: `KMAE_Photo_Motor::all_slots`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `PHOTO-MOTOR`, `MODERATION`

## `KMAE_Photo_Motor::recommended_total_count`
- FILE: `includes/class-kmae-photo-motor.php:233-234`
- SYMBOL: `KMAE_Photo_Motor::recommended_total_count`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: —
- CALLS: `KMAE_Photo_Motor::all_slots`
- READS: —
- WRITES: —
- RELATED FEATURE: `PHOTO-MOTOR`, `MODERATION`

## `KMAE_Photo_Motor::all_slots`
- FILE: `includes/class-kmae-photo-motor.php:240-241`
- SYMBOL: `KMAE_Photo_Motor::all_slots`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Photo_Motor::recommended_total_count`, `KMAE_Photo_Motor::get_slots`, `KMAE_Photo_Motor::has_any_upload`, `KMAE_Photo_Motor::handle_slot_uploads`, `KMAE_Photo_Motor::slots_to_gallery`
- CALLS: `KMAE_Photo_Motor::required_slots`, `KMAE_Photo_Motor::recommended_slots`
- READS: —
- WRITES: —
- RELATED FEATURE: `PHOTO-MOTOR`, `MODERATION`

## `KMAE_Photo_Motor::required_count`
- FILE: `includes/class-kmae-photo-motor.php:244-245`
- SYMBOL: `KMAE_Photo_Motor::required_count`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Listings::activate_if_photos_ready`, `KMAE_Moderation::validate`, `KMAE_Public::admin_update_listing`, `KMAE_Public::process_create_listing`
- CALLS: `KMAE_Photo_Motor::required_slots`
- READS: —
- WRITES: —
- RELATED FEATURE: `PHOTO-MOTOR`, `MODERATION`

## `KMAE_Photo_Motor::is_enabled`
- FILE: `includes/class-kmae-photo-motor.php:248-250`
- SYMBOL: `KMAE_Photo_Motor::is_enabled`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Listings::activate_if_photos_ready`, `KMAE_Listings::handle_image_uploads`, `KMAE_Moderation::validate`, `KMAE_Moderation::count_uploaded_images`, `KMAE_Photo_Motor::validate_request`, `KMAE_Public::admin_update_listing`, `KMAE_Public::process_create_listing`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `PHOTO-MOTOR`, `MODERATION`

## `KMAE_Photo_Motor::get_slots`
- FILE: `includes/class-kmae-photo-motor.php:257-271`
- SYMBOL: `KMAE_Photo_Motor::get_slots`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Photo_Motor::count_required_filled`, `KMAE_Photo_Motor::validate_request`, `KMAE_Photo_Motor::handle_slot_uploads`
- CALLS: `KMAE_Photo_Motor::all_slots`
- READS: —
- WRITES: —
- RELATED FEATURE: `PHOTO-MOTOR`, `MODERATION`

## `KMAE_Photo_Motor::count_required_filled`
- FILE: `includes/class-kmae-photo-motor.php:278-286`
- SYMBOL: `KMAE_Photo_Motor::count_required_filled`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Listings::activate_if_photos_ready`, `KMAE_Public::admin_update_listing`, `KMAE_Public::process_create_listing`
- CALLS: `KMAE_Photo_Motor::get_slots`, `KMAE_Photo_Motor::required_slots`
- READS: —
- WRITES: —
- RELATED FEATURE: `PHOTO-MOTOR`, `MODERATION`

## `KMAE_Photo_Motor::count_required_uploads`
- FILE: `includes/class-kmae-photo-motor.php:294-301`
- SYMBOL: `KMAE_Photo_Motor::count_required_uploads`
- PURPOSE: Count required slot files in current request.
- CALLED BY: `KMAE_Moderation::count_uploaded_images`
- CALLS: `KMAE_Photo_Motor::required_slots`, `KMAE_Photo_Motor::has_upload_for_slot`
- READS: —
- WRITES: —
- RELATED FEATURE: `PHOTO-MOTOR`, `MODERATION`

## `KMAE_Photo_Motor::has_upload_for_slot`
- FILE: `includes/class-kmae-photo-motor.php:308-313`
- SYMBOL: `KMAE_Photo_Motor::has_upload_for_slot`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Photo_Motor::count_required_uploads`, `KMAE_Photo_Motor::has_any_upload`, `KMAE_Photo_Motor::validate_request`, `KMAE_Photo_Motor::handle_slot_uploads`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `PHOTO-MOTOR`, `MODERATION`

## `KMAE_Photo_Motor::has_any_upload`
- FILE: `includes/class-kmae-photo-motor.php:321-327`
- SYMBOL: `KMAE_Photo_Motor::has_any_upload`
- PURPOSE: Whether the current request includes any slot photo upload.
- CALLED BY: `KMAE_Public::admin_update_listing`
- CALLS: `KMAE_Photo_Motor::all_slots`, `KMAE_Photo_Motor::has_upload_for_slot`
- READS: —
- WRITES: —
- RELATED FEATURE: `PHOTO-MOTOR`, `MODERATION`

## `KMAE_Photo_Motor::validate_request`
- FILE: `includes/class-kmae-photo-motor.php:337-366`
- SYMBOL: `KMAE_Photo_Motor::validate_request`
- PURPOSE: Validate create/update photo requirements.
- CALLED BY: `KMAE_Public::admin_update_listing`, `KMAE_Public::process_create_listing`
- CALLS: `KMAE_Photo_Motor::is_enabled`, `KMAE_Photo_Motor::get_slots`, `KMAE_Photo_Motor::required_slots`, `KMAE_Photo_Motor::has_upload_for_slot`
- READS: —
- WRITES: —
- RELATED FEATURE: `PHOTO-MOTOR`, `MODERATION`

## `KMAE_Photo_Motor::handle_slot_uploads`
- FILE: `includes/class-kmae-photo-motor.php:376-508`
- SYMBOL: `KMAE_Photo_Motor::handle_slot_uploads`
- PURPOSE: Process slot uploads, rebuild gallery order.
- CALLED BY: `KMAE_Listings::handle_image_uploads`
- CALLS: `KMAE_Images::process_attachment`, `KMAE_Photo_Motor::get_slots`, `KMAE_Photo_Motor::all_slots`, `KMAE_Photo_Motor::has_upload_for_slot`, `KMAE_Photo_Motor::analyze_file`, `KMAE_Photo_Motor::fix_advice`, `KMAE_Photo_Motor::autocorrect_file`, `KMAE_Photo_Motor::fix_labels`, `KMAE_Photo_Motor::analysis_record`, `KMAE_Photo_Motor::attachment_belongs_to_listing`, `KMAE_Photo_Motor::slots_to_gallery`, `KMAE_Photo_Motor::autofix_notice_key`
- READS: —
- WRITES: `postmeta:_kmae_gallery`
- RELATED FEATURE: `PHOTO-MOTOR`, `MODERATION`

## `KMAE_Photo_Motor::autofix_notice_key`
- FILE: `includes/class-kmae-photo-motor.php:516-517`
- SYMBOL: `KMAE_Photo_Motor::autofix_notice_key`
- PURPOSE: A gépi javításokról szóló értesítés kulcsa — felhasználónként.
- CALLED BY: `KMAE_Photo_Motor::handle_slot_uploads`, `KMAE_Photo_Motor::take_autofix_notice`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `PHOTO-MOTOR`, `MODERATION`

## `KMAE_Photo_Motor::take_autofix_notice`
- FILE: `includes/class-kmae-photo-motor.php:525-532`
- SYMBOL: `KMAE_Photo_Motor::take_autofix_notice`
- PURPOSE: Egyszer olvasható értesítés az utolsó mentés gépi javításairól.
- CALLED BY: —
- CALLS: `KMAE_Photo_Motor::autofix_notice_key`
- READS: —
- WRITES: —
- RELATED FEATURE: `PHOTO-MOTOR`, `MODERATION`

## `KMAE_Photo_Motor::fix_advice`
- FILE: `includes/class-kmae-photo-motor.php:541-552`
- SYMBOL: `KMAE_Photo_Motor::fix_advice`
- PURPOSE: Gyakorlati tanács a hibakódhoz — általános biztatás helyett konkrétum.
- CALLED BY: `KMAE_Photo_Motor::handle_slot_uploads`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `PHOTO-MOTOR`, `MODERATION`

## `KMAE_Photo_Motor::slots_to_gallery`
- FILE: `includes/class-kmae-photo-motor.php:559-566`
- SYMBOL: `KMAE_Photo_Motor::slots_to_gallery`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Photo_Motor::handle_slot_uploads`
- CALLS: `KMAE_Photo_Motor::all_slots`
- READS: —
- WRITES: —
- RELATED FEATURE: `PHOTO-MOTOR`, `MODERATION`

## `KMAE_Photo_Motor::analyze_file`
- FILE: `includes/class-kmae-photo-motor.php:587-641`
- SYMBOL: `KMAE_Photo_Motor::analyze_file`
- PURPOSE: Képminőség-elemzés (V2). Nem átlagfényerőt néz, hanem luminancia-hisztogramot: percentiliseket, bebukott árnyék- és kiégett csúcsfény-arányt, dinamikatartományt —
- CALLED BY: `KMAE_Listings::handle_image_uploads`, `KMAE_Photo_Motor::handle_slot_uploads`
- CALLS: `KMAE_Photo_Motor::measure`, `KMAE_Photo_Motor::classify`
- READS: —
- WRITES: —
- RELATED FEATURE: `PHOTO-MOTOR`, `MODERATION`

## `KMAE_Photo_Motor::measure`
- FILE: `includes/class-kmae-photo-motor.php:655-702`
- SYMBOL: `KMAE_Photo_Motor::measure`
- PURPOSE: Egy megnyitott képről minden mérés egy helyen.
- CALLED BY: `KMAE_Photo_Motor::analyze_file`, `KMAE_Photo_Motor::autocorrect_file`, `KMAE_Photo_Motor::try_sharpen_step`, `KMAE_Photo_Motor::try_step`
- CALLS: `KMAE_Photo_Motor::edge_and_hash`, `KMAE_Photo_Motor::region_stats`
- READS: —
- WRITES: —
- RELATED FEATURE: `PHOTO-MOTOR`, `MODERATION`

## `KMAE_Photo_Motor::region_stats`
- FILE: `includes/class-kmae-photo-motor.php:717-793`
- SYMBOL: `KMAE_Photo_Motor::region_stats`
- PURPOSE: Egy képterület hisztogramja és az abból számolt mérőszámok.
- CALLED BY: `KMAE_Photo_Motor::measure`
- CALLS: `KMAE_Photo_Motor::percentile`
- READS: —
- WRITES: —
- RELATED FEATURE: `PHOTO-MOTOR`, `MODERATION`

## `KMAE_Photo_Motor::percentile`
- FILE: `includes/class-kmae-photo-motor.php:802-811`
- SYMBOL: `KMAE_Photo_Motor::percentile`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Photo_Motor::region_stats`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `PHOTO-MOTOR`, `MODERATION`

## `KMAE_Photo_Motor::edge_and_hash`
- FILE: `includes/class-kmae-photo-motor.php:820-881`
- SYMBOL: `KMAE_Photo_Motor::edge_and_hash`
- PURPOSE: Élesség, szórás és képujjlenyomat a régi 64×64-es mintáról.
- CALLED BY: `KMAE_Photo_Motor::measure`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `PHOTO-MOTOR`, `MODERATION`

## `KMAE_Photo_Motor::classify`
- FILE: `includes/class-kmae-photo-motor.php:893-991`
- SYMBOL: `KMAE_Photo_Motor::classify`
- PURPOSE: A mérésekből ítélet: mi a baj, mit javítunk, és mit üzenünk.
- CALLED BY: `KMAE_Photo_Motor::analyze_file`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `PHOTO-MOTOR`, `MODERATION`

## `KMAE_Photo_Motor::autocorrect_file`
- FILE: `includes/class-kmae-photo-motor.php:1005-1205`
- SYMBOL: `KMAE_Photo_Motor::autocorrect_file`
- PURPOSE: Gépi képjavítás a feltöltés ideiglenes fájlján (V2).
- CALLED BY: `KMAE_Listings::handle_image_uploads`, `KMAE_Photo_Motor::handle_slot_uploads`
- CALLS: `KMAE_Photo_Motor::measure`, `KMAE_Photo_Motor::try_step`, `KMAE_Photo_Motor::build_dark_lut`, `KMAE_Photo_Motor::build_bright_lut`, `KMAE_Photo_Motor::build_s_curve_lut`, `KMAE_Photo_Motor::sharpen_allowed`, `KMAE_Photo_Motor::try_sharpen_step`, `KMAE_Photo_Motor::compact_stats`
- READS: —
- WRITES: —
- RELATED FEATURE: `PHOTO-MOTOR`, `MODERATION`

## `KMAE_Photo_Motor::try_sharpen_step`
- FILE: `includes/class-kmae-photo-motor.php:1216-1258`
- SYMBOL: `KMAE_Photo_Motor::try_sharpen_step`
- PURPOSE: Élesítés másolaton, méréssel: csak akkor marad, ha tényleg élesebb lett és közben nem gyártott új kiégést vagy bebukást.
- CALLED BY: `KMAE_Photo_Motor::autocorrect_file`
- CALLS: `KMAE_Photo_Motor::clone_image`, `KMAE_Photo_Motor::measure`
- READS: —
- WRITES: —
- RELATED FEATURE: `PHOTO-MOTOR`, `MODERATION`

## `KMAE_Photo_Motor::try_step`
- FILE: `includes/class-kmae-photo-motor.php:1270-1294`
- SYMBOL: `KMAE_Photo_Motor::try_step`
- PURPOSE: Egy korrekciós lépés másolaton, méréssel és döntéssel.
- CALLED BY: `KMAE_Photo_Motor::autocorrect_file`
- CALLS: `KMAE_Photo_Motor::clone_image`, `KMAE_Photo_Motor::apply_luma_lut`, `KMAE_Photo_Motor::measure`, `KMAE_Photo_Motor::step_improved`
- READS: —
- WRITES: —
- RELATED FEATURE: `PHOTO-MOTOR`, `MODERATION`

## `KMAE_Photo_Motor::step_improved`
- FILE: `includes/class-kmae-photo-motor.php:1305-1322`
- SYMBOL: `KMAE_Photo_Motor::step_improved`
- PURPOSE: A korrekció csak akkor marad, ha a számok szerint tényleg javított.
- CALLED BY: `KMAE_Photo_Motor::try_step`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `PHOTO-MOTOR`, `MODERATION`

## `KMAE_Photo_Motor::sharpen_allowed`
- FILE: `includes/class-kmae-photo-motor.php:1332-1345`
- SYMBOL: `KMAE_Photo_Motor::sharpen_allowed`
- PURPOSE: Élesítés csak ott, ahol nem a zajt emeli ki.
- CALLED BY: `KMAE_Photo_Motor::autocorrect_file`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `PHOTO-MOTOR`, `MODERATION`

## `KMAE_Photo_Motor::build_dark_lut`
- FILE: `includes/class-kmae-photo-motor.php:1355-1365`
- SYMBOL: `KMAE_Photo_Motor::build_dark_lut`
- PURPOSE: Sötét kép tónusgörbéje: az árnyékokat és a középtónusokat emeli, a csúcsfényeket pedig egyre kevésbé bántja — így az ég nem ég ki.
- CALLED BY: `KMAE_Photo_Motor::autocorrect_file`
- CALLS: `KMAE_Photo_Motor::highlight_guard`
- READS: —
- WRITES: —
- RELATED FEATURE: `PHOTO-MOTOR`, `MODERATION`

## `KMAE_Photo_Motor::build_bright_lut`
- FILE: `includes/class-kmae-photo-motor.php:1375-1386`
- SYMBOL: `KMAE_Photo_Motor::build_bright_lut`
- PURPOSE: Túl világos kép: a közép- és világos tónusokat tömöríti, az árnyékokat lehetőleg érintetlenül hagyja.
- CALLED BY: `KMAE_Photo_Motor::autocorrect_file`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `PHOTO-MOTOR`, `MODERATION`

## `KMAE_Photo_Motor::build_s_curve_lut`
- FILE: `includes/class-kmae-photo-motor.php:1395-1403`
- SYMBOL: `KMAE_Photo_Motor::build_s_curve_lut`
- PURPOSE: Enyhe S-görbe a fakó képhez: középen ad egy kis tartást, a két végén fokozatosan elhal, hogy ne gyártson új bebukást vagy kiégést.
- CALLED BY: `KMAE_Photo_Motor::autocorrect_file`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `PHOTO-MOTOR`, `MODERATION`

## `KMAE_Photo_Motor::highlight_guard`
- FILE: `includes/class-kmae-photo-motor.php:1412-1420`
- SYMBOL: `KMAE_Photo_Motor::highlight_guard`
- PURPOSE: A világosítás ereje 170 fölött fokozatosan elhal, 245 közelében nulla.
- CALLED BY: `KMAE_Photo_Motor::build_dark_lut`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `PHOTO-MOTOR`, `MODERATION`

## `KMAE_Photo_Motor::apply_luma_lut`
- FILE: `includes/class-kmae-photo-motor.php:1432-1474`
- SYMBOL: `KMAE_Photo_Motor::apply_luma_lut`
- PURPOSE: A tónusgörbét a fényességre alkalmazzuk, és a különbséget adjuk a csatornákhoz — így a színek nem tolódnak el. A lépést a rendelkezésre álló fejtérhez igazítjuk, hogy ne keletkezzen új kiégés vagy bebukás.
- CALLED BY: `KMAE_Photo_Motor::try_step`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `PHOTO-MOTOR`, `MODERATION`

## `KMAE_Photo_Motor::clone_image`
- FILE: `includes/class-kmae-photo-motor.php:1481-1497`
- SYMBOL: `KMAE_Photo_Motor::clone_image`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Photo_Motor::try_sharpen_step`, `KMAE_Photo_Motor::try_step`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `PHOTO-MOTOR`, `MODERATION`

## `KMAE_Photo_Motor::compact_stats`
- FILE: `includes/class-kmae-photo-motor.php:1506-1528`
- SYMBOL: `KMAE_Photo_Motor::compact_stats`
- PURPOSE: A metába csak a lényeg kerül — a 256 rekeszes hisztogram nem.
- CALLED BY: `KMAE_Photo_Motor::autocorrect_file`, `KMAE_Photo_Motor::analysis_record`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `PHOTO-MOTOR`, `MODERATION`

## `KMAE_Photo_Motor::analysis_record`
- FILE: `includes/class-kmae-photo-motor.php:1539-1558`
- SYMBOL: `KMAE_Photo_Motor::analysis_record`
- PURPOSE: A képhez mentett mérési napló. Ha később az derül ki, hogy egy kép megítélése rossz volt, nem találgatunk: itt vannak a számok.
- CALLED BY: `KMAE_Listings::handle_image_uploads`, `KMAE_Photo_Motor::handle_slot_uploads`
- CALLS: `KMAE_Photo_Motor::compact_stats`
- READS: —
- WRITES: —
- RELATED FEATURE: `PHOTO-MOTOR`, `MODERATION`

## `KMAE_Photo_Motor::client_config`
- FILE: `includes/class-kmae-photo-motor.php:1567-1594`
- SYMBOL: `KMAE_Photo_Motor::client_config`
- PURPOSE: A küszöbök egyetlen forrása a PHP — a böngésző innen kapja őket, hogy a két oldal soha ne mondhasson mást ugyanarról a képről.
- CALLED BY: `KMAE_Public::enqueue`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `PHOTO-MOTOR`, `MODERATION`

## `KMAE_Photo_Motor::fix_labels`
- FILE: `includes/class-kmae-photo-motor.php:1603-1617`
- SYMBOL: `KMAE_Photo_Motor::fix_labels`
- PURPOSE: A javítások emberi nyelvű megfogalmazása a visszajelzéshez.
- CALLED BY: `KMAE_Photo_Motor::handle_slot_uploads`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `PHOTO-MOTOR`, `MODERATION`

## `KMAE_Photo_Motor::attachment_belongs_to_listing`
- FILE: `includes/class-kmae-photo-motor.php:1620-1624`
- SYMBOL: `KMAE_Photo_Motor::attachment_belongs_to_listing`
- PURPOSE: A javítások emberi nyelvű megfogalmazása a visszajelzéshez.
- CALLED BY: `KMAE_Photo_Motor::handle_slot_uploads`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `PHOTO-MOTOR`, `MODERATION`

## `KMAE_Plugin::run`
- FILE: `includes/class-kmae-plugin.php:14-39`
- SYMBOL: `KMAE_Plugin::run`
- PURPOSE: Main plugin orchestrator.
- CALLED BY: —
- CALLS: `KMAE_Activator::maybe_upgrade`, `KMAE_Brand::init`, `KMAE_Auth::init`, `KMAE_Google_Auth::init`, `KMAE_Notifications::init`, `KMAE_Listings::init`, `KMAE_Listing_Drafts::init`, `KMAE_Images::init`, `KMAE_Dashboard::init`
- READS: —
- WRITES: —
- RELATED FEATURE: `BOOT-ARCHITECTURE`

## `KMAE_Post_Types::__construct`
- FILE: `includes/class-kmae-post-types.php:14-16`
- SYMBOL: `KMAE_Post_Types::__construct`
- PURPOSE: Custom post type: kmae_listing (hirdetés).
- CALLED BY: —
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `PAGES-ROUTING`, `TAXONOMY-LAUNCH`

## `KMAE_Post_Types::register`
- FILE: `includes/class-kmae-post-types.php:19-20`
- SYMBOL: `KMAE_Post_Types::register`
- PURPOSE: Custom post type: kmae_listing (hirdetés).
- CALLED BY: `WP action `init``
- CALLS: `KMAE_Post_Types::register_post_type`
- READS: —
- WRITES: —
- RELATED FEATURE: `PAGES-ROUTING`, `TAXONOMY-LAUNCH`

## `KMAE_Post_Types::register_post_type`
- FILE: `includes/class-kmae-post-types.php:23-51`
- SYMBOL: `KMAE_Post_Types::register_post_type`
- PURPOSE: Custom post type: kmae_listing (hirdetés).
- CALLED BY: `KMAE_Post_Types::register`, `KMAE_Activator::activate`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `PAGES-ROUTING`, `TAXONOMY-LAUNCH`

## `KMAE_Post_Types::template_loader`
- FILE: `includes/class-kmae-post-types.php:54-67`
- SYMBOL: `KMAE_Post_Types::template_loader`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `WP filter `template_include``
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `PAGES-ROUTING`, `TAXONOMY-LAUNCH`

## `KMAE_Query::get_listings`
- FILE: `includes/class-kmae-query.php:14-107`
- SYMBOL: `KMAE_Query::get_listings`
- PURPOSE: Listing query helpers with filters.
- CALLED BY: `KMAE_Query::get_popular_listings`, `KMAE_Shortcodes::browse`, `KMAE_Shortcodes::browse_vehicle_wizard`
- CALLS: `KMAE_Launch::is_single_category`, `KMAE_Launch::category_slug`, `KMAE_Browse::get_offered_listing_ids`, `KMAE_Browse::personalize_listings`
- READS: —
- WRITES: —
- RELATED FEATURE: `BROWSE-SEARCH`

## `KMAE_Query::get_popular_listings`
- FILE: `includes/class-kmae-query.php:116-122`
- SYMBOL: `KMAE_Query::get_popular_listings`
- PURPOSE: Popular listings for landing page (newest first).
- CALLED BY: —
- CALLS: `KMAE_Query::get_listings`
- READS: —
- WRITES: —
- RELATED FEATURE: `BROWSE-SEARCH`

## `KMAE_Query::get_listing_thumbnail_url`
- FILE: `includes/class-kmae-query.php:128-145`
- SYMBOL: `KMAE_Query::get_listing_thumbnail_url`
- PURPOSE: Featured image URL, or first gallery image as fallback.
- CALLED BY: `KMAE_Query::get_listing_full_image_url`
- CALLS: `KMAE_Images::get_url`, `KMAE_Query::get_gallery_ids`
- READS: —
- WRITES: —
- RELATED FEATURE: `BROWSE-SEARCH`

## `KMAE_Query::get_listing_thumbnail_id`
- FILE: `includes/class-kmae-query.php:157-164`
- SYMBOL: `KMAE_Query::get_listing_thumbnail_id`
- PURPOSE: A kártyaképhez tartozó attachment azonosítója — ugyanaz a visszaesési sorrend, mint a `get_listing_thumbnail_url()`-nél. A reszponzív `srcset` előállításához kell, ahhoz ugyanis nem az URL, hanem az azonosító szükséges.
- CALLED BY: —
- CALLS: `KMAE_Query::get_gallery_ids`
- READS: —
- WRITES: —
- RELATED FEATURE: `BROWSE-SEARCH`

## `KMAE_Query::get_listing_full_image_url`
- FILE: `includes/class-kmae-query.php:170-171`
- SYMBOL: `KMAE_Query::get_listing_full_image_url`
- PURPOSE: Full-size URL for lightbox.
- CALLED BY: —
- CALLS: `KMAE_Query::get_listing_thumbnail_url`
- READS: —
- WRITES: —
- RELATED FEATURE: `BROWSE-SEARCH`

## `KMAE_Query::get_gallery_ids`
- FILE: `includes/class-kmae-query.php:174-180`
- SYMBOL: `KMAE_Query::get_gallery_ids`
- PURPOSE: Full-size URL for lightbox.
- CALLED BY: `KMAE_Dashboard::format_listing_row`, `KMAE_Query::get_listing_thumbnail_url`, `KMAE_Query::get_listing_thumbnail_id`, `KMAE_Public::admin_update_listing`
- CALLS: —
- READS: `postmeta:_kmae_gallery`
- WRITES: —
- RELATED FEATURE: `BROWSE-SEARCH`

## `KMAE_Seller::price_mode_defs`
- FILE: `includes/class-kmae-seller.php:36-75`
- SYMBOL: `KMAE_Seller::price_mode_defs`
- PURPOSE: The three sale modes. Single source for wizard cards, admin and public labels.
- CALLED BY: `KMAE_Seller::price_mode_labels`, `KMAE_Seller::sanitize_price_mode`, `KMAE_Seller::get_public_price_row`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `LISTINGS`

## `KMAE_Seller::price_mode_labels`
- FILE: `includes/class-kmae-seller.php:81-82`
- SYMBOL: `KMAE_Seller::price_mode_labels`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: —
- CALLS: `KMAE_Seller::price_mode_defs`
- READS: —
- WRITES: —
- RELATED FEATURE: `LISTINGS`

## `KMAE_Seller::commitment_defs`
- FILE: `includes/class-kmae-seller.php:90-102`
- SYMBOL: `KMAE_Seller::commitment_defs`
- PURPOSE: Core optional seller pledges (checkboxes).
- CALLED BY: `KMAE_Seller::get_commitments`, `KMAE_Seller::get_badge_rows`, `KMAE_Seller::save_from_post`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `LISTINGS`

## `KMAE_Seller::extra_commitment_defs`
- FILE: `includes/class-kmae-seller.php:110-132`
- SYMBOL: `KMAE_Seller::extra_commitment_defs`
- PURPOSE: Extra pledges shown as badges.
- CALLED BY: `KMAE_Seller::get_commitments`, `KMAE_Seller::get_badge_rows`, `KMAE_Seller::save_from_post`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `LISTINGS`

## `KMAE_Seller::sanitize_price_mode`
- FILE: `includes/class-kmae-seller.php:139-147`
- SYMBOL: `KMAE_Seller::sanitize_price_mode`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Seller::get_price_mode`, `KMAE_Seller::save_from_post`
- CALLS: `KMAE_Seller::price_mode_defs`
- READS: —
- WRITES: —
- RELATED FEATURE: `LISTINGS`

## `KMAE_Seller::get_price_mode`
- FILE: `includes/class-kmae-seller.php:154-155`
- SYMBOL: `KMAE_Seller::get_price_mode`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Seller::is_fixed_price`, `KMAE_Seller::is_guide_price`, `KMAE_Seller::is_open_price`, `KMAE_Seller::get_public_price`, `KMAE_Seller::get_public_price_row`, `KMAE_Meta::save_listing_meta`
- CALLS: `KMAE_Seller::sanitize_price_mode`
- READS: —
- WRITES: —
- RELATED FEATURE: `LISTINGS`

## `KMAE_Seller::get_fixed_price`
- FILE: `includes/class-kmae-seller.php:162-163`
- SYMBOL: `KMAE_Seller::get_fixed_price`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Seller::get_public_price`, `KMAE_Offers::submit_cash_offer`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `LISTINGS`

## `KMAE_Seller::get_guide_price`
- FILE: `includes/class-kmae-seller.php:170-171`
- SYMBOL: `KMAE_Seller::get_guide_price`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Seller::get_public_price`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `LISTINGS`

## `KMAE_Seller::is_fixed_price`
- FILE: `includes/class-kmae-seller.php:178-179`
- SYMBOL: `KMAE_Seller::is_fixed_price`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Offers::submit_cash_offer`
- CALLS: `KMAE_Seller::get_price_mode`
- READS: —
- WRITES: —
- RELATED FEATURE: `LISTINGS`

## `KMAE_Seller::is_guide_price`
- FILE: `includes/class-kmae-seller.php:186-187`
- SYMBOL: `KMAE_Seller::is_guide_price`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: —
- CALLS: `KMAE_Seller::get_price_mode`
- READS: —
- WRITES: —
- RELATED FEATURE: `LISTINGS`

## `KMAE_Seller::is_open_price`
- FILE: `includes/class-kmae-seller.php:194-195`
- SYMBOL: `KMAE_Seller::is_open_price`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Browse::listing_matches_wizard`
- CALLS: `KMAE_Seller::get_price_mode`
- READS: —
- WRITES: —
- RELATED FEATURE: `LISTINGS`

## `KMAE_Seller::get_public_price`
- FILE: `includes/class-kmae-seller.php:204-213`
- SYMBOL: `KMAE_Seller::get_public_price`
- PURPOSE: Publicly shown price. 0 when the mode has no public price.
- CALLED BY: `KMAE_Seller::get_public_price_row`
- CALLS: `KMAE_Seller::get_price_mode`, `KMAE_Seller::get_fixed_price`, `KMAE_Seller::get_guide_price`
- READS: —
- WRITES: —
- RELATED FEATURE: `LISTINGS`

## `KMAE_Seller::get_public_price_row`
- FILE: `includes/class-kmae-seller.php:222-235`
- SYMBOL: `KMAE_Seller::get_public_price_row`
- PURPOSE: Single source for price rendering on cards, swipe and single view.
- CALLED BY: `KMAE_Dashboard::format_listing_row`
- CALLS: `KMAE_Offers::format_cash`, `KMAE_Seller::get_price_mode`, `KMAE_Seller::get_public_price`, `KMAE_Seller::price_mode_defs`
- READS: —
- WRITES: —
- RELATED FEATURE: `LISTINGS`

## `KMAE_Seller::get_commitments`
- FILE: `includes/class-kmae-seller.php:242-248`
- SYMBOL: `KMAE_Seller::get_commitments`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Seller::has_commitment`
- CALLS: `KMAE_Seller::commitment_defs`, `KMAE_Seller::extra_commitment_defs`
- READS: —
- WRITES: —
- RELATED FEATURE: `LISTINGS`

## `KMAE_Seller::has_commitment`
- FILE: `includes/class-kmae-seller.php:256-257`
- SYMBOL: `KMAE_Seller::has_commitment`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Seller::get_badge_rows`
- CALLS: `KMAE_Seller::get_commitments`
- READS: —
- WRITES: —
- RELATED FEATURE: `LISTINGS`

## `KMAE_Seller::get_extra_other`
- FILE: `includes/class-kmae-seller.php:264-265`
- SYMBOL: `KMAE_Seller::get_extra_other`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Seller::get_badge_rows`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `LISTINGS`

## `KMAE_Seller::get_badge_rows`
- FILE: `includes/class-kmae-seller.php:274-311`
- SYMBOL: `KMAE_Seller::get_badge_rows`
- PURPOSE: Public badge rows for listing cards / single view.
- CALLED BY: —
- CALLS: `KMAE_Seller::commitment_defs`, `KMAE_Seller::extra_commitment_defs`, `KMAE_Seller::has_commitment`, `KMAE_Seller::get_extra_other`
- READS: —
- WRITES: —
- RELATED FEATURE: `LISTINGS`

## `KMAE_Seller::count_active_cycle_listings`
- FILE: `includes/class-kmae-seller.php:320-344`
- SYMBOL: `KMAE_Seller::count_active_cycle_listings`
- PURPOSE: Active selling cycle = listing with status "active".
- CALLED BY: —
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `LISTINGS`

## `KMAE_Seller::can_create_listing`
- FILE: `includes/class-kmae-seller.php:353-354`
- SYMBOL: `KMAE_Seller::can_create_listing`
- PURPOSE: Listing creation is unlimited for every account type (private and company).
- CALLED BY: `KMAE_Public::process_create_listing`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `LISTINGS`

## `KMAE_Seller::parse_price_from_post`
- FILE: `includes/class-kmae-seller.php:363-369`
- SYMBOL: `KMAE_Seller::parse_price_from_post`
- PURPOSE: Parse a whole-number price from POST (supports formatted input like 3.500.000).
- CALLED BY: `KMAE_Seller::save_from_post`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `LISTINGS`

## `KMAE_Seller::save_from_post`
- FILE: `includes/class-kmae-seller.php:379-424`
- SYMBOL: `KMAE_Seller::save_from_post`
- PURPOSE: Validate + save price mode, defects, commitments from POST.
- CALLED BY: `KMAE_Listings::save_meta_from_post`
- CALLS: `KMAE_Meta::get_offer_types`, `KMAE_Taxonomies::default_offer_types`, `KMAE_Database::save_private_data`, `KMAE_Seller::sanitize_price_mode`, `KMAE_Seller::parse_price_from_post`, `KMAE_Seller::commitment_defs`, `KMAE_Seller::extra_commitment_defs`
- READS: —
- WRITES: `postmeta:_kmae_offer_types`
- RELATED FEATURE: `LISTINGS`
- POST KEYS: `kmae_commit_extra_other`, `kmae_commitments`, `kmae_price_mode`

## `KMAE_Settings::init`
- FILE: `includes/class-kmae-settings.php:14-15`
- SYMBOL: `KMAE_Settings::init`
- PURPOSE: Plugin settings and defaults.
- CALLED BY: `KMAE_Admin::__construct`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `BOOT-ARCHITECTURE`, `GOOGLE-AUTH`, `ADMIN`, `CONTACT-FORM`

## `KMAE_Settings::register_settings`
- FILE: `includes/class-kmae-settings.php:18-74`
- SYMBOL: `KMAE_Settings::register_settings`
- PURPOSE: Plugin settings and defaults.
- CALLED BY: `WP action `admin_init``
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `BOOT-ARCHITECTURE`, `GOOGLE-AUTH`, `ADMIN`, `CONTACT-FORM`

## `KMAE_Settings::init_defaults`
- FILE: `includes/class-kmae-settings.php:77-81`
- SYMBOL: `KMAE_Settings::init_defaults`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: —
- CALLS: —
- READS: —
- WRITES: `option:kmae_auto_moderation`, `option:kmae_seller_video_url`, `option:kmae_buyer_video_url`, `option:kmae_contact_form_email`
- RELATED FEATURE: `BOOT-ARCHITECTURE`, `GOOGLE-AUTH`, `ADMIN`, `CONTACT-FORM`

## `KMAE_Settings::sanitize_youtube_url`
- FILE: `includes/class-kmae-settings.php:90-101`
- SYMBOL: `KMAE_Settings::sanitize_youtube_url`
- PURPOSE: Keep only valid YouTube watch / short / embed / youtu.be URLs.
- CALLED BY: —
- CALLS: `KMAE_Settings::youtube_id_from_url`
- READS: —
- WRITES: —
- RELATED FEATURE: `BOOT-ARCHITECTURE`, `GOOGLE-AUTH`, `ADMIN`, `CONTACT-FORM`

## `KMAE_Settings::youtube_id_from_url`
- FILE: `includes/class-kmae-settings.php:110-145`
- SYMBOL: `KMAE_Settings::youtube_id_from_url`
- PURPOSE: Extract a YouTube video ID from common URL formats.
- CALLED BY: `KMAE_Settings::sanitize_youtube_url`, `KMAE_Settings::seller_video_id`, `KMAE_Settings::buyer_video_id`
- CALLS: `KMAE_Settings::is_youtube_id`
- READS: —
- WRITES: —
- RELATED FEATURE: `BOOT-ARCHITECTURE`, `GOOGLE-AUTH`, `ADMIN`, `CONTACT-FORM`

## `KMAE_Settings::is_youtube_id`
- FILE: `includes/class-kmae-settings.php:151-152`
- SYMBOL: `KMAE_Settings::is_youtube_id`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Settings::youtube_id_from_url`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `BOOT-ARCHITECTURE`, `GOOGLE-AUTH`, `ADMIN`, `CONTACT-FORM`

## `KMAE_Settings::auto_moderation_enabled`
- FILE: `includes/class-kmae-settings.php:155-156`
- SYMBOL: `KMAE_Settings::auto_moderation_enabled`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: —
- CALLS: —
- READS: `option:kmae_auto_moderation`
- WRITES: —
- RELATED FEATURE: `BOOT-ARCHITECTURE`, `GOOGLE-AUTH`, `ADMIN`, `CONTACT-FORM`

## `KMAE_Settings::seller_video_url`
- FILE: `includes/class-kmae-settings.php:159-160`
- SYMBOL: `KMAE_Settings::seller_video_url`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Settings::seller_video_id`
- CALLS: —
- READS: `option:kmae_seller_video_url`
- WRITES: —
- RELATED FEATURE: `BOOT-ARCHITECTURE`, `GOOGLE-AUTH`, `ADMIN`, `CONTACT-FORM`

## `KMAE_Settings::buyer_video_url`
- FILE: `includes/class-kmae-settings.php:163-164`
- SYMBOL: `KMAE_Settings::buyer_video_url`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Settings::buyer_video_id`
- CALLS: —
- READS: `option:kmae_buyer_video_url`
- WRITES: —
- RELATED FEATURE: `BOOT-ARCHITECTURE`, `GOOGLE-AUTH`, `ADMIN`, `CONTACT-FORM`

## `KMAE_Settings::contact_form_email`
- FILE: `includes/class-kmae-settings.php:172-177`
- SYMBOL: `KMAE_Settings::contact_form_email`
- PURPOSE: Inbox for the public contact form.
- CALLED BY: `KMAE_Public::admin_contact_form`
- CALLS: —
- READS: `option:kmae_contact_form_email`
- WRITES: —
- RELATED FEATURE: `BOOT-ARCHITECTURE`, `GOOGLE-AUTH`, `ADMIN`, `CONTACT-FORM`

## `KMAE_Settings::seller_video_id`
- FILE: `includes/class-kmae-settings.php:180-181`
- SYMBOL: `KMAE_Settings::seller_video_id`
- PURPOSE: Inbox for the public contact form.
- CALLED BY: `KMAE_Shortcodes::how_it_works`
- CALLS: `KMAE_Settings::youtube_id_from_url`, `KMAE_Settings::seller_video_url`
- READS: —
- WRITES: —
- RELATED FEATURE: `BOOT-ARCHITECTURE`, `GOOGLE-AUTH`, `ADMIN`, `CONTACT-FORM`

## `KMAE_Settings::buyer_video_id`
- FILE: `includes/class-kmae-settings.php:184-185`
- SYMBOL: `KMAE_Settings::buyer_video_id`
- PURPOSE: Inbox for the public contact form.
- CALLED BY: `KMAE_Shortcodes::how_it_works`
- CALLS: `KMAE_Settings::youtube_id_from_url`, `KMAE_Settings::buyer_video_url`
- READS: —
- WRITES: —
- RELATED FEATURE: `BOOT-ARCHITECTURE`, `GOOGLE-AUTH`, `ADMIN`, `CONTACT-FORM`

## `KMAE_Taxonomies::__construct`
- FILE: `includes/class-kmae-taxonomies.php:14-16`
- SYMBOL: `KMAE_Taxonomies::__construct`
- PURPOSE: Taxonomies: category + accepted offer types on listing.
- CALLED BY: —
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `PAGES-ROUTING`, `TAXONOMY-LAUNCH`

## `KMAE_Taxonomies::register`
- FILE: `includes/class-kmae-taxonomies.php:19-20`
- SYMBOL: `KMAE_Taxonomies::register`
- PURPOSE: Taxonomies: category + accepted offer types on listing.
- CALLED BY: `WP action `init``
- CALLS: `KMAE_Taxonomies::register_taxonomy`
- READS: —
- WRITES: —
- RELATED FEATURE: `PAGES-ROUTING`, `TAXONOMY-LAUNCH`

## `KMAE_Taxonomies::register_taxonomy`
- FILE: `includes/class-kmae-taxonomies.php:23-38`
- SYMBOL: `KMAE_Taxonomies::register_taxonomy`
- PURPOSE: Taxonomies: category + accepted offer types on listing.
- CALLED BY: `KMAE_Taxonomies::register`, `KMAE_Activator::activate`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `PAGES-ROUTING`, `TAXONOMY-LAUNCH`

## `KMAE_Taxonomies::maybe_seed_categories`
- FILE: `includes/class-kmae-taxonomies.php:44-59`
- SYMBOL: `KMAE_Taxonomies::maybe_seed_categories`
- PURPOSE: Ensure default categories exist (activation + fallback on init).
- CALLED BY: `WP action `init``
- CALLS: `KMAE_Taxonomies::seed_categories`
- READS: —
- WRITES: —
- RELATED FEATURE: `PAGES-ROUTING`, `TAXONOMY-LAUNCH`

## `KMAE_Taxonomies::seed_categories`
- FILE: `includes/class-kmae-taxonomies.php:62-80`
- SYMBOL: `KMAE_Taxonomies::seed_categories`
- PURPOSE: Ensure default categories exist (activation + fallback on init).
- CALLED BY: `KMAE_Launch::get_available_categories`, `KMAE_Taxonomies::maybe_seed_categories`, `KMAE_Activator::activate`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `PAGES-ROUTING`, `TAXONOMY-LAUNCH`

## `KMAE_Taxonomies::offer_type_labels`
- FILE: `includes/class-kmae-taxonomies.php:86-89`
- SYMBOL: `KMAE_Taxonomies::offer_type_labels`
- PURPOSE: Get human-readable offer type labels.
- CALLED BY: `KMAE_Admin::listing_column_content`, `KMAE_Meta::render_meta_box`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `PAGES-ROUTING`, `TAXONOMY-LAUNCH`

## `KMAE_Taxonomies::default_offer_types`
- FILE: `includes/class-kmae-taxonomies.php:97-98`
- SYMBOL: `KMAE_Taxonomies::default_offer_types`
- PURPOSE: Default accepted offer types when the seller form no longer collects them.
- CALLED BY: `KMAE_Seller::save_from_post`, `KMAE_Listings::save_meta_from_post`, `KMAE_Meta::save_listing_meta`, `KMAE_Meta::get_offer_types`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `PAGES-ROUTING`, `TAXONOMY-LAUNCH`

## `KMAE_Taxonomies::offer_type_descriptions`
- FILE: `includes/class-kmae-taxonomies.php:104-107`
- SYMBOL: `KMAE_Taxonomies::offer_type_descriptions`
- PURPOSE: Seller-facing descriptions when creating a listing.
- CALLED BY: —
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `PAGES-ROUTING`, `TAXONOMY-LAUNCH`

## `KMAE_Taxonomies::offer_type_buyer_hints`
- FILE: `includes/class-kmae-taxonomies.php:113-116`
- SYMBOL: `KMAE_Taxonomies::offer_type_buyer_hints`
- PURPOSE: Buyer-facing hints on the offer form tabs.
- CALLED BY: —
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `PAGES-ROUTING`, `TAXONOMY-LAUNCH`

## `KMAE_Taxonomies::counter_templates`
- FILE: `includes/class-kmae-taxonomies.php:122-126`
- SYMBOL: `KMAE_Taxonomies::counter_templates`
- PURPOSE: Counter-offer template labels (seller responses).
- CALLED BY: `KMAE_Counter_Offers::submit_seller_counter`, `KMAE_Counter_Offers::format_counter_message`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `PAGES-ROUTING`, `TAXONOMY-LAUNCH`

## `KMAE_Trust::seller_criteria`
- FILE: `includes/class-kmae-trust.php:23-30`
- SYMBOL: `KMAE_Trust::seller_criteria`
- PURPOSE: Criteria when buyer rates seller.
- CALLED BY: `KMAE_Trust::criteria_for_rated_role`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `TRUST-RATINGS`

## `KMAE_Trust::buyer_criteria`
- FILE: `includes/class-kmae-trust.php:38-45`
- SYMBOL: `KMAE_Trust::buyer_criteria`
- PURPOSE: Criteria when seller rates buyer.
- CALLED BY: `KMAE_Trust::criteria_for_rated_role`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `TRUST-RATINGS`

## `KMAE_Trust::criteria_for_rated_role`
- FILE: `includes/class-kmae-trust.php:52-53`
- SYMBOL: `KMAE_Trust::criteria_for_rated_role`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Trust::submit`
- CALLS: `KMAE_Trust::seller_criteria`, `KMAE_Trust::buyer_criteria`
- READS: —
- WRITES: —
- RELATED FEATURE: `TRUST-RATINGS`

## `KMAE_Trust::get_pending_for_user`
- FILE: `includes/class-kmae-trust.php:62-71`
- SYMBOL: `KMAE_Trust::get_pending_for_user`
- PURPOSE: Pending ratings for a user after successful deals.
- CALLED BY: —
- CALLS: `KMAE_Database::table`
- READS: `table:offers`, `table:ratings`
- WRITES: —
- RELATED FEATURE: `TRUST-RATINGS`

## `KMAE_Trust::has_rated`
- FILE: `includes/class-kmae-trust.php:96-105`
- SYMBOL: `KMAE_Trust::has_rated`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Trust::submit`
- CALLS: `KMAE_Database::table`
- READS: `table:ratings`, `wpdb:get_var`
- WRITES: —
- RELATED FEATURE: `TRUST-RATINGS`

## `KMAE_Trust::resolve_rated_party`
- FILE: `includes/class-kmae-trust.php:115-133`
- SYMBOL: `KMAE_Trust::resolve_rated_party`
- PURPOSE: Who the rater should rate on this offer.
- CALLED BY: `KMAE_Trust::submit`
- CALLS: `KMAE_Meta::get_status`
- READS: —
- WRITES: —
- RELATED FEATURE: `TRUST-RATINGS`

## `KMAE_Trust::submit`
- FILE: `includes/class-kmae-trust.php:144-201`
- SYMBOL: `KMAE_Trust::submit`
- PURPOSE: Submit a rating.
- CALLED BY: `KMAE_Public::admin_submit_rating`
- CALLS: `KMAE_Database::get_offer`, `KMAE_Database::table`, `KMAE_Trust::resolve_rated_party`, `KMAE_Trust::has_rated`, `KMAE_Trust::criteria_for_rated_role`, `KMAE_Trust::recalculate`
- READS: `table:ratings`
- WRITES: `wpdb:insert`
- RELATED FEATURE: `TRUST-RATINGS`
- EMITS: `kmae_rating_submitted`

## `KMAE_Trust::recalculate`
- FILE: `includes/class-kmae-trust.php:209-252`
- SYMBOL: `KMAE_Trust::recalculate`
- PURPOSE: Recalculate cached trust stats for a user.
- CALLED BY: `KMAE_Trust::submit`, `KMAE_Trust::on_deal_success`
- CALLS: `KMAE_Database::table`, `KMAE_Trust::count_successful_deals`
- READS: `table:ratings`, `wpdb:get_results`
- WRITES: —
- RELATED FEATURE: `TRUST-RATINGS`

## `KMAE_Trust::count_successful_deals`
- FILE: `includes/class-kmae-trust.php:261-269`
- SYMBOL: `KMAE_Trust::count_successful_deals`
- PURPOSE: Successful closed deals as seller or buyer.
- CALLED BY: `KMAE_Trust::recalculate`, `KMAE_Trust::get_summary`
- CALLS: `KMAE_Database::table`
- READS: `table:offers`, `wpdb:get_var`
- WRITES: —
- RELATED FEATURE: `TRUST-RATINGS`

## `KMAE_Trust::get_summary`
- FILE: `includes/class-kmae-trust.php:297-311`
- SYMBOL: `KMAE_Trust::get_summary`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Dashboard::get_data`
- CALLS: `KMAE_Trust::count_successful_deals`, `KMAE_Trust::get_badges`
- READS: —
- WRITES: —
- RELATED FEATURE: `TRUST-RATINGS`

## `KMAE_Trust::get_badges`
- FILE: `includes/class-kmae-trust.php:320-335`
- SYMBOL: `KMAE_Trust::get_badges`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Trust::get_summary`
- CALLS: `KMAE_Trust::user_used_onsite_guarantee`
- READS: —
- WRITES: —
- RELATED FEATURE: `TRUST-RATINGS`

## `KMAE_Trust::user_used_onsite_guarantee`
- FILE: `includes/class-kmae-trust.php:342-361`
- SYMBOL: `KMAE_Trust::user_used_onsite_guarantee`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Trust::get_badges`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `TRUST-RATINGS`

## `KMAE_Trust::rate_url`
- FILE: `includes/class-kmae-trust.php:370-372`
- SYMBOL: `KMAE_Trust::rate_url`
- PURPOSE: Rating URL for an offer.
- CALLED BY: `KMAE_Notifications::request_rating`, `KMAE_Public::process_deal_success`
- CALLS: `KMAE_Pages::url`
- READS: —
- WRITES: —
- RELATED FEATURE: `TRUST-RATINGS`

## `KMAE_Trust::on_deal_success`
- FILE: `includes/class-kmae-trust.php:382-397`
- SYMBOL: `KMAE_Trust::on_deal_success`
- PURPOSE: Ask both parties to rate after deal success.
- CALLED BY: `WP action `kmae_deal_success``
- CALLS: `KMAE_Database::get_offer`, `KMAE_Notifications::request_rating`, `KMAE_Trust::recalculate`
- READS: —
- WRITES: —
- RELATED FEATURE: `TRUST-RATINGS`

## `KMAE_Vehicle::is_vehicle_launch`
- FILE: `includes/class-kmae-vehicle.php:35-36`
- SYMBOL: `KMAE_Vehicle::is_vehicle_launch`
- PURPOSE: Legfeljebb ennyi jellemzőt lehet kiválasztani.
- CALLED BY: `KMAE_Admin::listing_columns`, `KMAE_Launch::wizard_total_steps`, `KMAE_Vehicle::save_from_post`, `KMAE_Vehicle::get_display_rows`, `KMAE_Moderation::validate`, `KMAE_Browse::filter_by_wizard`, `KMAE_Public::enqueue`, `KMAE_Shortcodes::browse`
- CALLS: `KMAE_Launch::is_single_category`, `KMAE_Launch::category_slug`
- READS: —
- WRITES: —
- RELATED FEATURE: `VEHICLE`, `MODERATION`, `TAXONOMY-LAUNCH`

## `KMAE_Vehicle::fuel_labels`
- FILE: `includes/class-kmae-vehicle.php:39-47`
- SYMBOL: `KMAE_Vehicle::fuel_labels`
- PURPOSE: Legfeljebb ennyi jellemzőt lehet kiválasztani.
- CALLED BY: `KMAE_Vehicle::save_from_post`, `KMAE_Vehicle::get_display_rows`, `KMAE_Vehicle::get_swipe_subtitle`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `VEHICLE`, `MODERATION`, `TAXONOMY-LAUNCH`

## `KMAE_Vehicle::transmission_labels`
- FILE: `includes/class-kmae-vehicle.php:50-54`
- SYMBOL: `KMAE_Vehicle::transmission_labels`
- PURPOSE: Legfeljebb ennyi jellemzőt lehet kiválasztani.
- CALLED BY: `KMAE_Vehicle::save_from_post`, `KMAE_Vehicle::get_display_rows`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `VEHICLE`, `MODERATION`, `TAXONOMY-LAUNCH`

## `KMAE_Vehicle::body_labels`
- FILE: `includes/class-kmae-vehicle.php:57-62`
- SYMBOL: `KMAE_Vehicle::body_labels`
- PURPOSE: Legfeljebb ennyi jellemzőt lehet kiválasztani.
- CALLED BY: `KMAE_Vehicle::get_display_rows`
- CALLS: `KMAE_Vehicle::body_types`
- READS: —
- WRITES: —
- RELATED FEATURE: `VEHICLE`, `MODERATION`, `TAXONOMY-LAUNCH`

## `KMAE_Vehicle::body_types`
- FILE: `includes/class-kmae-vehicle.php:70-90`
- SYMBOL: `KMAE_Vehicle::body_types`
- PURPOSE: All body types for browse wizard and forms.
- CALLED BY: `KMAE_Vehicle::body_labels`, `KMAE_Vehicle::save_from_post`, `KMAE_Browse::parse_bodies_param`, `KMAE_Browse::bodies_label`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `VEHICLE`, `MODERATION`, `TAXONOMY-LAUNCH`

## `KMAE_Vehicle::browse_body_cards`
- FILE: `includes/class-kmae-vehicle.php:99-107`
- SYMBOL: `KMAE_Vehicle::browse_body_cards`
- PURPOSE: A keresés kivitel-lépésének kártyái: ugyanaz a 6 kivitel és ugyanazok a képek, mint a hirdetésfeladás wizardjában (listing-wizard.js, BODY_CARD_PHOTOS).
- CALLED BY: —
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `VEHICLE`, `MODERATION`, `TAXONOMY-LAUNCH`

## `KMAE_Vehicle::browse_mode_labels`
- FILE: `includes/class-kmae-vehicle.php:110-114`
- SYMBOL: `KMAE_Vehicle::browse_mode_labels`
- PURPOSE: A keresés kivitel-lépésének kártyái: ugyanaz a 6 kivitel és ugyanazok a képek, mint a hirdetésfeladás wizardjában (listing-wizard.js, BODY_CARD_PHOTOS).
- CALLED BY: `KMAE_Browse::wizard_summary_label`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `VEHICLE`, `MODERATION`, `TAXONOMY-LAUNCH`

## `KMAE_Vehicle::get_vehicle_value`
- FILE: `includes/class-kmae-vehicle.php:117-118`
- SYMBOL: `KMAE_Vehicle::get_vehicle_value`
- PURPOSE: A keresés kivitel-lépésének kártyái: ugyanaz a 6 kivitel és ugyanazok a képek, mint a hirdetésfeladás wizardjában (listing-wizard.js, BODY_CARD_PHOTOS).
- CALLED BY: `KMAE_Vehicle::get_specs`, `KMAE_Browse::listing_matches_wizard`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `VEHICLE`, `MODERATION`, `TAXONOMY-LAUNCH`

## `KMAE_Vehicle::format_value`
- FILE: `includes/class-kmae-vehicle.php:121-125`
- SYMBOL: `KMAE_Vehicle::format_value`
- PURPOSE: A keresés kivitel-lépésének kártyái: ugyanaz a 6 kivitel és ugyanazok a képek, mint a hirdetésfeladás wizardjában (listing-wizard.js, BODY_CARD_PHOTOS).
- CALLED BY: `KMAE_Vehicle::get_display_rows`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `VEHICLE`, `MODERATION`, `TAXONOMY-LAUNCH`

## `KMAE_Vehicle::traits`
- FILE: `includes/class-kmae-vehicle.php:134-146`
- SYMBOL: `KMAE_Vehicle::traits`
- PURPOSE: Az autó jellemzői. Legfeljebb három választható belőlük — ezek nem mérhető adatok, hanem az eladó saját kiemelései.
- CALLED BY: `KMAE_Vehicle::get_traits`, `KMAE_Vehicle::get_trait_labels`, `KMAE_Vehicle::save_from_post`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `VEHICLE`, `MODERATION`, `TAXONOMY-LAUNCH`

## `KMAE_Vehicle::get_traits`
- FILE: `includes/class-kmae-vehicle.php:153-158`
- SYMBOL: `KMAE_Vehicle::get_traits`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Vehicle::get_trait_labels`
- CALLS: `KMAE_Vehicle::traits`
- READS: —
- WRITES: —
- RELATED FEATURE: `VEHICLE`, `MODERATION`, `TAXONOMY-LAUNCH`

## `KMAE_Vehicle::get_trait_labels`
- FILE: `includes/class-kmae-vehicle.php:165-171`
- SYMBOL: `KMAE_Vehicle::get_trait_labels`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Vehicle::get_display_rows`
- CALLS: `KMAE_Vehicle::traits`, `KMAE_Vehicle::get_traits`
- READS: —
- WRITES: —
- RELATED FEATURE: `VEHICLE`, `MODERATION`, `TAXONOMY-LAUNCH`

## `KMAE_Vehicle::format_owners`
- FILE: `includes/class-kmae-vehicle.php:184-192`
- SYMBOL: `KMAE_Vehicle::format_owners`
- PURPOSE: A tulajdonosok számának felirata. A „4" a feladásnál a „Negyedik vagy több" kártyát jelenti, ezért nem írhatjuk ki pontos számként — az mást állítana, mint amit választott.
- CALLED BY: `KMAE_Vehicle::get_display_rows`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `VEHICLE`, `MODERATION`, `TAXONOMY-LAUNCH`

## `KMAE_Vehicle::condition_labels`
- FILE: `includes/class-kmae-vehicle.php:195-201`
- SYMBOL: `KMAE_Vehicle::condition_labels`
- PURPOSE: A tulajdonosok számának felirata. A „4" a feladásnál a „Negyedik vagy több" kártyát jelenti, ezért nem írhatjuk ki pontos számként — az mást állítana, mint amit választott.
- CALLED BY: `KMAE_Vehicle::save_from_post`, `KMAE_Vehicle::get_display_rows`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `VEHICLE`, `MODERATION`, `TAXONOMY-LAUNCH`

## `KMAE_Vehicle::catalog`
- FILE: `includes/class-kmae-vehicle.php:209-242`
- SYMBOL: `KMAE_Vehicle::catalog`
- PURPOSE: Brand => models map from the bundled catalog.
- CALLED BY: `KMAE_Vehicle::brands`, `KMAE_Vehicle::models_for`, `KMAE_Vehicle::catalog_payload`, `KMAE_Vehicle::resolve_brand_key`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `VEHICLE`, `MODERATION`, `TAXONOMY-LAUNCH`

## `KMAE_Vehicle::brands`
- FILE: `includes/class-kmae-vehicle.php:250-253`
- SYMBOL: `KMAE_Vehicle::brands`
- PURPOSE: Sorted brand names from the catalog.
- CALLED BY: `KMAE_Vehicle::catalog_payload`
- CALLS: `KMAE_Vehicle::catalog`
- READS: —
- WRITES: —
- RELATED FEATURE: `VEHICLE`, `MODERATION`, `TAXONOMY-LAUNCH`

## `KMAE_Vehicle::models_for`
- FILE: `includes/class-kmae-vehicle.php:262-267`
- SYMBOL: `KMAE_Vehicle::models_for`
- PURPOSE: Models for a catalog brand (case-insensitive brand match).
- CALLED BY: `KMAE_Vehicle::is_known_model`
- CALLS: `KMAE_Vehicle::resolve_brand_key`, `KMAE_Vehicle::catalog`
- READS: —
- WRITES: —
- RELATED FEATURE: `VEHICLE`, `MODERATION`, `TAXONOMY-LAUNCH`

## `KMAE_Vehicle::is_known_brand`
- FILE: `includes/class-kmae-vehicle.php:274-275`
- SYMBOL: `KMAE_Vehicle::is_known_brand`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: —
- CALLS: `KMAE_Vehicle::resolve_brand_key`
- READS: —
- WRITES: —
- RELATED FEATURE: `VEHICLE`, `MODERATION`, `TAXONOMY-LAUNCH`

## `KMAE_Vehicle::is_known_model`
- FILE: `includes/class-kmae-vehicle.php:283-293`
- SYMBOL: `KMAE_Vehicle::is_known_model`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: —
- CALLS: `KMAE_Vehicle::models_for`
- READS: —
- WRITES: —
- RELATED FEATURE: `VEHICLE`, `MODERATION`, `TAXONOMY-LAUNCH`

## `KMAE_Vehicle::brand_logo_slugs`
- FILE: `includes/class-kmae-vehicle.php:309-373`
- SYMBOL: `KMAE_Vehicle::brand_logo_slugs`
- PURPOSE: Catalog brand => emblem file slug. The slug is the uploaded file name, so a few entries intentionally differ from the brand name (rolls-royes, daevoo) — those are the real file names.
- CALLED BY: `KMAE_Vehicle::brand_logos`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `VEHICLE`, `MODERATION`, `TAXONOMY-LAUNCH`

## `KMAE_Vehicle::brand_logos`
- FILE: `includes/class-kmae-vehicle.php:381-386`
- SYMBOL: `KMAE_Vehicle::brand_logos`
- PURPOSE: Brand => emblem URL, for catalog brands that have one.
- CALLED BY: `KMAE_Vehicle::catalog_payload`
- CALLS: `KMAE_Vehicle::brand_logo_slugs`
- READS: —
- WRITES: —
- RELATED FEATURE: `VEHICLE`, `MODERATION`, `TAXONOMY-LAUNCH`

## `KMAE_Vehicle::popular_brands`
- FILE: `includes/class-kmae-vehicle.php:394-395`
- SYMBOL: `KMAE_Vehicle::popular_brands`
- PURPOSE: Brands offered before the user types anything.
- CALLED BY: `KMAE_Vehicle::catalog_payload`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `VEHICLE`, `MODERATION`, `TAXONOMY-LAUNCH`

## `KMAE_Vehicle::catalog_payload`
- FILE: `includes/class-kmae-vehicle.php:403-409`
- SYMBOL: `KMAE_Vehicle::catalog_payload`
- PURPOSE: Catalog payload for the frontend picker.
- CALLED BY: `KMAE_Public::enqueue_vehicle_catalog`
- CALLS: `KMAE_Vehicle::brands`, `KMAE_Vehicle::catalog`, `KMAE_Vehicle::brand_logos`, `KMAE_Vehicle::popular_brands`
- READS: —
- WRITES: —
- RELATED FEATURE: `VEHICLE`, `MODERATION`, `TAXONOMY-LAUNCH`

## `KMAE_Vehicle::resolve_brand_key`
- FILE: `includes/class-kmae-vehicle.php:416-426`
- SYMBOL: `KMAE_Vehicle::resolve_brand_key`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Vehicle::models_for`, `KMAE_Vehicle::is_known_brand`
- CALLS: `KMAE_Vehicle::catalog`
- READS: —
- WRITES: —
- RELATED FEATURE: `VEHICLE`, `MODERATION`, `TAXONOMY-LAUNCH`

## `KMAE_Vehicle::get_specs`
- FILE: `includes/class-kmae-vehicle.php:429-446`
- SYMBOL: `KMAE_Vehicle::get_specs`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Vehicle::get_display_rows`, `KMAE_Vehicle::get_display_title`, `KMAE_Vehicle::get_swipe_subtitle`
- CALLS: `KMAE_Vehicle::get_vehicle_value`
- READS: `postmeta:_kmae_condition`, `postmeta:_kmae_condition_note`
- WRITES: —
- RELATED FEATURE: `VEHICLE`, `MODERATION`, `TAXONOMY-LAUNCH`

## `KMAE_Vehicle::posted_mot`
- FILE: `includes/class-kmae-vehicle.php:454-475`
- SYMBOL: `KMAE_Vehicle::posted_mot`
- PURPOSE: Műszaki érvényessége a beküldött mezőkből: "ÉÉÉÉ-HH", vagy üres.
- CALLED BY: `KMAE_Vehicle::save_from_post`, `KMAE_Vehicle::parse_post_data`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `VEHICLE`, `MODERATION`, `TAXONOMY-LAUNCH`
- POST KEYS: `kmae_vehicle_mot_day`, `kmae_vehicle_mot_has`, `kmae_vehicle_mot_month`, `kmae_vehicle_mot_year`

## `KMAE_Vehicle::kw_to_horsepower`
- FILE: `includes/class-kmae-vehicle.php:478-479`
- SYMBOL: `KMAE_Vehicle::kw_to_horsepower`
- PURPOSE: Műszaki érvényessége a beküldött mezőkből: "ÉÉÉÉ-HH", vagy üres.
- CALLED BY: —
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `VEHICLE`, `MODERATION`, `TAXONOMY-LAUNCH`

## `KMAE_Vehicle::horsepower_to_kw`
- FILE: `includes/class-kmae-vehicle.php:482-483`
- SYMBOL: `KMAE_Vehicle::horsepower_to_kw`
- PURPOSE: Műszaki érvényessége a beküldött mezőkből: "ÉÉÉÉ-HH", vagy üres.
- CALLED BY: `KMAE_Vehicle::posted_power_kw`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `VEHICLE`, `MODERATION`, `TAXONOMY-LAUNCH`

## `KMAE_Vehicle::posted_power_kw`
- FILE: `includes/class-kmae-vehicle.php:486-491`
- SYMBOL: `KMAE_Vehicle::posted_power_kw`
- PURPOSE: Műszaki érvényessége a beküldött mezőkből: "ÉÉÉÉ-HH", vagy üres.
- CALLED BY: `KMAE_Vehicle::save_from_post`, `KMAE_Vehicle::parse_post_data`
- CALLS: `KMAE_Vehicle::horsepower_to_kw`
- READS: —
- WRITES: —
- RELATED FEATURE: `VEHICLE`, `MODERATION`, `TAXONOMY-LAUNCH`
- POST KEYS: `kmae_vehicle_power_hp`, `kmae_vehicle_power_kw`

## `KMAE_Vehicle::save_from_post`
- FILE: `includes/class-kmae-vehicle.php:494-555`
- SYMBOL: `KMAE_Vehicle::save_from_post`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Listings::save_meta_from_post`, `KMAE_Meta::save_listing_meta`
- CALLS: `KMAE_Launch::get_launch_category_id`, `KMAE_Vehicle::is_vehicle_launch`, `KMAE_Vehicle::posted_power_kw`, `KMAE_Vehicle::posted_mot`, `KMAE_Vehicle::fuel_labels`, `KMAE_Vehicle::transmission_labels`, `KMAE_Vehicle::body_types`, `KMAE_Vehicle::traits`, `KMAE_Vehicle::condition_labels`
- READS: —
- WRITES: `postmeta:_kmae_condition`, `postmeta:_kmae_condition_note`
- RELATED FEATURE: `VEHICLE`, `MODERATION`, `TAXONOMY-LAUNCH`
- POST KEYS: `kmae_condition`, `kmae_condition_note`, `kmae_vehicle_body`, `kmae_vehicle_brand`, `kmae_vehicle_color`, `kmae_vehicle_engine_cc`, `kmae_vehicle_fuel`, `kmae_vehicle_mileage`, `kmae_vehicle_model`, `kmae_vehicle_owners`, `kmae_vehicle_traits`, `kmae_vehicle_transmission`, `kmae_vehicle_value`, `kmae_vehicle_year`

## `KMAE_Vehicle::get_missing_required`
- FILE: `includes/class-kmae-vehicle.php:561-604`
- SYMBOL: `KMAE_Vehicle::get_missing_required`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Moderation::validate`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `VEHICLE`, `MODERATION`, `TAXONOMY-LAUNCH`

## `KMAE_Vehicle::build_title_from_specs`
- FILE: `includes/class-kmae-vehicle.php:607-615`
- SYMBOL: `KMAE_Vehicle::build_title_from_specs`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: —
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `VEHICLE`, `MODERATION`, `TAXONOMY-LAUNCH`

## `KMAE_Vehicle::format_mileage`
- FILE: `includes/class-kmae-vehicle.php:618-622`
- SYMBOL: `KMAE_Vehicle::format_mileage`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Vehicle::get_display_rows`, `KMAE_Vehicle::get_swipe_subtitle`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `VEHICLE`, `MODERATION`, `TAXONOMY-LAUNCH`

## `KMAE_Vehicle::get_display_rows`
- FILE: `includes/class-kmae-vehicle.php:630-665`
- SYMBOL: `KMAE_Vehicle::get_display_rows`
- PURPOSE: Display rows for templates.
- CALLED BY: —
- CALLS: `KMAE_Vehicle::is_vehicle_launch`, `KMAE_Vehicle::get_specs`, `KMAE_Vehicle::format_mileage`, `KMAE_Vehicle::fuel_labels`, `KMAE_Vehicle::transmission_labels`, `KMAE_Vehicle::body_labels`, `KMAE_Vehicle::format_owners`, `KMAE_Vehicle::format_value`, `KMAE_Vehicle::condition_labels`, `KMAE_Vehicle::get_trait_labels`
- READS: —
- WRITES: —
- RELATED FEATURE: `VEHICLE`, `MODERATION`, `TAXONOMY-LAUNCH`

## `KMAE_Vehicle::get_display_title`
- FILE: `includes/class-kmae-vehicle.php:668-676`
- SYMBOL: `KMAE_Vehicle::get_display_title`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: —
- CALLS: `KMAE_Vehicle::get_specs`
- READS: —
- WRITES: —
- RELATED FEATURE: `VEHICLE`, `MODERATION`, `TAXONOMY-LAUNCH`

## `KMAE_Vehicle::get_swipe_subtitle`
- FILE: `includes/class-kmae-vehicle.php:679-688`
- SYMBOL: `KMAE_Vehicle::get_swipe_subtitle`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Admin::listing_column_content`, `KMAE_Dashboard::format_listing_row`
- CALLS: `KMAE_Vehicle::get_specs`, `KMAE_Vehicle::format_mileage`, `KMAE_Vehicle::fuel_labels`
- READS: —
- WRITES: —
- RELATED FEATURE: `VEHICLE`, `MODERATION`, `TAXONOMY-LAUNCH`

## `KMAE_Vehicle::parse_post_data`
- FILE: `includes/class-kmae-vehicle.php:691-710`
- SYMBOL: `KMAE_Vehicle::parse_post_data`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Public::admin_update_listing`, `KMAE_Public::process_create_listing`
- CALLS: `KMAE_Vehicle::posted_power_kw`, `KMAE_Vehicle::posted_mot`
- READS: —
- WRITES: —
- RELATED FEATURE: `VEHICLE`, `MODERATION`, `TAXONOMY-LAUNCH`
- POST KEYS: `kmae_condition`, `kmae_condition_note`, `kmae_description`, `kmae_title`, `kmae_vehicle_body`, `kmae_vehicle_brand`, `kmae_vehicle_color`, `kmae_vehicle_engine_cc`, `kmae_vehicle_fuel`, `kmae_vehicle_mileage`, `kmae_vehicle_model`, `kmae_vehicle_owners`, `kmae_vehicle_transmission`, `kmae_vehicle_value`, `kmae_vehicle_year`

## `kmae_run`
- FILE: `ki-mit-adna-erte.php:54-56`
- SYMBOL: `kmae_run`
- PURPOSE: Legacy codes kept only so previously stored offers remain readable.
- CALLED BY: —
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `BOOT-ARCHITECTURE`, `TAXONOMY-LAUNCH`

## `KMAE_Public::__construct`
- FILE: `public/class-kmae-public.php:14-40`
- SYMBOL: `KMAE_Public::__construct`
- PURPOSE: Frontend assets and form handlers.
- CALLED BY: —
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `LISTINGS`, `MODERATION`, `OFFERS`, `NEGOTIATION-CHAT`, `DEAL`, `CONTACT-UNLOCK`, `TRUST-RATINGS`, `LIVE-NAV`, `CONTACT-FORM`

## `KMAE_Public::enqueue`
- FILE: `public/class-kmae-public.php:43-171`
- SYMBOL: `KMAE_Public::enqueue`
- PURPOSE: Frontend assets and form handlers.
- CALLED BY: `WP action `wp_enqueue_scripts``
- CALLS: `KMAE_Vehicle::is_vehicle_launch`, `KMAE_Photo_Motor::client_config`, `KMAE_Counter_Offers::get_rounds_warning_message`, `KMAE_Public::is_register_page`, `KMAE_Public::should_enqueue_public_assets`, `KMAE_Public::is_create_listing_page`, `KMAE_Public::enqueue_vehicle_catalog`, `KMAE_Public::enqueue_listing_wizard`
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `LISTINGS`, `MODERATION`, `OFFERS`, `NEGOTIATION-CHAT`, `DEAL`, `CONTACT-UNLOCK`, `TRUST-RATINGS`, `LIVE-NAV`, `CONTACT-FORM`

## `KMAE_Public::is_create_listing_page`
- FILE: `public/class-kmae-public.php:179-185`
- SYMBOL: `KMAE_Public::is_create_listing_page`
- PURPOSE: Create / edit listing form page (logged-in users only).
- CALLED BY: `KMAE_Public::enqueue`, `KMAE_Public::enqueue_vehicle_catalog`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `LISTINGS`, `MODERATION`, `OFFERS`, `NEGOTIATION-CHAT`, `DEAL`, `CONTACT-UNLOCK`, `TRUST-RATINGS`, `LIVE-NAV`, `CONTACT-FORM`

## `KMAE_Public::enqueue_vehicle_catalog`
- FILE: `public/class-kmae-public.php:191-203`
- SYMBOL: `KMAE_Public::enqueue_vehicle_catalog`
- PURPOSE: Brand / model catalog picker for create and edit listing forms.
- CALLED BY: `KMAE_Public::enqueue`
- CALLS: `KMAE_Vehicle::catalog_payload`, `KMAE_Public::is_create_listing_page`
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `LISTINGS`, `MODERATION`, `OFFERS`, `NEGOTIATION-CHAT`, `DEAL`, `CONTACT-UNLOCK`, `TRUST-RATINGS`, `LIVE-NAV`, `CONTACT-FORM`

## `KMAE_Public::enqueue_listing_wizard`
- FILE: `public/class-kmae-public.php:209-265`
- SYMBOL: `KMAE_Public::enqueue_listing_wizard`
- PURPOSE: Guided create wizard: engine plus its phase and validation config.
- CALLED BY: `KMAE_Public::enqueue`
- CALLS: `KMAE_Listing_Wizard::phases`, `KMAE_Listing_Drafts::get_user_draft`, `KMAE_Listing_Drafts::get_latest_draft`, `KMAE_Listing_Drafts::to_client`, `KMAE_Moderation::is_enabled`, `KMAE_Listing_Wizard::description_progress_messages`, `KMAE_Listing_Wizard::assistant_intro`, `KMAE_Listing_Wizard::assistant_reactions`, `KMAE_Listing_Wizard::assistant_done`, `KMAE_Listing_Wizard::assistant_publish`
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `LISTINGS`, `MODERATION`, `OFFERS`, `NEGOTIATION-CHAT`, `DEAL`, `CONTACT-UNLOCK`, `TRUST-RATINGS`, `LIVE-NAV`, `CONTACT-FORM`
- GET KEYS: `kmae_draft`, `kmae_edit`, `kmae_mode`

## `KMAE_Public::should_enqueue_public_assets`
- FILE: `public/class-kmae-public.php:273-282`
- SYMBOL: `KMAE_Public::should_enqueue_public_assets`
- PURPOSE: Skip plugin public assets on Simple Mode guest marketing shell (theme owns layout).
- CALLED BY: `KMAE_Public::enqueue`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `LISTINGS`, `MODERATION`, `OFFERS`, `NEGOTIATION-CHAT`, `DEAL`, `CONTACT-UNLOCK`, `TRUST-RATINGS`, `LIVE-NAV`, `CONTACT-FORM`

## `KMAE_Public::is_register_page`
- FILE: `public/class-kmae-public.php:285-292`
- SYMBOL: `KMAE_Public::is_register_page`
- PURPOSE: Skip plugin public assets on Simple Mode guest marketing shell (theme owns layout).
- CALLED BY: `KMAE_Public::enqueue`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `LISTINGS`, `MODERATION`, `OFFERS`, `NEGOTIATION-CHAT`, `DEAL`, `CONTACT-UNLOCK`, `TRUST-RATINGS`, `LIVE-NAV`, `CONTACT-FORM`

## `KMAE_Public::block_nonpublic_listings`
- FILE: `public/class-kmae-public.php:298-315`
- SYMBOL: `KMAE_Public::block_nonpublic_listings`
- PURPOSE: Hide awaiting-photos listings from non-owners.
- CALLED BY: `WP action `template_redirect``
- CALLS: `KMAE_Meta::get_status`
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `LISTINGS`, `MODERATION`, `OFFERS`, `NEGOTIATION-CHAT`, `DEAL`, `CONTACT-UNLOCK`, `TRUST-RATINGS`, `LIVE-NAV`, `CONTACT-FORM`

## `KMAE_Public::ajax_browse_pass`
- FILE: `public/class-kmae-public.php:318-331`
- SYMBOL: `KMAE_Public::ajax_browse_pass`
- PURPOSE: Hide awaiting-photos listings from non-owners.
- CALLED BY: `WP action `wp_ajax_kmae_browse_pass``
- CALLS: `KMAE_Browse::record_pass`
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `LISTINGS`, `MODERATION`, `OFFERS`, `NEGOTIATION-CHAT`, `DEAL`, `CONTACT-UNLOCK`, `TRUST-RATINGS`, `LIVE-NAV`, `CONTACT-FORM`
- POST KEYS: `listing_id`

## `KMAE_Public::ajax_poll_page`
- FILE: `public/class-kmae-public.php:334-358`
- SYMBOL: `KMAE_Public::ajax_poll_page`
- PURPOSE: Hide awaiting-photos listings from non-owners.
- CALLED BY: `WP action `wp_ajax_kmae_poll_page``
- CALLS: `KMAE_Live_Page::get_fingerprint`, `KMAE_Database::count_unseen_offer_activity`
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `LISTINGS`, `MODERATION`, `OFFERS`, `NEGOTIATION-CHAT`, `DEAL`, `CONTACT-UNLOCK`, `TRUST-RATINGS`, `LIVE-NAV`, `CONTACT-FORM`
- POST KEYS: `context`, `listing_id`, `offer_id`

## `KMAE_Public::render_rounds_modal`
- FILE: `public/class-kmae-public.php:361-378`
- SYMBOL: `KMAE_Public::render_rounds_modal`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `WP action `wp_footer``
- CALLS: `KMAE_Icons::render`
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `LISTINGS`, `MODERATION`, `OFFERS`, `NEGOTIATION-CHAT`, `DEAL`, `CONTACT-UNLOCK`, `TRUST-RATINGS`, `LIVE-NAV`, `CONTACT-FORM`

## `KMAE_Public::handle_forms`
- FILE: `public/class-kmae-public.php:380-433`
- SYMBOL: `KMAE_Public::handle_forms`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `WP action `init``
- CALLS: `KMAE_Auth::should_gate_for_verification`, `KMAE_Public::process_create_listing`, `KMAE_Public::process_cash_offer`, `KMAE_Public::process_counter_offer`, `KMAE_Public::process_revise_offer`, `KMAE_Public::process_accept_offer`, `KMAE_Public::process_deal_success`, `KMAE_Public::process_deal_failure`, `KMAE_Public::process_withdraw_offer`, `KMAE_Public::process_unlock_contact`
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `LISTINGS`, `MODERATION`, `OFFERS`, `NEGOTIATION-CHAT`, `DEAL`, `CONTACT-UNLOCK`, `TRUST-RATINGS`, `LIVE-NAV`, `CONTACT-FORM`
- POST KEYS: `kmae_action`

## `KMAE_Public::verify_nonce`
- FILE: `public/class-kmae-public.php:436-437`
- SYMBOL: `KMAE_Public::verify_nonce`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Public::process_create_listing`, `KMAE_Public::process_cash_offer`, `KMAE_Public::process_counter_offer`, `KMAE_Public::process_revise_offer`, `KMAE_Public::process_accept_offer`, `KMAE_Public::process_deal_success`, `KMAE_Public::process_deal_failure`, `KMAE_Public::process_withdraw_offer`, `KMAE_Public::process_unlock_contact`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `LISTINGS`, `MODERATION`, `OFFERS`, `NEGOTIATION-CHAT`, `DEAL`, `CONTACT-UNLOCK`, `TRUST-RATINGS`, `LIVE-NAV`, `CONTACT-FORM`

## `KMAE_Public::verify_nonce_action`
- FILE: `public/class-kmae-public.php:440-441`
- SYMBOL: `KMAE_Public::verify_nonce_action`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Public::admin_save_profile`, `KMAE_Public::admin_save_settings`, `KMAE_Public::admin_change_email`, `KMAE_Public::admin_change_password`, `KMAE_Public::admin_logout_everywhere`, `KMAE_Public::admin_submit_rating`, `KMAE_Public::admin_continue_shopping`, `KMAE_Public::admin_login`, `KMAE_Public::admin_register`, `KMAE_Public::admin_lost_password`, `KMAE_Public::admin_reset_password`, `KMAE_Public::admin_contact_form`, `KMAE_Public::admin_update_listing`, `KMAE_Public::admin_delete_listing`, `KMAE_Public::admin_reactivate_listing`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `LISTINGS`, `MODERATION`, `OFFERS`, `NEGOTIATION-CHAT`, `DEAL`, `CONTACT-UNLOCK`, `TRUST-RATINGS`, `LIVE-NAV`, `CONTACT-FORM`

## `KMAE_Public::get_profile_redirect_url`
- FILE: `public/class-kmae-public.php:444-448`
- SYMBOL: `KMAE_Public::get_profile_redirect_url`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Public::redirect_profile`, `KMAE_Public::admin_save_profile`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `LISTINGS`, `MODERATION`, `OFFERS`, `NEGOTIATION-CHAT`, `DEAL`, `CONTACT-UNLOCK`, `TRUST-RATINGS`, `LIVE-NAV`, `CONTACT-FORM`
- POST KEYS: `kmae_redirect`

## `KMAE_Public::redirect_profile`
- FILE: `public/class-kmae-public.php:451-454`
- SYMBOL: `KMAE_Public::redirect_profile`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Public::admin_save_profile`, `KMAE_Public::admin_submit_rating`, `KMAE_Public::admin_continue_shopping`
- CALLS: `KMAE_Public::get_profile_redirect_url`
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `LISTINGS`, `MODERATION`, `OFFERS`, `NEGOTIATION-CHAT`, `DEAL`, `CONTACT-UNLOCK`, `TRUST-RATINGS`, `LIVE-NAV`, `CONTACT-FORM`

## `KMAE_Public::admin_save_profile`
- FILE: `public/class-kmae-public.php:457-508`
- SYMBOL: `KMAE_Public::admin_save_profile`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `WP action `admin_post_kmae_save_profile``
- CALLS: `KMAE_Auth::normalize_phone`, `KMAE_Auth::sync_phone`, `KMAE_Auth::is_company`, `KMAE_Company::save_profile_fields`, `KMAE_Public::get_profile_redirect_url`, `KMAE_Public::verify_nonce_action`, `KMAE_Public::redirect_profile`
- READS: —
- WRITES: `usermeta:kmae_phone`
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `LISTINGS`, `MODERATION`, `OFFERS`, `NEGOTIATION-CHAT`, `DEAL`, `CONTACT-UNLOCK`, `TRUST-RATINGS`, `LIVE-NAV`, `CONTACT-FORM`
- POST KEYS: `kmae_company_address`, `kmae_company_city`, `kmae_company_county`, `kmae_company_name`, `kmae_company_tax_id`, `kmae_display_name`, `kmae_phone`

## `KMAE_Public::get_settings_redirect_url`
- FILE: `public/class-kmae-public.php:515-519`
- SYMBOL: `KMAE_Public::get_settings_redirect_url`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Public::redirect_settings`, `KMAE_Public::require_settings_login`
- CALLS: `KMAE_Pages::url`
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `LISTINGS`, `MODERATION`, `OFFERS`, `NEGOTIATION-CHAT`, `DEAL`, `CONTACT-UNLOCK`, `TRUST-RATINGS`, `LIVE-NAV`, `CONTACT-FORM`
- POST KEYS: `kmae_redirect`

## `KMAE_Public::redirect_settings`
- FILE: `public/class-kmae-public.php:526-529`
- SYMBOL: `KMAE_Public::redirect_settings`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Public::admin_save_settings`, `KMAE_Public::admin_change_email`, `KMAE_Public::admin_change_password`, `KMAE_Public::admin_logout_everywhere`
- CALLS: `KMAE_Public::get_settings_redirect_url`
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `LISTINGS`, `MODERATION`, `OFFERS`, `NEGOTIATION-CHAT`, `DEAL`, `CONTACT-UNLOCK`, `TRUST-RATINGS`, `LIVE-NAV`, `CONTACT-FORM`

## `KMAE_Public::require_settings_login`
- FILE: `public/class-kmae-public.php:532-536`
- SYMBOL: `KMAE_Public::require_settings_login`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Public::admin_save_settings`, `KMAE_Public::admin_change_email`, `KMAE_Public::admin_change_password`, `KMAE_Public::admin_logout_everywhere`
- CALLS: `KMAE_Public::get_settings_redirect_url`
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `LISTINGS`, `MODERATION`, `OFFERS`, `NEGOTIATION-CHAT`, `DEAL`, `CONTACT-UNLOCK`, `TRUST-RATINGS`, `LIVE-NAV`, `CONTACT-FORM`

## `KMAE_Public::admin_save_settings`
- FILE: `public/class-kmae-public.php:539-552`
- SYMBOL: `KMAE_Public::admin_save_settings`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `WP action `admin_post_kmae_save_settings``
- CALLS: `KMAE_Auth::save_email_prefs`, `KMAE_Public::require_settings_login`, `KMAE_Public::verify_nonce_action`, `KMAE_Public::redirect_settings`
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `LISTINGS`, `MODERATION`, `OFFERS`, `NEGOTIATION-CHAT`, `DEAL`, `CONTACT-UNLOCK`, `TRUST-RATINGS`, `LIVE-NAV`, `CONTACT-FORM`
- POST KEYS: `kmae_email_news`, `kmae_email_offers`

## `KMAE_Public::admin_change_email`
- FILE: `public/class-kmae-public.php:555-594`
- SYMBOL: `KMAE_Public::admin_change_email`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `WP action `admin_post_kmae_change_email``
- CALLS: `KMAE_Public::require_settings_login`, `KMAE_Public::verify_nonce_action`, `KMAE_Public::redirect_settings`
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `LISTINGS`, `MODERATION`, `OFFERS`, `NEGOTIATION-CHAT`, `DEAL`, `CONTACT-UNLOCK`, `TRUST-RATINGS`, `LIVE-NAV`, `CONTACT-FORM`
- POST KEYS: `kmae_current_password`, `kmae_new_email`

## `KMAE_Public::admin_change_password`
- FILE: `public/class-kmae-public.php:597-628`
- SYMBOL: `KMAE_Public::admin_change_password`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `WP action `admin_post_kmae_change_password``
- CALLS: `KMAE_Public::require_settings_login`, `KMAE_Public::verify_nonce_action`, `KMAE_Public::redirect_settings`
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `LISTINGS`, `MODERATION`, `OFFERS`, `NEGOTIATION-CHAT`, `DEAL`, `CONTACT-UNLOCK`, `TRUST-RATINGS`, `LIVE-NAV`, `CONTACT-FORM`
- POST KEYS: `kmae_current_password`, `kmae_new_password`, `kmae_new_password_repeat`

## `KMAE_Public::admin_logout_everywhere`
- FILE: `public/class-kmae-public.php:631-641`
- SYMBOL: `KMAE_Public::admin_logout_everywhere`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `WP action `admin_post_kmae_logout_everywhere``
- CALLS: `KMAE_Public::require_settings_login`, `KMAE_Public::verify_nonce_action`, `KMAE_Public::redirect_settings`
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `LISTINGS`, `MODERATION`, `OFFERS`, `NEGOTIATION-CHAT`, `DEAL`, `CONTACT-UNLOCK`, `TRUST-RATINGS`, `LIVE-NAV`, `CONTACT-FORM`

## `KMAE_Public::admin_submit_rating`
- FILE: `public/class-kmae-public.php:644-670`
- SYMBOL: `KMAE_Public::admin_submit_rating`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `WP action `admin_post_kmae_submit_rating``
- CALLS: `KMAE_Trust::submit`, `KMAE_Public::verify_nonce_action`, `KMAE_Public::redirect_profile`
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `LISTINGS`, `MODERATION`, `OFFERS`, `NEGOTIATION-CHAT`, `DEAL`, `CONTACT-UNLOCK`, `TRUST-RATINGS`, `LIVE-NAV`, `CONTACT-FORM`
- POST KEYS: `kmae_criteria`, `kmae_deal_ok`, `kmae_offer_id`, `kmae_overall`, `kmae_rating_comment`

## `KMAE_Public::admin_continue_shopping`
- FILE: `public/class-kmae-public.php:673-703`
- SYMBOL: `KMAE_Public::admin_continue_shopping`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `WP action `admin_post_kmae_continue_shopping``
- CALLS: `KMAE_Deal::continue_shopping`, `KMAE_Deal::stop_shopping`, `KMAE_Public::verify_nonce_action`, `KMAE_Public::redirect_profile`
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `LISTINGS`, `MODERATION`, `OFFERS`, `NEGOTIATION-CHAT`, `DEAL`, `CONTACT-UNLOCK`, `TRUST-RATINGS`, `LIVE-NAV`, `CONTACT-FORM`
- POST KEYS: `kmae_choice`

## `KMAE_Public::admin_login`
- FILE: `public/class-kmae-public.php:706-729`
- SYMBOL: `KMAE_Public::admin_login`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `WP action `admin_post_kmae_login``, `WP action `admin_post_nopriv_kmae_login``
- CALLS: `KMAE_Auth::login_url`, `KMAE_Auth::login`, `KMAE_Public::verify_nonce_action`
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `LISTINGS`, `MODERATION`, `OFFERS`, `NEGOTIATION-CHAT`, `DEAL`, `CONTACT-UNLOCK`, `TRUST-RATINGS`, `LIVE-NAV`, `CONTACT-FORM`
- POST KEYS: `kmae_login_email`, `kmae_login_password`, `kmae_redirect`, `kmae_remember`

## `KMAE_Public::client_ip`
- FILE: `public/class-kmae-public.php:737-739`
- SYMBOL: `KMAE_Public::client_ip`
- PURPOSE: A regisztráló IP-címe. Csak korlátozáshoz használjuk, nem tároljuk.
- CALLED BY: `KMAE_Public::register_spam_check`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `LISTINGS`, `MODERATION`, `OFFERS`, `NEGOTIATION-CHAT`, `DEAL`, `CONTACT-UNLOCK`, `TRUST-RATINGS`, `LIVE-NAV`, `CONTACT-FORM`

## `KMAE_Public::register_spam_check`
- FILE: `public/class-kmae-public.php:750-778`
- SYMBOL: `KMAE_Public::register_spam_check`
- PURPOSE: Botszűrés a regisztrációnál. Három egymástól független ellenőrzés.
- CALLED BY: `KMAE_Public::admin_register`
- CALLS: `KMAE_Public::client_ip`
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `LISTINGS`, `MODERATION`, `OFFERS`, `NEGOTIATION-CHAT`, `DEAL`, `CONTACT-UNLOCK`, `TRUST-RATINGS`, `LIVE-NAV`, `CONTACT-FORM`
- POST KEYS: `kmae_form_time`, `kmae_form_token`, `kmae_website`

## `KMAE_Public::admin_register`
- FILE: `public/class-kmae-public.php:781-822`
- SYMBOL: `KMAE_Public::admin_register`
- PURPOSE: Botszűrés a regisztrációnál. Három egymástól független ellenőrzés.
- CALLED BY: `WP action `admin_post_kmae_register``, `WP action `admin_post_nopriv_kmae_register``
- CALLS: `KMAE_Auth::register_url`, `KMAE_Auth::register`, `KMAE_Auth::login_url`, `KMAE_Public::verify_nonce_action`, `KMAE_Public::register_spam_check`
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `LISTINGS`, `MODERATION`, `OFFERS`, `NEGOTIATION-CHAT`, `DEAL`, `CONTACT-UNLOCK`, `TRUST-RATINGS`, `LIVE-NAV`, `CONTACT-FORM`
- POST KEYS: `kmae_account_type`, `kmae_company_address`, `kmae_company_city`, `kmae_company_county`, `kmae_company_name`, `kmae_company_tax_id`, `kmae_display_name`, `kmae_email`, `kmae_email_news`, `kmae_email_offers`, `kmae_password`, `kmae_password_confirm`, `kmae_phone`, `kmae_terms`

## `KMAE_Public::admin_lost_password`
- FILE: `public/class-kmae-public.php:825-840`
- SYMBOL: `KMAE_Public::admin_lost_password`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `WP action `admin_post_kmae_lost_password``, `WP action `admin_post_nopriv_kmae_lost_password``
- CALLS: `KMAE_Auth::lost_password_url`, `KMAE_Auth::request_password_reset`, `KMAE_Auth::login_url`, `KMAE_Public::verify_nonce_action`
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `LISTINGS`, `MODERATION`, `OFFERS`, `NEGOTIATION-CHAT`, `DEAL`, `CONTACT-UNLOCK`, `TRUST-RATINGS`, `LIVE-NAV`, `CONTACT-FORM`
- POST KEYS: `kmae_email`

## `KMAE_Public::admin_reset_password`
- FILE: `public/class-kmae-public.php:843-862`
- SYMBOL: `KMAE_Public::admin_reset_password`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `WP action `admin_post_kmae_reset_password``, `WP action `admin_post_nopriv_kmae_reset_password``
- CALLS: `KMAE_Auth::lost_password_url`, `KMAE_Auth::reset_password_with_key`, `KMAE_Auth::reset_password_url`, `KMAE_Auth::login_url`, `KMAE_Public::verify_nonce_action`
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `LISTINGS`, `MODERATION`, `OFFERS`, `NEGOTIATION-CHAT`, `DEAL`, `CONTACT-UNLOCK`, `TRUST-RATINGS`, `LIVE-NAV`, `CONTACT-FORM`
- POST KEYS: `kmae_password`, `kmae_password_confirm`, `kmae_reset_key`, `kmae_reset_login`

## `KMAE_Public::admin_contact_form`
- FILE: `public/class-kmae-public.php:868-968`
- SYMBOL: `KMAE_Public::admin_contact_form`
- PURPOSE: Public contact form → email inbox.
- CALLED BY: `WP action `admin_post_kmae_contact_form``, `WP action `admin_post_nopriv_kmae_contact_form``
- CALLS: `KMAE_Pages::url`, `KMAE_Settings::contact_form_email`, `KMAE_Brand::send_mail`, `KMAE_Public::verify_nonce_action`
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `LISTINGS`, `MODERATION`, `OFFERS`, `NEGOTIATION-CHAT`, `DEAL`, `CONTACT-UNLOCK`, `TRUST-RATINGS`, `LIVE-NAV`, `CONTACT-FORM`
- POST KEYS: `kmae_contact_email`, `kmae_contact_message`, `kmae_contact_name`, `kmae_contact_topic`, `kmae_website`

## `KMAE_Public::get_listings_redirect_url`
- FILE: `public/class-kmae-public.php:971-972`
- SYMBOL: `KMAE_Public::get_listings_redirect_url`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Public::admin_update_listing`, `KMAE_Public::admin_delete_listing`, `KMAE_Public::admin_reactivate_listing`
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `LISTINGS`, `MODERATION`, `OFFERS`, `NEGOTIATION-CHAT`, `DEAL`, `CONTACT-UNLOCK`, `TRUST-RATINGS`, `LIVE-NAV`, `CONTACT-FORM`

## `KMAE_Public::admin_update_listing`
- FILE: `public/class-kmae-public.php:975-1096`
- SYMBOL: `KMAE_Public::admin_update_listing`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `WP action `admin_post_kmae_update_listing``
- CALLS: `KMAE_Listings::user_owns_listing`, `KMAE_Listings::can_edit_listing`, `KMAE_Auth::is_company`, `KMAE_Company::get_county`, `KMAE_Company::get_city`, `KMAE_Counties::validate_listing_location`, `KMAE_Meta::get_status`, `KMAE_Moderation::is_enabled`, `KMAE_Vehicle::parse_post_data`, `KMAE_Query::get_gallery_ids`, `KMAE_Moderation::count_uploaded_images`, `KMAE_Moderation::validate`, `KMAE_Moderation::stash_errors_for_user`, `KMAE_Listings::save_meta_from_post`, `KMAE_Photo_Motor::is_enabled` +9 more
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `LISTINGS`, `MODERATION`, `OFFERS`, `NEGOTIATION-CHAT`, `DEAL`, `CONTACT-UNLOCK`, `TRUST-RATINGS`, `LIVE-NAV`, `CONTACT-FORM`
- POST KEYS: `kmae_city`, `kmae_county`, `kmae_description`, `kmae_listing_id`, `kmae_redirect`, `kmae_title`

## `KMAE_Public::admin_delete_listing`
- FILE: `public/class-kmae-public.php:1099-1124`
- SYMBOL: `KMAE_Public::admin_delete_listing`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `WP action `admin_post_kmae_delete_listing``
- CALLS: `KMAE_Listings::can_delete_listing`, `KMAE_Listings::delete_listing`, `KMAE_Public::get_listings_redirect_url`, `KMAE_Public::verify_nonce_action`
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `LISTINGS`, `MODERATION`, `OFFERS`, `NEGOTIATION-CHAT`, `DEAL`, `CONTACT-UNLOCK`, `TRUST-RATINGS`, `LIVE-NAV`, `CONTACT-FORM`
- POST KEYS: `kmae_listing_id`

## `KMAE_Public::admin_reactivate_listing`
- FILE: `public/class-kmae-public.php:1127-1147`
- SYMBOL: `KMAE_Public::admin_reactivate_listing`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `WP action `admin_post_kmae_reactivate_listing``
- CALLS: `KMAE_Listings::reactivate_listing`, `KMAE_Public::get_listings_redirect_url`, `KMAE_Public::verify_nonce_action`
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `LISTINGS`, `MODERATION`, `OFFERS`, `NEGOTIATION-CHAT`, `DEAL`, `CONTACT-UNLOCK`, `TRUST-RATINGS`, `LIVE-NAV`, `CONTACT-FORM`
- POST KEYS: `kmae_listing_id`

## `KMAE_Public::process_create_listing`
- FILE: `public/class-kmae-public.php:1150-1270`
- SYMBOL: `KMAE_Public::process_create_listing`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Public::handle_forms`
- CALLS: `KMAE_Seller::can_create_listing`, `KMAE_Auth::is_company`, `KMAE_Company::get_county`, `KMAE_Company::get_city`, `KMAE_Counties::validate_listing_location`, `KMAE_Photo_Motor::is_enabled`, `KMAE_Vehicle::parse_post_data`, `KMAE_Moderation::count_uploaded_images`, `KMAE_Moderation::validate`, `KMAE_Moderation::stash_errors_for_user`, `KMAE_Photo_Motor::validate_request`, `KMAE_Listings::save_meta_from_post`, `KMAE_Listing_Drafts::discard_submitted`, `KMAE_Listings::handle_image_uploads`, `KMAE_Photo_Motor::count_required_filled` +2 more
- READS: —
- WRITES: `postmeta:_kmae_create_device`
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `LISTINGS`, `MODERATION`, `OFFERS`, `NEGOTIATION-CHAT`, `DEAL`, `CONTACT-UNLOCK`, `TRUST-RATINGS`, `LIVE-NAV`, `CONTACT-FORM`
- POST KEYS: `kmae_city`, `kmae_county`, `kmae_create_device`, `kmae_description`, `kmae_price_mode`, `kmae_title`
- EMITS: `kmae_listing_published`

## `KMAE_Public::process_cash_offer`
- FILE: `public/class-kmae-public.php:1273-1289`
- SYMBOL: `KMAE_Public::process_cash_offer`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Public::handle_forms`
- CALLS: `KMAE_Offers::parse_amount_input`, `KMAE_Offers::submit_cash_offer`, `KMAE_Public::verify_nonce`
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `LISTINGS`, `MODERATION`, `OFFERS`, `NEGOTIATION-CHAT`, `DEAL`, `CONTACT-UNLOCK`, `TRUST-RATINGS`, `LIVE-NAV`, `CONTACT-FORM`
- POST KEYS: `kmae_cash_amount`, `kmae_listing_id`

## `KMAE_Public::process_counter_offer`
- FILE: `public/class-kmae-public.php:1292-1314`
- SYMBOL: `KMAE_Public::process_counter_offer`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Public::handle_forms`
- CALLS: `KMAE_Offers::parse_amount_input`, `KMAE_Counter_Offers::submit_seller_counter`, `KMAE_Public::verify_nonce`
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `LISTINGS`, `MODERATION`, `OFFERS`, `NEGOTIATION-CHAT`, `DEAL`, `CONTACT-UNLOCK`, `TRUST-RATINGS`, `LIVE-NAV`, `CONTACT-FORM`
- POST KEYS: `kmae_counter_amount`, `kmae_offer_id`, `kmae_template_code`

## `KMAE_Public::process_revise_offer`
- FILE: `public/class-kmae-public.php:1317-1333`
- SYMBOL: `KMAE_Public::process_revise_offer`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Public::handle_forms`
- CALLS: `KMAE_Offers::parse_amount_input`, `KMAE_Counter_Offers::submit_buyer_revision`, `KMAE_Public::verify_nonce`
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `LISTINGS`, `MODERATION`, `OFFERS`, `NEGOTIATION-CHAT`, `DEAL`, `CONTACT-UNLOCK`, `TRUST-RATINGS`, `LIVE-NAV`, `CONTACT-FORM`
- POST KEYS: `kmae_cash_amount`, `kmae_offer_id`

## `KMAE_Public::process_accept_offer`
- FILE: `public/class-kmae-public.php:1336-1350`
- SYMBOL: `KMAE_Public::process_accept_offer`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Public::handle_forms`
- CALLS: `KMAE_Counter_Offers::accept_offer`, `KMAE_Public::verify_nonce`
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `LISTINGS`, `MODERATION`, `OFFERS`, `NEGOTIATION-CHAT`, `DEAL`, `CONTACT-UNLOCK`, `TRUST-RATINGS`, `LIVE-NAV`, `CONTACT-FORM`
- POST KEYS: `kmae_offer_id`

## `KMAE_Public::process_deal_success`
- FILE: `public/class-kmae-public.php:1353-1367`
- SYMBOL: `KMAE_Public::process_deal_success`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Public::handle_forms`
- CALLS: `KMAE_Deal::confirm_success`, `KMAE_Trust::rate_url`, `KMAE_Public::verify_nonce`
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `LISTINGS`, `MODERATION`, `OFFERS`, `NEGOTIATION-CHAT`, `DEAL`, `CONTACT-UNLOCK`, `TRUST-RATINGS`, `LIVE-NAV`, `CONTACT-FORM`
- POST KEYS: `kmae_offer_id`

## `KMAE_Public::process_deal_failure`
- FILE: `public/class-kmae-public.php:1370-1384`
- SYMBOL: `KMAE_Public::process_deal_failure`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Public::handle_forms`
- CALLS: `KMAE_Deal::confirm_failure`, `KMAE_Public::verify_nonce`
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `LISTINGS`, `MODERATION`, `OFFERS`, `NEGOTIATION-CHAT`, `DEAL`, `CONTACT-UNLOCK`, `TRUST-RATINGS`, `LIVE-NAV`, `CONTACT-FORM`
- POST KEYS: `kmae_offer_id`

## `KMAE_Public::process_withdraw_offer`
- FILE: `public/class-kmae-public.php:1387-1401`
- SYMBOL: `KMAE_Public::process_withdraw_offer`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Public::handle_forms`
- CALLS: `KMAE_Offers::withdraw_offer`, `KMAE_Public::verify_nonce`
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `LISTINGS`, `MODERATION`, `OFFERS`, `NEGOTIATION-CHAT`, `DEAL`, `CONTACT-UNLOCK`, `TRUST-RATINGS`, `LIVE-NAV`, `CONTACT-FORM`
- POST KEYS: `kmae_offer_id`

## `KMAE_Public::process_unlock_contact`
- FILE: `public/class-kmae-public.php:1404-1418`
- SYMBOL: `KMAE_Public::process_unlock_contact`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Public::handle_forms`
- CALLS: `KMAE_Contact::unlock`, `KMAE_Public::verify_nonce`
- READS: —
- WRITES: —
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`, `PROFILE-COMPANY-SETTINGS`, `LISTINGS`, `MODERATION`, `OFFERS`, `NEGOTIATION-CHAT`, `DEAL`, `CONTACT-UNLOCK`, `TRUST-RATINGS`, `LIVE-NAV`, `CONTACT-FORM`
- POST KEYS: `kmae_offer_id`

## `KMAE_Shortcodes::__construct`
- FILE: `public/class-kmae-shortcodes.php:14-39`
- SYMBOL: `KMAE_Shortcodes::__construct`
- PURPOSE: Frontend shortcodes.
- CALLED BY: —
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `PAGES-ROUTING`, `BROWSE-SEARCH`, `DASHBOARD-HUBS`

## `KMAE_Shortcodes::require_login`
- FILE: `public/class-kmae-shortcodes.php:42-57`
- SYMBOL: `KMAE_Shortcodes::require_login`
- PURPOSE: Frontend shortcodes.
- CALLED BY: `KMAE_Shortcodes::my_listings`, `KMAE_Shortcodes::my_offers`, `KMAE_Shortcodes::profile`, `KMAE_Shortcodes::settings`, `KMAE_Shortcodes::notifications`, `KMAE_Shortcodes::messages`, `KMAE_Shortcodes::render_hub_section`
- CALLS: `KMAE_Auth::login_url`, `KMAE_Auth::register_url`
- READS: —
- WRITES: —
- RELATED FEATURE: `PAGES-ROUTING`, `BROWSE-SEARCH`, `DASHBOARD-HUBS`

## `KMAE_Shortcodes::login`
- FILE: `public/class-kmae-shortcodes.php:60-63`
- SYMBOL: `KMAE_Shortcodes::login`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `shortcode `[kmae_login]``
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `PAGES-ROUTING`, `BROWSE-SEARCH`, `DASHBOARD-HUBS`

## `KMAE_Shortcodes::register`
- FILE: `public/class-kmae-shortcodes.php:66-69`
- SYMBOL: `KMAE_Shortcodes::register`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `shortcode `[kmae_register]``
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `PAGES-ROUTING`, `BROWSE-SEARCH`, `DASHBOARD-HUBS`

## `KMAE_Shortcodes::hero`
- FILE: `public/class-kmae-shortcodes.php:72-75`
- SYMBOL: `KMAE_Shortcodes::hero`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Shortcodes::landing`, `shortcode `[kmae_hero]``
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `PAGES-ROUTING`, `BROWSE-SEARCH`, `DASHBOARD-HUBS`

## `KMAE_Shortcodes::landing_features`
- FILE: `public/class-kmae-shortcodes.php:78-81`
- SYMBOL: `KMAE_Shortcodes::landing_features`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Shortcodes::landing`, `shortcode `[kmae_landing_features]``
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `PAGES-ROUTING`, `BROWSE-SEARCH`, `DASHBOARD-HUBS`

## `KMAE_Shortcodes::landing_search`
- FILE: `public/class-kmae-shortcodes.php:84-87`
- SYMBOL: `KMAE_Shortcodes::landing_search`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Shortcodes::landing`, `shortcode `[kmae_landing_search]``
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `PAGES-ROUTING`, `BROWSE-SEARCH`, `DASHBOARD-HUBS`

## `KMAE_Shortcodes::landing_popular`
- FILE: `public/class-kmae-shortcodes.php:90-93`
- SYMBOL: `KMAE_Shortcodes::landing_popular`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Shortcodes::landing`, `shortcode `[kmae_landing_popular]``
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `PAGES-ROUTING`, `BROWSE-SEARCH`, `DASHBOARD-HUBS`

## `KMAE_Shortcodes::landing`
- FILE: `public/class-kmae-shortcodes.php:96-102`
- SYMBOL: `KMAE_Shortcodes::landing`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `shortcode `[kmae_landing]``
- CALLS: `KMAE_Shortcodes::hero`, `KMAE_Shortcodes::landing_search`, `KMAE_Shortcodes::landing_popular`, `KMAE_Shortcodes::landing_features`
- READS: —
- WRITES: —
- RELATED FEATURE: `PAGES-ROUTING`, `BROWSE-SEARCH`, `DASHBOARD-HUBS`

## `KMAE_Shortcodes::create_listing`
- FILE: `public/class-kmae-shortcodes.php:105-138`
- SYMBOL: `KMAE_Shortcodes::create_listing`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `shortcode `[kmae_create_listing]``
- CALLS: `KMAE_Auth::should_gate_for_verification`, `KMAE_Listings::user_owns_listing`, `KMAE_Listings::can_edit_listing`
- READS: —
- WRITES: —
- RELATED FEATURE: `PAGES-ROUTING`, `BROWSE-SEARCH`, `DASHBOARD-HUBS`
- GET KEYS: `kmae_edit`

## `KMAE_Shortcodes::my_listings`
- FILE: `public/class-kmae-shortcodes.php:141-167`
- SYMBOL: `KMAE_Shortcodes::my_listings`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `shortcode `[kmae_my_listings]``
- CALLS: `KMAE_Meta::get_status`, `KMAE_Shortcodes::require_login`
- READS: —
- WRITES: —
- RELATED FEATURE: `PAGES-ROUTING`, `BROWSE-SEARCH`, `DASHBOARD-HUBS`

## `KMAE_Shortcodes::browse`
- FILE: `public/class-kmae-shortcodes.php:170-258`
- SYMBOL: `KMAE_Shortcodes::browse`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `shortcode `[kmae_browse]``
- CALLS: `KMAE_Vehicle::is_vehicle_launch`, `KMAE_Query::get_listings`, `KMAE_Counties::is_valid`, `KMAE_Launch::should_skip_category_wizard`, `KMAE_Launch::category_slug`, `KMAE_Shortcodes::get_browse_base_url`, `KMAE_Shortcodes::browse_vehicle_wizard`
- READS: —
- WRITES: —
- RELATED FEATURE: `PAGES-ROUTING`, `BROWSE-SEARCH`, `DASHBOARD-HUBS`
- GET KEYS: `kategoria`, `megye`, `tipus`

## `KMAE_Shortcodes::browse_vehicle_wizard`
- FILE: `public/class-kmae-shortcodes.php:261-314`
- SYMBOL: `KMAE_Shortcodes::browse_vehicle_wizard`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Shortcodes::browse`
- CALLS: `KMAE_Browse::parse_wizard_params`, `KMAE_Counties::is_valid`, `KMAE_Browse::is_wizard_complete`, `KMAE_Browse::bodies_to_query_value`, `KMAE_Query::get_listings`, `KMAE_Browse::filter_by_wizard`
- READS: —
- WRITES: —
- RELATED FEATURE: `PAGES-ROUTING`, `BROWSE-SEARCH`, `DASHBOARD-HUBS`
- GET KEYS: `step`

## `KMAE_Shortcodes::get_browse_base_url`
- FILE: `public/class-kmae-shortcodes.php:317-318`
- SYMBOL: `KMAE_Shortcodes::get_browse_base_url`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `KMAE_Shortcodes::browse`
- CALLS: `KMAE_Pages::browse_page_url`
- READS: —
- WRITES: —
- RELATED FEATURE: `PAGES-ROUTING`, `BROWSE-SEARCH`, `DASHBOARD-HUBS`

## `KMAE_Shortcodes::my_offers`
- FILE: `public/class-kmae-shortcodes.php:321-353`
- SYMBOL: `KMAE_Shortcodes::my_offers`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `shortcode `[kmae_my_offers]``
- CALLS: `KMAE_Database::get_offer`, `KMAE_Counter_Offers::user_can_access`, `KMAE_Pages::offers_page_url`, `KMAE_Database::mark_offer_seen`, `KMAE_Database::get_offers_by_user`, `KMAE_Database::get_offers_received_by_user`, `KMAE_Database::mark_offer_activity_seen`, `KMAE_Shortcodes::require_login`
- READS: —
- WRITES: —
- RELATED FEATURE: `PAGES-ROUTING`, `BROWSE-SEARCH`, `DASHBOARD-HUBS`
- GET KEYS: `kmae_offer`

## `KMAE_Shortcodes::profile`
- FILE: `public/class-kmae-shortcodes.php:356-363`
- SYMBOL: `KMAE_Shortcodes::profile`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `shortcode `[kmae_profile]``
- CALLS: `KMAE_Shortcodes::require_login`
- READS: —
- WRITES: —
- RELATED FEATURE: `PAGES-ROUTING`, `BROWSE-SEARCH`, `DASHBOARD-HUBS`

## `KMAE_Shortcodes::how_it_works`
- FILE: `public/class-kmae-shortcodes.php:366-371`
- SYMBOL: `KMAE_Shortcodes::how_it_works`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `shortcode `[kmae_how_it_works]``
- CALLS: `KMAE_Settings::seller_video_id`, `KMAE_Settings::buyer_video_id`
- READS: —
- WRITES: —
- RELATED FEATURE: `PAGES-ROUTING`, `BROWSE-SEARCH`, `DASHBOARD-HUBS`

## `KMAE_Shortcodes::education`
- FILE: `public/class-kmae-shortcodes.php:374-377`
- SYMBOL: `KMAE_Shortcodes::education`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `shortcode `[kmae_education]``
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `PAGES-ROUTING`, `BROWSE-SEARCH`, `DASHBOARD-HUBS`

## `KMAE_Shortcodes::settings`
- FILE: `public/class-kmae-shortcodes.php:380-387`
- SYMBOL: `KMAE_Shortcodes::settings`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `shortcode `[kmae_settings]``
- CALLS: `KMAE_Shortcodes::require_login`
- READS: —
- WRITES: —
- RELATED FEATURE: `PAGES-ROUTING`, `BROWSE-SEARCH`, `DASHBOARD-HUBS`

## `KMAE_Shortcodes::security`
- FILE: `public/class-kmae-shortcodes.php:390-393`
- SYMBOL: `KMAE_Shortcodes::security`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `shortcode `[kmae_security]``
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `PAGES-ROUTING`, `BROWSE-SEARCH`, `DASHBOARD-HUBS`

## `KMAE_Shortcodes::faq`
- FILE: `public/class-kmae-shortcodes.php:396-399`
- SYMBOL: `KMAE_Shortcodes::faq`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `shortcode `[kmae_faq]``
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `PAGES-ROUTING`, `BROWSE-SEARCH`, `DASHBOARD-HUBS`

## `KMAE_Shortcodes::contact`
- FILE: `public/class-kmae-shortcodes.php:402-405`
- SYMBOL: `KMAE_Shortcodes::contact`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `shortcode `[kmae_contact]``
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `PAGES-ROUTING`, `BROWSE-SEARCH`, `DASHBOARD-HUBS`

## `KMAE_Shortcodes::terms`
- FILE: `public/class-kmae-shortcodes.php:408-411`
- SYMBOL: `KMAE_Shortcodes::terms`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `shortcode `[kmae_terms]``
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `PAGES-ROUTING`, `BROWSE-SEARCH`, `DASHBOARD-HUBS`

## `KMAE_Shortcodes::privacy`
- FILE: `public/class-kmae-shortcodes.php:414-417`
- SYMBOL: `KMAE_Shortcodes::privacy`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `shortcode `[kmae_privacy]``
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `PAGES-ROUTING`, `BROWSE-SEARCH`, `DASHBOARD-HUBS`

## `KMAE_Shortcodes::notifications`
- FILE: `public/class-kmae-shortcodes.php:420-427`
- SYMBOL: `KMAE_Shortcodes::notifications`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `shortcode `[kmae_notifications]``
- CALLS: `KMAE_Shortcodes::require_login`
- READS: —
- WRITES: —
- RELATED FEATURE: `PAGES-ROUTING`, `BROWSE-SEARCH`, `DASHBOARD-HUBS`

## `KMAE_Shortcodes::messages`
- FILE: `public/class-kmae-shortcodes.php:430-437`
- SYMBOL: `KMAE_Shortcodes::messages`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `shortcode `[kmae_messages]``
- CALLS: `KMAE_Shortcodes::require_login`
- READS: —
- WRITES: —
- RELATED FEATURE: `PAGES-ROUTING`, `BROWSE-SEARCH`, `DASHBOARD-HUBS`

## `KMAE_Shortcodes::hub_sell`
- FILE: `public/class-kmae-shortcodes.php:440-441`
- SYMBOL: `KMAE_Shortcodes::hub_sell`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `shortcode `[kmae_hub_sell]``
- CALLS: `KMAE_Shortcodes::render_hub_section`
- READS: —
- WRITES: —
- RELATED FEATURE: `PAGES-ROUTING`, `BROWSE-SEARCH`, `DASHBOARD-HUBS`

## `KMAE_Shortcodes::hub_buy`
- FILE: `public/class-kmae-shortcodes.php:444-445`
- SYMBOL: `KMAE_Shortcodes::hub_buy`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `shortcode `[kmae_hub_buy]``
- CALLS: `KMAE_Shortcodes::render_hub_section`
- READS: —
- WRITES: —
- RELATED FEATURE: `PAGES-ROUTING`, `BROWSE-SEARCH`, `DASHBOARD-HUBS`

## `KMAE_Shortcodes::hub_stats`
- FILE: `public/class-kmae-shortcodes.php:448-449`
- SYMBOL: `KMAE_Shortcodes::hub_stats`
- PURPOSE: No dedicated source docblock; inspect the referenced implementation range.
- CALLED BY: `shortcode `[kmae_hub_stats]``
- CALLS: `KMAE_Shortcodes::render_hub_section`
- READS: —
- WRITES: —
- RELATED FEATURE: `PAGES-ROUTING`, `BROWSE-SEARCH`, `DASHBOARD-HUBS`

## `KMAE_Shortcodes::render_hub_section`
- FILE: `public/class-kmae-shortcodes.php:458-564`
- SYMBOL: `KMAE_Shortcodes::render_hub_section`
- PURPOSE: Hub submenu pages (Eladni / Venni / Statisztikák).
- CALLED BY: `KMAE_Shortcodes::hub_sell`, `KMAE_Shortcodes::hub_buy`, `KMAE_Shortcodes::hub_stats`
- CALLS: `KMAE_Dashboard::get_data`, `KMAE_Shortcodes::require_login`
- READS: —
- WRITES: —
- RELATED FEATURE: `PAGES-ROUTING`, `BROWSE-SEARCH`, `DASHBOARD-HUBS`

## `kmae_how_icon`
- FILE: `templates/how-it-works.php:102-124`
- SYMBOL: `kmae_how_icon`
- PURPOSE: Inline step / trust icons for the how-it-works page.
- CALLED BY: —
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `BOOT-ARCHITECTURE`

## `kmae_how_render_flow`
- FILE: `templates/how-it-works.php:140-203`
- SYMBOL: `kmae_how_render_flow`
- PURPOSE: Render a role flow row.
- CALLED BY: —
- CALLS: —
- READS: —
- WRITES: —
- RELATED FEATURE: `BOOT-ARCHITECTURE`
