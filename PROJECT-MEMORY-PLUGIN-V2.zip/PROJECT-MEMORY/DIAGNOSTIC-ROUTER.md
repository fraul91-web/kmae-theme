# PLUGIN DIAGNOSTIC ROUTER — V2

MAP-TYPE: ROUTER

**Authority:** SOURCE CODE > PROJECT MEMORY. `VERIFIED` below means the route was checked against the uploaded plugin source snapshot.

## Context budget
Default debug context: **this router + 1 matching FEATURE map + 1–5 source symbols**. Do not load the full repository, full SYMBOL-MAP, all feature maps, all JS/CSS, or the theme unless a checkpoint proves escalation is needed.

### Új ajánlat létrejön, de az eladó nem kap emailt
**SYMPTOM:** Új ajánlat létrejön, de az eladó nem kap emailt  
**FEATURE:** OFFERS + NOTIFICATIONS  
**START HERE:** `includes/class-kmae-offers.php :: KMAE_Offers::submit_cash_offer()`  
**EXPECTED:** non-filtered offer emits `kmae_new_offer`.  
**NEXT IF TRUE:** `includes/class-kmae-notifications.php :: KMAE_Notifications::on_new_offer()`  
**NEXT IF FALSE:** stay at the START HERE producer/guard and inspect its immediate dependencies only.  
**SEARCH TERMS:** `submit_cash_offer kmae_new_offer on_new_offer send_offer_email wants_offer_emails`  
**DO NOT LOAD:** AUTH only if email preference/verification is implicated.  
**PLUGIN BOUNDARY:** plugin-owned unless the checkpoint explicitly reaches WordPress mail/theme/external service.  
**VERIFY:** VERIFIED against source snapshot.

### Új ajánlat email rossz címzettnek vagy rossz tartalommal megy
**SYMPTOM:** Új ajánlat email rossz címzettnek vagy rossz tartalommal megy  
**FEATURE:** NOTIFICATIONS  
**START HERE:** `includes/class-kmae-notifications.php :: KMAE_Notifications::on_new_offer()`  
**EXPECTED:** listener resolves listing seller, offerer and email body.  
**NEXT IF TRUE:** `includes/class-kmae-notifications.php :: KMAE_Notifications::send_offer_email()`  
**NEXT IF FALSE:** stay at the START HERE producer/guard and inspect its immediate dependencies only.  
**SEARCH TERMS:** `on_new_offer send_offer_email wrap_email wp_mail`  
**DO NOT LOAD:** Do not load counter/deal code unless this occurs only after those events.  
**PLUGIN BOUNDARY:** plugin-owned unless the checkpoint explicitly reaches WordPress mail/theme/external service.  
**VERIFY:** VERIFIED against source snapshot.

### Ellenajánlat után nem megy email / rossz email megy
**SYMPTOM:** Ellenajánlat után nem megy email / rossz email megy  
**FEATURE:** NEGOTIATION-CHAT + NOTIFICATIONS  
**START HERE:** `includes/class-kmae-counter-offers.php :: KMAE_Counter_Offers::submit_seller_counter()`  
**EXPECTED:** persist counter then emit `kmae_new_counter_offer`.  
**NEXT IF TRUE:** `includes/class-kmae-notifications.php :: KMAE_Notifications::on_counter_offer()`  
**NEXT IF FALSE:** stay at the START HERE producer/guard and inspect its immediate dependencies only.  
**SEARCH TERMS:** `submit_seller_counter kmae_new_counter_offer on_counter_offer`  
**DO NOT LOAD:** Do not load deal success/failure path.  
**PLUGIN BOUNDARY:** plugin-owned unless the checkpoint explicitly reaches WordPress mail/theme/external service.  
**VERIFY:** VERIFIED against source snapshot.

### Vevői ajánlatmódosítás után nem frissül az értesítés
**SYMPTOM:** Vevői ajánlatmódosítás után nem frissül az értesítés  
**FEATURE:** NEGOTIATION-CHAT + NOTIFICATIONS  
**START HERE:** `includes/class-kmae-counter-offers.php :: KMAE_Counter_Offers::submit_buyer_revision()`  
**EXPECTED:** update offer/history then emit `kmae_buyer_revised_offer`.  
**NEXT IF TRUE:** `includes/class-kmae-notifications.php :: KMAE_Notifications::on_buyer_revision()`  
**NEXT IF FALSE:** stay at the START HERE producer/guard and inspect its immediate dependencies only.  
**SEARCH TERMS:** `submit_buyer_revision kmae_buyer_revised_offer on_buyer_revision`  
**DO NOT LOAD:** Do not load listing creation.  
**PLUGIN BOUNDARY:** plugin-owned unless the checkpoint explicitly reaches WordPress mail/theme/external service.  
**VERIFY:** VERIFIED against source snapshot.

### Ajánlat elfogadás után rossz email megy ki
**SYMPTOM:** Ajánlat elfogadás után rossz email megy ki  
**FEATURE:** NEGOTIATION-CHAT + DEAL + NOTIFICATIONS  
**START HERE:** `includes/class-kmae-counter-offers.php :: KMAE_Counter_Offers::accept_offer()`  
**EXPECTED:** acceptance emits `kmae_offer_accepted`; deal lock runs priority 5; notification priority 10.  
**NEXT IF TRUE:** `includes/class-kmae-deal.php :: KMAE_Deal::lock_on_accept() → includes/class-kmae-notifications.php :: KMAE_Notifications::on_offer_accepted()`  
**NEXT IF FALSE:** stay at the START HERE producer/guard and inspect its immediate dependencies only.  
**SEARCH TERMS:** `accept_offer kmae_offer_accepted lock_on_accept on_offer_accepted priority 5 10`  
**DO NOT LOAD:** Do not inspect unrelated new-offer handler.  
**PLUGIN BOUNDARY:** plugin-owned unless the checkpoint explicitly reaches WordPress mail/theme/external service.  
**VERIFY:** VERIFIED against source snapshot.

### Elfogadás nem oldja fel a kapcsolatot
**SYMPTOM:** Elfogadás nem oldja fel a kapcsolatot  
**FEATURE:** CONTACT-UNLOCK + NEGOTIATION-CHAT  
**START HERE:** `includes/class-kmae-counter-offers.php :: KMAE_Counter_Offers::accept_offer()`  
**EXPECTED:** accept path calls contact unlock for accepted deal.  
**NEXT IF TRUE:** `includes/class-kmae-contact.php :: KMAE_Contact::unlock_accepted_deal()`  
**NEXT IF FALSE:** stay at the START HERE producer/guard and inspect its immediate dependencies only.  
**SEARCH TERMS:** `accept_offer unlock_accepted_deal contact unlock`  
**DO NOT LOAD:** Theme not needed until plugin-rendered contact state is proven correct.  
**PLUGIN BOUNDARY:** plugin-owned unless the checkpoint explicitly reaches WordPress mail/theme/external service.  
**VERIFY:** VERIFIED against source snapshot.

### Elfogadás után nincs deal lock / rossz listing záródik
**SYMPTOM:** Elfogadás után nincs deal lock / rossz listing záródik  
**FEATURE:** DEAL  
**START HERE:** `includes/class-kmae-listings.php :: KMAE_Listings::init()`  
**EXPECTED:** registers `KMAE_Deal::lock_on_accept` on `kmae_offer_accepted` priority 5.  
**NEXT IF TRUE:** `includes/class-kmae-deal.php :: KMAE_Deal::lock_on_accept()`  
**NEXT IF FALSE:** stay at the START HERE producer/guard and inspect its immediate dependencies only.  
**SEARCH TERMS:** `kmae_offer_accepted lock_on_accept deal_locked accepted_offer_id`  
**DO NOT LOAD:** Do not load email code unless notification is also wrong.  
**PLUGIN BOUNDARY:** plugin-owned unless the checkpoint explicitly reaches WordPress mail/theme/external service.  
**VERIFY:** VERIFIED against source snapshot.

### Deal siker után nem archiválódik vagy rossz offer státuszok maradnak
**SYMPTOM:** Deal siker után nem archiválódik vagy rossz offer státuszok maradnak  
**FEATURE:** DEAL + LISTINGS  
**START HERE:** `includes/class-kmae-deal.php :: KMAE_Deal::confirm_success()`  
**EXPECTED:** finalizes deal, adjusts remaining offers/listing, emits `kmae_deal_success`.  
**NEXT IF TRUE:** `includes/class-kmae-listings.php :: archive/lifecycle helpers`  
**NEXT IF FALSE:** stay at the START HERE producer/guard and inspect its immediate dependencies only.  
**SEARCH TERMS:** `confirm_success kmae_deal_success archive rejected offers`  
**DO NOT LOAD:** Do not load rating code until success event verified.  
**PLUGIN BOUNDARY:** plugin-owned unless the checkpoint explicitly reaches WordPress mail/theme/external service.  
**VERIFY:** VERIFIED against source snapshot.

### Deal siker után nem jelenik meg értékelés / nincs rating kérés
**SYMPTOM:** Deal siker után nem jelenik meg értékelés / nincs rating kérés  
**FEATURE:** TRUST-RATINGS + DEAL  
**START HERE:** `includes/class-kmae-deal.php :: KMAE_Deal::confirm_success()`  
**EXPECTED:** emits `kmae_deal_success`.  
**NEXT IF TRUE:** `includes/class-kmae-trust.php :: KMAE_Trust::on_deal_success()`  
**NEXT IF FALSE:** stay at the START HERE producer/guard and inspect its immediate dependencies only.  
**SEARCH TERMS:** `kmae_deal_success on_deal_success request_rating pending rating`  
**DO NOT LOAD:** Do not load counter-offer UI.  
**PLUGIN BOUNDARY:** plugin-owned unless the checkpoint explicitly reaches WordPress mail/theme/external service.  
**VERIFY:** VERIFIED against source snapshot.

### Deal sikertelen, de listing/ajánlatok nem nyílnak vissza megfelelően
**SYMPTOM:** Deal sikertelen, de listing/ajánlatok nem nyílnak vissza megfelelően  
**FEATURE:** DEAL  
**START HERE:** `includes/class-kmae-deal.php :: KMAE_Deal::confirm_failure()`  
**EXPECTED:** failure recovery updates state and emits `kmae_deal_failed`.  
**NEXT IF TRUE:** `includes/class-kmae-notifications.php :: KMAE_Notifications::on_deal_failed()`  
**NEXT IF FALSE:** stay at the START HERE producer/guard and inspect its immediate dependencies only.  
**SEARCH TERMS:** `confirm_failure kmae_deal_failed resume reopen`  
**DO NOT LOAD:** Do not load success/rating path.  
**PLUGIN BOUNDARY:** plugin-owned unless the checkpoint explicitly reaches WordPress mail/theme/external service.  
**VERIFY:** VERIFIED against source snapshot.

### Ajánlatot nem lehet beküldeni
**SYMPTOM:** Ajánlatot nem lehet beküldeni  
**FEATURE:** OFFERS  
**START HERE:** `public/class-kmae-public.php :: KMAE_Public::handle_forms()`  
**EXPECTED:** dispatches cash offer after auth/verification/form checks.  
**NEXT IF TRUE:** `includes/class-kmae-offers.php :: KMAE_Offers::guard_new_offer() + submit_cash_offer()`  
**NEXT IF FALSE:** stay at the START HERE producer/guard and inspect its immediate dependencies only.  
**SEARCH TERMS:** `handle_forms cash_offer guard_new_offer submit_cash_offer fair buyer pledge`  
**DO NOT LOAD:** Photo/listing wizard irrelevant.  
**PLUGIN BOUNDARY:** plugin-owned unless the checkpoint explicitly reaches WordPress mail/theme/external service.  
**VERIFY:** VERIFIED against source snapshot.

### Minimum alatti ajánlat láthatatlan / furcsa státusz
**SYMPTOM:** Minimum alatti ajánlat láthatatlan / furcsa státusz  
**FEATURE:** OFFERS  
**START HERE:** `includes/class-kmae-offers.php :: KMAE_Offers::submit_cash_offer()`  
**EXPECTED:** minimum logic may persist `filtered_out` and intentionally suppress seller event.  
**NEXT IF TRUE:** `includes/class-kmae-database.php :: offer persistence/read methods`  
**NEXT IF FALSE:** stay at the START HERE producer/guard and inspect its immediate dependencies only.  
**SEARCH TERMS:** `filtered_out minimum cash private_data submit_cash_offer`  
**DO NOT LOAD:** Do not load notifications unless offer is non-filtered.  
**PLUGIN BOUNDARY:** plugin-owned unless the checkpoint explicitly reaches WordPress mail/theme/external service.  
**VERIFY:** VERIFIED against source snapshot.

### Ajánlat visszavonás nem működik
**SYMPTOM:** Ajánlat visszavonás nem működik  
**FEATURE:** OFFERS  
**START HERE:** `includes/class-kmae-offers.php :: KMAE_Offers::can_withdraw()`  
**EXPECTED:** checks withdrawal eligibility.  
**NEXT IF TRUE:** `includes/class-kmae-offers.php :: KMAE_Offers::withdraw_offer()`  
**NEXT IF FALSE:** stay at the START HERE producer/guard and inspect its immediate dependencies only.  
**SEARCH TERMS:** `can_withdraw withdraw_offer kmae_offer_withdrawn`  
**DO NOT LOAD:** Do not load deal unless offer is locked/accepted.  
**PLUGIN BOUNDARY:** plugin-owned unless the checkpoint explicitly reaches WordPress mail/theme/external service.  
**VERIFY:** VERIFIED against source snapshot.

### Offer chat gomb rossz állapotban van / rossz fél tud lépni
**SYMPTOM:** Offer chat gomb rossz állapotban van / rossz fél tud lépni  
**FEATURE:** NEGOTIATION-CHAT  
**START HERE:** `includes/class-kmae-counter-offers.php :: can_seller_counter()/can_buyer_revise()/can_seller_accept()/can_buyer_accept()`  
**EXPECTED:** server rules derive action eligibility from role/status/round state.  
**NEXT IF TRUE:** `includes/class-kmae-counter-offers.php :: get_chat_action_state()`  
**NEXT IF FALSE:** stay at the START HERE producer/guard and inspect its immediate dependencies only.  
**SEARCH TERMS:** `get_chat_action_state can_seller_counter can_buyer_revise offer-chat-actions`  
**DO NOT LOAD:** Do not edit template first if server state is wrong.  
**PLUGIN BOUNDARY:** plugin-owned unless the checkpoint explicitly reaches WordPress mail/theme/external service.  
**VERIFY:** VERIFIED against source snapshot.

### Wizard autosave nem ment
**SYMPTOM:** Wizard autosave nem ment  
**FEATURE:** LISTING-WIZARD-DRAFTS  
**START HERE:** `assets/js/listing-wizard.js :: action `kmae_save_listing_draft``  
**EXPECTED:** authenticated WP AJAX request.  
**NEXT IF TRUE:** `includes/class-kmae-listing-drafts.php :: KMAE_Listing_Drafts::ajax_save()`  
**NEXT IF FALSE:** stay at the START HERE producer/guard and inspect its immediate dependencies only.  
**SEARCH TERMS:** `kmae_save_listing_draft ajax_save wizard draft`  
**DO NOT LOAD:** Do not load final create-listing flow yet.  
**PLUGIN BOUNDARY:** plugin-owned unless the checkpoint explicitly reaches WordPress mail/theme/external service.  
**VERIFY:** VERIFIED against source snapshot.

### Wizard visszatöltéskor rossz adat jelenik meg
**SYMPTOM:** Wizard visszatöltéskor rossz adat jelenik meg  
**FEATURE:** LISTING-WIZARD-DRAFTS  
**START HERE:** `includes/class-kmae-listing-drafts.php :: get_user_draft()/to_client()`  
**EXPECTED:** server serializes owned draft for client.  
**NEXT IF TRUE:** `assets/js/listing-wizard.js :: draft restore/state logic`  
**NEXT IF FALSE:** stay at the START HERE producer/guard and inspect its immediate dependencies only.  
**SEARCH TERMS:** `get_user_draft to_client draft restore listing-wizard`  
**DO NOT LOAD:** Do not load moderation/photo processing unless affected field belongs there.  
**PLUGIN BOUNDARY:** plugin-owned unless the checkpoint explicitly reaches WordPress mail/theme/external service.  
**VERIFY:** VERIFIED against source snapshot.

### Hirdetés elküldhető, de nem publikálódik
**SYMPTOM:** Hirdetés elküldhető, de nem publikálódik  
**FEATURE:** LISTINGS + MODERATION + PHOTO-MOTOR  
**START HERE:** `public/class-kmae-public.php :: KMAE_Public::process_create_listing()`  
**EXPECTED:** validates seller/location/vehicle/moderation/photo state and inserts listing.  
**NEXT IF TRUE:** `includes/class-kmae-listings.php :: KMAE_Listings::activate_if_photos_ready()`  
**NEXT IF FALSE:** stay at the START HERE producer/guard and inspect its immediate dependencies only.  
**SEARCH TERMS:** `process_create_listing awaiting_photos activate_if_photos_ready moderation`  
**DO NOT LOAD:** Do not inspect browse/search until publication state is correct.  
**PLUGIN BOUNDARY:** plugin-owned unless the checkpoint explicitly reaches WordPress mail/theme/external service.  
**VERIFY:** VERIFIED against source snapshot.

### Fotók megvannak, de awaiting_photos marad
**SYMPTOM:** Fotók megvannak, de awaiting_photos marad  
**FEATURE:** PHOTO-MOTOR + LISTINGS  
**START HERE:** `includes/class-kmae-photo-motor.php :: KMAE_Photo_Motor::validate_request()/required slot checks`  
**EXPECTED:** photo readiness controls activation path.  
**NEXT IF TRUE:** `includes/class-kmae-listings.php :: KMAE_Listings::activate_if_photos_ready()`  
**NEXT IF FALSE:** stay at the START HERE producer/guard and inspect its immediate dependencies only.  
**SEARCH TERMS:** `required_slots validate_request activate_if_photos_ready awaiting_photos`  
**DO NOT LOAD:** Do not load offer/deal code.  
**PLUGIN BOUNDARY:** plugin-owned unless the checkpoint explicitly reaches WordPress mail/theme/external service.  
**VERIFY:** VERIFIED against source snapshot.

### Fotó kliensen elfogadott, szerveren elutasított
**SYMPTOM:** Fotó kliensen elfogadott, szerveren elutasított  
**FEATURE:** PHOTO-MOTOR  
**START HERE:** `assets/js/photo-motor.js :: client validation/upload flow`  
**EXPECTED:** client config mirrors source thresholds but server is authoritative.  
**NEXT IF TRUE:** `includes/class-kmae-photo-motor.php :: validate_request() + includes/class-kmae-images.php`  
**NEXT IF FALSE:** stay at the START HERE producer/guard and inspect its immediate dependencies only.  
**SEARCH TERMS:** `photo motor client_config validate_request image mime size blur`  
**DO NOT LOAD:** Do not load listing lifecycle unless upload succeeds.  
**PLUGIN BOUNDARY:** plugin-owned unless the checkpoint explicitly reaches WordPress mail/theme/external service.  
**VERIFY:** VERIFIED against source snapshot.

### Márka/modell kereső nem működik
**SYMPTOM:** Márka/modell kereső nem működik  
**FEATURE:** VEHICLE  
**START HERE:** `assets/js/vehicle-catalog.js :: catalog/autocomplete handlers`  
**EXPECTED:** reads localized catalog and form fields.  
**NEXT IF TRUE:** `includes/class-kmae-vehicle.php + public/class-kmae-public.php :: enqueue_vehicle_catalog()`  
**NEXT IF FALSE:** stay at the START HERE producer/guard and inspect its immediate dependencies only.  
**SEARCH TERMS:** `vehicle-catalog kmaeVehicleCatalog vehicle_brand vehicle_model`  
**DO NOT LOAD:** Do not load offer system.  
**PLUGIN BOUNDARY:** plugin-owned unless the checkpoint explicitly reaches WordPress mail/theme/external service.  
**VERIFY:** VERIFIED against source snapshot.

### Browse kártyák rossz autókat adnak / már ajánlott autó visszajön
**SYMPTOM:** Browse kártyák rossz autókat adnak / már ajánlott autó visszajön  
**FEATURE:** BROWSE-SEARCH  
**START HERE:** `includes/class-kmae-browse.php :: personalize_listings()/get_offered_listing_ids()`  
**EXPECTED:** personalization excludes/merges based on offer/pass history.  
**NEXT IF TRUE:** `includes/class-kmae-query.php :: query construction`  
**NEXT IF FALSE:** stay at the START HERE producer/guard and inspect its immediate dependencies only.  
**SEARCH TERMS:** `personalize_listings get_offered_listing_ids passed filter_by_wizard`  
**DO NOT LOAD:** Do not load templates until ID set is correct.  
**PLUGIN BOUNDARY:** plugin-owned unless the checkpoint explicitly reaches WordPress mail/theme/external service.  
**VERIFY:** VERIFIED against source snapshot.

### Swipe pass nem marad meg
**SYMPTOM:** Swipe pass nem marad meg  
**FEATURE:** BROWSE-SEARCH  
**START HERE:** `assets/js/swipe.js :: `kmae_browse_pass``  
**EXPECTED:** WP AJAX to public controller.  
**NEXT IF TRUE:** `public/class-kmae-public.php :: ajax_browse_pass() → KMAE_Browse::record_pass()`  
**NEXT IF FALSE:** stay at the START HERE producer/guard and inspect its immediate dependencies only.  
**SEARCH TERMS:** `kmae_browse_pass ajax_browse_pass record_pass _kmae_browse_passed`  
**DO NOT LOAD:** Do not load offer persistence.  
**PLUGIN BOUNDARY:** plugin-owned unless the checkpoint explicitly reaches WordPress mail/theme/external service.  
**VERIFY:** VERIFIED against source snapshot.

### Live badge/számláló nem frissül
**SYMPTOM:** Live badge/számláló nem frissül  
**FEATURE:** LIVE-NAV  
**START HERE:** `assets/js/public.js :: `kmae_poll_page``  
**EXPECTED:** WP AJAX poll.  
**NEXT IF TRUE:** `public/class-kmae-public.php :: ajax_poll_page() → KMAE_Live_Page`  
**NEXT IF FALSE:** stay at the START HERE producer/guard and inspect its immediate dependencies only.  
**SEARCH TERMS:** `kmae_poll_page ajax_poll_page fingerprint unseen offers nav badge`  
**DO NOT LOAD:** Do not load notifications email.  
**PLUGIN BOUNDARY:** plugin-owned unless the checkpoint explicitly reaches WordPress mail/theme/external service.  
**VERIFY:** VERIFIED against source snapshot.

### Bejelentkezés/regisztráció nem működik
**SYMPTOM:** Bejelentkezés/regisztráció nem működik  
**FEATURE:** AUTH  
**START HERE:** `public/class-kmae-public.php :: admin_login()/admin_register()`  
**EXPECTED:** admin-post request delegates auth rules.  
**NEXT IF TRUE:** `includes/class-kmae-auth.php :: auth helpers/verification`  
**NEXT IF FALSE:** stay at the START HERE producer/guard and inspect its immediate dependencies only.  
**SEARCH TERMS:** `admin_login admin_register email verification wp_signon`  
**DO NOT LOAD:** Do not load Google auth unless Google flow used.  
**PLUGIN BOUNDARY:** plugin-owned unless the checkpoint explicitly reaches WordPress mail/theme/external service.  
**VERIFY:** VERIFIED against source snapshot.

### Email megerősítés miatt indokolatlanul tiltott művelet
**SYMPTOM:** Email megerősítés miatt indokolatlanul tiltott művelet  
**FEATURE:** AUTH  
**START HERE:** `includes/class-kmae-auth.php :: verification state/check helpers`  
**EXPECTED:** server gates actions based on verification requirement.  
**NEXT IF TRUE:** `public/class-kmae-public.php :: handle_forms()`  
**NEXT IF FALSE:** stay at the START HERE producer/guard and inspect its immediate dependencies only.  
**SEARCH TERMS:** `email verify requires verification handle_forms gate`  
**DO NOT LOAD:** Do not bypass server gate in JS.  
**PLUGIN BOUNDARY:** plugin-owned unless the checkpoint explicitly reaches WordPress mail/theme/external service.  
**VERIFY:** VERIFIED against source snapshot.

### Google login callback hibás
**SYMPTOM:** Google login callback hibás  
**FEATURE:** GOOGLE-AUTH  
**START HERE:** `includes/class-kmae-google-auth.php :: maybe_handle_request()/handle_callback()`  
**EXPECTED:** authorization callback resolves/links user then completion state.  
**NEXT IF TRUE:** `includes/class-kmae-google-auth.php :: enforce_completion()`  
**NEXT IF FALSE:** stay at the START HERE producer/guard and inspect its immediate dependencies only.  
**SEARCH TERMS:** `handle_callback redirect_to_google enforce_completion client_id redirect_uri`  
**DO NOT LOAD:** Do not load password login unless account-linking issue.  
**PLUGIN BOUNDARY:** plugin-owned unless the checkpoint explicitly reaches WordPress mail/theme/external service.  
**VERIFY:** VERIFIED against source snapshot.

### Céges hirdetés helye rossz
**SYMPTOM:** Céges hirdetés helye rossz  
**FEATURE:** PROFILE-COMPANY-SETTINGS + LISTINGS  
**START HERE:** `includes/class-kmae-company.php :: apply_listing_location()`  
**EXPECTED:** company account location can override listing location save.  
**NEXT IF TRUE:** `includes/class-kmae-listings.php :: save_meta_from_post()`  
**NEXT IF FALSE:** stay at the START HERE producer/guard and inspect its immediate dependencies only.  
**SEARCH TERMS:** `apply_listing_location company county settlement save_meta_from_post`  
**DO NOT LOAD:** Browse map only after stored listing location verified.  
**PLUGIN BOUNDARY:** plugin-owned unless the checkpoint explicitly reaches WordPress mail/theme/external service.  
**VERIFY:** VERIFIED against source snapshot.

### Hirdetés nem törölhető / nem reaktiválható
**SYMPTOM:** Hirdetés nem törölhető / nem reaktiválható  
**FEATURE:** LISTINGS  
**START HERE:** `includes/class-kmae-listings.php :: can_delete_listing()/can_reactivate_listing()`  
**EXPECTED:** lifecycle and ownership gates action.  
**NEXT IF TRUE:** `public/class-kmae-public.php :: admin_delete_listing()/admin_reactivate_listing()`  
**NEXT IF FALSE:** stay at the START HERE producer/guard and inspect its immediate dependencies only.  
**SEARCH TERMS:** `can_delete_listing can_reactivate_listing admin_delete_listing reactivate`  
**DO NOT LOAD:** Do not load admin backend unless wp-admin path.  
**PLUGIN BOUNDARY:** plugin-owned unless the checkpoint explicitly reaches WordPress mail/theme/external service.  
**VERIFY:** VERIFIED against source snapshot.

### Archivált hirdetés nem törlődik cronból
**SYMPTOM:** Archivált hirdetés nem törlődik cronból  
**FEATURE:** CRON-ARCHIVE  
**START HERE:** `includes/class-kmae-activator.php :: schedule_cron()`  
**EXPECTED:** daily `kmae_purge_archived_listings` event.  
**NEXT IF TRUE:** `includes/class-kmae-listings.php :: purge_expired_archived()`  
**NEXT IF FALSE:** stay at the START HERE producer/guard and inspect its immediate dependencies only.  
**SEARCH TERMS:** `schedule_cron kmae_purge_archived_listings purge_expired_archived force_delete_listing`  
**DO NOT LOAD:** Do not load frontend.  
**PLUGIN BOUNDARY:** plugin-owned unless the checkpoint explicitly reaches WordPress mail/theme/external service.  
**VERIFY:** VERIFIED against source snapshot.

### Contact form nem küld
**SYMPTOM:** Contact form nem küld  
**FEATURE:** CONTACT-FORM  
**START HERE:** `public/class-kmae-public.php :: admin_contact_form()`  
**EXPECTED:** validates nonce/input and sends to configured recipient.  
**NEXT IF TRUE:** `includes/class-kmae-settings.php :: contact_form_email()`  
**NEXT IF FALSE:** stay at the START HERE producer/guard and inspect its immediate dependencies only.  
**SEARCH TERMS:** `admin_contact_form contact_form_email wp_mail`  
**DO NOT LOAD:** Offer notification code unrelated.  
**PLUGIN BOUNDARY:** plugin-owned unless the checkpoint explicitly reaches WordPress mail/theme/external service.  
**VERIFY:** VERIFIED against source snapshot.

### Admin ajánlat/listing művelet rossz rekordot érint
**SYMPTOM:** Admin ajánlat/listing művelet rossz rekordot érint  
**FEATURE:** ADMIN  
**START HERE:** `admin/class-kmae-admin.php :: action handler`  
**EXPECTED:** admin handler checks request and delegates DB/listing mutation.  
**NEXT IF TRUE:** `includes/class-kmae-database.php / includes/class-kmae-listings.php :: targeted mutation`  
**NEXT IF FALSE:** stay at the START HERE producer/guard and inspect its immediate dependencies only.  
**SEARCH TERMS:** `handle_delete_offer handle_delete_listing handle_set_status admin`  
**DO NOT LOAD:** Public forms unrelated.  
**PLUGIN BOUNDARY:** plugin-owned unless the checkpoint explicitly reaches WordPress mail/theme/external service.  
**VERIFY:** VERIFIED against source snapshot.

### Oldal/shortcode rossz template-et renderel
**SYMPTOM:** Oldal/shortcode rossz template-et renderel  
**FEATURE:** PAGES-ROUTING  
**START HERE:** `includes/class-kmae-pages.php :: shortcode_for()/url()/routing helpers`  
**EXPECTED:** page maps to shortcode/template path.  
**NEXT IF TRUE:** `public/class-kmae-shortcodes.php :: matching shortcode method`  
**NEXT IF FALSE:** stay at the START HERE producer/guard and inspect its immediate dependencies only.  
**SEARCH TERMS:** `shortcode_for template_include shortcode KMAE_Pages KMAE_Shortcodes`  
**DO NOT LOAD:** Do not load business services unless data passed into template is wrong.  
**PLUGIN BOUNDARY:** plugin-owned unless the checkpoint explicitly reaches WordPress mail/theme/external service.  
**VERIFY:** VERIFIED against source snapshot.

### Plugin induláskor class/hook hiányzik
**SYMPTOM:** Plugin induláskor class/hook hiányzik  
**FEATURE:** BOOT-ARCHITECTURE  
**START HERE:** `ki-mit-adna-erte.php :: kmae_run()`  
**EXPECTED:** creates KMAE_Plugin and calls run.  
**NEXT IF TRUE:** `includes/class-kmae-plugin.php :: KMAE_Plugin::run()`  
**NEXT IF FALSE:** stay at the START HERE producer/guard and inspect its immediate dependencies only.  
**SEARCH TERMS:** `kmae_run KMAE_Plugin run loader require init`  
**DO NOT LOAD:** Do not load all features by default.  
**PLUGIN BOUNDARY:** plugin-owned unless the checkpoint explicitly reaches WordPress mail/theme/external service.  
**VERIFY:** VERIFIED against source snapshot.

