# CHANGE-RISK MAP

## Very high fan-out

### Listing status (`_kmae_status`)
Consumers: public visibility, browse query, offer eligibility, deal lock, archive lifecycle, rating eligibility, dashboard, public singular blocking.

Before changing: `FEATURES/LISTINGS.md`, `FEATURES/DEAL.md`, `FEATURES/BROWSE-SEARCH.md`, `FEATURES/TRUST-RATINGS.md`.

### Offer status / accepted amount
Consumers: counter rules, deal lock, contact visibility, browse exclusion, dashboard, trust, notifications.

Before changing: `FEATURES/OFFERS.md`, `FEATURES/NEGOTIATION-CHAT.md`, `FEATURES/DEAL.md`, `FEATURES/CONTACT-UNLOCK.md`.

### `kmae_offer_accepted` event
Listeners run at different priorities. Deal lock (5) precedes accepted notification (10).

### Listing deletion
`force_delete_listing()` spans WP attachments/posts plus multiple custom tables and participant notifications. Search callers before changing cleanup.

### Vehicle field names
Shared across PHP parser/meta, templates, wizard JS, catalog JS, moderation and browse.

### Photo slot names
Shared between request validation, JS inputs, server upload loop, listing slot meta, gallery order.

## Medium fan-out

- Managed page slugs / shortcodes.
- E-mail verification/profile table fields.
- Company location meta.
- Offer-seen/unseen markers.
- Trust cache user meta.
- Launch constants.

## Destructive operations to treat carefully

- `KMAE_Listings::force_delete_listing`
- cron purge
- admin listing/offer deletion
- gallery/slot attachment replacement
- logout everywhere / password changes

Use `SYMBOL-MAP.md` reverse callers plus `FLOWS.md` before edits.
