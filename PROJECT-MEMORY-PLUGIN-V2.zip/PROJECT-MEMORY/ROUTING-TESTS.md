# ROUTING TESTS — PLUGIN V2

MAP-TYPE: VERIFICATION

These are simulated localization tests; they do **not** modify source. Pass criterion: reach the likely source area from minimal context without repository-wide discovery.

## TEST 1 — PASS
- **USER SYMPTOM:** Új ajánlat van DB-ben, de nincs email
- **ROUTE:** DIAGNOSTIC-ROUTER → OFFERS → NOTIFICATIONS
- **MAPS READ:** `DIAGNOSTIC-ROUTER.md` + one primary feature map (secondary only at proven boundary)
- **SOURCE TARGETS:** KMAE_Offers::submit_cash_offer; KMAE_Notifications::on_new_offer; KMAE_Notifications::send_offer_email
- **EXPECTED SOURCE FILE COUNT:** 2 files
- **WHY:** distinguishes filtered/event failure from mail failure.

## TEST 2 — PASS
- **USER SYMPTOM:** Elfogadás után rossz email
- **ROUTE:** ROUTER → NEGOTIATION → DEAL → NOTIFICATIONS
- **MAPS READ:** `DIAGNOSTIC-ROUTER.md` + one primary feature map (secondary only at proven boundary)
- **SOURCE TARGETS:** KMAE_Counter_Offers::accept_offer; KMAE_Deal::lock_on_accept; KMAE_Notifications::on_offer_accepted
- **EXPECTED SOURCE FILE COUNT:** 3 files
- **WHY:** checks priority-5 state before priority-10 mail.

## TEST 3 — PASS
- **USER SYMPTOM:** Elfogadás után nincs telefonszám
- **ROUTE:** ROUTER → CONTACT-UNLOCK
- **MAPS READ:** `DIAGNOSTIC-ROUTER.md` + one primary feature map (secondary only at proven boundary)
- **SOURCE TARGETS:** KMAE_Counter_Offers::accept_offer; KMAE_Contact::unlock_accepted_deal
- **EXPECTED SOURCE FILE COUNT:** 2 files
- **WHY:** isolates access write from render.

## TEST 4 — PASS
- **USER SYMPTOM:** Chatban rossz gomb látszik
- **ROUTE:** ROUTER → NEGOTIATION
- **MAPS READ:** `DIAGNOSTIC-ROUTER.md` + one primary feature map (secondary only at proven boundary)
- **SOURCE TARGETS:** KMAE_Counter_Offers::get_chat_action_state; matching offer chat partial
- **EXPECTED SOURCE FILE COUNT:** 2 files
- **WHY:** server eligibility before UI.

## TEST 5 — PASS
- **USER SYMPTOM:** Autosave nem ment
- **ROUTE:** ROUTER → WIZARD-DRAFTS
- **MAPS READ:** `DIAGNOSTIC-ROUTER.md` + one primary feature map (secondary only at proven boundary)
- **SOURCE TARGETS:** listing-wizard.js kmae_save_listing_draft; KMAE_Listing_Drafts::ajax_save
- **EXPECTED SOURCE FILE COUNT:** 2 files
- **WHY:** request vs persistence split.

## TEST 6 — PASS
- **USER SYMPTOM:** Fotók után awaiting_photos marad
- **ROUTE:** ROUTER → PHOTO-MOTOR → LISTINGS
- **MAPS READ:** `DIAGNOSTIC-ROUTER.md` + one primary feature map (secondary only at proven boundary)
- **SOURCE TARGETS:** KMAE_Photo_Motor required/readiness; KMAE_Listings::activate_if_photos_ready
- **EXPECTED SOURCE FILE COUNT:** 2 files
- **WHY:** avoids full listing flow.

## TEST 7 — PASS
- **USER SYMPTOM:** Browse visszaad már ajánlott autót
- **ROUTE:** ROUTER → BROWSE
- **MAPS READ:** `DIAGNOSTIC-ROUTER.md` + one primary feature map (secondary only at proven boundary)
- **SOURCE TARGETS:** KMAE_Browse::get_offered_listing_ids; KMAE_Browse::personalize_listings
- **EXPECTED SOURCE FILE COUNT:** 1–2 files
- **WHY:** targets personalization not template.

## TEST 8 — PASS
- **USER SYMPTOM:** Pass után újra azonnal megjelenik autó
- **ROUTE:** ROUTER → BROWSE
- **MAPS READ:** `DIAGNOSTIC-ROUTER.md` + one primary feature map (secondary only at proven boundary)
- **SOURCE TARGETS:** KMAE_Public::ajax_browse_pass; KMAE_Browse::record_pass; KMAE_Browse::personalize_listings
- **EXPECTED SOURCE FILE COUNT:** 2 files
- **WHY:** persistence then consumption.

## TEST 9 — PASS
- **USER SYMPTOM:** Live ajánlatszámláló nem frissül
- **ROUTE:** ROUTER → LIVE-NAV
- **MAPS READ:** `DIAGNOSTIC-ROUTER.md` + one primary feature map (secondary only at proven boundary)
- **SOURCE TARGETS:** KMAE_Public::ajax_poll_page; KMAE_Live_Page fingerprint/count; public.js poll consumer
- **EXPECTED SOURCE FILE COUNT:** 2–3 files
- **WHY:** JSON checkpoint separates backend/UI.

## TEST 10 — PASS
- **USER SYMPTOM:** Céges listing rossz települést kap
- **ROUTE:** ROUTER → PROFILE/COMPANY → LISTINGS
- **MAPS READ:** `DIAGNOSTIC-ROUTER.md` + one primary feature map (secondary only at proven boundary)
- **SOURCE TARGETS:** KMAE_Company::apply_listing_location; KMAE_Listings::save_meta_from_post
- **EXPECTED SOURCE FILE COUNT:** 2 files
- **WHY:** targets override path.

## TEST 11 — PASS
- **USER SYMPTOM:** Deal success után nincs rating
- **ROUTE:** ROUTER → DEAL → TRUST
- **MAPS READ:** `DIAGNOSTIC-ROUTER.md` + one primary feature map (secondary only at proven boundary)
- **SOURCE TARGETS:** KMAE_Deal::confirm_success; KMAE_Trust::on_deal_success
- **EXPECTED SOURCE FILE COUNT:** 2 files
- **WHY:** checks domain event before rating UI.

## TEST 12 — PASS
- **USER SYMPTOM:** Archivált listing nem purge-olódik
- **ROUTE:** ROUTER → CRON-ARCHIVE
- **MAPS READ:** `DIAGNOSTIC-ROUTER.md` + one primary feature map (secondary only at proven boundary)
- **SOURCE TARGETS:** KMAE_Activator::schedule_cron; KMAE_Listings::purge_expired_archived
- **EXPECTED SOURCE FILE COUNT:** 2 files
- **WHY:** scheduler/runtime vs deletion eligibility.

## TEST 13 — PASS
- **USER SYMPTOM:** Google callback loopol
- **ROUTE:** ROUTER → GOOGLE-AUTH
- **MAPS READ:** `DIAGNOSTIC-ROUTER.md` + one primary feature map (secondary only at proven boundary)
- **SOURCE TARGETS:** KMAE_Google_Auth::handle_callback; KMAE_Google_Auth::enforce_completion
- **EXPECTED SOURCE FILE COUNT:** 1 file
- **WHY:** keeps password auth out unless linking issue.

## TEST 14 — PASS
- **USER SYMPTOM:** Contact form elküldve, email nincs
- **ROUTE:** ROUTER → CONTACT-FORM
- **MAPS READ:** `DIAGNOSTIC-ROUTER.md` + one primary feature map (secondary only at proven boundary)
- **SOURCE TARGETS:** KMAE_Public::admin_contact_form; KMAE_Settings::contact_form_email; wp_mail boundary
- **EXPECTED SOURCE FILE COUNT:** 2 files
- **WHY:** stops at mail transport if args correct.

## TEST 15 — PASS
- **USER SYMPTOM:** Plugin feature hook egyáltalán nem fut
- **ROUTE:** ROUTER → BOOT
- **MAPS READ:** `DIAGNOSTIC-ROUTER.md` + one primary feature map (secondary only at proven boundary)
- **SOURCE TARGETS:** kmae_run; KMAE_Plugin::run; feature init method
- **EXPECTED SOURCE FILE COUNT:** 2–3 files
- **WHY:** loads boot only when registration actually missing.

