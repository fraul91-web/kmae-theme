# DECISION TREES — PLUGIN V2

MAP-TYPE: ON-DEMAND

All branches are routing rules; source remains authoritative.

## 1. Email did not arrive
```text
Domain mutation happened?
├─ NO → feature producer/guard
└─ YES → expected do_action emitted?
   ├─ NO → producer event branch
   └─ YES → notification listener invoked?
      ├─ NO → hook registration/init
      └─ YES → recipient + wants_offer_emails correct?
         ├─ NO → Notifications/Auth preference
         └─ YES → KMAE_Brand::send_mail → wp_mail boundary
```
**STOP:** once `wp_mail` is called with correct recipient/subject/body, plugin routing ends.

## 2. Wrong email after accepted offer
```text
KMAE_Counter_Offers::accept_offer state correct?
├─ NO → acceptance mutation
└─ YES → kmae_offer_accepted payload correct?
   ├─ NO → accept_offer emitter
   └─ YES → KMAE_Deal::lock_on_accept priority-5 state correct?
      ├─ NO → deal lock
      └─ YES → KMAE_Notifications::on_offer_accepted priority-10
```
**SKIP:** do not inspect `on_new_offer()` for an accepted-offer-only email bug.

## 3. Offer action button wrong
```text
Server `get_chat_action_state()` wrong?
├─ YES → role/status/round rules in KMAE_Counter_Offers
└─ NO → rendered template state wrong?
   ├─ YES → offer chat partials
   └─ NO → frontend event/DOM in assets/js/public.js
```

## 4. Listing not published
```text
process_create_listing failed validation?
├─ YES → failing validator only
└─ NO → inserted status = awaiting_photos?
   ├─ YES → Photo_Motor readiness → activate_if_photos_ready
   └─ NO → moderation/status/lifecycle branch
```

## 5. Wizard autosave/restore
```text
AJAX request sent?
├─ NO → listing-wizard.js
└─ YES → ajax_save response error?
   ├─ YES → nonce/ownership/payload in KMAE_Listing_Drafts::ajax_save
   └─ NO → saved payload correct?
      ├─ NO → server serialization
      └─ YES → client restore/state
```

## 6. Photo mismatch client vs server
```text
Client rejects before upload? → photo-motor.js/client_config
Server rejects? → KMAE_Photo_Motor::validate_request / KMAE_Images
Server accepts but listing stays awaiting_photos? → activate_if_photos_ready
```
**Rule:** never weaken only client validation to bypass authoritative server rejection.

## 7. Browse result wrong
```text
Base query IDs wrong? → KMAE_Query
Base IDs right, personalized IDs wrong? → KMAE_Browse
IDs right, UI wrong? → template/JS
```

## 8. Live count/badge wrong
```text
AJAX poll response count wrong? → ajax_poll_page/KMAE_Live_Page
Response right, badge wrong? → public.js/nav.js + rendered selector
```

## 9. Auth-gated action blocked
```text
User logged in?
├─ NO → auth
└─ YES → verification required and incomplete?
   ├─ YES → verification flow
   └─ NO → action-specific guard (offer/listing/deal/etc.)
```

## 10. Deal outcome wrong
```text
Accepted offer lock wrong? → lock_on_accept
Lock right, success mutation wrong? → confirm_success
Lock right, failure recovery wrong? → confirm_failure
Deal state right, trust/rating wrong? → kmae_deal_success → KMAE_Trust
```

## 11. Contact not visible after acceptance
```text
unlock_accepted_deal wrote correct access?
├─ NO → KMAE_Contact / accept_offer call
└─ YES → contact render/template
```

## 12. Cron archive purge wrong
```text
Event scheduled?
├─ NO → KMAE_Activator::schedule_cron
└─ YES → hook fires?
   ├─ NO → WordPress cron runtime boundary
   └─ YES → KMAE_Listings::purge_expired_archived eligibility/delete
```

## 13. Page route wrong
```text
Correct managed page/query var? → KMAE_Pages
Correct shortcode chosen? → KMAE_Shortcodes
Correct shortcode but wrong markup? → plugin template
Correct plugin markup but layout/style wrong? → THEME BOUNDARY
```

## 14. Plugin boot failure
```text
kmae_run reached? → KMAE_Plugin::run
Class unavailable? → loader/require list
Class available but hooks absent? → feature init registration
```
