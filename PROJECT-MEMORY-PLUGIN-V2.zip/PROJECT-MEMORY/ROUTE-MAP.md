# PAGE / SHORTCODE ROUTE MAP

- `/belepes/` → `[kmae_login]`
- `/regisztracio/` → `[kmae_register]`
- `/hirdetes-feladasa/` → `[kmae_create_listing]`
- `/sajat-hirdetesek/` → `[kmae_my_listings]`
- `/hirdetesek/` → `[kmae_browse]`
- `/kezdolap/` → `[kmae_landing]`
- `/ajanlatok/` → `[kmae_my_offers]`
- `/profil/` → `[kmae_profile]`
- `/hogyan-mukodik/` → `[kmae_how_it_works]`
- `/oktatas/` → `[kmae_education]`
- `/beallitasok/` → `[kmae_settings]`
- `/biztonsag/` → `[kmae_security]`
- `/gyik/` → `[kmae_faq]`
- `/kapcsolat/` → `[kmae_contact]`
- `/feltetelek/` → `[kmae_terms]`
- `/adatvedelem/` → `[kmae_privacy]`
- `/ertesitesek/` → `[kmae_notifications]`
- `/uzenetek/` → `[kmae_messages]`
- `/eladni/` → `[kmae_hub_sell]`
- `/venni/` → `[kmae_hub_buy]`
- `/statisztikak/` → `[kmae_hub_stats]`

## Query vars registered by `KMAE_Pages`

`megye`, `kivitel`, `mod`, `kp_min`, `kp_max`, `step`, `tipus`, `kategoria`.

## Offer thread

`/ajanlatok/?kmae_offer=<offer_id>` → offer-thread branch in `[kmae_my_offers]`; visit hook marks that offer activity seen and body class marks offer-thread state.
