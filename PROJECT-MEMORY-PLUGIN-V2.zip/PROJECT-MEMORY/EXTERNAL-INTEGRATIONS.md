# EXTERNAL INTEGRATIONS

## Google OAuth
Source: `includes/class-kmae-google-auth.php`
- Authorization endpoint: Google accounts authorization endpoint constant.
- Token exchange: Google OAuth token endpoint via WordPress `wp_remote_post`.
- Config: `kmae_google_client_id`, `kmae_google_client_secret` options.
- State: transient with 15-minute expiry.
- Redirect URI: home URL query `kmae_google=callback`.

Runtime availability and Google Console configuration are **UNVERIFIED**.

## E-mail
Source: `includes/class-kmae-brand.php`, `includes/class-kmae-notifications.php`, `includes/class-kmae-auth.php`, public contact handler.
- Delivery through WordPress `wp_mail`.
- `KMAE_Brand` wraps branded HTML and filters mail headers to HTML.
- Offer e-mails respect `KMAE_Auth::wants_offer_emails()` where `send_offer_email()` is used.

Actual SMTP/mail provider is outside this ZIP: **UNVERIFIED**.

## YouTube
Source: `includes/class-kmae-settings.php` and education/how-it-works rendering paths.
- Seller/buyer URLs are WP options.
- Sanitizer accepts YouTube/youtu.be/embed/short/live patterns and extracts video ID.

## Remote Albira assets
`KMAE_Vehicle` contains a remote logo base on `albira.hu`; branded e-mail code also references site-hosted image URLs. Network availability is **UNVERIFIED**.

## Local static data
- `assets/data/vehicle-catalog.json`
- `assets/data/counties-paths.json`
- `assets/svg/hungary-counties.svg`
No external catalog API is required by the inspected source for these datasets.
