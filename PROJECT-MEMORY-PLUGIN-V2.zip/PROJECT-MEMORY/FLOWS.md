# FLOW MAP

## 1. Plugin boot

`ki-mit-adna-erte.php`
→ constants / loader require
→ activation + deactivation hooks registered
→ `kmae_run()`
→ `new KMAE_Plugin()`
→ `KMAE_Plugin::run()`
→ upgrade check + domain initializers
→ public controller / shortcode / pages / nav registration
→ admin controller only when `is_admin()`.

## 2. Activation / upgrade

Activation
→ `KMAE_Activator::activate()`
→ `create_tables()` (7 custom tables + settings defaults + db version)
→ `migrate_price_modes()`
→ register CPT/taxonomy + seed categories
→ `flush_rewrite_rules()`
→ `KMAE_Pages::ensure_pages()`
→ `KMAE_Auth::ensure_subscriber_caps()`
→ daily archive purge cron scheduled.

Normal boot also runs `KMAE_Activator::maybe_upgrade()`; if stored db version is older than plugin version, it repeats schema/migration/page/cap/cron maintenance.

## 3. Password registration → email verification

`/regisztracio/` → `[kmae_register]` → registration template
→ POST `admin-post.php?action=kmae_register`
→ `KMAE_Public::admin_register()`
→ spam checks / terms / input assembly
→ `KMAE_Auth::register()`
→ validates email, phone, account type, password and company location when applicable
→ `wp_insert_user(role=subscriber)`
→ user meta + optional company meta
→ `kmae_user_profiles` row with `email_verified=0`
→ `generate_email_verify_token()` stores only hash + sent timestamp in user meta
→ `send_verification_email()`
→ user clicks home URL with `kmae_email_verify` + raw token
→ `KMAE_Auth::maybe_handle_email_verify_link()` on `init`
→ `verify_email_link()` validates hash and 7-day age
→ `mark_email_verified()` updates custom profile table
→ token meta deleted → redirect to profile/login.

Server-side core-action gate:
`KMAE_Public::handle_forms()` blocks `create_listing` and `submit_cash_offer` when `KMAE_Auth::should_gate_for_verification()` is true.

## 4. Google login

Google button
→ `KMAE_Google_Auth::start_url()` (`?kmae_google=start`)
→ `maybe_handle_request()` on `init`
→ transient state created (15 min)
→ redirect Google authorization endpoint
→ callback `?kmae_google=callback&state=...&code=...`
→ state transient validated/deleted
→ `fetch_profile()` POSTs authorization code to Google token endpoint
→ claims extracted from returned `id_token`
→ `resolve_user()` by stored Google subject, then by email, else creates subscriber
→ WP auth cookie set
→ `KMAE_Auth::mark_email_verified()`
→ if new/incomplete: `kmae_google_pending` forces registration-completion page
→ `handle_complete()` stores phone/account type/terms/company fields and clears pending state.

`template_redirect` → `enforce_completion()` prevents non-admin logged-in users with incomplete Google profiles from using other pages.

## 5. Listing creation — immediate photo path

`/hirdetes-feladasa/` → `[kmae_create_listing]`
→ listing form + wizard assets
→ browser wizard validates stages and can AJAX-save draft
→ final same-page POST `kmae_action=create_listing`
→ `KMAE_Public::handle_forms()`
→ email verification gate
→ `process_create_listing()`
→ nonce + seller eligibility
→ company users obtain listing location from company profile; private users submit valid county/city
→ `KMAE_Vehicle::parse_post_data()`
→ `KMAE_Moderation::validate()` (required vehicle fields, description, photos when required, no contact info)
→ `wp_insert_post(post_type=kmae_listing, post_status=publish)`
→ `KMAE_Listings::save_meta_from_post()`
   → listing condition/category/offer types
   → seller pricing/commitments/private minimum
   → location
   → vehicle meta / launch category
→ photo request validation + `KMAE_Listings::handle_image_uploads()`
   → `KMAE_Photo_Motor::handle_slot_uploads()` when photo motor enabled
   → analyze → optional autocorrect → media upload → `KMAE_Images::process_attachment()` → slot/analysis/hash meta → gallery/thumbnail
→ on failure newly inserted listing is deleted
→ `kmae_listing_published` emitted
→ submitted draft discarded
→ redirect.

## 6. Listing creation — computer/deferred-photo path

`process_create_listing()` receives creation device indicating computer
→ moderation does not require photos at this moment
→ listing created with `_kmae_status=awaiting_photos`
→ redirect to later photo completion/edit path
→ after required slots exist, `KMAE_Listings::activate_if_photos_ready()`
→ status becomes active
→ publish timestamp/state updated
→ `kmae_listing_published` emitted.

## 7. Wizard draft autosave

`assets/js/listing-wizard.js`
→ serializes current wizard state
→ authenticated AJAX action `kmae_save_listing_draft`
→ `KMAE_Listing_Drafts::ajax_save()`
→ creates/updates draft `kmae_listing` post owned by current user
→ `_kmae_status=draft`
→ `_kmae_wizard_draft` stores payload
→ response returns draft ID.

Opening create-listing can read `kmae_draft`/latest draft through `KMAE_Public::enqueue_listing_wizard()` and `KMAE_Listing_Drafts::to_client()`.

## 8. Listing edit

Edit UI
→ admin-post `kmae_update_listing`
→ `KMAE_Public::admin_update_listing()`
→ login/nonce/ownership/`KMAE_Listings::can_edit_listing()`
→ validate fields/location/vehicle/moderation
→ `wp_update_post()` + `KMAE_Listings::save_meta_from_post()`
→ photo motor request validation/upload or legacy gallery edits
→ if previously awaiting photos: `activate_if_photos_ready()` may activate
→ redirect with status.

## 9. Browse/search personalization

`[kmae_browse]`
→ vehicle launch wizard parses `megye`, `kivitel`, `mod`, `kp_min`, `kp_max`
→ `KMAE_Query::get_listings()` queries published listings with `_kmae_status=active`, launch category and relevant meta filters
→ logged-in user: own listings excluded
→ `KMAE_Browse::get_offered_listing_ids()` excludes listings where user has pending/accepted/withdrawn offer
→ results newest-first
→ `KMAE_Browse::personalize_listings()` separates `_kmae_browse_passed`
→ passed items are reinserted every `PASSED_INTERVAL=20` fresh items.

Swipe/pass:
`assets/js/swipe.js` → AJAX `kmae_browse_pass` → `KMAE_Public::ajax_browse_pass()` → `KMAE_Browse::record_pass()` → `_kmae_browse_passed` user meta.

## 10. New cash offer

Offer form → `kmae_action=submit_cash_offer`
→ `KMAE_Public::process_cash_offer()`
→ `KMAE_Offers::submit_cash_offer()`
→ guards: no permanent re-offer after withdrawn; no existing active offer; private buyer fair-buyer pledge; valid active foreign listing; listing accepts cash
→ hidden minimum read from `kmae_private_data`
→ fixed-price listing requires amount approximately equal to fixed price
→ row inserted into `kmae_offers`, status pending
→ below hidden minimum: `filtered_out=1`; buyer still receives returned offer ID, and `kmae_new_offer` is not emitted
→ otherwise `do_action('kmae_new_offer', ...)`
→ `KMAE_Notifications::on_new_offer()` may email seller if preference allows.

## 11. Negotiation / chat

Seller counter:
thread → `submit_counter_offer`
→ `KMAE_Counter_Offers::submit_seller_counter()`
→ pending offer + seller ownership + no deal lock + turn order + seller round count < `KMAE_MAX_COUNTER_ROUNDS`
→ counter row inserted → offer counter count updated
→ `kmae_new_counter_offer` → notification.

Buyer revision:
thread → `revise_offer`
→ `submit_buyer_revision()`
→ latest counter must be seller; same lock/round gates
→ offer cash amount updated + counter history row `buyer_revision`
→ `kmae_buyer_revised_offer` → notification.

Chat timeline is reconstructed from base offer + `kmae_counter_offers` via `KMAE_Counter_Offers::get_chat_messages()` and rendered by `templates/offer-thread.php` / partials.

## 12. Offer acceptance → contact unlock → soft deal lock

`accept_offer`
→ `KMAE_Counter_Offers::accept_offer()`
→ validates party/turn/pending state/listing lock and buyer single-deal constraint
→ if buyer accepts seller counter, accepted amount becomes latest seller counter amount
→ offer status `accepted`
→ `KMAE_Contact::unlock_accepted_deal()` creates unlock rows for seller and buyer
→ `do_action('kmae_offer_accepted', offer_id, listing_id)`
→ priority 5: `KMAE_Deal::lock_on_accept()`
   → listing status `closed`
   → accepted offer ID + lock timestamp + deal phase `viewing`
   → emits `kmae_deal_locked`
→ priority 10: `KMAE_Notifications::on_offer_accepted()`
→ `kmae_deal_locked` listeners send deal-lock related notifications.

Other offers are **not** globally rejected at this soft-lock step.

## 13. Deal success

`deal_success`
→ `KMAE_Deal::confirm_success()`
→ only seller/buyer of accepted locked deal can confirm
→ `KMAE_Counter_Offers::reject_other_offers()` for remaining pending offers
→ listing lock phase/meta cleared as appropriate
→ listing status becomes `archived`, `_kmae_archived_at` stored; accepted offer retained
→ buyer user meta `kmae_post_purchase_offer_id`
→ `kmae_deal_success` emitted
→ listener `KMAE_Trust::on_deal_success()` recalculates both users and sends rating-request notifications
→ `KMAE_Notifications::listing_closed()` notifies impacted participants.

## 14. Deal failure / reopen

`deal_failure`
→ `KMAE_Deal::confirm_failure()`
→ accepted offer reset to pending
→ deal phase/accepted/lock/archive metadata cleared
→ listing status `active`
→ `kmae_deal_failed` emitted
→ notifications resume the negotiation/listing state.

## 15. Contact visibility

Accepted offer path records contact unlock rows through `unlock_accepted_deal()`.
`KMAE_Contact::can_view()` also checks party membership and accepted state; contact presentation uses WordPress user data plus stored phone/profile data.
Manual `unlock_contact` form action → `KMAE_Contact::unlock()` is available only within its server checks.

## 16. Rating / trust

Successful archived deal
→ `KMAE_Trust::get_pending_for_user()` can surface accepted archived offers not yet rated by current user
→ rating form admin-post `kmae_submit_rating`
→ `KMAE_Public::admin_submit_rating()`
→ `KMAE_Trust::submit()`
→ verifies accepted offer + archived listing + party + no duplicate + deal confirmation + 1–5 overall
→ row inserted into `kmae_ratings`
→ `recalculate(rated_user)` caches trust score/deals/positive in user meta
→ `kmae_rating_submitted` emitted.

Trust score formula in source: average of per-rating `(0.6 * overall/5 + 0.4 * criteria-average) * 100`.

## 17. Live page poll / offer badge

`KMAE_Public::enqueue()` localizes `ajaxUrl`, nonce, polling interval 30s and unseen interval 15s
→ `assets/js/public.js`
→ AJAX `kmae_poll_page`
→ `KMAE_Public::ajax_poll_page()`
→ `KMAE_Live_Page::get_fingerprint(...)` + `KMAE_Database::count_unseen_offer_activity()`
→ JSON response lets frontend detect relevant state/activity changes.

## 18. Archive lifecycle / cron purge

Deal success → listing `archived` + `_kmae_archived_at`.
`KMAE_Listings::get_archive_lifecycle()` applies source constants: 5-day locked period + 2-day reactivation window (7 days total).
Activation/normal listing init ensures daily `kmae_purge_archived_listings` cron.
Cron → `KMAE_Listings::purge_expired_archived()`
→ finds expired archived listings
→ `force_delete_listing()`
→ participant notification + attachment cleanup + offer-related custom-table cleanup + `wp_delete_post()`.

## 19. Forced listing deletion

`KMAE_Listings::force_delete_listing()`
→ loads all listing offers including filtered
→ notifies impacted offerers through `KMAE_Notifications::on_listing_deleted()`
→ deletes listing-owned attachments
→ deletes counter-offer, offer-image and contact-unlock records tied to those offer IDs
→ deletes listing offers + private data
→ `wp_delete_post(force=true)`.

The function does not contain a ratings-table delete statement. That is a verified source observation; this map does not infer whether retained rating rows are intentional.
