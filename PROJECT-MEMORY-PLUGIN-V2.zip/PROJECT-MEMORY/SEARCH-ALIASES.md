# SEARCH ALIASES — PLUGIN V2

MAP-TYPE: INDEX

| User wording / UI concept | Technical aliases to search |
|---|---|
| új ajánlat | `kmae_new_offer`, `submit_cash_offer`, `on_new_offer`, offers table |
| ellenajánlat | `submit_seller_counter`, `kmae_new_counter_offer`, `on_counter_offer`, counter_offers |
| vevő módosította az ajánlatot | `submit_buyer_revision`, `kmae_buyer_revised_offer`, `on_buyer_revision` |
| elfogadás | `accept_offer`, `kmae_offer_accepted`, `lock_on_accept`, `on_offer_accepted` |
| rossz elfogadási email | `on_offer_accepted`, `send_offer_email`, `wrap_email`, priority 5/10 |
| visszavonás | `can_withdraw`, `withdraw_offer`, `kmae_offer_withdrawn` |
| kapcsolat megjelenik | `unlock_accepted_deal`, `KMAE_Contact`, `contact-unlock.php` |
| sikeres üzlet | `confirm_success`, `kmae_deal_success`, `on_deal_success`, archive |
| sikertelen üzlet | `confirm_failure`, `kmae_deal_failed`, resume |
| értékelés | `KMAE_Trust`, `request_rating`, `rate-form.php`, pending rating |
| ajánlat kártya / chat | `offer-thread.php`, `offer-chat-timeline.php`, `get_chat_action_state` |
| ajánlat számláló | `ajax_poll_page`, `KMAE_Live_Page`, unseen, `kmae_poll_page` |
| wizard mentés | `kmae_save_listing_draft`, `ajax_save`, `_kmae_wizard_draft` |
| wizard folytatás | `get_user_draft`, `get_latest_draft`, `to_client`, restore |
| fotó 7/7 | `required_slots`, `required_count`, `count_required_filled`, photo-motor |
| awaiting photos | `awaiting_photos`, `activate_if_photos_ready` |
| márka/modell | `vehicle-catalog.js`, `kmaeVehicleCatalog`, `vehicle_brand`, `vehicle_model` |
| hirdetés publikálás | `process_create_listing`, `kmae_listing_published`, `activate_if_photos_ready` |
| céges telephely | `KMAE_Company`, `apply_listing_location` |
| kereső / browse | `KMAE_Query`, `KMAE_Browse`, `filter_by_wizard`, `personalize_listings` |
| pass / kihagyás | `kmae_browse_pass`, `ajax_browse_pass`, `record_pass`, `_kmae_browse_passed` |
| login | `admin_post_kmae_login`, `admin_login`, `KMAE_Auth` |
| regisztráció | `admin_post_kmae_register`, `admin_register`, account type |
| email megerősítés | `verify`, `resend_verification`, `maybe_handle_email_verify_link` |
| Google login | `KMAE_Google_Auth`, `handle_callback`, `redirect_to_google` |
| profil | `admin_post_kmae_save_profile`, `admin_save_profile`, `KMAE_Company` |
| archív / törlés cron | `kmae_purge_archived_listings`, `purge_expired_archived`, `force_delete_listing` |
| kapcsolat űrlap | `admin_contact_form`, `contact_form_email`, `wp_mail` |
| shortcode / oldal | `KMAE_Pages`, `KMAE_Shortcodes`, `shortcode_for`, managed page |
| plugin nem indul | `kmae_run`, `KMAE_Plugin::run`, `KMAE_Loader` |

Search exact hook/action strings before broad text when a symptom names a concrete interaction.
