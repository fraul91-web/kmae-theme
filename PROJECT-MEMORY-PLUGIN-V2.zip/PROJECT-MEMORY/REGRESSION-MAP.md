# REGRESSION ROUTING — PLUGIN V2

MAP-TYPE: ON-DEMAND

## CHANGED: `KMAE_Counter_Offers::accept_offer`
**VERIFY:** seller accepts; buyer accepts; contact unlock; deal lock; accepted email; competing offer status; page reload state.

## CHANGED: `KMAE_Deal::lock_on_accept`
**VERIFY:** listing viewing/lock metadata; buyer single-lock; deal_locked notification; acceptance notification ordering.

## CHANGED: `KMAE_Deal::confirm_success`
**VERIFY:** listing archived; pending offers rejected/closed; buyer post-purchase state; trust pending rating; seller+buyer notifications.

## CHANGED: `KMAE_Deal::confirm_failure`
**VERIFY:** listing reopened/recoverable; offer state restored as designed; buyer other offers resume; failure notification.

## CHANGED: `KMAE_Offers::submit_cash_offer`
**VERIFY:** normal offer; below-minimum filtered offer; seller self-offer guard; duplicate/active guard; kmae_new_offer emission.

## CHANGED: `KMAE_Notifications::send_offer_email`
**VERIFY:** preference ON/OFF; new/counter/revision/accepted/rejected/withdrawn messages; HTML wrapper; recipient identity.

## CHANGED: `KMAE_Brand::send_mail / wrap_email`
**VERIFY:** auth mail, offer mail, contact-related branded output where used; HTML headers; logo/mascot URLs.

## CHANGED: `KMAE_Public::handle_forms`
**VERIFY:** create listing; offer; negotiation actions; deal outcome; verification gate; nonce/error redirects.

## CHANGED: `KMAE_Public::process_create_listing`
**VERIFY:** private and company seller; manual/catalog vehicle; moderation pass/fail; photos ready/not ready; draft discard; publish event.

## CHANGED: `KMAE_Listings::save_meta_from_post`
**VERIFY:** create + edit; company location override; seller price/commitments; vehicle fields.

## CHANGED: `KMAE_Photo_Motor validation`
**VERIFY:** required 7 slots; recommended slots; MIME/size/quality paths; client_config parity; awaiting_photos activation.

## CHANGED: `KMAE_Listing_Drafts::ajax_save/to_client`
**VERIFY:** new draft; update same user draft; ownership; autosave payload; reload restore; final submit discard.

## CHANGED: `KMAE_Browse::personalize_listings`
**VERIFY:** offered exclusion; passed list; reinsertion interval; wizard filters; anonymous/logged-in behavior.

## CHANGED: `KMAE_Auth verification`
**VERIFY:** registration; login; verify link; resend; create-listing gate; offer gate.

## CHANGED: `KMAE_Pages routing`
**VERIFY:** managed URLs; offer thread query; offers seen state; browse URL; legacy redirect; shortcode mapping.

## CHANGED: `KMAE_Plugin::run`
**VERIFY:** front end; wp-admin; activation-upgrade dependent services; every feature init/hook still registered.

