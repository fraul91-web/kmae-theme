# DATA MAP

## Custom tables created by `KMAE_Activator::create_tables()`

### `${prefix}kmae_offers`
- PK `id`; logical links `listing_id` → WP post, `offerer_id` → WP user.
- Core fields: `offer_type`, `cash_amount`, `currency`, `status`, `counter_rounds`, `filtered_out`, timestamps.
- Statuses in `KMAE_Offers`: `pending`, `accepted`, `rejected`, `withdrawn`.
- Used by offers, counter-offers, deal lock, browse personalization, dashboard, notifications, trust.

### `${prefix}kmae_offer_images`
- `offer_id`, `attachment_id`, `sort_order`, `created_at`.
- Read by offer summary/image helpers; retained by schema even though active launch offer type is cash.

### `${prefix}kmae_counter_offers`
- `offer_id`, `user_id`, `template_code`, `cash_amount`, `message`, `status`, `round_number`, timestamps.
- Negotiation history and chat timeline source.

### `${prefix}kmae_private_data`
- One row per `listing_id`; `minimum_cash`, `currency`.
- Hidden seller minimum. `KMAE_Offers::submit_cash_offer()` can set `filtered_out=1` when below it.

### `${prefix}kmae_contact_unlocks`
- `offer_id`, `user_id`, timestamp; unique `(offer_id,user_id)`.
- Audit/persistence for unlocked contact access.

### `${prefix}kmae_ratings`
- `offer_id`, `listing_id`, `rater_id`, `rated_id`, `rated_role`, `overall`, JSON criteria, comment.
- Unique `(offer_id,rater_id)`, so each party rates an offer at most once.

### `${prefix}kmae_user_profiles`
- PK `user_id`; `phone`, `account_type`, email/phone verification flags, email preferences.
- Supplements WP user/usermeta.

**Foreign keys are logical, not DB-enforced**: the source creates indexes/unique keys but no SQL `FOREIGN KEY` constraints.

## Literal WordPress data keys found in executable PHP

| Key | Readers | Writers |
|---|---|---|
| `option:blogname` | `KMAE_Auth::password_reset_email_html`, `KMAE_Auth::request_password_reset` | — |
| `option:kmae_auto_moderation` | `KMAE_Settings::auto_moderation_enabled`, `KMAE_Moderation::is_enabled` | `KMAE_Settings::init_defaults` |
| `option:kmae_buyer_video_url` | `KMAE_Settings::buyer_video_url` | `KMAE_Settings::init_defaults` |
| `option:kmae_contact_form_email` | `KMAE_Settings::contact_form_email` | `KMAE_Settings::init_defaults` |
| `option:kmae_db_version` | `KMAE_Activator::maybe_upgrade` | — |
| `option:kmae_google_client_id` | `KMAE_Google_Auth::client_id` | — |
| `option:kmae_google_client_secret` | `KMAE_Google_Auth::client_secret` | — |
| `option:kmae_pages_version` | `KMAE_Pages::maybe_ensure_pages` | `KMAE_Pages::maybe_ensure_pages` |
| `option:kmae_price_modes_migrated` | `KMAE_Activator::migrate_price_modes` | `KMAE_Activator::migrate_price_modes` |
| `option:kmae_seller_video_url` | `KMAE_Settings::seller_video_url` | `KMAE_Settings::init_defaults` |
| `option:page_on_front` | `KMAE_Pages::ensure_front_page` | `KMAE_Pages::ensure_front_page` |
| `option:show_on_front` | — | `KMAE_Pages::ensure_front_page` |
| `postmeta:_kmae_accepted_offer_id` | `KMAE_Deal::get_locked_offer_id` | `KMAE_Listings::reactivate_listing`, `KMAE_Deal::lock_on_accept`, `KMAE_Deal::confirm_success`, `KMAE_Deal::confirm_failure` |
| `postmeta:_kmae_archived_at` | `KMAE_Listings::get_archive_lifecycle`, `KMAE_Dashboard::get_data` | `KMAE_Listings::reactivate_listing`, `KMAE_Deal::confirm_success`, `KMAE_Deal::confirm_failure` |
| `postmeta:_kmae_city` | `KMAE_Counties::format_listing_location`, `KMAE_Meta::render_meta_box` | `KMAE_Counties::save_listing_location` |
| `postmeta:_kmae_condition` | `KMAE_Vehicle::get_specs`, `KMAE_Meta::render_meta_box` | `KMAE_Listings::save_meta_from_post`, `KMAE_Vehicle::save_from_post`, `KMAE_Meta::save_listing_meta` |
| `postmeta:_kmae_condition_note` | `KMAE_Vehicle::get_specs` | `KMAE_Vehicle::save_from_post` |
| `postmeta:_kmae_county` | `KMAE_Counties::format_listing_location`, `KMAE_Meta::render_meta_box` | `KMAE_Counties::save_listing_location` |
| `postmeta:_kmae_create_device` | — | `KMAE_Public::process_create_listing` |
| `postmeta:_kmae_gallery` | `KMAE_Listings::collect_listing_attachment_ids`, `KMAE_Query::get_gallery_ids` | `KMAE_Listings::handle_image_uploads`, `KMAE_Listings::apply_gallery_edits`, `KMAE_Photo_Motor::handle_slot_uploads` |
| `postmeta:_kmae_location` | `KMAE_Counties::format_listing_location`, `KMAE_Meta::render_meta_box` | `KMAE_Counties::save_listing_location`, `KMAE_Meta::save_listing_meta` |
| `postmeta:_kmae_offer_types` | — | `KMAE_Seller::save_from_post`, `KMAE_Listings::save_meta_from_post`, `KMAE_Meta::save_listing_meta` |
| `postmeta:_kmae_orientation` | `KMAE_Images::get_orientation` | `KMAE_Images::process_attachment` |
| `postmeta:_kmae_published_at` | `KMAE_Listings::activate_if_photos_ready`, `KMAE_Meta::save_listing_meta` | `KMAE_Admin::handle_set_status`, `KMAE_Listings::activate_if_photos_ready`, `KMAE_Listings::save_meta_from_post`, `KMAE_Meta::save_listing_meta` |
| `postmeta:_kmae_reactivated_at` | — | `KMAE_Listings::reactivate_listing` |
| `postmeta:_kmae_status` | `KMAE_Listing_Drafts::get_user_draft`, `KMAE_Meta::render_meta_box`, `KMAE_Meta::get_status` | `KMAE_Admin::handle_set_status`, `KMAE_Admin::handle_listing_bulk_actions`, `KMAE_Listings::reactivate_listing`, `KMAE_Listings::activate_if_photos_ready`, `KMAE_Listings::save_meta_from_post` +5 more |
| `postmeta:_kmae_trade_in_categories` | — | `KMAE_Listings::save_meta_from_post`, `KMAE_Meta::save_listing_meta` |
| `transient:kmae_google_` | `KMAE_Google_Auth::handle_callback` | `KMAE_Google_Auth::redirect_to_google`, `KMAE_Google_Auth::handle_callback` |
| `transient:kmae_mod_errors_` | — | `KMAE_Moderation::stash_errors_for_user` |
| `usermeta:kmae_account_type` | `KMAE_Auth::get_account_type`, `KMAE_Auth::get_profile` | `KMAE_Google_Auth::handle_complete`, `KMAE_Auth::register`, `KMAE_Auth::sync_phone` |
| `usermeta:kmae_email_verify_sent` | `KMAE_Auth::verify_email_link` | `KMAE_Auth::generate_email_verify_token`, `KMAE_Auth::verify_email_link` |
| `usermeta:kmae_email_verify_token` | `KMAE_Auth::verify_email_link` | `KMAE_Auth::generate_email_verify_token`, `KMAE_Auth::verify_email_link` |
| `usermeta:kmae_fair_buyer_pledge` | — | `KMAE_Offers::require_fair_buyer_pledge` |
| `usermeta:kmae_given_name` | `KMAE_Auth::first_name` | — |
| `usermeta:kmae_phone` | `KMAE_Contact::get_contact_details`, `KMAE_Auth::get_profile` | `KMAE_Google_Auth::handle_complete`, `KMAE_Auth::register`, `KMAE_Auth::sync_phone`, `KMAE_Public::admin_save_profile` |

## Important symbolic meta constants

- Listing status: `_kmae_status`; values `active`, `awaiting_photos`, `closed`, `archived`, `draft` (`KMAE_Meta`).
- Offer types: `_kmae_offer_types`; launch active type is `cash`.
- Seller pricing: `_kmae_price_mode`, `_kmae_fixed_price`, `_kmae_guide_price`, `_kmae_commitments`, `_kmae_commit_extra_other`.
- Vehicle: `_kmae_vehicle_brand/model/year/mileage/fuel/transmission/body/color/owners/power_kw/engine_cc/mot/value/traits`.
- Location: `_kmae_county`, `_kmae_city`.
- Photo motor listing meta: `_kmae_photo_slots`, `_kmae_gallery`; attachment meta: `_kmae_photo_slot`, `_kmae_photo_hash`, `_kmae_photo_autofixed`, `_kmae_photo_analysis_v2`.
- Deal: `_kmae_deal_phase`, `_kmae_accepted_offer_id`, `_kmae_deal_locked_at`, `_kmae_archived_at`, `_kmae_reactivated_at`.
- Draft: WP post type `kmae_listing` with `post_status=draft`, `_kmae_status=draft`, payload `_kmae_wizard_draft`.
- Browse user meta: `_kmae_browse_passed`; offer-seen map/meta is maintained in `KMAE_Database`.
- Trust cache user meta: `kmae_trust_score`, `kmae_trust_deals`, `kmae_trust_positive`.
- Google user meta: `kmae_google_sub`, `kmae_given_name`, `kmae_google_pending`.
- Company user meta: `kmae_company_name`, `kmae_company_tax_id`, `kmae_company_address`, `kmae_company_county`, `kmae_company_city`.
- Verification user meta: `kmae_email_verify_token`, `kmae_email_verify_sent`; stored token is hashed with `wp_hash()`.

## Options / migration markers

- `kmae_db_version` — source schema version marker.
- `kmae_price_modes_migrated` — legacy `offers` → `open` migration marker.
- `kmae_auto_moderation`, seller/buyer YouTube URLs, Google OAuth client ID/secret, contact form recipient.
- Page creation/front-page migration options are owned by `KMAE_Pages` (see symbol map for exact keys).

## Runtime-state caveat
The map describes schema and data contracts declared in source. The actual deployed WordPress database contents/schema version are **UNVERIFIED** in this ZIP-only analysis.
