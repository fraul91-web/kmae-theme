# TEMPLATE MAP

Templates are passive views unless they contain form/action wiring. This map records source references and action values visible in templates.

## `admin/views/dashboard.php`
- REFERENCED/INCLUDED BY: `admin/class-kmae-admin.php`, `includes/class-kmae-loader.php`
- `kmae_action` VALUES: —
- `action` VALUES: —
- DIRECT KMAE SYMBOL REFERENCES: `KMAE_Admin::admin_action_url`, `KMAE_Admin::status_badge`, `KMAE_Database::count_offers_for_listing`, `KMAE_Launch::site_tagline`, `KMAE_Meta::get_status`, `KMAE_Vehicle::get_swipe_subtitle`, `KMAE_Vehicle::is_vehicle_launch`
- RELATED FEATURE: `ADMIN`

## `admin/views/meta-box-listing.php`
- REFERENCED/INCLUDED BY: `includes/class-kmae-meta.php`
- `kmae_action` VALUES: —
- `action` VALUES: —
- DIRECT KMAE SYMBOL REFERENCES: `KMAE_Counties::get_all`, `KMAE_Vehicle::body_labels`, `KMAE_Vehicle::condition_labels`, `KMAE_Vehicle::fuel_labels`, `KMAE_Vehicle::get_specs`, `KMAE_Vehicle::is_vehicle_launch`, `KMAE_Vehicle::transmission_labels`
- RELATED FEATURE: `ADMIN`

## `admin/views/offers.php`
- REFERENCED/INCLUDED BY: `admin/class-kmae-admin.php`, `includes/class-kmae-loader.php`, `public/class-kmae-shortcodes.php`
- `kmae_action` VALUES: —
- `action` VALUES: —
- DIRECT KMAE SYMBOL REFERENCES: `KMAE_Admin::admin_action_url`, `KMAE_Admin::status_badge`, `KMAE_Database::count_all_offers`, `KMAE_Offers::get_offer_summary`, `KMAE_Pages::offer_thread_url`
- RELATED FEATURE: `ADMIN`

## `admin/views/settings.php`
- REFERENCED/INCLUDED BY: `admin/class-kmae-admin.php`, `includes/class-kmae-loader.php`, `public/class-kmae-shortcodes.php`
- `kmae_action` VALUES: —
- `action` VALUES: —
- DIRECT KMAE SYMBOL REFERENCES: `KMAE_Google_Auth::redirect_uri`, `KMAE_Settings::auto_moderation_enabled`, `KMAE_Settings::buyer_video_url`, `KMAE_Settings::contact_form_email`, `KMAE_Settings::seller_video_url`
- RELATED FEATURE: `ADMIN`

## `templates/archive-listing.php`
- REFERENCED/INCLUDED BY: `includes/class-kmae-post-types.php`
- `kmae_action` VALUES: —
- `action` VALUES: —
- DIRECT KMAE SYMBOL REFERENCES: —
- RELATED FEATURE: `PAGES-ROUTING`

## `templates/browse-swipe.php`
- REFERENCED/INCLUDED BY: `public/class-kmae-shortcodes.php`
- `kmae_action` VALUES: —
- `action` VALUES: —
- DIRECT KMAE SYMBOL REFERENCES: `KMAE_Browse::bodies_label`, `KMAE_Counties::format_listing_location`, `KMAE_Counties::get_label`, `KMAE_Icons::render`, `KMAE_Meta::get_offer_types`, `KMAE_Query::get_listing_thumbnail_url`, `KMAE_Seller::PRICE_GUIDE`, `KMAE_Seller::get_public_price_row`, `KMAE_Taxonomies::offer_type_labels`, `KMAE_Vehicle::browse_mode_labels`, `KMAE_Vehicle::format_value`, `KMAE_Vehicle::get_swipe_subtitle`, `KMAE_Vehicle::get_vehicle_value`, `KMAE_Vehicle::is_vehicle_launch`
- RELATED FEATURE: `BROWSE-SEARCH`

## `templates/browse-wizard-body.php`
- REFERENCED/INCLUDED BY: `public/class-kmae-shortcodes.php`
- `kmae_action` VALUES: —
- `action` VALUES: —
- DIRECT KMAE SYMBOL REFERENCES: `KMAE_Counties::get_label`, `KMAE_Icons::render`, `KMAE_Launch::wizard_step_label`, `KMAE_Vehicle::browse_body_cards`
- RELATED FEATURE: `BROWSE-SEARCH`

## `templates/browse-wizard-category.php`
- REFERENCED/INCLUDED BY: `public/class-kmae-shortcodes.php`
- `kmae_action` VALUES: —
- `action` VALUES: —
- DIRECT KMAE SYMBOL REFERENCES: `KMAE_Counties::get_label`, `KMAE_Taxonomies::offer_type_labels`, `KMAE_Taxonomies::seed_categories`
- RELATED FEATURE: `BOOT-ARCHITECTURE`

## `templates/browse-wizard-map.php`
- REFERENCED/INCLUDED BY: `public/class-kmae-shortcodes.php`
- `kmae_action` VALUES: —
- `action` VALUES: —
- DIRECT KMAE SYMBOL REFERENCES: `KMAE_Counties::ORSZAG`, `KMAE_Counties::get_label`, `KMAE_Counties::get_map_data`, `KMAE_Counties::get_map_label_short`, `KMAE_Launch::wizard_step_label`, `KMAE_Pages::browse_page_url`
- RELATED FEATURE: `BROWSE-SEARCH`

## `templates/browse-wizard-offer.php`
- REFERENCED/INCLUDED BY: `public/class-kmae-shortcodes.php`
- `kmae_action` VALUES: —
- `action` VALUES: —
- DIRECT KMAE SYMBOL REFERENCES: `KMAE_Browse::bodies_label`, `KMAE_Browse::bodies_to_query_value`, `KMAE_Counties::get_label`, `KMAE_Icons::render`, `KMAE_Launch::wizard_step_label`, `KMAE_Vehicle::BROWSE_AJANLAT`, `KMAE_Vehicle::BROWSE_KP`
- RELATED FEATURE: `BROWSE-SEARCH`

## `templates/browse-wizard-type.php`
- REFERENCED/INCLUDED BY: `public/class-kmae-shortcodes.php`
- `kmae_action` VALUES: —
- `action` VALUES: —
- DIRECT KMAE SYMBOL REFERENCES: `KMAE_Counties::get_label`, `KMAE_Launch::wizard_step_label`, `KMAE_Taxonomies::offer_type_labels`, `KMAE_Vehicle::is_vehicle_launch`
- RELATED FEATURE: `BOOT-ARCHITECTURE`

## `templates/browse.php`
- REFERENCED/INCLUDED BY: `includes/class-kmae-loader.php`, `public/class-kmae-shortcodes.php`
- `kmae_action` VALUES: —
- `action` VALUES: —
- DIRECT KMAE SYMBOL REFERENCES: `KMAE_Counties::format_listing_location`, `KMAE_Images::responsive_attrs`, `KMAE_Meta::get_offer_types`, `KMAE_Query::get_listing_thumbnail_id`, `KMAE_Query::get_listing_thumbnail_url`, `KMAE_Seller::PRICE_GUIDE`, `KMAE_Seller::get_public_price_row`, `KMAE_Taxonomies::offer_type_labels`
- RELATED FEATURE: `BROWSE-SEARCH`

## `templates/contact.php`
- REFERENCED/INCLUDED BY: `includes/class-kmae-loader.php`, `public/class-kmae-shortcodes.php`
- `kmae_action` VALUES: —
- `action` VALUES: `kmae_contact_form`
- DIRECT KMAE SYMBOL REFERENCES: `KMAE_Pages::url`
- RELATED FEATURE: `CONTACT-FORM`

## `templates/education.php`
- REFERENCED/INCLUDED BY: `public/class-kmae-shortcodes.php`
- `kmae_action` VALUES: —
- `action` VALUES: —
- DIRECT KMAE SYMBOL REFERENCES: `KMAE_Back::home_label`, `KMAE_Back::home_url`, `KMAE_Settings::buyer_video_id`, `KMAE_Settings::seller_video_id`
- RELATED FEATURE: `BOOT-ARCHITECTURE`

## `templates/faq.php`
- REFERENCED/INCLUDED BY: `public/class-kmae-shortcodes.php`
- `kmae_action` VALUES: —
- `action` VALUES: —
- DIRECT KMAE SYMBOL REFERENCES: `KMAE_Pages::url`
- RELATED FEATURE: `BOOT-ARCHITECTURE`

## `templates/form-create-listing.php`
- REFERENCED/INCLUDED BY: `public/class-kmae-shortcodes.php`
- `kmae_action` VALUES: —
- `action` VALUES: —
- DIRECT KMAE SYMBOL REFERENCES: —
- RELATED FEATURE: `LISTINGS`

## `templates/form-listing.php`
- REFERENCED/INCLUDED BY: `templates/form-create-listing.php`, `public/class-kmae-shortcodes.php`
- `kmae_action` VALUES: —
- `action` VALUES: —
- DIRECT KMAE SYMBOL REFERENCES: `KMAE_Auth::is_company`, `KMAE_Company::get_city`, `KMAE_Company::get_county`, `KMAE_Counties::get_label`, `KMAE_Database::get_private_data`, `KMAE_Launch::get_available_categories`, `KMAE_Launch::get_launch_category_id`, `KMAE_Listing_Drafts::get_user_draft`, `KMAE_Meta::STATUS_AWAITING_PHOTOS`, `KMAE_Meta::get_status`, `KMAE_Moderation::MIN_IMAGES`, `KMAE_Moderation::is_enabled`, `KMAE_Moderation::pull_errors_for_user`, `KMAE_Photo_Motor::take_autofix_notice`, `KMAE_Query::get_gallery_ids`, `KMAE_Seller::can_create_listing`, `KMAE_Seller::get_commitments`, `KMAE_Seller::get_extra_other`, `KMAE_Seller::get_fixed_price`, `KMAE_Seller::get_guide_price` +2 more
- RELATED FEATURE: `LISTINGS`

## `templates/form-login.php`
- REFERENCED/INCLUDED BY: `includes/class-kmae-pages.php`, `public/class-kmae-shortcodes.php`
- `kmae_action` VALUES: —
- `action` VALUES: `kmae_login`, `kmae_lost_password`, `kmae_reset_password`
- DIRECT KMAE SYMBOL REFERENCES: `KMAE_Auth::login_url`, `KMAE_Auth::lost_password_url`, `KMAE_Auth::register_url`, `KMAE_Dashboard::greeting_case`
- RELATED FEATURE: `AUTH`

## `templates/form-profile.php`
- REFERENCED/INCLUDED BY: `public/class-kmae-shortcodes.php`
- `kmae_action` VALUES: —
- `action` VALUES: `kmae_resend_verification`, `kmae_save_profile`
- DIRECT KMAE SYMBOL REFERENCES: `KMAE_Auth::account_type_label`, `KMAE_Auth::get_profile`, `KMAE_Auth::is_company`, `KMAE_Back::home_label`, `KMAE_Back::home_url`, `KMAE_Company::get_address`, `KMAE_Company::get_city`, `KMAE_Company::get_company_name`, `KMAE_Company::get_county`, `KMAE_Company::get_tax_id`, `KMAE_Counties::get_all`, `KMAE_Database::get_offer`, `KMAE_Deal::get_continue_offer_id`, `KMAE_Icons::render`, `KMAE_Pages::url`, `KMAE_Trust::get_pending_for_user`, `KMAE_Trust::get_summary`, `KMAE_Trust::has_rated`, `KMAE_Trust::rate_url`, `KMAE_Trust::resolve_rated_party`
- RELATED FEATURE: `PROFILE-COMPANY-SETTINGS`

## `templates/form-register.php`
- REFERENCED/INCLUDED BY: `includes/class-kmae-pages.php`, `public/class-kmae-shortcodes.php`
- `kmae_action` VALUES: —
- `action` VALUES: `kmae_register`
- DIRECT KMAE SYMBOL REFERENCES: `KMAE_Auth::ACCOUNT_COMPANY`, `KMAE_Auth::ACCOUNT_PRIVATE`, `KMAE_Auth::login_url`, `KMAE_Counties::get_all`, `KMAE_Google_Auth::needs_completion`, `KMAE_Pages::url`
- RELATED FEATURE: `AUTH`

## `templates/hero.php`
- REFERENCED/INCLUDED BY: `public/class-kmae-shortcodes.php`
- `kmae_action` VALUES: —
- `action` VALUES: —
- DIRECT KMAE SYMBOL REFERENCES: `KMAE_Pages::browse_page_url`
- RELATED FEATURE: `PAGES-ROUTING`

## `templates/how-it-works.php`
- REFERENCED/INCLUDED BY: `public/class-kmae-shortcodes.php`
- `kmae_action` VALUES: —
- `action` VALUES: —
- DIRECT KMAE SYMBOL REFERENCES: —
- RELATED FEATURE: `BOOT-ARCHITECTURE`

## `templates/hub-section.php`
- REFERENCED/INCLUDED BY: `public/class-kmae-shortcodes.php`
- `kmae_action` VALUES: —
- `action` VALUES: —
- DIRECT KMAE SYMBOL REFERENCES: `KMAE_Icons::render`
- RELATED FEATURE: `DASHBOARD-HUBS`

## `templates/landing-features.php`
- REFERENCED/INCLUDED BY: `public/class-kmae-shortcodes.php`
- `kmae_action` VALUES: —
- `action` VALUES: —
- DIRECT KMAE SYMBOL REFERENCES: `KMAE_Icons::render`
- RELATED FEATURE: `PAGES-ROUTING`

## `templates/landing-popular.php`
- REFERENCED/INCLUDED BY: `public/class-kmae-shortcodes.php`
- `kmae_action` VALUES: —
- `action` VALUES: —
- DIRECT KMAE SYMBOL REFERENCES: `KMAE_Icons::render`, `KMAE_Pages::browse_page_url`, `KMAE_Query::get_listing_thumbnail_url`, `KMAE_Query::get_popular_listings`, `KMAE_Vehicle::format_value`, `KMAE_Vehicle::get_display_title`, `KMAE_Vehicle::get_vehicle_value`
- RELATED FEATURE: `PAGES-ROUTING`

## `templates/landing-search.php`
- REFERENCED/INCLUDED BY: `public/class-kmae-shortcodes.php`
- `kmae_action` VALUES: —
- `action` VALUES: —
- DIRECT KMAE SYMBOL REFERENCES: `KMAE_Pages::browse_page_url`, `KMAE_Vehicle::brands`
- RELATED FEATURE: `PAGES-ROUTING`

## `templates/messages.php`
- REFERENCED/INCLUDED BY: `public/class-kmae-shortcodes.php`
- `kmae_action` VALUES: —
- `action` VALUES: —
- DIRECT KMAE SYMBOL REFERENCES: `KMAE_Back::home_label`, `KMAE_Back::home_url`, `KMAE_Pages::url`
- RELATED FEATURE: `BOOT-ARCHITECTURE`

## `templates/my-listings.php`
- REFERENCED/INCLUDED BY: `public/class-kmae-shortcodes.php`
- `kmae_action` VALUES: —
- `action` VALUES: `kmae_delete_listing`, `kmae_reactivate_listing`
- DIRECT KMAE SYMBOL REFERENCES: `KMAE_Icons::render`, `KMAE_Images::get_url`, `KMAE_Listings::can_delete_listing`, `KMAE_Listings::can_edit_listing`, `KMAE_Listings::can_reactivate_listing`, `KMAE_Listings::get_archive_lifecycle`, `KMAE_Meta::STATUS_ACTIVE`, `KMAE_Meta::STATUS_AWAITING_PHOTOS`, `KMAE_Meta::STATUS_CLOSED`, `KMAE_Meta::STATUS_DRAFT`, `KMAE_Meta::get_status`, `KMAE_Query::get_gallery_ids`, `KMAE_Vehicle::format_mileage`, `KMAE_Vehicle::fuel_labels`, `KMAE_Vehicle::get_specs`, `KMAE_Vehicle::transmission_labels`
- RELATED FEATURE: `LISTINGS`

## `templates/my-offers.php`
- REFERENCED/INCLUDED BY: `public/class-kmae-shortcodes.php`
- `kmae_action` VALUES: —
- `action` VALUES: —
- DIRECT KMAE SYMBOL REFERENCES: `KMAE_Auth::is_company`, `KMAE_Back::home_label`, `KMAE_Back::home_url`, `KMAE_Live_Page::get_fingerprint`, `KMAE_Pages::offer_thread_url`
- RELATED FEATURE: `OFFERS`

## `templates/notifications.php`
- REFERENCED/INCLUDED BY: `includes/class-kmae-loader.php`, `public/class-kmae-shortcodes.php`
- `kmae_action` VALUES: —
- `action` VALUES: —
- DIRECT KMAE SYMBOL REFERENCES: `KMAE_Back::home_label`, `KMAE_Back::home_url`
- RELATED FEATURE: `BOOT-ARCHITECTURE`

## `templates/offer-thread.php`
- REFERENCED/INCLUDED BY: `public/class-kmae-shortcodes.php`
- `kmae_action` VALUES: —
- `action` VALUES: —
- DIRECT KMAE SYMBOL REFERENCES: `KMAE_Counter_Offers::get_current_amount_summary`, `KMAE_Counter_Offers::get_other_party_name`, `KMAE_Counter_Offers::status_labels`, `KMAE_Live_Page::get_fingerprint`, `KMAE_Offers::STATUS_ACCEPTED`, `KMAE_Offers::STATUS_REJECTED`, `KMAE_Offers::STATUS_WITHDRAWN`, `KMAE_Offers::can_withdraw`, `KMAE_Offers::render_offer_images`, `KMAE_Pages::offers_page_url`, `KMAE_Query::get_listing_thumbnail_url`
- RELATED FEATURE: `NEGOTIATION-CHAT`

## `templates/partials/cash-amount-input.php`
- REFERENCED/INCLUDED BY: `templates/partials/offer-owner-actions.php`, `templates/partials/offer-forms.php`, `templates/partials/offer-buyer-negotiation.php`, `templates/partials/offer-chat-message-actions.php`
- `kmae_action` VALUES: —
- `action` VALUES: —
- DIRECT KMAE SYMBOL REFERENCES: —
- RELATED FEATURE: `OFFERS`

## `templates/partials/contact-unlock.php`
- REFERENCED/INCLUDED BY: `templates/partials/offer-owner-actions.php`, `templates/partials/offer-chat-actions.php`, `templates/partials/offer-buyer-negotiation.php`
- `kmae_action` VALUES: —
- `action` VALUES: —
- DIRECT KMAE SYMBOL REFERENCES: `KMAE_Contact::can_view`, `KMAE_Contact::get_contact_details`, `KMAE_Contact::get_other_party_id`, `KMAE_Offers::STATUS_ACCEPTED`
- RELATED FEATURE: `CONTACT-UNLOCK`

## `templates/partials/continue-shopping.php`
- REFERENCED/INCLUDED BY: `templates/form-profile.php`
- `kmae_action` VALUES: —
- `action` VALUES: `kmae_continue_shopping`
- DIRECT KMAE SYMBOL REFERENCES: `KMAE_Auth::is_company`, `KMAE_Database::get_offer`, `KMAE_Deal::get_buyer_other_pending_offers`, `KMAE_Icons::render`
- RELATED FEATURE: `DEAL`

## `templates/partials/create-listing-guest.php`
- REFERENCED/INCLUDED BY: `public/class-kmae-shortcodes.php`
- `kmae_action` VALUES: —
- `action` VALUES: —
- DIRECT KMAE SYMBOL REFERENCES: `KMAE_Auth::login_url`, `KMAE_Auth::register_url`
- RELATED FEATURE: `LISTINGS`

## `templates/partials/dashboard-home.php`
- REFERENCED/INCLUDED BY: —
- `kmae_action` VALUES: —
- `action` VALUES: —
- DIRECT KMAE SYMBOL REFERENCES: `KMAE_Dashboard::take_home_greeting`, `KMAE_Icons::render`
- RELATED FEATURE: `DASHBOARD-HUBS`

## `templates/partials/deal-outcome.php`
- REFERENCED/INCLUDED BY: `templates/partials/offer-owner-actions.php`, `templates/partials/offer-chat-actions.php`, `templates/partials/offer-buyer-negotiation.php`
- `kmae_action` VALUES: `deal_failure`, `deal_success`
- `action` VALUES: —
- DIRECT KMAE SYMBOL REFERENCES: `KMAE_Deal::can_confirm`, `KMAE_Deal::is_viewing_deal`
- RELATED FEATURE: `DEAL`

## `templates/partials/email-verify-gate.php`
- REFERENCED/INCLUDED BY: `templates/single-listing.php`, `public/class-kmae-shortcodes.php`
- `kmae_action` VALUES: —
- `action` VALUES: `kmae_resend_verification`
- DIRECT KMAE SYMBOL REFERENCES: —
- RELATED FEATURE: `AUTH`

## `templates/partials/fair-buyer-pledge.php`
- REFERENCED/INCLUDED BY: `templates/partials/offer-forms.php`
- `kmae_action` VALUES: —
- `action` VALUES: —
- DIRECT KMAE SYMBOL REFERENCES: `KMAE_Auth::is_private_person`
- RELATED FEATURE: `OFFERS`

## `templates/partials/google-button.php`
- REFERENCED/INCLUDED BY: `templates/form-login.php`, `templates/form-register.php`
- `kmae_action` VALUES: —
- `action` VALUES: —
- DIRECT KMAE SYMBOL REFERENCES: `KMAE_Google_Auth::is_configured`, `KMAE_Google_Auth::start_url`
- RELATED FEATURE: `AUTH`, `GOOGLE-AUTH`

## `templates/partials/google-complete.php`
- REFERENCED/INCLUDED BY: `templates/form-register.php`
- `kmae_action` VALUES: —
- `action` VALUES: `kmae_google_complete`
- DIRECT KMAE SYMBOL REFERENCES: `KMAE_Auth::ACCOUNT_COMPANY`, `KMAE_Auth::ACCOUNT_PRIVATE`, `KMAE_Auth::first_name`, `KMAE_Counties::get_all`, `KMAE_Dashboard::greeting_case`, `KMAE_Pages::url`
- RELATED FEATURE: `GOOGLE-AUTH`

## `templates/partials/listing-form-layout.php`
- REFERENCED/INCLUDED BY: `templates/form-listing.php`
- `kmae_action` VALUES: `create_listing`
- `action` VALUES: `kmae_update_listing`
- DIRECT KMAE SYMBOL REFERENCES: `KMAE_Back::browse_url`, `KMAE_Counties::get_all`, `KMAE_Icons::render`, `KMAE_Moderation::MIN_DESC_LENGTH`, `KMAE_Moderation::is_enabled`, `KMAE_Photo_Motor::get_slots`, `KMAE_Photo_Motor::is_enabled`, `KMAE_Photo_Motor::recommended_slots`, `KMAE_Photo_Motor::recommended_total_count`, `KMAE_Photo_Motor::required_count`, `KMAE_Photo_Motor::required_slots`, `KMAE_Seller::COMMIT_OTHER`, `KMAE_Seller::PRICE_FIXED`, `KMAE_Seller::PRICE_GUIDE`, `KMAE_Seller::commitment_defs`, `KMAE_Seller::extra_commitment_defs`, `KMAE_Seller::price_mode_defs`
- RELATED FEATURE: `LISTINGS`, `LISTING-WIZARD-DRAFTS`

## `templates/partials/listing-gallery-manager.php`
- REFERENCED/INCLUDED BY: `templates/partials/listing-form-layout.php`
- `kmae_action` VALUES: —
- `action` VALUES: —
- DIRECT KMAE SYMBOL REFERENCES: `KMAE_Icons::render`, `KMAE_Images::get_url`
- RELATED FEATURE: `PHOTO-MOTOR`

## `templates/partials/listing-gallery.php`
- REFERENCED/INCLUDED BY: `templates/single-listing.php`
- `kmae_action` VALUES: —
- `action` VALUES: —
- DIRECT KMAE SYMBOL REFERENCES: `KMAE_Images::get_url`, `KMAE_Images::responsive_attrs`, `KMAE_Query::get_gallery_ids`
- RELATED FEATURE: `PHOTO-MOTOR`

## `templates/partials/listing-photo-motor.php`
- REFERENCED/INCLUDED BY: `templates/partials/listing-form-layout.php`
- `kmae_action` VALUES: —
- `action` VALUES: —
- DIRECT KMAE SYMBOL REFERENCES: `KMAE_Images::get_url`, `KMAE_Photo_Motor::all_slots`, `KMAE_Photo_Motor::get_slots`, `KMAE_Photo_Motor::recommended_slots`, `KMAE_Photo_Motor::required_slots`
- RELATED FEATURE: `PHOTO-MOTOR`

## `templates/partials/listing-pledge-badges.php`
- REFERENCED/INCLUDED BY: `templates/browse-swipe.php`, `templates/browse.php`, `templates/single-listing.php`
- `kmae_action` VALUES: —
- `action` VALUES: —
- DIRECT KMAE SYMBOL REFERENCES: `KMAE_Seller::get_badge_rows`
- RELATED FEATURE: `LISTINGS`

## `templates/partials/listing-wizard.php`
- REFERENCED/INCLUDED BY: `includes/class-kmae-loader.php`, `templates/partials/listing-form-layout.php`
- `kmae_action` VALUES: —
- `action` VALUES: —
- DIRECT KMAE SYMBOL REFERENCES: `KMAE_Icons::render`, `KMAE_Listing_Wizard::description_topics`, `KMAE_Listing_Wizard::phases`
- RELATED FEATURE: `LISTING-WIZARD-DRAFTS`

## `templates/partials/offer-buyer-negotiation.php`
- REFERENCED/INCLUDED BY: `templates/single-listing.php`
- `kmae_action` VALUES: `accept_offer`, `revise_offer`
- `action` VALUES: —
- DIRECT KMAE SYMBOL REFERENCES: `KMAE_Counter_Offers::can_buyer_accept`, `KMAE_Counter_Offers::can_buyer_revise`, `KMAE_Counter_Offers::format_counter_message`, `KMAE_Counter_Offers::get_negotiation_summary`, `KMAE_Counter_Offers::is_seller`, `KMAE_Counter_Offers::status_labels`, `KMAE_Deal::assert_buyer_can_lock`, `KMAE_Deal::is_locked`, `KMAE_Deal::is_viewing_deal`, `KMAE_Offers::STATUS_ACCEPTED`, `KMAE_Offers::STATUS_PENDING`, `KMAE_Offers::STATUS_REJECTED`, `KMAE_Offers::STATUS_WITHDRAWN`, `KMAE_Offers::format_cash`
- RELATED FEATURE: `NEGOTIATION-CHAT`

## `templates/partials/offer-chat-actions.php`
- REFERENCED/INCLUDED BY: `templates/offer-thread.php`
- `kmae_action` VALUES: —
- `action` VALUES: —
- DIRECT KMAE SYMBOL REFERENCES: `KMAE_Deal::is_locked`, `KMAE_Deal::is_viewing_deal`, `KMAE_Offers::STATUS_ACCEPTED`, `KMAE_Offers::STATUS_PENDING`, `KMAE_Offers::STATUS_REJECTED`, `KMAE_Offers::STATUS_WITHDRAWN`
- RELATED FEATURE: `NEGOTIATION-CHAT`

## `templates/partials/offer-chat-message-actions.php`
- REFERENCED/INCLUDED BY: `templates/partials/offer-chat-timeline.php`
- `kmae_action` VALUES: `accept_offer`, `revise_offer`, `submit_counter_offer`
- `action` VALUES: —
- DIRECT KMAE SYMBOL REFERENCES: `KMAE_Counter_Offers::is_seller`, `KMAE_Offers::STATUS_PENDING`, `KMAE_Offers::format_cash`, `KMAE_Taxonomies::counter_templates`
- RELATED FEATURE: `NEGOTIATION-CHAT`

## `templates/partials/offer-chat-timeline.php`
- REFERENCED/INCLUDED BY: `templates/offer-thread.php`
- `kmae_action` VALUES: —
- `action` VALUES: —
- DIRECT KMAE SYMBOL REFERENCES: `KMAE_Counter_Offers::get_chat_action_state`, `KMAE_Counter_Offers::get_chat_kind_label`, `KMAE_Counter_Offers::get_chat_messages`, `KMAE_Counter_Offers::is_seller`, `KMAE_Dashboard::greeting_case`, `KMAE_Icons::render`, `KMAE_Offers::STATUS_ACCEPTED`, `KMAE_Offers::STATUS_PENDING`, `KMAE_Offers::STATUS_REJECTED`, `KMAE_Offers::STATUS_WITHDRAWN`, `KMAE_Offers::get_offerer_display_name`
- RELATED FEATURE: `NEGOTIATION-CHAT`

## `templates/partials/offer-forms.php`
- REFERENCED/INCLUDED BY: `templates/single-listing.php`
- `kmae_action` VALUES: `submit_cash_offer`
- `action` VALUES: —
- DIRECT KMAE SYMBOL REFERENCES: `KMAE_Offers::format_cash`, `KMAE_Seller::get_fixed_price`, `KMAE_Seller::get_guide_price`, `KMAE_Seller::is_fixed_price`, `KMAE_Seller::is_guide_price`, `KMAE_Taxonomies::offer_type_buyer_hints`, `KMAE_Taxonomies::offer_type_labels`
- RELATED FEATURE: `OFFERS`

## `templates/partials/offer-hub-card.php`
- REFERENCED/INCLUDED BY: `templates/my-offers.php`
- `kmae_action` VALUES: —
- `action` VALUES: —
- DIRECT KMAE SYMBOL REFERENCES: `KMAE_Auth::is_company`, `KMAE_Counter_Offers::get_current_amount_summary`, `KMAE_Counter_Offers::get_last_chat_preview`, `KMAE_Counter_Offers::get_other_party_name`, `KMAE_Counter_Offers::status_labels`, `KMAE_Database::get_offer_alert_state`, `KMAE_Offers::get_offerer_display_name`, `KMAE_Query::get_listing_thumbnail_url`
- RELATED FEATURE: `OFFERS`

## `templates/partials/offer-hub-listing-head.php`
- REFERENCED/INCLUDED BY: —
- `kmae_action` VALUES: —
- `action` VALUES: —
- DIRECT KMAE SYMBOL REFERENCES: `KMAE_Query::get_listing_thumbnail_url`
- RELATED FEATURE: `OFFERS`

## `templates/partials/offer-owner-actions.php`
- REFERENCED/INCLUDED BY: —
- `kmae_action` VALUES: `accept_offer`, `submit_counter_offer`
- `action` VALUES: —
- DIRECT KMAE SYMBOL REFERENCES: `KMAE_Auth::is_company`, `KMAE_Counter_Offers::can_seller_accept`, `KMAE_Counter_Offers::can_seller_counter`, `KMAE_Counter_Offers::format_counter_message`, `KMAE_Counter_Offers::get_negotiation_summary`, `KMAE_Counter_Offers::status_labels`, `KMAE_Deal::assert_buyer_can_lock`, `KMAE_Deal::is_locked`, `KMAE_Deal::is_viewing_deal`, `KMAE_Offers::STATUS_ACCEPTED`, `KMAE_Offers::STATUS_PENDING`, `KMAE_Offers::get_offer_summary`, `KMAE_Offers::get_offerer_display_name`, `KMAE_Offers::render_offer_images`, `KMAE_Taxonomies::counter_templates`, `KMAE_Trust::get_summary`
- RELATED FEATURE: `NEGOTIATION-CHAT`

## `templates/partials/offer-withdraw-form.php`
- REFERENCED/INCLUDED BY: `templates/offer-thread.php`, `templates/single-listing.php`
- `kmae_action` VALUES: `withdraw_offer`
- `action` VALUES: —
- DIRECT KMAE SYMBOL REFERENCES: `KMAE_Offers::can_withdraw`
- RELATED FEATURE: `OFFERS`

## `templates/partials/page-back.php`
- REFERENCED/INCLUDED BY: `templates/messages.php`, `templates/single-listing.php`, `templates/education.php`, `templates/security.php`, `templates/notifications.php`, `templates/my-offers.php`
- `kmae_action` VALUES: —
- `action` VALUES: —
- DIRECT KMAE SYMBOL REFERENCES: `KMAE_Back::home_label`, `KMAE_Back::home_url`
- RELATED FEATURE: `BOOT-ARCHITECTURE`

## `templates/partials/rate-form.php`
- REFERENCED/INCLUDED BY: `templates/form-profile.php`
- `kmae_action` VALUES: —
- `action` VALUES: `kmae_submit_rating`
- DIRECT KMAE SYMBOL REFERENCES: `KMAE_Dashboard::greeting_case`, `KMAE_Icons::render`, `KMAE_Trust::criteria_for_rated_role`
- RELATED FEATURE: `TRUST-RATINGS`

## `templates/partials/trust-card.php`
- REFERENCED/INCLUDED BY: `templates/single-listing.php`, `templates/security.php`
- `kmae_action` VALUES: —
- `action` VALUES: —
- DIRECT KMAE SYMBOL REFERENCES: `KMAE_Auth::is_company`, `KMAE_Company::get_company_name`, `KMAE_Trust::get_summary`
- RELATED FEATURE: `TRUST-RATINGS`

## `templates/partials/vehicle-form-fields.php`
- REFERENCED/INCLUDED BY: `templates/partials/listing-form-layout.php`
- `kmae_action` VALUES: —
- `action` VALUES: —
- DIRECT KMAE SYMBOL REFERENCES: `KMAE_Icons::render`, `KMAE_Vehicle::MAX_TRAITS`, `KMAE_Vehicle::body_types`, `KMAE_Vehicle::condition_labels`, `KMAE_Vehicle::fuel_labels`, `KMAE_Vehicle::get_specs`, `KMAE_Vehicle::get_traits`, `KMAE_Vehicle::is_known_brand`, `KMAE_Vehicle::is_known_model`, `KMAE_Vehicle::kw_to_horsepower`, `KMAE_Vehicle::traits`, `KMAE_Vehicle::transmission_labels`
- RELATED FEATURE: `VEHICLE`

## `templates/partials/vehicle-specs-display.php`
- REFERENCED/INCLUDED BY: `templates/single-listing.php`
- `kmae_action` VALUES: —
- `action` VALUES: —
- DIRECT KMAE SYMBOL REFERENCES: `KMAE_Icons::render`, `KMAE_Vehicle::get_display_rows`, `KMAE_Vehicle::get_traits`, `KMAE_Vehicle::traits`
- RELATED FEATURE: `VEHICLE`

## `templates/privacy.php`
- REFERENCED/INCLUDED BY: `public/class-kmae-shortcodes.php`
- `kmae_action` VALUES: —
- `action` VALUES: —
- DIRECT KMAE SYMBOL REFERENCES: —
- RELATED FEATURE: `BOOT-ARCHITECTURE`

## `templates/security.php`
- REFERENCED/INCLUDED BY: `public/class-kmae-shortcodes.php`
- `kmae_action` VALUES: —
- `action` VALUES: —
- DIRECT KMAE SYMBOL REFERENCES: `KMAE_Back::home_label`, `KMAE_Back::home_url`
- RELATED FEATURE: `PROFILE-COMPANY-SETTINGS`

## `templates/settings.php`
- REFERENCED/INCLUDED BY: `admin/class-kmae-admin.php`, `includes/class-kmae-loader.php`, `public/class-kmae-shortcodes.php`
- `kmae_action` VALUES: —
- `action` VALUES: `kmae_change_email`, `kmae_change_password`, `kmae_logout_everywhere`, `kmae_save_settings`
- DIRECT KMAE SYMBOL REFERENCES: `KMAE_Auth::account_type_label`, `KMAE_Auth::is_company`, `KMAE_Auth::wants_news_emails`, `KMAE_Auth::wants_offer_emails`, `KMAE_Back::home_label`, `KMAE_Back::home_url`, `KMAE_Icons::render`, `KMAE_Pages::url`
- RELATED FEATURE: `PROFILE-COMPANY-SETTINGS`

## `templates/single-listing.php`
- REFERENCED/INCLUDED BY: `includes/class-kmae-post-types.php`
- `kmae_action` VALUES: —
- `action` VALUES: —
- DIRECT KMAE SYMBOL REFERENCES: `KMAE_Auth::account_type_label`, `KMAE_Auth::is_company`, `KMAE_Auth::login_url`, `KMAE_Auth::should_gate_for_verification`, `KMAE_Back::listing_back_url`, `KMAE_Counter_Offers::status_labels`, `KMAE_Counties::format_listing_location`, `KMAE_Database::get_active_user_offer_for_listing`, `KMAE_Database::get_offers_for_listing`, `KMAE_Database::get_withdrawn_user_offer_for_listing`, `KMAE_Icons::render`, `KMAE_Live_Page::get_fingerprint`, `KMAE_Meta::STATUS_ACTIVE`, `KMAE_Meta::get_offer_types`, `KMAE_Meta::get_status`, `KMAE_Offers::get_offer_summary`, `KMAE_Offers::render_offer_images`, `KMAE_Pages::offer_thread_url`, `KMAE_Seller::get_badge_rows`, `KMAE_Seller::get_public_price_row`
- RELATED FEATURE: `PAGES-ROUTING`

## `templates/terms.php`
- REFERENCED/INCLUDED BY: `public/class-kmae-shortcodes.php`
- `kmae_action` VALUES: —
- `action` VALUES: —
- DIRECT KMAE SYMBOL REFERENCES: —
- RELATED FEATURE: `BOOT-ARCHITECTURE`
