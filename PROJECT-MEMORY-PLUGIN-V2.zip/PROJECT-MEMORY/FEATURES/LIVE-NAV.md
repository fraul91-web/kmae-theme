# FEATURE — Live polling, navigation and badges

## PURPOSE
Oldal fingerprint polling, unseen offer activity count, navigation filterezés és badge frissítési frontend.

## READ FIRST
- `includes/class-kmae-live-page.php`
- `includes/class-kmae-nav.php`
- `public/class-kmae-public.php`
- `assets/js/public.js`

## THEN IF NEEDED
- `assets/js/nav.js`
- `includes/class-kmae-pages.php`
- `includes/class-kmae-database.php`

## DO NOT LOAD UNLESS RELEVANT
- `ki-mit-adna-erte.php`
- `includes/class-kmae-loader.php`
- `includes/class-kmae-plugin.php`
- `includes/class-kmae-activator.php`
- `includes/class-kmae-deactivator.php`


## ENTRY POINTS
Public asset enqueue, AJAX `kmae_poll_page`, WP menu/block filters, nav assets.

## IMPORTANT SYMBOLS
`KMAE_Public::ajax_poll_page`, `KMAE_Live_Page::get_fingerprint`, `KMAE_Database::count_unseen_offer_activity`, `KMAE_Nav` filter methods.

## DATA USED
Current context/listing/offer, unseen offer activity meta/table state, navigation tree.

## FLOW
See `../FLOWS.md` section 17.

## DEPENDENCIES
Pages/offer thread seen markers feed unseen count. Public JS consumes poll response.

## SIDE EFFECTS
Poll is read-oriented; visiting offers/thread can mark activity seen via page routing hooks.

## CHANGE RISKS
Badge count semantics and seen-marker semantics must change together; otherwise polling can continually re-surface already viewed activity.


## SOURCE-DETECTED EXTERNAL CLASS FILE DEPENDENCIES

- `includes/class-kmae-meta.php`
- `includes/class-kmae-counter-offers.php`
- `includes/class-kmae-photo-motor.php`
- `includes/class-kmae-vehicle.php`
- `includes/class-kmae-listing-drafts.php`
- `includes/class-kmae-listing-wizard.php`
- `includes/class-kmae-moderation.php`
- `includes/class-kmae-browse.php`
- `includes/class-kmae-icons.php`
- `includes/class-kmae-auth.php`
- `includes/class-kmae-company.php`
- `includes/class-kmae-trust.php`
- `includes/class-kmae-deal.php`
- `includes/class-kmae-brand.php`
- `includes/class-kmae-settings.php`
- `includes/class-kmae-counties.php`
- `includes/class-kmae-listings.php`
- `includes/class-kmae-query.php`
- `includes/class-kmae-seller.php`
- `includes/class-kmae-offers.php`


## V2 DIAGNOSTIC ROUTING

**FEATURE:** Live/nav  
**COMMON SYMPTOMS:** poll fingerprint/count + DOM nav.  
**READ FIRST (symbol-level):** `KMAE_Public::ajax_poll_page()`; `KMAE_Live_Page`; `assets/js/public.js/nav.js`.  
**EXPECTED FLOW:** entry/producer → validation/state mutation → domain event or persistence → render/response. Use `../DIAGNOSTIC-ROUTER.md` for the symptom-specific chain.  
**CHECKPOINTS:** (1) did the entry point execute; (2) is authoritative persisted/server state correct; (3) was the expected hook/response emitted; (4) if server state is correct, continue only into render/client/boundary.  
**IF SERVER STATE WRONG → GO TO:** the first producer/guard listed above and its immediate dependency only.  
**IF SERVER STATE CORRECT → GO TO:** next consumer from `../DIAGNOSTIC-ROUTER.md`; do not re-read upstream persistence.  
**SEARCH TERMS:** `kmae_poll_page ajax_poll_page fingerprint unseen`.  
**DO NOT LOAD UNLESS:** notifications email.  
**PLUGIN BOUNDARY:** see `../PLUGIN-BOUNDARIES.md` when flow reaches theme, `wp_mail`, WordPress cron/session, or external services.  
**CHANGE RISKS:** preserve event order, persisted status/meta/table semantics, authorization and reverse callers documented in existing map.  
**REGRESSION CHECKS:** use `../REGRESSION-MAP.md` for shared hotspots; re-run the exact entry state plus reload/downstream consumer.  
**VERIFICATION STATUS:** VERIFIED against the uploaded plugin source snapshot for plugin-owned routing; external runtime remains UNVERIFIED.
