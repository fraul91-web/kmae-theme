# FEATURE — Event notifications and email

## PURPOSE
Domain hookokra feliratkozó ajánlat/deal/rating e-mailek, recipient logika és brandelt HTML mail.

## READ FIRST
- `includes/class-kmae-notifications.php`
- `includes/class-kmae-brand.php`

## THEN IF NEEDED
- `includes/class-kmae-auth.php`
- `includes/class-kmae-deal.php`
- `includes/class-kmae-counter-offers.php`
- `includes/class-kmae-offers.php`

## DO NOT LOAD UNLESS RELEVANT
- `ki-mit-adna-erte.php`
- `includes/class-kmae-loader.php`
- `includes/class-kmae-plugin.php`
- `includes/class-kmae-activator.php`
- `includes/class-kmae-deactivator.php`


## ENTRY POINTS
Domain actions: new offer, counters/revision, accepted, deal locked/failed/success-related methods, rejected, withdrawn; direct listing closed/deleted/buyer-found-other-car calls.

## IMPORTANT SYMBOLS
`KMAE_Notifications::{on_new_offer,on_counter_offer,on_buyer_revision,on_offer_accepted,on_deal_locked,on_deal_failed,on_offer_rejected,on_offer_withdrawn,listing_closed,on_listing_deleted,request_rating,send_offer_email}`; `KMAE_Brand::{send_mail,wrap_email,ensure_html_headers}`.

## DATA USED
Offer/listing/user data; user e-mail preference `KMAE_Auth::wants_offer_emails()`; brand URLs/content.

## FLOW
Domain mutation emits event → notification listener resolves parties/data → `send_offer_email()` checks preference → brand mail layer → `wp_mail`.

## DEPENDENCIES
Event ordering matters around `kmae_offer_accepted`: deal lock priority 5, accepted notification priority 10.

## SIDE EFFECTS
External e-mail delivery through WordPress mail stack.

## CHANGE RISKS
Notification methods can be called both by hooks and directly. Search callers before removing/renaming any method.


## SOURCE-DETECTED EXTERNAL CLASS FILE DEPENDENCIES

- `includes/class-kmae-database.php`
- `includes/class-kmae-pages.php`
- `includes/class-kmae-contact.php`
- `includes/class-kmae-trust.php`


## V2 DIAGNOSTIC ROUTING

**FEATURE:** Notifications/email  
**COMMON SYMPTOMS:** domain event → recipient/body → preference → brand mail.  
**READ FIRST (symbol-level):** `KMAE_Notifications` event handler matching the event; `send_offer_email()`.  
**EXPECTED FLOW:** entry/producer → validation/state mutation → domain event or persistence → render/response. Use `../DIAGNOSTIC-ROUTER.md` for the symptom-specific chain.  
**CHECKPOINTS:** (1) did the entry point execute; (2) is authoritative persisted/server state correct; (3) was the expected hook/response emitted; (4) if server state is correct, continue only into render/client/boundary.  
**IF SERVER STATE WRONG → GO TO:** the first producer/guard listed above and its immediate dependency only.  
**IF SERVER STATE CORRECT → GO TO:** next consumer from `../DIAGNOSTIC-ROUTER.md`; do not re-read upstream persistence.  
**SEARCH TERMS:** `on_new_offer on_offer_accepted send_offer_email wants_offer_emails`.  
**DO NOT LOAD UNLESS:** event producer once event payload verified.  
**PLUGIN BOUNDARY:** see `../PLUGIN-BOUNDARIES.md` when flow reaches theme, `wp_mail`, WordPress cron/session, or external services.  
**CHANGE RISKS:** preserve event order, persisted status/meta/table semantics, authorization and reverse callers documented in existing map.  
**REGRESSION CHECKS:** use `../REGRESSION-MAP.md` for shared hotspots; re-run the exact entry state plus reload/downstream consumer.  
**VERIFICATION STATUS:** VERIFIED against the uploaded plugin source snapshot for plugin-owned routing; external runtime remains UNVERIFIED.
