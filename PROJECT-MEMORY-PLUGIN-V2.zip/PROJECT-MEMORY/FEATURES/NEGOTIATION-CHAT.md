# FEATURE — Counter offers and negotiation chat

## PURPOSE
Eladói ellenajánlat, vevői revízió, körlimit, offer thread/chat timeline és elfogadási szabályok.

## READ FIRST
- `includes/class-kmae-counter-offers.php`
- `templates/offer-thread.php`
- `templates/partials/offer-chat-timeline.php`
- `public/class-kmae-public.php`

## THEN IF NEEDED
- `templates/partials/offer-buyer-negotiation.php`
- `templates/partials/offer-owner-actions.php`
- `templates/partials/offer-chat-actions.php`
- `templates/partials/offer-chat-message-actions.php`
- `assets/js/public.js`

## DO NOT LOAD UNLESS RELEVANT
- `ki-mit-adna-erte.php`
- `includes/class-kmae-loader.php`
- `includes/class-kmae-plugin.php`
- `includes/class-kmae-activator.php`
- `includes/class-kmae-deactivator.php`


## ENTRY POINTS
`/ajanlatok/?kmae_offer=<id>` and offer thread form actions.

## IMPORTANT SYMBOLS
- `KMAE_Counter_Offers::{can_seller_counter,can_buyer_revise,can_seller_accept,can_buyer_accept,submit_seller_counter,submit_buyer_revision,accept_offer,get_chat_messages,get_chat_action_state}`
- `KMAE_Pages::mark_offers_seen_on_visit`

## DATA USED
Offer row + `kmae_counter_offers` + seen-state user meta + listing/deal state.

## FLOW
See `../FLOWS.md` sections 11–12.

## DEPENDENCIES
Max round constant is 2 per party. Deal lock and buyer single-lock guard acceptance. Contact unlock happens inside acceptance.

## SIDE EFFECTS
Writes counter history and offer amount/status; emits negotiation/acceptance domain actions.

## CHANGE RISKS
Turn order, round counts, acceptance amount and lock checks are coupled. Chat rendering reconstructs state from persisted history, so changing only UI buttons is insufficient.


## SOURCE-DETECTED EXTERNAL CLASS FILE DEPENDENCIES

- `includes/class-kmae-database.php`
- `includes/class-kmae-deal.php`
- `includes/class-kmae-taxonomies.php`
- `includes/class-kmae-contact.php`
- `includes/class-kmae-offers.php`
- `includes/class-kmae-auth.php`
- `includes/class-kmae-company.php`
- `includes/class-kmae-dashboard.php`
- `includes/class-kmae-photo-motor.php`
- `includes/class-kmae-vehicle.php`
- `includes/class-kmae-listing-drafts.php`
- `includes/class-kmae-listing-wizard.php`
- `includes/class-kmae-moderation.php`
- `includes/class-kmae-meta.php`
- `includes/class-kmae-browse.php`
- `includes/class-kmae-live-page.php`
- `includes/class-kmae-icons.php`
- `includes/class-kmae-pages.php`
- `includes/class-kmae-trust.php`
- `includes/class-kmae-brand.php`


## V2 DIAGNOSTIC ROUTING

**FEATURE:** Negotiation  
**COMMON SYMPTOMS:** counter/revision/acceptance/chat state.  
**READ FIRST (symbol-level):** `KMAE_Counter_Offers` action/eligibility methods.  
**EXPECTED FLOW:** entry/producer → validation/state mutation → domain event or persistence → render/response. Use `../DIAGNOSTIC-ROUTER.md` for the symptom-specific chain.  
**CHECKPOINTS:** (1) did the entry point execute; (2) is authoritative persisted/server state correct; (3) was the expected hook/response emitted; (4) if server state is correct, continue only into render/client/boundary.  
**IF SERVER STATE WRONG → GO TO:** the first producer/guard listed above and its immediate dependency only.  
**IF SERVER STATE CORRECT → GO TO:** next consumer from `../DIAGNOSTIC-ROUTER.md`; do not re-read upstream persistence.  
**SEARCH TERMS:** `submit_seller_counter submit_buyer_revision accept_offer get_chat_action_state`.  
**DO NOT LOAD UNLESS:** email until mutation/event verified.  
**PLUGIN BOUNDARY:** see `../PLUGIN-BOUNDARIES.md` when flow reaches theme, `wp_mail`, WordPress cron/session, or external services.  
**CHANGE RISKS:** preserve event order, persisted status/meta/table semantics, authorization and reverse callers documented in existing map.  
**REGRESSION CHECKS:** use `../REGRESSION-MAP.md` for shared hotspots; re-run the exact entry state plus reload/downstream consumer.  
**VERIFICATION STATUS:** VERIFIED against the uploaded plugin source snapshot for plugin-owned routing; external runtime remains UNVERIFIED.
