# FEATURE — Archive lifecycle and scheduled purge

## PURPOSE
Eladott/archivált hirdetések 5 napos lock + 2 napos reaktiválási ablak és napi törlési cron.

## READ FIRST
- `includes/class-kmae-listings.php`
- `includes/class-kmae-activator.php`
- `includes/class-kmae-deactivator.php`

## THEN IF NEEDED
- `includes/class-kmae-deal.php`

## DO NOT LOAD UNLESS RELEVANT
- `ki-mit-adna-erte.php`
- `includes/class-kmae-loader.php`
- `includes/class-kmae-plugin.php`
- `public/class-kmae-shortcodes.php`
- `public/class-kmae-public.php`


## ENTRY POINTS
Activation and `KMAE_Listings::init()` schedule daily `kmae_purge_archived_listings`; hook calls `purge_expired_archived()`; deactivation clears cron.

## IMPORTANT SYMBOLS
`KMAE_Activator::schedule_cron`, `KMAE_Listings::{get_archive_lifecycle,purge_expired_archived,force_delete_listing}`, `KMAE_Deactivator::deactivate`.

## DATA USED
`_kmae_status=archived`, `_kmae_archived_at`, `_kmae_reactivated_at`; lifecycle constants from main plugin file.

## FLOW
See `../FLOWS.md` section 18.

## DEPENDENCIES
Deal success creates archived state; forced deletion performs multi-domain cleanup.

## SIDE EFFECTS
Permanent listing/attachment/custom-row deletion after lifecycle expiration.

## CHANGE RISKS
Changing lifecycle days alters both UI eligibility and destructive cron timing. Verify all constants and `get_archive_lifecycle()` consumers together.


## SOURCE-DETECTED EXTERNAL CLASS FILE DEPENDENCIES

- `includes/class-kmae-meta.php`
- `includes/class-kmae-photo-motor.php`
- `includes/class-kmae-auth.php`
- `includes/class-kmae-company.php`
- `includes/class-kmae-counties.php`
- `includes/class-kmae-seller.php`
- `includes/class-kmae-taxonomies.php`
- `includes/class-kmae-vehicle.php`
- `includes/class-kmae-images.php`
- `includes/class-kmae-database.php`
- `includes/class-kmae-notifications.php`
- `includes/class-kmae-pages.php`
- `includes/class-kmae-post-types.php`


## V2 DIAGNOSTIC ROUTING

**FEATURE:** Cron/archive  
**COMMON SYMPTOMS:** schedule + lifecycle eligibility + delete.  
**READ FIRST (symbol-level):** `KMAE_Activator::schedule_cron()` → `KMAE_Listings::purge_expired_archived()`.  
**EXPECTED FLOW:** entry/producer → validation/state mutation → domain event or persistence → render/response. Use `../DIAGNOSTIC-ROUTER.md` for the symptom-specific chain.  
**CHECKPOINTS:** (1) did the entry point execute; (2) is authoritative persisted/server state correct; (3) was the expected hook/response emitted; (4) if server state is correct, continue only into render/client/boundary.  
**IF SERVER STATE WRONG → GO TO:** the first producer/guard listed above and its immediate dependency only.  
**IF SERVER STATE CORRECT → GO TO:** next consumer from `../DIAGNOSTIC-ROUTER.md`; do not re-read upstream persistence.  
**SEARCH TERMS:** `kmae_purge_archived_listings purge_expired_archived`.  
**DO NOT LOAD UNLESS:** frontend.  
**PLUGIN BOUNDARY:** see `../PLUGIN-BOUNDARIES.md` when flow reaches theme, `wp_mail`, WordPress cron/session, or external services.  
**CHANGE RISKS:** preserve event order, persisted status/meta/table semantics, authorization and reverse callers documented in existing map.  
**REGRESSION CHECKS:** use `../REGRESSION-MAP.md` for shared hotspots; re-run the exact entry state plus reload/downstream consumer.  
**VERIFICATION STATUS:** VERIFIED against the uploaded plugin source snapshot for plugin-owned routing; external runtime remains UNVERIFIED.
