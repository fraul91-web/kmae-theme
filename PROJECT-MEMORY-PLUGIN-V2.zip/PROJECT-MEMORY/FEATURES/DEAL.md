# FEATURE — Accepted-deal lock and outcome

## PURPOSE
Elfogadott ajánlat utáni soft lock, viewing phase, siker/sikertelenség, archiválás/visszanyitás és buyer single-lock.

## READ FIRST
- `includes/class-kmae-deal.php`
- `includes/class-kmae-counter-offers.php`
- `includes/class-kmae-listings.php`
- `public/class-kmae-public.php`

## THEN IF NEEDED
- `templates/partials/deal-outcome.php`
- `templates/partials/continue-shopping.php`

## DO NOT LOAD UNLESS RELEVANT
- `ki-mit-adna-erte.php`
- `includes/class-kmae-loader.php`
- `includes/class-kmae-plugin.php`
- `includes/class-kmae-deactivator.php`
- `public/class-kmae-shortcodes.php`


## ENTRY POINTS
`kmae_offer_accepted` action (priority-5 lock), same-page `deal_success` / `deal_failure`, post-purchase continue/stop admin-post.

## IMPORTANT SYMBOLS
`KMAE_Deal::{lock_on_accept,get_buyer_active_lock_offer_id,assert_buyer_can_lock,confirm_success,confirm_failure,continue_shopping,stop_shopping}`.

## DATA USED
Listing status + `_kmae_deal_phase`, `_kmae_accepted_offer_id`, `_kmae_deal_locked_at`, archive timestamps; offers table; buyer post-purchase user meta.

## FLOW
See `../FLOWS.md` sections 12–14.

## DEPENDENCIES
Counter-offer acceptance emits the trigger; notifications/trust listen to downstream events.

## SIDE EFFECTS
Closes/reopens/archives listing, rejects or reopens offers, may withdraw buyer's other pending offers.

## CHANGE RISKS
Acceptance is a soft lock, not final sale. Rejecting other offers too early changes recovery semantics on deal failure.


## SOURCE-DETECTED EXTERNAL CLASS FILE DEPENDENCIES

- `includes/class-kmae-activator.php`
- `includes/class-kmae-meta.php`
- `includes/class-kmae-photo-motor.php`
- `includes/class-kmae-auth.php`
- `includes/class-kmae-company.php`
- `includes/class-kmae-counties.php`
- `includes/class-kmae-seller.php`
- `includes/class-kmae-taxonomies.php`
- `includes/class-kmae-vehicle.php`
- `includes/class-kmae-images.php`
- `includes/class-kmae-database.php`
- `includes/class-kmae-notifications.php`
- `includes/class-kmae-contact.php`
- `includes/class-kmae-offers.php`
- `includes/class-kmae-dashboard.php`
- `includes/class-kmae-listing-drafts.php`
- `includes/class-kmae-listing-wizard.php`
- `includes/class-kmae-moderation.php`
- `includes/class-kmae-browse.php`
- `includes/class-kmae-live-page.php`


## V2 DIAGNOSTIC ROUTING

**FEATURE:** Deal lock/outcome  
**COMMON SYMPTOMS:** accepted lock and final outcome/recovery.  
**READ FIRST (symbol-level):** `KMAE_Deal::lock_on_accept()/confirm_success()/confirm_failure()`.  
**EXPECTED FLOW:** entry/producer → validation/state mutation → domain event or persistence → render/response. Use `../DIAGNOSTIC-ROUTER.md` for the symptom-specific chain.  
**CHECKPOINTS:** (1) did the entry point execute; (2) is authoritative persisted/server state correct; (3) was the expected hook/response emitted; (4) if server state is correct, continue only into render/client/boundary.  
**IF SERVER STATE WRONG → GO TO:** the first producer/guard listed above and its immediate dependency only.  
**IF SERVER STATE CORRECT → GO TO:** next consumer from `../DIAGNOSTIC-ROUTER.md`; do not re-read upstream persistence.  
**SEARCH TERMS:** `lock_on_accept confirm_success confirm_failure`.  
**DO NOT LOAD UNLESS:** trust until success event verified.  
**PLUGIN BOUNDARY:** see `../PLUGIN-BOUNDARIES.md` when flow reaches theme, `wp_mail`, WordPress cron/session, or external services.  
**CHANGE RISKS:** preserve event order, persisted status/meta/table semantics, authorization and reverse callers documented in existing map.  
**REGRESSION CHECKS:** use `../REGRESSION-MAP.md` for shared hotspots; re-run the exact entry state plus reload/downstream consumer.  
**VERIFICATION STATUS:** VERIFIED against the uploaded plugin source snapshot for plugin-owned routing; external runtime remains UNVERIFIED.
