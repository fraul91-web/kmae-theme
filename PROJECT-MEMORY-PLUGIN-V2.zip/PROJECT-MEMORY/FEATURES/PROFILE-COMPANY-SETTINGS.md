# FEATURE — Profile, company accounts and user settings

## PURPOSE
Profiladatok, magán/cég fiók, céges telephely, e-mail preferenciák, e-mail/jelszó/security műveletek.

## READ FIRST
- `includes/class-kmae-company.php`
- `includes/class-kmae-auth.php`
- `public/class-kmae-public.php`
- `templates/form-profile.php`
- `templates/settings.php`
- `templates/security.php`

## THEN IF NEEDED
- `includes/class-kmae-counties.php`
- `assets/js/phone-field.js`

## DO NOT LOAD UNLESS RELEVANT
- `ki-mit-adna-erte.php`
- `includes/class-kmae-loader.php`
- `includes/class-kmae-plugin.php`
- `includes/class-kmae-activator.php`
- `includes/class-kmae-deactivator.php`


## ENTRY POINTS
- `[kmae_profile]`, `[kmae_settings]`, `[kmae_security]`
- admin-post profile/settings/e-mail/password/logout-everywhere handlers.

## IMPORTANT SYMBOLS
- `KMAE_Public::admin_save_profile`
- `KMAE_Company::{save_profile_fields,apply_listing_location}`
- `KMAE_Auth::{sync_phone,save_email_prefs,get_profile}`
- security handlers in `KMAE_Public`.

## DATA USED
WP user/display name/email/password/session tokens; company user meta; `kmae_user_profiles`.

## FLOW
Profile POST → nonce/login → user/profile changes → company validation if company → redirect. Company listings source county/city from company profile instead of arbitrary listing POST.

## DEPENDENCIES
`KMAE_Counties` validates location. Listing save depends on company profile completeness.

## SIDE EFFECTS
Changes user identity/profile and may invalidate sessions on logout-everywhere.

## CHANGE RISKS
Company location is reused by listing creation/edit; profile changes therefore affect future listing location.


## SOURCE-DETECTED EXTERNAL CLASS FILE DEPENDENCIES

- `includes/class-kmae-pages.php`
- `includes/class-kmae-brand.php`
- `includes/class-kmae-database.php`
- `includes/class-kmae-counter-offers.php`
- `includes/class-kmae-photo-motor.php`
- `includes/class-kmae-vehicle.php`
- `includes/class-kmae-listing-drafts.php`
- `includes/class-kmae-listing-wizard.php`
- `includes/class-kmae-moderation.php`
- `includes/class-kmae-meta.php`
- `includes/class-kmae-browse.php`
- `includes/class-kmae-live-page.php`
- `includes/class-kmae-icons.php`
- `includes/class-kmae-trust.php`
- `includes/class-kmae-deal.php`
- `includes/class-kmae-settings.php`
- `includes/class-kmae-listings.php`
- `includes/class-kmae-query.php`
- `includes/class-kmae-seller.php`
- `includes/class-kmae-offers.php`


## V2 DIAGNOSTIC ROUTING

**FEATURE:** Profile/company/settings  
**COMMON SYMPTOMS:** profile save, company fields/location, settings.  
**READ FIRST (symbol-level):** `public/class-kmae-public.php :: admin_save_profile()`; `includes/class-kmae-company.php`.  
**EXPECTED FLOW:** entry/producer → validation/state mutation → domain event or persistence → render/response. Use `../DIAGNOSTIC-ROUTER.md` for the symptom-specific chain.  
**CHECKPOINTS:** (1) did the entry point execute; (2) is authoritative persisted/server state correct; (3) was the expected hook/response emitted; (4) if server state is correct, continue only into render/client/boundary.  
**IF SERVER STATE WRONG → GO TO:** the first producer/guard listed above and its immediate dependency only.  
**IF SERVER STATE CORRECT → GO TO:** next consumer from `../DIAGNOSTIC-ROUTER.md`; do not re-read upstream persistence.  
**SEARCH TERMS:** `save_profile company apply_listing_location settings`.  
**DO NOT LOAD UNLESS:** offers/deal unless symptom crosses user preference.  
**PLUGIN BOUNDARY:** see `../PLUGIN-BOUNDARIES.md` when flow reaches theme, `wp_mail`, WordPress cron/session, or external services.  
**CHANGE RISKS:** preserve event order, persisted status/meta/table semantics, authorization and reverse callers documented in existing map.  
**REGRESSION CHECKS:** use `../REGRESSION-MAP.md` for shared hotspots; re-run the exact entry state plus reload/downstream consumer.  
**VERIFICATION STATUS:** VERIFIED against the uploaded plugin source snapshot for plugin-owned routing; external runtime remains UNVERIFIED.
