# FEATURE — Browse, search wizard and personalization

## PURPOSE
Hirdetéslekérdezés, megye/kivitel/mód/ár szűrés, pass kezelés, már megajánlott hirdetések kizárása és resurfacing.

## READ FIRST
- `includes/class-kmae-query.php`
- `includes/class-kmae-browse.php`
- `includes/class-kmae-counties.php`
- `public/class-kmae-shortcodes.php`

## THEN IF NEEDED
- `assets/js/browse-wizard.js`
- `assets/js/swipe.js`
- `assets/js/map.js`
- `templates/browse.php`
- `templates/browse-swipe.php`
- `templates/browse-wizard-map.php`
- `templates/browse-wizard-body.php`
- `templates/browse-wizard-offer.php`

## DO NOT LOAD UNLESS RELEVANT
- `ki-mit-adna-erte.php`
- `includes/class-kmae-loader.php`
- `includes/class-kmae-plugin.php`
- `includes/class-kmae-activator.php`
- `includes/class-kmae-deactivator.php`


## ENTRY POINTS
`[kmae_browse]`; browse query vars; swipe pass AJAX.

## IMPORTANT SYMBOLS
- `KMAE_Query::get_listings`
- `KMAE_Browse::{parse_wizard_params,is_wizard_complete,filter_by_wizard,listing_matches_wizard,record_pass,personalize_listings}`
- `KMAE_Counties`

## DATA USED
Active listing post/meta/taxonomy; vehicle body/value; seller price mode; offers table; user meta `_kmae_browse_passed`.

## FLOW
See `../FLOWS.md` section 9.

## DEPENDENCIES
Launch/vehicle mode, offer history, counties, seller price mode.

## SIDE EFFECTS
Pass AJAX only updates pass user meta. Query itself is read-only.

## CHANGE RISKS
`KMAE_Query::get_listings()` excludes own and already-offered listings before personalization. Changing query exclusions can alter browse and landing popular listings because landing uses same query helper.


## SOURCE-DETECTED EXTERNAL CLASS FILE DEPENDENCIES

- `includes/class-kmae-database.php`
- `includes/class-kmae-vehicle.php`
- `includes/class-kmae-meta.php`
- `includes/class-kmae-seller.php`
- `includes/class-kmae-launch.php`
- `includes/class-kmae-images.php`
- `includes/class-kmae-auth.php`
- `includes/class-kmae-listings.php`
- `includes/class-kmae-pages.php`
- `includes/class-kmae-counter-offers.php`
- `includes/class-kmae-settings.php`
- `includes/class-kmae-dashboard.php`


## V2 DIAGNOSTIC ROUTING

**FEATURE:** Browse/search  
**COMMON SYMPTOMS:** query + personalization + pass history.  
**READ FIRST (symbol-level):** `KMAE_Query`; `KMAE_Browse::personalize_listings()/filter_by_wizard()`.  
**EXPECTED FLOW:** entry/producer → validation/state mutation → domain event or persistence → render/response. Use `../DIAGNOSTIC-ROUTER.md` for the symptom-specific chain.  
**CHECKPOINTS:** (1) did the entry point execute; (2) is authoritative persisted/server state correct; (3) was the expected hook/response emitted; (4) if server state is correct, continue only into render/client/boundary.  
**IF SERVER STATE WRONG → GO TO:** the first producer/guard listed above and its immediate dependency only.  
**IF SERVER STATE CORRECT → GO TO:** next consumer from `../DIAGNOSTIC-ROUTER.md`; do not re-read upstream persistence.  
**SEARCH TERMS:** `personalize_listings filter_by_wizard record_pass`.  
**DO NOT LOAD UNLESS:** templates until ID/result set verified.  
**PLUGIN BOUNDARY:** see `../PLUGIN-BOUNDARIES.md` when flow reaches theme, `wp_mail`, WordPress cron/session, or external services.  
**CHANGE RISKS:** preserve event order, persisted status/meta/table semantics, authorization and reverse callers documented in existing map.  
**REGRESSION CHECKS:** use `../REGRESSION-MAP.md` for shared hotspots; re-run the exact entry state plus reload/downstream consumer.  
**VERIFICATION STATUS:** VERIFIED against the uploaded plugin source snapshot for plugin-owned routing; external runtime remains UNVERIFIED.
