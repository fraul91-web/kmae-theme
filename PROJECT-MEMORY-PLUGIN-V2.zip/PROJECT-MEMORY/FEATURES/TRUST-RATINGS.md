# FEATURE — Ratings and trust score

## PURPOSE
Sikeres deal utáni kétoldalú rating, criteria, cached trust score/deal statisztika és badge logika.

## READ FIRST
- `includes/class-kmae-trust.php`
- `templates/partials/rate-form.php`
- `templates/partials/trust-card.php`

## THEN IF NEEDED
- `includes/class-kmae-notifications.php`
- `public/class-kmae-public.php`

## DO NOT LOAD UNLESS RELEVANT
- `ki-mit-adna-erte.php`
- `includes/class-kmae-loader.php`
- `includes/class-kmae-plugin.php`
- `includes/class-kmae-activator.php`
- `includes/class-kmae-deactivator.php`


## ENTRY POINTS
`kmae_deal_success` listener; profile pending-rating UI; admin-post rating submit.

## IMPORTANT SYMBOLS
`KMAE_Trust::{on_deal_success,get_pending_for_user,resolve_rated_party,submit,recalculate,count_successful_deals,get_summary,get_badges}`.

## DATA USED
`kmae_ratings`; accepted offer + archived listing; trust cache user meta.

## FLOW
See `../FLOWS.md` section 16.

## DEPENDENCIES
A listing must be archived and offer accepted. Deal-success hook asks both sides to rate.

## SIDE EFFECTS
Rating insert; rated user's cached trust metrics updated; rating-submitted domain action emitted.

## CHANGE RISKS
Trust score uses both overall stars and binary criteria. Successful-deal count is derived separately from accepted offers on archived listings.


## SOURCE-DETECTED EXTERNAL CLASS FILE DEPENDENCIES

- `includes/class-kmae-database.php`
- `includes/class-kmae-meta.php`
- `includes/class-kmae-pages.php`


## V2 DIAGNOSTIC ROUTING

**FEATURE:** Trust/ratings  
**COMMON SYMPTOMS:** pending rating, submit, score/badges.  
**READ FIRST (symbol-level):** `KMAE_Trust::on_deal_success()/submit()/recalculate()`.  
**EXPECTED FLOW:** entry/producer → validation/state mutation → domain event or persistence → render/response. Use `../DIAGNOSTIC-ROUTER.md` for the symptom-specific chain.  
**CHECKPOINTS:** (1) did the entry point execute; (2) is authoritative persisted/server state correct; (3) was the expected hook/response emitted; (4) if server state is correct, continue only into render/client/boundary.  
**IF SERVER STATE WRONG → GO TO:** the first producer/guard listed above and its immediate dependency only.  
**IF SERVER STATE CORRECT → GO TO:** next consumer from `../DIAGNOSTIC-ROUTER.md`; do not re-read upstream persistence.  
**SEARCH TERMS:** `on_deal_success submit recalculate request_rating`.  
**DO NOT LOAD UNLESS:** deal once success event verified.  
**PLUGIN BOUNDARY:** see `../PLUGIN-BOUNDARIES.md` when flow reaches theme, `wp_mail`, WordPress cron/session, or external services.  
**CHANGE RISKS:** preserve event order, persisted status/meta/table semantics, authorization and reverse callers documented in existing map.  
**REGRESSION CHECKS:** use `../REGRESSION-MAP.md` for shared hotspots; re-run the exact entry state plus reload/downstream consumer.  
**VERIFICATION STATUS:** VERIFIED against the uploaded plugin source snapshot for plugin-owned routing; external runtime remains UNVERIFIED.
