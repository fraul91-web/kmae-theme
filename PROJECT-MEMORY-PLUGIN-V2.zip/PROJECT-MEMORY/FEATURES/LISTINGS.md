# FEATURE — Listing creation, editing and lifecycle

## PURPOSE
Hirdetés létrehozás/szerkesztés/törlés/reaktiválás, listing meta, állapotok és tulajdonosi jogosultság.

## READ FIRST
- `public/class-kmae-public.php`
- `includes/class-kmae-listings.php`
- `includes/class-kmae-meta.php`
- `includes/class-kmae-seller.php`

## THEN IF NEEDED
- `templates/form-create-listing.php`
- `templates/form-listing.php`
- `templates/partials/listing-form-layout.php`
- `templates/my-listings.php`
- `assets/js/my-listings.js`

## DO NOT LOAD UNLESS RELEVANT
- `ki-mit-adna-erte.php`
- `includes/class-kmae-loader.php`
- `includes/class-kmae-plugin.php`
- `includes/class-kmae-deactivator.php`
- `public/class-kmae-shortcodes.php`


## ENTRY POINTS
- `[kmae_create_listing]`, `[kmae_my_listings]`
- same-page `create_listing`
- admin-post update/delete/reactivate
- single/archive CPT routing.

## IMPORTANT SYMBOLS
- `KMAE_Public::{process_create_listing,admin_update_listing,admin_delete_listing,admin_reactivate_listing}`
- `KMAE_Listings::{save_meta_from_post,activate_if_photos_ready,delete_listing,force_delete_listing,reactivate_listing,get_archive_lifecycle}`
- `KMAE_Meta::{get_status,set_status,get_offer_types}`
- `KMAE_Seller::save_from_post`

## DATA USED
WP `kmae_listing` post + taxonomy + listing postmeta + private minimum custom table + photo attachments.

## FLOW
See `../FLOWS.md` sections 5–8, 18–19.

## DEPENDENCIES
Auth verification; seller quota; county/company; vehicle; moderation; photo motor/images; notifications; cron.

## SIDE EFFECTS
Creates/updates/deletes posts and attachments, emits publication events, can cascade-delete offer-related records on forced deletion.

## CHANGE RISKS
Listing status is consumed by browse, offers, deal, trust, dashboard and public-access blocking. Never alter status transitions without checking those features.


## SOURCE-DETECTED EXTERNAL CLASS FILE DEPENDENCIES

- `includes/class-kmae-offers.php`
- `includes/class-kmae-database.php`
- `includes/class-kmae-taxonomies.php`
- `includes/class-kmae-activator.php`
- `includes/class-kmae-deal.php`
- `includes/class-kmae-photo-motor.php`
- `includes/class-kmae-auth.php`
- `includes/class-kmae-company.php`
- `includes/class-kmae-counties.php`
- `includes/class-kmae-vehicle.php`
- `includes/class-kmae-images.php`
- `includes/class-kmae-notifications.php`
- `includes/class-kmae-counter-offers.php`
- `includes/class-kmae-listing-drafts.php`
- `includes/class-kmae-listing-wizard.php`
- `includes/class-kmae-moderation.php`
- `includes/class-kmae-browse.php`
- `includes/class-kmae-live-page.php`
- `includes/class-kmae-icons.php`
- `includes/class-kmae-pages.php`


## V2 DIAGNOSTIC ROUTING

**FEATURE:** Listing lifecycle  
**COMMON SYMPTOMS:** create/edit/delete/reactivate/publish/archive.  
**READ FIRST (symbol-level):** `KMAE_Public::process_create_listing()`; `KMAE_Listings` lifecycle methods.  
**EXPECTED FLOW:** entry/producer → validation/state mutation → domain event or persistence → render/response. Use `../DIAGNOSTIC-ROUTER.md` for the symptom-specific chain.  
**CHECKPOINTS:** (1) did the entry point execute; (2) is authoritative persisted/server state correct; (3) was the expected hook/response emitted; (4) if server state is correct, continue only into render/client/boundary.  
**IF SERVER STATE WRONG → GO TO:** the first producer/guard listed above and its immediate dependency only.  
**IF SERVER STATE CORRECT → GO TO:** next consumer from `../DIAGNOSTIC-ROUTER.md`; do not re-read upstream persistence.  
**SEARCH TERMS:** `process_create_listing save_meta_from_post can_reactivate`.  
**DO NOT LOAD UNLESS:** offer/chat unless listing state caused by accepted deal.  
**PLUGIN BOUNDARY:** see `../PLUGIN-BOUNDARIES.md` when flow reaches theme, `wp_mail`, WordPress cron/session, or external services.  
**CHANGE RISKS:** preserve event order, persisted status/meta/table semantics, authorization and reverse callers documented in existing map.  
**REGRESSION CHECKS:** use `../REGRESSION-MAP.md` for shared hotspots; re-run the exact entry state plus reload/downstream consumer.  
**VERIFICATION STATUS:** VERIFIED against the uploaded plugin source snapshot for plugin-owned routing; external runtime remains UNVERIFIED.
