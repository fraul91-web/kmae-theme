# FEATURE — Dashboard, hubs and statistics

## PURPOSE
Dashboard/hub aggregáció, listing view tracking, offer/message/activity rows és kezdőoldali user summary.

## READ FIRST
- `includes/class-kmae-dashboard.php`
- `templates/partials/dashboard-home.php`
- `templates/hub-section.php`
- `public/class-kmae-shortcodes.php`

## THEN IF NEEDED
- `assets/js/home-greeting.js`
- `includes/class-kmae-database.php`

## DO NOT LOAD UNLESS RELEVANT
- `ki-mit-adna-erte.php`
- `includes/class-kmae-loader.php`
- `includes/class-kmae-plugin.php`
- `includes/class-kmae-activator.php`
- `includes/class-kmae-deactivator.php`


## ENTRY POINTS
Hub shortcodes (`kmae_hub_sell`, `kmae_hub_buy`, `kmae_hub_stats`), dashboard partial, listing-view `template_redirect` tracking.

## IMPORTANT SYMBOLS
`KMAE_Dashboard::{get_data,maybe_track_listing_view,increment_views,get_user_view_stats,format_listing_row,format_offer_row,format_message_row}`.

## DATA USED
User listings, offers, counters, trust summary, unseen counts; listing view meta `_kmae_view_count` / weekly data; visitor cookie prefix `kmae_v_`.

## FLOW
Request dashboard/hub → aggregate current-user domain data → format rows → render template. Singular listing request can increment view stats with duplicate-view guard.

## DEPENDENCIES
Reads most business domains but should not own their state transitions.

## SIDE EFFECTS
View tracking writes listing meta/cookie; dashboard reads otherwise aggregate state.

## CHANGE RISKS
Because this feature is an aggregator, field/schema changes elsewhere often surface here even if dashboard code is not the root cause.


## SOURCE-DETECTED EXTERNAL CLASS FILE DEPENDENCIES

- `includes/class-kmae-meta.php`
- `includes/class-kmae-auth.php`
- `includes/class-kmae-pages.php`
- `includes/class-kmae-trust.php`
- `includes/class-kmae-images.php`
- `includes/class-kmae-query.php`
- `includes/class-kmae-seller.php`
- `includes/class-kmae-vehicle.php`
- `includes/class-kmae-offers.php`
- `includes/class-kmae-counter-offers.php`
- `includes/class-kmae-listings.php`
- `includes/class-kmae-counties.php`
- `includes/class-kmae-launch.php`
- `includes/class-kmae-browse.php`
- `includes/class-kmae-settings.php`


## V2 DIAGNOSTIC ROUTING

**FEATURE:** Dashboard/hubs  
**COMMON SYMPTOMS:** aggregated listing/offer/message stats.  
**READ FIRST (symbol-level):** `KMAE_Dashboard::get_data()` + formatter matching row.  
**EXPECTED FLOW:** entry/producer → validation/state mutation → domain event or persistence → render/response. Use `../DIAGNOSTIC-ROUTER.md` for the symptom-specific chain.  
**CHECKPOINTS:** (1) did the entry point execute; (2) is authoritative persisted/server state correct; (3) was the expected hook/response emitted; (4) if server state is correct, continue only into render/client/boundary.  
**IF SERVER STATE WRONG → GO TO:** the first producer/guard listed above and its immediate dependency only.  
**IF SERVER STATE CORRECT → GO TO:** next consumer from `../DIAGNOSTIC-ROUTER.md`; do not re-read upstream persistence.  
**SEARCH TERMS:** `get_data format_listing_row format_offer_row activity`.  
**DO NOT LOAD UNLESS:** mutation feature if raw persisted state already wrong.  
**PLUGIN BOUNDARY:** see `../PLUGIN-BOUNDARIES.md` when flow reaches theme, `wp_mail`, WordPress cron/session, or external services.  
**CHANGE RISKS:** preserve event order, persisted status/meta/table semantics, authorization and reverse callers documented in existing map.  
**REGRESSION CHECKS:** use `../REGRESSION-MAP.md` for shared hotspots; re-run the exact entry state plus reload/downstream consumer.  
**VERIFICATION STATUS:** VERIFIED against the uploaded plugin source snapshot for plugin-owned routing; external runtime remains UNVERIFIED.
