# FEATURE — Cash offers

## PURPOSE
Új készpénzes ajánlat, fair-buyer pledge, hidden minimum szűrés, fixed-price szabály, visszavonás és offer summary.

## READ FIRST
- `includes/class-kmae-offers.php`
- `includes/class-kmae-database.php`
- `public/class-kmae-public.php`

## THEN IF NEEDED
- `templates/partials/offer-forms.php`
- `templates/partials/cash-amount-input.php`
- `templates/partials/fair-buyer-pledge.php`

## DO NOT LOAD UNLESS RELEVANT
- `ki-mit-adna-erte.php`
- `includes/class-kmae-loader.php`
- `includes/class-kmae-plugin.php`
- `includes/class-kmae-activator.php`
- `includes/class-kmae-deactivator.php`


## ENTRY POINTS
Offer forms on listing / offer hub; same-page `submit_cash_offer` and `withdraw_offer`.

## IMPORTANT SYMBOLS
- `KMAE_Offers::{submit_cash_offer,guard_new_offer,require_fair_buyer_pledge,withdraw_offer,get_offer_summary}`
- `KMAE_Database` offer helpers

## DATA USED
`kmae_offers`, hidden minimum `kmae_private_data`, listing offer-type/status/price mode, fair-buyer user meta.

## FLOW
See `../FLOWS.md` section 10.

## DEPENDENCIES
Listing must be active; buyer cannot be listing author; auth verification handled earlier in public dispatcher; notifications depend on emitted `kmae_new_offer`.

## SIDE EFFECTS
Inserts offer row; may mark it `filtered_out`; emits event only for non-filtered offers; withdraw changes status and emits event.

## CHANGE RISKS
Below-minimum behavior is intentionally silent to seller/event layer in source. Do not “simplify” filtered offers without checking privacy semantics and browse offer-history exclusion.


## SOURCE-DETECTED EXTERNAL CLASS FILE DEPENDENCIES

- `includes/class-kmae-pages.php`
- `includes/class-kmae-auth.php`
- `includes/class-kmae-meta.php`
- `includes/class-kmae-seller.php`
- `includes/class-kmae-company.php`
- `includes/class-kmae-dashboard.php`
- `includes/class-kmae-counter-offers.php`
- `includes/class-kmae-photo-motor.php`
- `includes/class-kmae-vehicle.php`
- `includes/class-kmae-listing-drafts.php`
- `includes/class-kmae-listing-wizard.php`
- `includes/class-kmae-moderation.php`
- `includes/class-kmae-browse.php`
- `includes/class-kmae-live-page.php`
- `includes/class-kmae-icons.php`
- `includes/class-kmae-trust.php`
- `includes/class-kmae-deal.php`
- `includes/class-kmae-brand.php`
- `includes/class-kmae-settings.php`
- `includes/class-kmae-counties.php`


## V2 DIAGNOSTIC ROUTING

**FEATURE:** Cash offers  
**COMMON SYMPTOMS:** eligibility, amount, filtered state, insert/event.  
**READ FIRST (symbol-level):** `KMAE_Offers::guard_new_offer()/submit_cash_offer()`.  
**EXPECTED FLOW:** entry/producer → validation/state mutation → domain event or persistence → render/response. Use `../DIAGNOSTIC-ROUTER.md` for the symptom-specific chain.  
**CHECKPOINTS:** (1) did the entry point execute; (2) is authoritative persisted/server state correct; (3) was the expected hook/response emitted; (4) if server state is correct, continue only into render/client/boundary.  
**IF SERVER STATE WRONG → GO TO:** the first producer/guard listed above and its immediate dependency only.  
**IF SERVER STATE CORRECT → GO TO:** next consumer from `../DIAGNOSTIC-ROUTER.md`; do not re-read upstream persistence.  
**SEARCH TERMS:** `submit_cash_offer filtered_out kmae_new_offer`.  
**DO NOT LOAD UNLESS:** notification code until event verified.  
**PLUGIN BOUNDARY:** see `../PLUGIN-BOUNDARIES.md` when flow reaches theme, `wp_mail`, WordPress cron/session, or external services.  
**CHANGE RISKS:** preserve event order, persisted status/meta/table semantics, authorization and reverse callers documented in existing map.  
**REGRESSION CHECKS:** use `../REGRESSION-MAP.md` for shared hotspots; re-run the exact entry state plus reload/downstream consumer.  
**VERIFICATION STATUS:** VERIFIED against the uploaded plugin source snapshot for plugin-owned routing; external runtime remains UNVERIFIED.
