# FEATURE — Contact unlock

## PURPOSE
Elfogadott ajánlat résztvevőinek kontakt-hozzáférése és audit rekordja.

## READ FIRST
- `includes/class-kmae-contact.php`
- `includes/class-kmae-database.php`
- `includes/class-kmae-counter-offers.php`

## THEN IF NEEDED
- `templates/partials/contact-unlock.php`
- `public/class-kmae-public.php`

## DO NOT LOAD UNLESS RELEVANT
- `ki-mit-adna-erte.php`
- `includes/class-kmae-loader.php`
- `includes/class-kmae-plugin.php`
- `includes/class-kmae-activator.php`
- `includes/class-kmae-deactivator.php`


## ENTRY POINTS
Accepted offer calls `unlock_accepted_deal()`; optional same-page `unlock_contact` action; contact partial renders details.

## IMPORTANT SYMBOLS
`KMAE_Contact::{is_unlocked,can_view,unlock_accepted_deal,unlock,get_contact_details,get_other_party_id}` and DB unlock helpers.

## DATA USED
`kmae_contact_unlocks`; offer/listing party IDs; WP user + stored phone.

## FLOW
See `../FLOWS.md` section 15.

## DEPENDENCIES
Offer status/party membership are authorization inputs.

## SIDE EFFECTS
Creates idempotent audit unlock rows for parties.

## CHANGE RISKS
Do not expose contact solely based on client UI. Keep server `can_view()` and accepted/party checks aligned.


## SOURCE-DETECTED EXTERNAL CLASS FILE DEPENDENCIES

- `includes/class-kmae-dashboard.php`
- `includes/class-kmae-pages.php`
- `includes/class-kmae-offers.php`
- `includes/class-kmae-deal.php`
- `includes/class-kmae-taxonomies.php`
- `includes/class-kmae-auth.php`
- `includes/class-kmae-company.php`


## V2 DIAGNOSTIC ROUTING

**FEATURE:** Contact unlock  
**COMMON SYMPTOMS:** accepted-party access.  
**READ FIRST (symbol-level):** `KMAE_Contact::unlock_accepted_deal()/unlock()`.  
**EXPECTED FLOW:** entry/producer → validation/state mutation → domain event or persistence → render/response. Use `../DIAGNOSTIC-ROUTER.md` for the symptom-specific chain.  
**CHECKPOINTS:** (1) did the entry point execute; (2) is authoritative persisted/server state correct; (3) was the expected hook/response emitted; (4) if server state is correct, continue only into render/client/boundary.  
**IF SERVER STATE WRONG → GO TO:** the first producer/guard listed above and its immediate dependency only.  
**IF SERVER STATE CORRECT → GO TO:** next consumer from `../DIAGNOSTIC-ROUTER.md`; do not re-read upstream persistence.  
**SEARCH TERMS:** `unlock_accepted_deal contact`.  
**DO NOT LOAD UNLESS:** theme until plugin access/render data correct.  
**PLUGIN BOUNDARY:** see `../PLUGIN-BOUNDARIES.md` when flow reaches theme, `wp_mail`, WordPress cron/session, or external services.  
**CHANGE RISKS:** preserve event order, persisted status/meta/table semantics, authorization and reverse callers documented in existing map.  
**REGRESSION CHECKS:** use `../REGRESSION-MAP.md` for shared hotspots; re-run the exact entry state plus reload/downstream consumer.  
**VERIFICATION STATUS:** VERIFIED against the uploaded plugin source snapshot for plugin-owned routing; external runtime remains UNVERIFIED.
