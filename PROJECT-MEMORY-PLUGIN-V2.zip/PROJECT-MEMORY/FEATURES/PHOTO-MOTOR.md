# FEATURE — Photo motor and image processing

## PURPOSE
Kötelező/ajánlott fotóslotok, kliens+szerver minőségellenőrzés, automatikus képjavítás, galéria és WebP feldolgozás.

## READ FIRST
- `includes/class-kmae-photo-motor.php`
- `includes/class-kmae-images.php`
- `assets/js/photo-motor.js`
- `templates/partials/listing-photo-motor.php`

## THEN IF NEEDED
- `templates/partials/listing-gallery.php`
- `templates/partials/listing-gallery-manager.php`
- `includes/class-kmae-listings.php`

## DO NOT LOAD UNLESS RELEVANT
- `ki-mit-adna-erte.php`
- `includes/class-kmae-loader.php`
- `includes/class-kmae-plugin.php`
- `includes/class-kmae-activator.php`
- `includes/class-kmae-deactivator.php`


## ENTRY POINTS
Listing create/edit forms, `assets/js/photo-motor.js`, `KMAE_Listings::handle_image_uploads()`.

## IMPORTANT SYMBOLS
- `KMAE_Photo_Motor::{required_slots,recommended_slots,validate_request,handle_slot_uploads,analyze_file,autocorrect_file,client_config}`
- `KMAE_Images::process_attachment`

## DATA USED
7 required slots: `front_left`, `front_right`, `rear_left`, `rear_right`, `side`, `interior`, `odometer`; 6 recommended slots: engine bay, trunk, seats, wheels, windshield, damage. Listing slot/gallery meta + attachment slot/hash/autofix/analysis meta.

## FLOW
See `../FLOWS.md` sections 5–6.

## DEPENDENCIES
PHP thresholds are localized to browser via `client_config()`. WordPress media APIs store attachments; image processor creates normalized output.

## SIDE EFFECTS
Can rewrite an uploaded temporary image only when correction passes re-analysis; stores analysis/calibration record; replaces old slot attachment; rebuilds gallery and featured image.

## CHANGE RISKS
Keep browser thresholds and server thresholds sourced from PHP. Duplicate hashing, slot replacement and attachment deletion are linked; inspect all three before changing upload behavior.


## V2 DIAGNOSTIC ROUTING

**FEATURE:** Photo motor  
**COMMON SYMPTOMS:** slot/readiness/validation.  
**READ FIRST (symbol-level):** `KMAE_Photo_Motor::validate_request()`; `assets/js/photo-motor.js`.  
**EXPECTED FLOW:** entry/producer → validation/state mutation → domain event or persistence → render/response. Use `../DIAGNOSTIC-ROUTER.md` for the symptom-specific chain.  
**CHECKPOINTS:** (1) did the entry point execute; (2) is authoritative persisted/server state correct; (3) was the expected hook/response emitted; (4) if server state is correct, continue only into render/client/boundary.  
**IF SERVER STATE WRONG → GO TO:** the first producer/guard listed above and its immediate dependency only.  
**IF SERVER STATE CORRECT → GO TO:** next consumer from `../DIAGNOSTIC-ROUTER.md`; do not re-read upstream persistence.  
**SEARCH TERMS:** `required_slots validate_request photo-motor`.  
**DO NOT LOAD UNLESS:** browse/offers.  
**PLUGIN BOUNDARY:** see `../PLUGIN-BOUNDARIES.md` when flow reaches theme, `wp_mail`, WordPress cron/session, or external services.  
**CHANGE RISKS:** preserve event order, persisted status/meta/table semantics, authorization and reverse callers documented in existing map.  
**REGRESSION CHECKS:** use `../REGRESSION-MAP.md` for shared hotspots; re-run the exact entry state plus reload/downstream consumer.  
**VERIFICATION STATUS:** VERIFIED against the uploaded plugin source snapshot for plugin-owned routing; external runtime remains UNVERIFIED.
