# HOTSPOTS — PLUGIN V2

MAP-TYPE: ON-DEMAND

Only source-connected, multi-feature/high-regression targets are listed. File size alone is not a hotspot criterion.

## `includes/class-kmae-counter-offers.php :: KMAE_Counter_Offers::accept_offer()`
- **USED BY:** NEGOTIATION-CHAT, CONTACT-UNLOCK, DEAL, NOTIFICATIONS
- **WHY SENSITIVE:** changes accepted state, unlocks contact and emits the cross-domain acceptance event.
- **VERIFY AFTER CHANGE:** seller/buyer acceptance, contact visibility, deal lock, accepted email, competing offers.
- **STATUS:** VERIFIED.

## `includes/class-kmae-deal.php :: KMAE_Deal::confirm_success()`
- **USED BY:** DEAL, LISTINGS, OFFERS, TRUST-RATINGS, NOTIFICATIONS
- **WHY SENSITIVE:** final-sale transition crosses listing, offers, buyer state and domain event.
- **VERIFY AFTER CHANGE:** listing archive, other offers, buyer state, rating request, close notifications.
- **STATUS:** VERIFIED.

## `includes/class-kmae-deal.php :: KMAE_Deal::confirm_failure()`
- **USED BY:** DEAL, LISTINGS, OFFERS, NOTIFICATIONS
- **WHY SENSITIVE:** recovery path must reverse viewing lock without corrupting offer/listing state.
- **VERIFY AFTER CHANGE:** listing reopen, accepted offer state, resumed offers, failure email.
- **STATUS:** VERIFIED.

## `public/class-kmae-public.php :: KMAE_Public::handle_forms()`
- **USED BY:** AUTH, LISTINGS, OFFERS, NEGOTIATION, DEAL
- **WHY SENSITIVE:** central POST dispatcher and auth/verification gate.
- **VERIFY AFTER CHANGE:** every form branch touched, nonce/redirect/error behavior.
- **STATUS:** VERIFIED.

## `public/class-kmae-public.php :: KMAE_Public::process_create_listing()`
- **USED BY:** LISTINGS, VEHICLE, COMPANY, MODERATION, PHOTO-MOTOR, DRAFTS
- **WHY SENSITIVE:** listing creation orchestrator across validators and lifecycle.
- **VERIFY AFTER CHANGE:** private/company, vehicle fields, moderation, photo status, draft discard, publish event.
- **STATUS:** VERIFIED.

## `includes/class-kmae-listings.php :: KMAE_Listings::save_meta_from_post()`
- **USED BY:** LISTINGS, VEHICLE, COMPANY, SELLER
- **WHY SENSITIVE:** shared listing metadata write path.
- **VERIFY AFTER CHANGE:** create/edit, company location, vehicle/seller fields.
- **STATUS:** VERIFIED.

## `includes/class-kmae-notifications.php :: KMAE_Notifications::send_offer_email()`
- **USED BY:** all offer/deal notification paths
- **WHY SENSITIVE:** shared preference + mail handoff for offer-related email.
- **VERIFY AFTER CHANGE:** new/counter/revision/accepted/rejected/withdrawn mail preferences and HTML output.
- **STATUS:** VERIFIED.

## `includes/class-kmae-brand.php :: KMAE_Brand::send_mail()/wrap_email()`
- **USED BY:** all branded email
- **WHY SENSITIVE:** common HTML mail transport/wrapper.
- **VERIFY AFTER CHANGE:** all notification/contact/auth branded mail users.
- **STATUS:** VERIFIED.

## `includes/class-kmae-database.php :: offer/counter/contact table accessors`
- **USED BY:** OFFERS, NEGOTIATION, CONTACT, ADMIN, DASHBOARD
- **WHY SENSITIVE:** shared custom-table persistence used by many domains.
- **VERIFY AFTER CHANGE:** CRUD callers, status filters, seen state, admin/dashboard reads.
- **STATUS:** VERIFIED.

## `includes/class-kmae-auth.php :: verification + wants_offer_emails()`
- **USED BY:** AUTH, LISTINGS/OFFERS gates, NOTIFICATIONS
- **WHY SENSITIVE:** shared identity/verification/preferences.
- **VERIFY AFTER CHANGE:** login/register/reset, protected actions, mail preference.
- **STATUS:** VERIFIED.

## `includes/class-kmae-photo-motor.php :: validate_request()/slot readiness/client_config()`
- **USED BY:** PHOTO-MOTOR, LISTINGS, WIZARD
- **WHY SENSITIVE:** authoritative photo constraints bridge JS and publication.
- **VERIFY AFTER CHANGE:** client config, upload validation, required slots, awaiting_photos activation.
- **STATUS:** VERIFIED.

## `includes/class-kmae-browse.php :: personalize_listings()`
- **USED BY:** BROWSE, OFFERS
- **WHY SENSITIVE:** uses offer/pass history to mutate search ordering/visibility.
- **VERIFY AFTER CHANGE:** fresh results, offered exclusion, passed reinsertion.
- **STATUS:** VERIFIED.

## `includes/class-kmae-plugin.php :: KMAE_Plugin::run()`
- **USED BY:** BOOT + every initialized service
- **WHY SENSITIVE:** global registration/init order.
- **VERIFY AFTER CHANGE:** feature hooks, admin/public instantiation, missing services.
- **STATUS:** VERIFIED.

## `includes/class-kmae-pages.php :: page URL/shortcode/routing methods`
- **USED BY:** PAGES, NAV, OFFERS, BROWSE
- **WHY SENSITIVE:** central managed-page routing consumed across UI.
- **VERIFY AFTER CHANGE:** URLs, legacy redirects, shortcode mapping, seen-on-visit.
- **STATUS:** VERIFIED.

